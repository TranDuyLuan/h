package asYouTypeDemo;
import java.awt.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.*;
import com.keyoti.rapidSpell.desktop.*;

/** The only lines in this demo directly relevant to the as you type checker are;
 *  RapidSpellAsYouType rapidAYT = new RapidSpellAsYouType();
 *  rapidAYT.setTextComponent(textPane);
 */

public class Main extends JFrame implements ActionListener, CaretListener{
  JScrollPane jScrollPane1;
  JTextPane textPane = new JTextPane();
  StyledDocument doc;
  Style style;
  JPanel jPanel1 = new JPanel();
  JComboBox fontSizeComboBox;
  String[] fontSizes = new String[]{"Font Size", "12", "16","24"};
  String[] fontNames = new String[]{"Font Name", "Sans-Serif", "Courier", "Times New Roman"};
  BorderLayout borderLayout1 = new BorderLayout();
  JComboBox fontNameComboBox;
  JPanel jPanel2 = new JPanel();
  RapidSpellAsYouType rapidAYT = new RapidSpellAsYouType();
  FlowLayout flowLayout1 = new FlowLayout();


  public Main() {
    super("As You Type Demo");


    try {
      jbInit();
      this.setSize(new Dimension(600, 400));
      this.setLocation(300, 300);
      show();
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    //get styled document so we can apply styles
    doc = textPane.getStyledDocument();
    // Makes text 24pts
    style = textPane.addStyle("24", null);
    StyleConstants.setFontSize(style, 24);

    // Makes text 12pts
    style = textPane.addStyle("12", null);
    StyleConstants.setFontSize(style, 12);

    // Makes text 16pts
    style = textPane.addStyle("16", null);
    StyleConstants.setFontSize(style, 16);

    style = textPane.addStyle("Sans-Serif", null);
    StyleConstants.setFontFamily(style, "Sans-Serif");

    style = textPane.addStyle("Courier", null);
    StyleConstants.setFontFamily(style, "Courier");

    style = textPane.addStyle("Times New Roman", null);
    StyleConstants.setFontFamily(style, "Times New Roman");

    //set default style
    doc.setCharacterAttributes(0,
                               90,
                               textPane.getStyle("Sans-Serif"),
                               false);
    doc.setCharacterAttributes(0,
                               90,
                               textPane.getStyle("12"),
                               false);

    doc.setCharacterAttributes(90,
                               textPane.getText().length(),
                               textPane.getStyle("Times New Roman"),
                               false);
    doc.setCharacterAttributes(90,
                               textPane.getText().length(),
                               textPane.getStyle("24"),
                               false);




    // this is required due to a known issue with JTextPane on Windows - see release notes for more.
    textPane.getDocument().putProperty( DefaultEditorKit.EndOfLineStringProperty, "\n" );

	textPane.setSelectedTextColor(Color.black);
	textPane.setSelectionColor(new Color(200,200,255));

    // config as you type checker
    rapidAYT.setTextComponent(textPane);

  }

  public void actionPerformed(ActionEvent e){
    Style style = textPane.getStyle((String)((JComboBox)e.getSource()).getSelectedItem());
    if(e.getActionCommand().equals("userSet") && style!=null)
      doc.setCharacterAttributes(textPane.getSelectionStart(),
                                 textPane.getSelectionEnd(),
                                 style,
                                 false);
  }

  public void caretUpdate(CaretEvent e){
    syncStyleMenus();
  }

  //display char attributes in font style menus
  void syncStyleMenus(){
    AttributeSet attributes = textPane.getCharacterAttributes();
    if(attributes!=null){
      //System.out.println(attributes.getAttributeCount());
      for (Enumeration names = attributes.getAttributeNames(); names.hasMoreElements(); ) {
        Object element =  names.nextElement();
        if(element.toString().equals("family")){
         fontNameComboBox.setActionCommand("internalSet");
         fontNameComboBox.setSelectedItem(attributes.getAttribute(element));
         fontNameComboBox.setActionCommand("userSet");
       }

        if(element.toString().equals("size")){
          fontSizeComboBox.setActionCommand("internalSet");
          fontSizeComboBox.setSelectedItem(attributes.getAttribute(element).toString());
          fontSizeComboBox.setActionCommand("userSet");
        }
      }
    }
  }

  public static void main(String[] a){
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception e) {
      System.out.println("Couldn't configure look and feel: " + e.toString());
    }

    new Main();
  }
  private void jbInit() throws Exception {
    jScrollPane1 = new JScrollPane();
    fontSizeComboBox = new JComboBox(fontSizes);
    fontNameComboBox = new JComboBox(fontNames);
    textPane.setText("This is a JTextPane, RapidSpellAsYouType works with JTextComponent and it's derivitives.\n\nThis texxt is in a different font.");
    textPane.addCaretListener(this);
    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    fontSizeComboBox.setAlignmentX((float) 0.0);
    fontSizeComboBox.setAlignmentY((float) 0.0);
    fontSizeComboBox.setPreferredSize(new Dimension(100, 19));
    fontSizeComboBox.addActionListener(this);
    fontSizeComboBox.setActionCommand("userSet");
    jPanel1.setAlignmentX((float) 0.0);
    jPanel1.setAlignmentY((float) 0.0);
    jPanel1.setBorder(null);
    jPanel1.setMinimumSize(new Dimension(192, 29));
    jPanel1.setPreferredSize(new Dimension(215, 29));
    jPanel1.setLayout(borderLayout1);
    fontNameComboBox.setPreferredSize(new Dimension(100, 19));
    fontNameComboBox.addActionListener(this);
    fontNameComboBox.setActionCommand("userSet");
    jPanel2.setAlignmentY((float) 0.0);
    jPanel2.setBorder(null);
    jPanel2.setMinimumSize(new Dimension(192, 20));
    jPanel2.setOpaque(true);
    jPanel2.setPreferredSize(new Dimension(215, 20));
    jPanel2.setLayout(flowLayout1);
    this.getContentPane().add(jScrollPane1,  BorderLayout.CENTER);
    this.getContentPane().add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jPanel2,  BorderLayout.WEST);
    jPanel2.add(fontSizeComboBox, null);
    jPanel2.add(fontNameComboBox, null);
    jScrollPane1.getViewport().add(textPane, null);
  }
}
