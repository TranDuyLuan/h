To use these 'source-only' projects run the 'build.bat' (in Windows or 'build.bash' in *nix) script to compile the source .java files into the classes directory.  

Then run 'run.bat' (or 'run.bash' in *nix) to run them.  If you modify anything under the 'src' directory, just rebuild before running again.


Note 'javac' and 'java' must be on your PATH for these scripts to work, this should be true for properly installed JDKs.

