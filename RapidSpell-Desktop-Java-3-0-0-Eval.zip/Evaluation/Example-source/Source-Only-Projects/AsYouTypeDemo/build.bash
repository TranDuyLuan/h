#Compile to 'classes' directory, using 'RapidSpell.Jar' in classpath where source files are located in 'src'
javac -d classes -classpath ../../../RapidSpell.jar -sourcepath src src/Main.java