import com.keyoti.rapidSpell.desktop.RapidSpellGUI;

import javax.swing.*;
import java.awt.*;

public class CustomGUI extends RapidSpellGUI
{


	public CustomGUI()
	{
		super();
	}
	
	/** VERY SIMPLE, BUT UGLY LOOKING EXAMPLE - uncomment to use it.
	public void buildGUI()
	{
		Box myBox = Box.createVerticalBox();

		//define the protected fields as I want
		ignoreButton.setText("Ignore");
		ignoreAllButton.setText("Ignore All");
		changeButton.setText("Change");
		changeAllButton.setText("Change All");
		cancelButton.setText("Cancel");

		//add all the protected fields I want to use
		myBox.add(notInDictionaryLabel);
		myBox.add(queryWordPane);
		myBox.add(ignoreButton);
		myBox.add(ignoreAllButton);
		myBox.add(new JScrollPane(suggestionsList, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED ));
		myBox.add(changeButton);
		myBox.add(changeAllButton);
		myBox.add(cancelButton);
		
		getContentPane().add(myBox);
	}*/


	/** VERY COMPLICATED BUT ATTRACTIVE GUI EXAMPLE */
	public void buildGUI()
	{
		// Code produced by JBuilder - essential aspects are that it uses the protected fields in RapidSpellGUI
		// for buttons and text fields 



		JPanel notInDictionaryTextHolder = new JPanel ();
		JScrollPane notInDictionaryScrollPane;


		JPanel suggestionsButtonHolder = new JPanel ();
		JScrollPane suggestionsScrollPane;


		JPanel suggestionsTextHolder = new JPanel ();


		// Holds not in dictionary query pane /
		JPanel notInDicPanel = new JPanel();

		// Holds suggestions list
		JPanel suggPanel = new JPanel();

		// Layout boxes.
		Box verticalBoxHolder, box2, box3, box5, box1, box7, box4;



		JPanel notInDictionaryButtonHolder = new JPanel ();
		notInDictionaryButtonHolder.setLayout(new GridLayout (0, 3));


		verticalBoxHolder = Box.createVerticalBox();



		box4 = Box.createVerticalBox();
		box2 = Box.createVerticalBox();
		box3 = Box.createVerticalBox();
		box1 = Box.createVerticalBox();
		box5 = Box.createHorizontalBox();
		box7 = Box.createHorizontalBox();


		


		ignoreButton.setText("Ignore");
		ignoreButton.setEnabled(false);
		ignoreButton.setMargin(new Insets(0, 10, 0, 10));
		//ignoreButton.setSelected(true);
		ignoreButton.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );

		ignoreAllButton.setMargin(new Insets(0, 10, 0, 10));
		ignoreAllButton.setText("Ignore All");
		ignoreAllButton.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );
		ignoreAllButton.setEnabled(false);



		queryWordPane.setEditable(true);
		queryWordPane.setColumns(30);
		queryWordPane.setRows(4);


		addButton.setMargin(new Insets(0, 10, 0, 10));
		addButton.setText("Add");
		addButton.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );
		addButton.setEnabled(false);

		notInDictionaryLabel.setAlignmentY((float) 0.0);
		notInDictionaryLabel.setHorizontalAlignment(SwingConstants.LEFT);
		notInDictionaryLabel.setHorizontalTextPosition(SwingConstants.LEFT);
		notInDictionaryLabel.setText("Not in Dictionary:");
		notInDictionaryLabel.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );


		notInDictionaryScrollPane = new JScrollPane(queryWordPane, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
		notInDictionaryScrollPane.setPreferredSize(new Dimension(245, 80));
		notInDictionaryScrollPane.setMinimumSize(new Dimension(245, 80));

		changeAllButton.setMargin(new Insets(0, 10, 0, 10));
		changeAllButton.setText("Change All");
		changeAllButton.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );
		changeAllButton.setEnabled(false);

		cancelButton.setText("Cancel");
		cancelButton.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );


		suggestionsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		suggestionsList.setEnabled(findSuggestions);

		suggestionsButtonHolder.setLayout(new GridLayout (0, 3));

		changeButton.setMargin(new Insets(0, 10, 0, 10));
		changeButton.setText("Change");
		changeButton.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );
		changeButton.setEnabled(false);
	

		suggestionsLabel.setAlignmentY((float) 0.0);
		suggestionsLabel.setMaximumSize(new Dimension(200, 17));
		suggestionsLabel.setPreferredSize(new Dimension(200, 17));
		suggestionsLabel.setHorizontalAlignment(SwingConstants.LEFT);
		suggestionsLabel.setHorizontalTextPosition(SwingConstants.LEFT);
		suggestionsLabel.setFont( new Font(suggestionsLabel.getFont().getFamily(), suggestionsLabel.getFont().getStyle(), 11) );
		suggestionsLabel.setEnabled(findSuggestions);

		suggPanel.add(box3, null);

		box1.add(suggestionsTextHolder, null);



		//when the query pane gets focus, lose any selection in the suggestions list

		suggestionsScrollPane = new JScrollPane(suggestionsList, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED );
		suggestionsTextHolder.add(suggestionsScrollPane, null);
		suggestionsScrollPane.setPreferredSize(new Dimension(245, 80));
		suggestionsScrollPane.setMinimumSize(new Dimension(245, 80));


		suggestionsButtonHolder.add(changeButton, null);
		suggestionsButtonHolder.add(changeAllButton, null);
		suggestionsButtonHolder.add(cancelButton, null);

		box1.add(suggestionsButtonHolder, null);
		box3.add(box7, null);
		box7.add(suggestionsLabel, null);

		box7.add(Box.createHorizontalGlue(), null);

		box3.add(box1, null);

		//create  a box for suggestions on/off
		Box toggleSuggBox = Box.createHorizontalBox();
		suggestionFinderCheckBox.setFont( new Font(suggestionFinderCheckBox.getFont().getFamily(), suggestionFinderCheckBox.getFont().getStyle(), 11) );
		toggleSuggBox.add(suggestionFinderCheckBox,null);
		toggleSuggBox.add(Box.createHorizontalGlue());
		box3.add(toggleSuggBox, null);
		suggestionFinderCheckBox.setEnabled(false);

		verticalBoxHolder.add(notInDicPanel, null);
		verticalBoxHolder.add(suggPanel, null);

		box4.add(box5, null);
		box4.add(box2, null);

		box5.add(notInDictionaryLabel, null);
		box5.add(Box.createHorizontalGlue(), null);

		notInDictionaryTextHolder.add(notInDictionaryScrollPane, null);
		box2.add(notInDictionaryTextHolder, null);
		box2.add(notInDictionaryButtonHolder, null);


		notInDictionaryButtonHolder.add(ignoreButton, null);
		notInDictionaryButtonHolder.add(ignoreAllButton, null);

		//add the "add" button if the dictionary is valid
		if (theSpellChecker.getUserDictionary() != null && theSpellChecker.getUserDictionary().isValid()) notInDictionaryButtonHolder.add(addButton, null);
		else {notInDictionaryButtonHolder.add(addButton, null); addButton.setEnabled(false);}



		notInDicPanel.add(box4, null);

		setResizable(false);


		// THIS METHOD MUST ADD COMPONENTS TO THE JFRAME'S CONTENT PANE //
		getContentPane().add(verticalBoxHolder, BorderLayout.CENTER);
	}
	

}