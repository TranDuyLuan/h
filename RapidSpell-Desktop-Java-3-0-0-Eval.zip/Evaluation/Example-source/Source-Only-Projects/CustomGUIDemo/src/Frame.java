import com.keyoti.rapidSpell.desktop.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Frame extends JFrame {
  JPanel contentPane;
  JMenuBar jMenuBar1 = new JMenuBar();
  BorderLayout borderLayout1 = new BorderLayout();
  JTextArea jTextArea1 = new JTextArea();
  JMenu jMenu1 = new JMenu();
  JMenuItem jMenuItem1 = new JMenuItem();

  CustomGUI rsg;

  //Construct the frame
  public Frame() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

    //setup RapidSpell Desktop
    rsg = new CustomGUI();
    rsg.setLocation(10, 10);
  }
  //Component initialization
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(600, 400));
    this.setTitle("Simple Text Component Demo");
    jTextArea1.setText("Welcome to the simple text component demo.  \nThis demonstrates how " +
    "easy it is to use RapidSpell Desktop with a custom interface.");
    jTextArea1.setLineWrap(true);
    jTextArea1.setWrapStyleWord(true);
    jMenu1.setText("Tools");
    jMenuItem1.setText("Check Spelling");
    jMenuItem1.addActionListener(new Frame_jMenuItem1_actionAdapter(this));
    contentPane.add(jTextArea1, BorderLayout.CENTER);
    jMenuBar1.add(jMenu1);
    jMenu1.add(jMenuItem1);
    this.setJMenuBar(jMenuBar1);
  }
  //File | Exit action performed
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }
  //Help | About action performed
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }

  //Check spelling menu click
  void jMenuItem1_actionPerformed(ActionEvent e) {
    //run RapidSpell
    rsg.check(jTextArea1);
  }
}

class Frame_jMenuItem1_actionAdapter implements java.awt.event.ActionListener {
  Frame adaptee;

  Frame_jMenuItem1_actionAdapter(Frame adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jMenuItem1_actionPerformed(e);
  }
}