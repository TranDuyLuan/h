

import com.keyoti.rapidSpell.desktop.*;
import com.keyoti.rapidSpell.*;
import com.keyoti.rapidSpell.event.*;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.event.*;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.util.ArrayList;

/** Demonstrates how to use RapidSpell to check more than one JTextComponent */
public class MultipleExample extends JFrame implements ActionListener, SpellCheckListener{
	JMenuBar menuBar;
	JMenu menu;
	JMenuItem checkSpellingMenuItem;
	JTextArea box1 = new JTextArea("Thank you for trying RapidSpell Desktop Java, this demo shows how to use RapidSpellGUI to check multiple text boxes, the code for this is located in MultipleExample.java. \n", 20, 60)
				,box2 = new JTextArea("Herre are somee misspelloings and tipogrphic erorrs.", 20, 60);

	RapidSpellGUI rapidGUI;






	public MultipleExample() {
		super("Spell");

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			System.out.println("Couldn't configure look and feel: "+e.toString());
		}

                addWindowListener(new WindowAdapter() {
                    public void windowClosing(WindowEvent e) {
                        System.exit(0);
                    }
                });

		getContentPane().setLayout(new BorderLayout());


		//build menu bar
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		//Build the first menu.
		menu = new JMenu("Spelling");
		menu.setMnemonic(KeyEvent.VK_S);
		menu.getAccessibleContext().setAccessibleDescription("The only menu in this program that has menu items");
		menuBar.add(menu);

		//a group of JMenuItems
		checkSpellingMenuItem = new JMenuItem("Check Spelling...",
								 KeyEvent.VK_C);
		checkSpellingMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F7, ActionEvent.ALT_MASK));

		menu.add(checkSpellingMenuItem);

		checkSpellingMenuItem.addActionListener(this);


//		setIconImage( (new ImageIcon(Example.class.getResource("/icon.gif")).getImage() ) );
		
		box1.setLineWrap(true);
		box1.setWrapStyleWord(true);

		box2.setLineWrap(true);
		box2.setWrapStyleWord(true);


		JScrollPane scrollPane = new JScrollPane(box1);
		scrollPane.setPreferredSize(new Dimension(600, 205));
		getContentPane().add(scrollPane, BorderLayout.NORTH);

		JScrollPane scrollPane2 = new JScrollPane(box2);
		scrollPane2.setPreferredSize(new Dimension(600, 205));
		getContentPane().add(scrollPane2, BorderLayout.SOUTH);


		//Create dialog checker object
		rapidGUI = new RapidSpellGUI();
		rapidGUI.setLocation(300,300);
//		rapidGUI.setIconImage(  (new ImageIcon(Example.class.getResource("/icon.gif")).getImage() ) );

		pack();
                setVisible(true);

		/*	Disable finished message box and listen to finished events--*/
		rapidGUI.setShowFinishedMessageBox(false);
		rapidGUI.addSpellCheckListener(this);
		/*---------------------------------------------------------------*/


	}


	/*-------------------------------------------------*/
	/** Listen to Spell check events */
	public void spellCheckStarted(SpellCheckEvent e){
	}
	public void spellCheckIgnore(SpellCheckEvent e,BadWord b){
	}
	public void spellCheckIgnoreAll(SpellCheckEvent e,BadWord b){
	}        
	public void spellCheckChange(SpellCheckEvent e,BadWord b){
	}    
	public void spellCheckChangeAll(SpellCheckEvent e,BadWord b){
	}  
	public void spellCheckAdd(SpellCheckEvent e,BadWord b){
	}          
        
	public void spellCheckFinished(SpellCheckEvent e){	
	}
	/*-------------------------------------------------*/




	/** Listen to GUI events and perform actions depending on the button sending the event. */
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == checkSpellingMenuItem){
			/*  Start spell check when menu clicked -----------*/

                        ArrayList components = new ArrayList();
                        components.add(box1);
                        components.add(box2);

                        rapidGUI.check(components);
			/*-------------------------------------------------*/
		}
	}





	


	public static void main(String[] args) {
		MultipleExample t = new MultipleExample();
	}
	



}
