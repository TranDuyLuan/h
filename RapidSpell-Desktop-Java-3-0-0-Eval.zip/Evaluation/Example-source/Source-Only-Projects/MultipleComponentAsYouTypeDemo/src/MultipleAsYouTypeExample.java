import com.keyoti.rapidSpell.desktop.*;
import com.keyoti.rapidSpell.event.*;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.event.*;
import java.awt.Dimension;
import java.awt.BorderLayout;
import java.io.File;

/** Demonstrates how to use RapidSpellAsYouType to check more than one JTextComponent */
public class MultipleAsYouTypeExample extends JFrame{

	JTextArea box1 = new JTextArea("Thank you for trying RapidSpell Desktop Java, this demo shows how to use RapidSpellAsYouType to check multiple text boxes, the code for this is located in MultipleAsYouTypeExample.java. \n", 20, 60)
				,box2 = new JTextArea("Herre are somee misspelloings and tipogrphic erorrs.", 20, 60);


	RapidSpellAsYouType rapidAYT;


	public MultipleAsYouTypeExample() {
		super("Spell");

		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			System.out.println("Couldn't configure look and feel: "+e.toString());
		}

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

		getContentPane().setLayout(new BorderLayout());





		
		
		box1.setLineWrap(true);
		box1.setWrapStyleWord(true);

		box2.setLineWrap(true);
		box2.setWrapStyleWord(true);


		JScrollPane scrollPane = new JScrollPane(box1);
		scrollPane.setPreferredSize(new Dimension(600, 205));
		getContentPane().add(scrollPane, BorderLayout.NORTH);

		JScrollPane scrollPane2 = new JScrollPane(box2);
		scrollPane2.setPreferredSize(new Dimension(600, 205));
		getContentPane().add(scrollPane2, BorderLayout.SOUTH);

		//Create as you type checker object
		rapidAYT = new RapidSpellAsYouType();
		rapidAYT.setTextComponents( new JTextComponent[]{box1, box2} );


		pack();
        setVisible(true);


	}


	


	public static void main(String[] args) {
		MultipleAsYouTypeExample t = new MultipleAsYouTypeExample();
	}
	

}
