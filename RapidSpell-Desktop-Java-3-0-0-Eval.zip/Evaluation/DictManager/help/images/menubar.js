/*** 
This is the menu creation code - place it right after you body tag
Feel free to add this to a stand-alone js file and link it to your page.
**/

//Menu object creation
oCMenu=new makeCM("oCMenu") //Making the menu object. Argument: menuname

//Menu properties   
oCMenu.pxBetween=10
oCMenu.fromLeft=0
oCMenu.fromTop=57   
oCMenu.rows=1 
//var avail="0+((cmpage.x2-0)/2)";
var avail="( cmpage.x2 - (cmpage.x2*0.18) - 140 )";
//oCMenu.menuPlacement=new Array(avail+"-80", avail, avail+"+80", avail+"+160")
oCMenu.menuPlacement="right"

                                                             
oCMenu.onlineRoot="" 
oCMenu.resizeCheck=1 
oCMenu.wait=300 

oCMenu.zIndex=0

//Background bar properties
oCMenu.useBar=0
oCMenu.barWidth="100%"
oCMenu.barHeight="menu" 
oCMenu.barClass="clBar"
oCMenu.barX=500 
oCMenu.barY=00
oCMenu.barBorderX=0
oCMenu.barBorderY=0
oCMenu.barBorderClass=""

//Level properties - ALL properties have to be spesified in level 0
oCMenu.level[0]=new cm_makeLevel() //Add this for each new level
oCMenu.level[0].width=100
oCMenu.level[0].height=16 
oCMenu.level[0].regClass="clLevel0"
oCMenu.level[0].overClass="clLevel0over"
oCMenu.level[0].borderX=1
oCMenu.level[0].borderY=1
oCMenu.level[0].borderClass="clLevel0border"
oCMenu.level[0].offsetX=0
oCMenu.level[0].offsetY=0
oCMenu.level[0].rows=0
oCMenu.level[0].arrow=0
oCMenu.level[0].arrowWidth=0
oCMenu.level[0].arrowHeight=0
oCMenu.level[0].align="bottom"


//EXAMPLE SUB LEVEL[1] PROPERTIES - You have to specify the properties you want different from LEVEL[0] - If you want all items to look the same just remove this
oCMenu.level[1]=new cm_makeLevel() //Add this for each new level (adding one to the number)
oCMenu.level[1].width=oCMenu.level[0].width-2
oCMenu.level[1].height=18
oCMenu.level[1].regClass="clLevel1"
oCMenu.level[1].overClass="clLevel1over"
oCMenu.level[1].borderX=1
oCMenu.level[1].borderY=1
oCMenu.level[1].align="right" 
oCMenu.level[1].offsetX=-(oCMenu.level[0].width-2)/2+20
oCMenu.level[1].offsetY=0
oCMenu.level[1].borderClass="clLevel1border"


//EXAMPLE SUB LEVEL[2] PROPERTIES - You have to spesify the properties you want different from LEVEL[1] OR LEVEL[0] - If you want all items to look the same just remove this
oCMenu.level[2]=new cm_makeLevel() //Add this for each new level (adding one to the number)
oCMenu.level[2].width=150
oCMenu.level[2].height=20
oCMenu.level[2].offsetX=0
oCMenu.level[2].offsetY=0
oCMenu.level[2].regClass="clLevel2"
oCMenu.level[2].overClass="clLevel2over"
oCMenu.level[2].borderClass="clLevel2border"


/******************************************
Menu item creation:
myCoolMenu.makeMenu(name, parent_name, text, link, target, width, height, regImage, overImage, regClass, overClass , align, rows, nolink, onclick, onmouseover, onmouseout) 
*************************************/
oCMenu.makeMenu('top0','','Products','/products','')
  oCMenu.makeMenu('sub00','top0','CreditCardPack','/products/creditcardpack')
  oCMenu.makeMenu('sub01','top0','RapidSpell','/products/rapidspell')
  oCMenu.makeMenu('sub02','top0','LuhnCheck','/products/luhncheck')
  oCMenu.makeMenu('sub03','top0','Wishlist','/wishlist.html')

oCMenu.makeMenu('top1','','Support','/support')
	
oCMenu.makeMenu('top2','','Services','http://jimwright.keyoti.com/')
	oCMenu.makeMenu('sub20','top2','Consultancy','http://jimwright.keyoti.com/')
	oCMenu.makeMenu('sub21','top2','Contractual','http://jimwright.keyoti.com/')

oCMenu.makeMenu('top3','','Keyoti','/about.html')
	oCMenu.makeMenu('sub30','top3','Home','/index.html')
	oCMenu.makeMenu('sub31','top3','About','/about.html')
	oCMenu.makeMenu('sub32','top3','Contact','/contact.html')


oCMenu.construct()