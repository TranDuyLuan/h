/*--Keyoti js--*/
/*#<![CDATA[*/
/*#Version 1.7f (RapidSpell Web assembly version 5.0 onwards)
Copyright Keyoti Inc. 2005-2021
This code is not to be modified, copied or used without a license in any form.
*/

var rsS47=new Array("Microsoft Internet Explorer",
"MSIE ([0-9]{1,}[\.0-9]{0,})",
"object",
"function",
"rsTCInt",
"undefined",
"IgnoreXML",
"True",
"popUpCheckSpelling",
"('rsTCInt",
"')",
"g",
"&#34;",
"&",
"&amp;",
"Error: element ",
" does not exist, check TextComponentName.",
"",
"Sorry, a textbox with ID=",
" couldn't be found - please check the TextComponentID or TextComponentName property.",
"_IF",
"&lt;",
"&gt;",
"TEXTAREA",
"INPUT",
" EDITABLE",
"\r\n",
" ",
"contentEditable",
"true",
"designMode",
"on",
"IFRAME",
" --has contentWindow.document",
"*",
"Gecko",
"MSIE",
"Chrome",
"AppleWebKit",
"core",
"ShowFinishedMessage",
"script",
"Sorry, cannot find a script import named ",
".js, please do not rename any RapidSpell scripts.",
"RapidSpell-",
"BackCompat",
"/",
"<",
"blank.html",
"menu.css",
"rs_style.css",
"RapidSpellModalHelper.html",
"UserDictionaryFile",
"SuggestionsMethod",
"SeparateHyphenWords",
"IncludeUserDictionaryInSuggestions",
"IgnoreCapitalizedWords",
"GuiLanguage",
"LanguageParser",
"Modal",
"AllowAnyCase",
"IgnoreWordsWithDigits",
"ShowNoErrorsMessage",
"ShowXMLTags",
"AllowMixedCase",
"WarnDuplicates",
"DictFile",
"PopUpWindowName",
"CreatePopUpWindow",
"ConsiderationRange",
"LookIntoHyphenatedText",
"CheckCompoundWords",
"EnableUndo",
"LeaveWindowOpenForUndo",
"SSLFriendlyPage",
"IgnoreURLsAndEmailAddresses",
"IgnoreIncorrectSentenceCapitalization",
"IgnoreInEnglishLowerCaseI",
"SuggestSplitWords",
"CorrectionNotifyListener",
"MaximumNumberOfSuggestions",
"ShowAddItemAlways",
"AddNotifyListener",
"EnableOptions",
"FieldDisplayText",
"~/user-dictionary.txt",
"HASHING_SUGGESTIONS",
"false",
"ENGLISH",
"80",
"rsw_ondialogcorrection",
"8",
"rsw_ondialogadd",
"dialog_correction",
"dialog_add",
"FRENCH",
"SPANISH",
"GERMAN",
"ITALIAN",
"PORTUGUESE",
"DUTCH",
"POLISH",
"RUSSIAN",
"Ignore",
"Ignore All",
"Add",
"Edit...",
"All",
"Remove duplicate word",
"No suggestions",
"The spelling check is complete.",
"Ignorer",
"Ignorer Tout",
"Ajouter",
"Éditez...",
"Tout",
"Enlevez le mot double",
"Aucun",
"Fini.",
"Ignorar",
"Ignorar Todas",
"Agregar",
"Corrija...",
"Todas",
"Quite la palabra duplicada",
"Ningunas sugerencias",
"La verificación ortográfica ha finalizado.",
"Ignorieren",
"Alle ignorieren",
"Hinzufügen",
"Redigieren...",
"Alle",
"Doppelte Wörter entfernen",
"Keine vorschläge",
"Die Rechtschreibprüfung ist abgeschlossen.",
"Ignora",
"Ignora tutto",
"Aggiungi",
"Modifica...",
"Tutto",
"Rimuovi la parola duplicata",
"Nessun suggerimento",
"Controllo completato.",
"Ignore Tudo",
"Adicione",
"Edite...",
"Tudo",
"Remova a palavra duplicada",
"Nenhumas sugestões",
"A verificação de soletração está completa.",
"Negeren",
"Alles negeren",
"Toevoegen",
"Corrigeren...",
"Allen",
"Verwijder herhaald woord",
"Geen suggesties",
"De spellingscontrole is voltooid.",
"Ignoruj",
"Ignoruj wszystko",
"Dodaj",
"Edytuj...",
"Wszystko",
"Usuń podwójne wystąpienie słowa",
"Nie ma sugestii",
"Zakończono Sprawdzanie pisowni.",
"Пропустить",
"Пропустить все",
"Добавить",
"Редактировать...",
"все",
"Удалить дубликат слова",
"Нет вариантов",
"Проверка орфографии.",
"ignore",
"ignoreAll",
"add",
"edit",
"changeAll",
"removeDuplicate",
"noSuggestions",
"complete",
"default",
"nospell",
"visibility",
"display",
"hidden",
"none",
"visible",
"wcf",
"asmx",
"servlet",
"/api",
"POST",
"/RapidSpellService.svc/",
"/RapidSpellService.asmx/",
"/RapidSpellAPI/",
"a.rapidspellweb",
"a.rapidspellweb?t=",
"data=",
"Using web service .NET 2",
"application/x-www-form-urlencoded",
"text",
"{",
"}",
"\r\nURL (click to get more error info): <a href='",
"'>",
"</a>",
"Unknown server error.",
"timeout",
"Sorry the server has not responded, please try again.",
"error",
" error from server.",
"\r\n\r\nURL (click to get more error info): <a href='",
"#rsw_dialogLoader",
"Using WCF service .NET 4",
"Using API Controller",
"d",
"A 500 server error occurred.\r\n****\r\nIf you are referencing Keyoti.RapidSpellWeb.ASP.NETv2.DLL then you must call this Javascript on your page:\r\nrapidSpell.setServiceType('asmx');\r\n*****",
"Version:2.0",
"It appears that you are running .NET 2 on the server, therefore you must call this Javascript in your page:\r\n\r\nrapidSpell.setServiceType('asmx');\r\n\r\nDoing that will use the .NET 2 ASMX Web Service instead of .NET 4 WCF",
"URL (click to get more error info): <a href='",
"\r\n\r\n",
"application/json",
"jQuery is not present, please add the jQuery core script to this page if you wish to have rapidSpell.useAJAXWebService set true.",
"Please ensure that you include the RapidSpell-Core.js file in your page, before the RapidSpell-Launcher.js file is imported.",
"popup.aspx",
"center",
"link",
"/code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css",
"/code.jquery.com/ui/1.11.4/jquery-ui.min.js",
"/code.jquery.com/jquery-1.11.3.min.js",
"string",
"rs",
"dialog",
"textarea",
"input",
"rsw_oldOnLoad",
"&#",
";",
"<input type=hidden name=",
" value='",
"head",
"rel",
"stylesheet",
"loaded",
"typeof(",
"var curState=",
"_SpellChecker.state",
"var cs=",
"overlay",
"_SpellChecker.OnSpellButtonClicked()",
"dialog_startedcheckingtextbox",
"rsTCInt['",
"']",
"dialogHeight: ",
"px; dialogWidth: ",
"px; ",
"dialogLeft:",
"; ",
"dialogTop:",
"edge: Sunken; center: Yes; help: No; resizable: No; status: No;",
"/blank.html",
"docdomain",
"?",
"docdomain=",
"rspellwin",
"resizable=yes,scrollbars=auto,dependent=yes,toolbar=no,left=",
",top=",
",status=no,location=no,menubar=no,width=",
",height=",
"dialog_finishedcheckingtextbox",
"dialog_finishedcheckingall",
"#rsw_dialog",
"close",
"findEditableElements failed: ",
"loading.gif",
"a.rapidspellweb?t=r&n=loading.gif",
"body",
"position",
"absolute",
"top",
"px",
"left",
"<style type='text/css'>\
 #rsw_documentTextPanel\
 {\
 border: 1px solid #aaa;\
 border-radius: 3px;\
 }\
 #rsw_word, #rsw_suggestions\
 {\
 border: 1px solid #aaa;\
 border-top-color: #a0a0a0;\
 }\
 #rsw_optionsDialog\
 {\
 \
 display: none;\
 position: absolute;\
 margin-left: auto;\
 margin-right: auto;\
 margin-top: auto;\
 margin-bottom: auto;\
 left: 0;\
 right: 0;\
 top: 0;\
 bottom: 0;\
 width: 295px;\
 height: 230px;\
 z-index: 99999;\
 background-color: white;\
 border: 1px solid #444;\
 border-radius: 5px;\
 padding: 8px;\
 }\
 #rsw_optionsDialog_Backing\
 {\
 display: none;\
 position: absolute;\
 margin-left: auto;\
 margin-right: auto;\
 margin-top: auto;\
 margin-bottom: auto;\
 left: 0;\
 right: 0;\
 top: 0;\
 bottom: 0;\
 width: 100%;\
 height: 100%;\
 background-color: rgba(100,100,100,.60);\
 z-index: 100;\
 }\
 #rsw_optionsDialog > label\
 {\
 display: block;\
 padding-bottom: 12px;\
\
 }\
 #rsw_optionsDialog > input\
 {\
 margin-right: 9px;\
 margin-top:12px;\
 }\
 #rsw_optionsHeader\
 {\
 font-size: 1.2em;\
 border-bottom: 1px solid #aaa;\
 }\
\
 #rsw_documentTextPanel\
 {\
 border: 1px solid #aaa;\
 border-radius: 3px;\
 \
 text-align: justify;\
 padding:4px;\
 overflow-y:scroll;\
 margin-bottom:4px;\
 }\
\
 \
 .badWordHighlight{\
 background-position: bottom;background-repeat: repeat-x;background-color: #ededff;\
\
 }\
 #rsw_documentTextPanel{\
 \
 height: 150px;\
 }\
\
 #rsw_changePanel{\
 \
 width: 200px;\
 float:left;\
 }\
\
 #rsw_buttonPanel{\
 width:120px;\
 float:right;\
 \
 }\
\
 #rsw_buttonPanel div, #rsw_buttonPanel input{\
 margin: 0 auto;\
 width:100px; \
 font-size:9pt; \
 }\
\
 #rsw_optionsButton\
 {\
 font-size:9pt;\
 }\
 #rsw_dialog input, #rsw_dialog select {\
 margin:4px;\
 }\
\
 #rsw_dialog\
 {\
 font-family:'Segoe UI', Arial, sans-serif;\
 font-size:10pt;\
 padding:10px;\
 }\
\
 #rsw_word\
 {\
 width:197px;\
 }\
\
 #rsw_suggestions\
 {\
 width:200px;\
 }\
\
 #rsw_fdtl\
 {\
 line-height:24px;\
 }\
 </style>",
"Options...",
"Spelling",
"Change To:",
"Suggestions:",
"No Suggestions.",
"</option> \
 </select> \
 ",
"Change",
"Change All",
"Undo",
"Finish",
"Basic Settings",
"Ignore words in UPPERCASE",
"Ignore words with numbers",
"Ignore internet addresses and emails",
"OK",
"Cancel",
"No textboxes were spell checked - this could be because they were all empty, or no textboxes were identified (are they inside of <form> tags?",
">",
"dialog_willOpenDialog",
"isOpen",
"underline.png",
"a.rapidspellweb?t=r&n=underline.png",
"<style>",
"type",
"text/css",
".badWordHighlight {background-image:url(",
");}",
"#rsw_suggestions",
"option",
"overflow",
"zIndex",
"\n",
"cnN3X29uZGlhbG9nY29ycmVjdGlvbg==",
"rsw_word",
"cnN3X29uZGlhbG9nYWRk",
"Adding...",
"rs0",
"rsw_finish(",
")",
"unknown",
"IgnoreCase",
"fdtl",
" \<style>body{font-family:Segoe UI, Sans-Serif, Arial, Helvetica; font-size:10pt; background-color:#ffffff; color:#000000; border: NotSet #000000 }.badWordHighlight{background-image: url(underline.png);background-position: bottom;background-repeat: repeat-x;background-color: #ededff}</style> ",
"popup",
"NULL",
"CheckMulti",
"<style></style>",
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
"rsw_optionsDialog_Backing",
"block",
"rsw_optionsDialog",
"fMessage=addWord&UserDictionaryFile=",
"&word=",
"&GuiLanguage=",
"<\\s*script([^<])*<([ ])*/([ ])*script([ ])*",
"i",
"<\\s*script([^<])*/([ ])*>",
"<\\s*script([^<])*>",
"<\\s*embed([^<])*>",
"(<([^>])*)on(([^ |^=)*([ |=])*=([ |=])*([^ |^>])*(([^>])*>))",
"$1$3",
"(<([^>])*)([ |=])*=([ |=])*([^ |^>])*javascript:([^ |^>])*(([^>])*>)",
"$1$7",
"<PUBLIC([ ])*:([^<])*<([ ])*/PUBLIC([ ])*",
"<PUBLIC([ ])*:([^<])*/([ ])*>",
"<PUBLIC([ ])*:([^<])*>",
"use strict",
"=",
"expires=",
"path=",
"domain=",
"secure;",
"httpOnly;",
"rsw_CookieJS deprecation warning:",
"rsw_CookieJS.del is deprecated and rsw_CookieJS.deleteX should be used instead.");																																				var rs_s2=window;var rs_s3=document;


if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}

var rsw_launcher_script_loaded = true;
var rsw_suppressWarnings=false;
function rsw_getInternetExplorerVersion()
{
 var rv = -1; if (navigator.appName == rsS47[0]) {
 var ua = navigator.userAgent;
 var re = new RegExp(rsS47[1]);
 if (re.exec(ua) != null)
 rv = parseFloat(RegExp.$1);
 }
 return rv;
}


function rsw_dialogOptionsClosed() {
 
 if (typeof rswm_PopUpWin == rsS47[2] && rswm_PopUpWin != null && typeof rswm_PopUpWin.rsw_finish == rsS47[3]) rswm_PopUpWin.rsw_finish();
 else if (typeof rsw_launcherWin == rsS47[2] && typeof rsw_launcherWin.rsw_finish == rsS47[3]) rsw_launcherWin.close(); if (typeof rswm_RunSpellCheck == rsS47[3]) rswm_RunSpellCheck(true);
 else if (rsw_currentLauncher != null) {

 setTimeout(function () { rsw_currentLauncher.OnSpellButtonClicked(); }, 500);
 }
}

var rsw_currentLauncher = null;
function SpellCheckLauncher(clientID){
 this.clientID = clientID;
 this.OnSpellButtonClicked = OnSpellButtonClicked;
 this.config;
 this.hasRunFieldID;
 this.getParameterValue = getParameterValue;
 this.setParameterValue = setParameterValue;
 this.tbInterface = null;
 
 function getParameterValue(param){
 for(var pp=0; pp<this.config.keys.length; pp++){
 if(this.config.keys[pp]==param)
 return this.config.values[pp];
 }
 }
 
 function setParameterValue(param, value){
 for(var pp=0; pp<this.config.keys.length; pp++){
 if(this.config.keys[pp]==param)
 this.config.values[pp] = value;
 }
 } 
 
 function OnSpellButtonClicked(){
 rsw_currentLauncher = this;
 this.tbInterface = eval(rsS47[4]+this.clientID);
 
 if(this.tbInterface!=null && typeof(this.tbInterface.findContainer)!=rsS47[5]){
 this.textBoxID = this.tbInterface.findContainer().id;
 if (!this.tbInterface.targetIsPlain){
 this.setParameterValue(rsS47[6], rsS47[7]);
 }
 } 
 
 
 eval(rsS47[8]+this.clientID+rsS47[9]+this.clientID+rsS47[10]);
 }
}


function RS_writeDoc(toWindow, isSafari){ 
 toWindow.document.open(); 
 toWindow.document.write(spellBoot); 
 toWindow.document.close(); 
 if(isSafari)
 toWindow.document.forms[0].submit();
} 
 
 
function escQuotes(text){ 
 var rx = new RegExp("\"", rsS47[11]); 
 return text.replace(rx,rsS47[12]);
}
function escEntities(text){
 var rx = new RegExp(rsS47[13], rsS47[11]); 
 return text.replace(rx,rsS47[14]);
}

function RSStandardInterface(tbElementName){
 this.tbName = tbElementName;
 this.getText = getText;
 this.setText = setText;
 function getText(){
 if(!document.getElementById(this.tbName) && !rsw_suppressWarnings) {
 alert(rsS47[15]+this.tbName+rsS47[16]);
 return rsS47[17];
 }
 else return rs_s3.getElementById(this.tbName).value;
 }
 function setText(text) {
 if(rs_s3.getElementById(this.tbName)) rs_s3.getElementById(this.tbName).value = text;
 if(typeof(rsw_tbs)!=rsS47[5]){
 for(var i=0; i<rsw_tbs.length; i++){
 if(rsw_tbs[i].shadowTB.id==this.tbName){
 if(rsw_tbs[i].updateIframe){rsw_tbs[i].updateIframe();rsw_tbs[i].focus();}
 }
 }
 }
 }
}




function RSAutomaticInterface(tbElementName){

 this.tbName = tbElementName;this.getText = getText;this.setText = setText;
 this.identifyTarget = identifyTarget;
 this.target=null;
 this.targetContainer = null;
 this.searchedForTarget = false;
 this.targetIsPlain = true;
 this.showNoFindError = showNoFindError;
 this.finder = null;
 
 this.findContainer = findContainer;
 
 function findContainer(){
 this.identifyTarget();
 return this.targetContainer;
 }
 
 function showNoFindError(){
 alert(rsS47[18]+this.tbName+rsS47[19]);
 }
 
 function identifyTarget(){
 if(!this.searchedForTarget){
 this.searchedForTarget = true;
 
 if(this.finder == null)
 this.finder = new RSW_EditableElementFinder();
 
 var plain = this.finder.findPlainTargetElement(this.tbName);
 var richs = this.finder.findRichTargetElements();
 
 if(plain==null && (richs==null || richs.length==0) && !rsw_suppressWarnings) showNoFindError();
 else{ 
 
 if(richs==null || richs.length==0){ this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 } else {
 
 
 if(plain==null && richs.length==1){ this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[0][0]);
 this.targetContainer = richs[0][1]; 
 
 } else {
 for (var rp = 0; rp < richs.length; rp ++){
 if(typeof(richs[rp][1].id)!=rsS47[5] && richs[rp][1].id.indexOf(this.tbName)>-1){
 if(plain!=null && richs[rp][1].id == plain.id+rsS47[20]){
 this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 break;
 } else {
 this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[rp][0]);
 this.targetContainer = richs[rp][1];
 break;
 }
 }
 }
 
 if(this.target==null){ this.target = plain;
 this.targetIsPlain = true;
 this.targetContainer = plain;
 }
 }
 }
 }
 } 
 }
 function getText(){ 
 this.identifyTarget();

 
 if( this.targetIsPlain )
 return this.target.value;
 else
 return this.target.innerHTML;
 }
 function setText(text){ 
 this.identifyTarget();
 if (this.targetIsPlain) {
 var ver = rsw_getInternetExplorerVersion();
 if (ver > 0 && ver < 9) text = text.replace(/</g, rsS47[21]).replace(/>/g, rsS47[22]);
 this.target.value = text;
 }
 else
 this.target.innerHTML = text;
 
 if(typeof(rsw_tbs)!=rsS47[5]){
 for(var i=0; i<rsw_tbs.length; i++){
 
 if(rsw_tbs[i].shadowTB.id==this.tbName){
 if(rsw_tbs[i].updateIframe){rsw_tbs[i].updateIframe();rsw_tbs[i].focus();}
 }
 }
 } 
 }
 }

function RSW_EditableElementFinder(){
 this.findPlainTargetElement = findPlainTargetElement;
 this.findRichTargetElements = findRichTargetElements;
 this.obtainElementWithInnerHTML = obtainElementWithInnerHTML;
 this.findEditableElements = findEditableElements;
 this.elementIsEditable = elementIsEditable;
 this.getEditableContentDocument = getEditableContentDocument;
 
 function findPlainTargetElement(elementID){
 var rsw_elected = rs_s3.getElementById(elementID);
 
 if(rsw_elected!=null && rsw_elected.tagName && 
 (rsw_elected.tagName.toUpperCase()==rsS47[23] || rsw_elected.tagName.toUpperCase()==rsS47[24])){
 return rsw_elected;
 } else
 return null;
 }
 
 function findRichTargetElements(debugTextBox){
 var editables = new Array();
 this.findEditableElements(document, editables, window,rsS47[17], debugTextBox);
 return editables;
 }
 
 function obtainElementWithInnerHTML(editable){
 if(typeof(editable.innerHTML)!=rsS47[5]) return editable;
 else
 if(typeof(editable.documentElement)!=rsS47[5])
 return editable.documentElement;
 
 return null;
 }
 
 
 function findEditableElements(node, editables, parent, debugInset, debugTextBox){
 var children = node.childNodes;
 var editableElement;
 
 if(debugTextBox)
 debugTextBox.value += debugInset + node.tagName;
 
 if( (editableElement=this.elementIsEditable(node))!=null || 
 (editableElement=this.getEditableContentDocument(node, debugTextBox))!=null
 ){
 if(debugTextBox)
 debugTextBox.value += rsS47[25]; 
 editables[editables.length] = editableElement;
 }
 
 if(debugTextBox)
 debugTextBox.value += rsS47[26];
 
 for (var i = 0; i < children.length; i++) {
 this.findEditableElements(children[i], editables, node, debugInset+rsS47[27], debugTextBox);
 } 
 
 }
 
 function elementIsEditable(element){
 if (
 (
 typeof(element.getAttribute)!=rsS47[5] &&
 (
 element.getAttribute(rsS47[28])==rsS47[29] ||
 element.getAttribute(rsS47[30])==rsS47[31]
 )
 )
 || 
 (
 (element.contentEditable && element.contentEditable==true) ||
 (element.designMode && element.designMode.toLowerCase()==rsS47[31])
 ) 
 
 
 )
 return [element, element]; else return null;
 }
 
 function getEditableContentDocument(element, debugTextBox){
 if(element.tagName && element.tagName==rsS47[32]){
 var kids = new Array();
 if(element.contentWindow && element.contentWindow.document){

 if(debugTextBox)
 debugTextBox.value += rsS47[33]; 
 
 this.findEditableElements(element.contentWindow.document, kids, element, rsS47[34], debugTextBox);
 

 if(kids.length>0){ var editable = kids[0][0];
 if(typeof(editable.body)!=rsS47[5])
 editable = editable.body;
 return [editable, element]; }
 }
 }
 return null;
 } 
 }





if( typeof(Sys)!=rsS47[5] && typeof(Sys.Application)!=rsS47[5]) Sys.Application.notifyScriptLoaded();




if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}

var rsw_mozly = navigator.userAgent.indexOf(rsS47[35]) > -1 ;
var rsw_msie = navigator.userAgent.indexOf(rsS47[36]) > -1 ; 
var rsw_chrome = navigator.userAgent.indexOf(rsS47[37]) > -1;
var rsw_applewebkit = navigator.userAgent.indexOf(rsS47[38]) > -1;

if(typeof(RapidSpell)==rsS47[5])RapidSpell = function () {
 };

RapidSpell.prototype.getConfigurationObject = rsw_getConfigurationObject;
RapidSpell.prototype.setParameterValue = rsw_setParameterValue;
RapidSpell.prototype.getParameterValue = rsw_getParameterValue;
RapidSpell.prototype.addEventListener = rsw_addEventListener;
RapidSpell.prototype.removeEventListener = rsw_removeEventListener;

RapidSpell.prototype.enableNETCore = function () {
 rapidSpell.setServiceType(rsS47[39]);
};

var rsw_eventListeners = [];

function rswEventListener(eventName, listener) {
 this.eventName = eventName;
 this.listener = listener;
}

function rsw_addEventListener(eventName, listenerFunction) {
 rsw_eventListeners[rsw_eventListeners.length] = new rswEventListener(eventName, listenerFunction);
}

function rsw_removeEventListener(eventName, listenerFunction) {
 var foundAt=-1;
 for (var i = 0; foundAt==-1 && i < rsw_eventListeners.length; i++) {
 if(rsw_eventListeners[i].listener==listenerFunction && rsw_eventListeners[i].eventName==eventName)
 foundAt=i;
 }
 if(foundAt>-1)
 rsw_eventListeners.splice(foundAt, 1);
}

function rsw_broadcastEvent(eventName, source, data1, data2, data3, data4, data5) {
 for (var i = 0; i < rsw_eventListeners.length; i++) {
 if (rsw_eventListeners[i].eventName == eventName)
 rsw_eventListeners[i].listener(source, data1, data2, data3, data4, data5);
 }
}
function rsw_createSpellBootJSON(text, textBoxForConfig) { var bootParams = [];
 bootParams[bootParams.length] = { 'ParameterName': 'textToCheck', 'ParameterValue': text }; rsw_getrsw_spellBootStringJSON(bootParams, textBoxForConfig);
 return bootParams;
}


function rsw_getrsw_spellBootStringJSON(paramObj, textBox) {
 var res = new String();
 

 for (var i = 0; i < rsw_config_defaults.keys.length; i++) {
 var key = rsw_config_defaults.keys[i];
 var value = rsw_config_defaults.values[i];
 var cval = rsw_getParameterValue(textBox, key);
 if (cval != null) value = cval;
 if (key == rsS47[40]) value = false;
 if (typeof (paramObj) != rsS47[5]) paramObj[paramObj.length] = { 'ParameterName': key, 'ParameterValue': value };
 }
 return res;
}




function rsw_getScriptLocation(name) {
 if (typeof rsw_presetScriptLocation === rsS47[5]) {
 var scripts = rs_s3.getElementsByTagName(rsS47[41]);
 var l;

 for (var i = 0; i < scripts.length; i++) {
 if ((l = scripts[i].src.indexOf(name)) > -1) {
 return scripts[i].src.substring(0, l);
 }
 }
 if (!rsw_suppressWarnings) {
 alert(rsS47[42] + name + rsS47[43]);
 }
 } else {
 return rsw_presetScriptLocation;
 }
}

var rsw_scriptLocation = rsw_getScriptLocation(rsS47[44]);
var rsw_resourceLocation = rsw_scriptLocation;
var rapidSpell = rapidSpell ? rapidSpell : new RapidSpell();

rapidSpell.useAJAXWebService = false;

var rsw_iever = rsw_getInternetExplorerVersion();
var rsw_thisBrowserOnlyFilename = ((rsw_iever > 0 && rsw_iever < 8) || (rsw_iever > 0 && rsw_iever < 10 && rs_s3.compatMode == rsS47[45])) && rsw_scriptLocation.charAt(0) != rsS47[46];

var rsw_RapidSpell_Core=true;
var rsw_ignoreDisabledTextBoxes = true;
var rsw_ignoreReadyOnlyTextBoxes = true;
var rsw_blankLocation = '<%= WebResource("blank.html") %>'.indexOf(rsS47[47]) > -1 ? rsw_resourceLocation + rsS47[48] : '<%= WebResource("blank.html") %>';
if (rsw_thisBrowserOnlyFilename) {
 rsw_rs_menu_styleURL = '<%= WebResource("menu-net2.css") %>'.indexOf(rsS47[47]) > -1 ? rsS47[49] : '<%= WebResource("menu-net2.css") %>';
 rsw_rs_styleURL = '<%= WebResource("rs_style-net2.css") %>'.indexOf(rsS47[47]) > -1 ? rsS47[50] : '<%= WebResource("rs_style-net2.css") %>';
} else {
 rsw_rs_menu_styleURL = ('<%= WebResource("menu-net2.css") %>'.indexOf(rsS47[47]) > -1 ? rsw_resourceLocation + rsS47[49] : '<%= WebResource("menu-net2.css") %>');
 rsw_rs_styleURL = ('<%= WebResource("rs_style-net2.css") %>'.indexOf(rsS47[47]) > -1 ? rsw_resourceLocation + rsS47[50] : '<%= WebResource("rs_style-net2.css") %>'); 
}
rsw_modalHelperURL = '<%= WebResource("RapidSpellModalHelperNET2.html") %>'.indexOf(rsS47[47]) > -1 ? rsw_resourceLocation + rsS47[51] : '<%= WebResource("RapidSpellModalHelperNET2.html") %>';
var rsw_targetIDs = new Array();
var rsw_rapidSpellControls = new Array();
var rsw_config_textBoxKeys = new Array();
var rsw_config_textBoxValues = new Array();
var rsw_config_defaults = { keys: [rsS47[52], rsS47[53], rsS47[54], rsS47[55], rsS47[6], rsS47[56], rsS47[57],
 rsS47[58], rsS47[59], rsS47[60], rsS47[61], rsS47[40], rsS47[62], rsS47[63], rsS47[64],
 rsS47[65], rsS47[66], rsS47[67], rsS47[68], rsS47[69], rsS47[70], rsS47[71], rsS47[72],
 rsS47[73], rsS47[74], rsS47[75], rsS47[76], rsS47[77], rsS47[78],
 rsS47[79], rsS47[80], rsS47[81], rsS47[82], rsS47[83], rsS47[84]],
 values: [rsS47[85], rsS47[86], rsS47[87], rsS47[29], rsS47[87], rsS47[87], rsS47[88],
 rsS47[88], rsS47[87], rsS47[87], rsS47[87], rsS47[29], rsS47[87], rsS47[87], rsS47[87],
 rsS47[29], rsS47[17], rsS47[17], rsS47[87], rsS47[89], rsS47[29], rsS47[87], rsS47[29],
 false, rsw_blankLocation, rsS47[29], rsS47[87], rsS47[87], rsS47[29],
 rsS47[90], rsS47[91], false, rsS47[92], rsS47[29], rsS47[17]]
};

function rsw_ondialogcorrection(a, b, c, tbName) {
 rsw_broadcastEvent(rsS47[93], null, rs_s3.getElementById(tbName), a, b, c);
}

function rsw_ondialogadd(a, b, c, tbName) {
 rsw_broadcastEvent(rsS47[94], null, rs_s3.getElementById(tbName), a, b, c);
}

var rsw_menuOptionKeys = [rsS47[88], rsS47[95], rsS47[96], rsS47[97], rsS47[98], rsS47[99], rsS47[100], rsS47[101], rsS47[102]];
var rsw_menuOptionValues = [
 [rsS47[103], rsS47[104], rsS47[105], rsS47[106], rsS47[107], rsS47[108], rsS47[109], rsS47[110]],
 [rsS47[111], rsS47[112], rsS47[113], rsS47[114], rsS47[115], rsS47[116], rsS47[117], rsS47[118]],
 [rsS47[119], rsS47[120], rsS47[121], rsS47[122], rsS47[123], rsS47[124], rsS47[125], rsS47[126]],
 [rsS47[127], rsS47[128], rsS47[129], rsS47[130], rsS47[131], rsS47[132], rsS47[133], rsS47[134]],
 [rsS47[135], rsS47[136], rsS47[137], rsS47[138], rsS47[139], rsS47[140], rsS47[141], rsS47[142]],
 [rsS47[103], rsS47[143], rsS47[144], rsS47[145], rsS47[146], rsS47[147], rsS47[148], rsS47[149]],
 [rsS47[150], rsS47[151], rsS47[152], rsS47[153], rsS47[154], rsS47[155], rsS47[156], rsS47[157]],
 [rsS47[158], rsS47[159], rsS47[160], rsS47[161], rsS47[162], rsS47[163], rsS47[164], rsS47[165]],
 [rsS47[166], rsS47[167], rsS47[168], rsS47[169], rsS47[170], rsS47[171], rsS47[172], rsS47[173]]
 ];
var rsw_dialogValues = {
 "FRENCH":{ 
 "Ignore":"Ignorer",
 "Ignore All":"Ignorer Tout",
 "All":"Tout",
 "Change":"Remplacer",
 "Change All":"Remp. Tout",
 "Add":"Ajouter",
 "Adding...":"s’ajouter..",
 "Cancel":"Annuler",
 "Finish":"Terminer",
 "Finished checking selection, would you like to check the rest of the text?":"Choix fini de vérification. Vérifiez le reste du texte?",
 "Finished Checking Selection":"Choix fini de vérification.",
 "The spelling check is complete.":"Fini.",
 "The Spelling Check Is Complete.":"Fini.",
 "No Spelling Errors In Text.":"Aucunes Erreurs.",
 "Spelling":"Correcteur orthographique",
 "Check Spelling":"Correcteur Orthographique",
 "Checking Document...":"Vérifiant Le Document...",
 "Checking...":"Vérifiant...",
 "Not In Dictionary:":"Non Trouvé",
 "Not in Dictionary:":"Non Trouvé",
 "In Dictionary:":"Trouvé",
 "Change To:":"Non Trouvé",
 "Resume":"Continuez",
 "Suggestions:":"Suggestions:",
 "Find Suggestions?":"Suggérer?",
 "Finding Suggestions...":"Recherche...",
 "No Suggestions.":"Aucun",
 "No suggestions":"Aucun",
 "Spell checking rs_s3...":"Vérification de l'orthographe du rs_s3...",
 "Remove duplicate word":"Enlevez le mot double",
 "Edit...":"Éditez...",
 "Undo":"Défaites",


 "Resume Editing":"Reprendre édition",

 "&Ignore":"&Ignorer",
 "Ignore &All":"Ignorer &Tout",
 "&Resume":"Continue&z",
 "A&dd":"&Ajouter",
 "&Change":"&Remplacer",
 "Chan&ge All":"Remp. T&out",
 "Canc&el":"Annul&er",

 
 "Check spelling as you type":"Vérifier l’orthographe en cours de frappe",
 "Always suggest corrections":"Suggestions du dictionnaire principal uniquement",
 "Ignore internet addresses and emails":"Ignorer les adresses internet et les courriels",
 "Ignore words with numbers":"Ignorer les mots contenant des nombres",
 "Ignore words in UPPERCASE":"Ignorer les mots en MAJUSCULES",
 "Suggest from main dictionary only":"Suggérez du dictionnaire principal seulement",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignorez le cas inexact (eg. \"l’australie\", \"tABle\")",
 "Basic Settings":"Paramètres de base",
 "Advanced Settings":"Paramètres avancés",
 "Recheck Text":"Revérifier le texte",
 "User Dictionary...":"Dictionnaires personnels...",
 
 "OK":"OK",

 "User Dictionary Contents":"Contenu de Dictionnaire D’utilisateur",
 "User Dictionary":"Dictionnaire D’utilisateur",
 "Word:":"Mot:",
 "Dictionary:":"Dictionnaire:",
 "Delete":"Supprimer",
 "Options...":"Options...",

 "Loading Dictionary...":"Chargement Dictionnaire..."
 }};
rsw_dialogValues.SPANISH = {
 "All":"Todas",
 "Ignore":"Ignorar",
 "Ignore All":"Ignorar Todas",
 "Change":"Cambiar",
 "Change All":"Cambiar Todos",
 "Add":"Agregar",
 "Adding...":"Adición...",
 "Cancel":"Cancelar",
 "Finish":"Acabar",
 "Finished checking selection, would you like to check the rest of the text?":"Selección acabada. ¿Verifique el resto del texto?",
 "Finished Checking Selection":"Selección acabada.",
 "The spelling check is complete.":"La verificación ortográfica ha finalizado.",
 "The Spelling Check Is Complete.":"La verificación ortográfica ha finalizado.",
 "No Spelling Errors In Text.":"No se encontraron errores.",
 "Spelling":"Corregir Ortografía",
 "Check Spelling":"Corregir Ortografía",
 "Checking Document...":"Comprobación Del Documento...",
 "Checking...":"Comprobación...",
 "Not in Dictionary:":"Palabra mal escrita",
 "Not In Dictionary:":"Palabra mal escrita",
 "In Dictionary:":"En Diccionario",
 "Change To:":"Palabra mal escrita",
 "Resume":"Continúe",
 "Suggestions:":"Sugerencias:",
 "Find Suggestions?":"¿Sugerencias?",
 "Finding Suggestions...":"Encontrar sugerencias...",
 "No Suggestions.":"Ningunas sugerencias",
 "No suggestions":"Ningunas sugerencias",
 "Spell checking rs_s3...":"Comprobación del deletreo el texto...",
 "Remove duplicate word":"Quite la palabra duplicada",

 "Edit...":"Corrija...",

 "Undo":"Deshaga",

 "Resume Editing":"Reasumir el corregir",

 "&Ignore":"&Ignorar",
 "Ignore &All":"Ignorar &Todas",
 "&Resume":"C&ontinúe",
 "A&dd":"&Agregar",
 "&Change":"&Cambiar",
 "Chan&ge All":"Cambia&r Todos",
 "Canc&el":"Cance&lar",


 
 "Check spelling as you type":"Revisar ortografía mientras escribe",
 "Always suggest corrections":"Sugiera siempre las correcciones",
 "Ignore internet addresses and emails":"No haga caso de las direcciones de Internet y email",
 "Ignore words with numbers":"No haga caso de las palabras con números",
 "Ignore words in UPPERCASE":"Omitir Palabras en UPPERCASE",
 "Suggest from main dictionary only":"Sugiera del diccionario principal solamente",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Omitir caso incorrecto (eg. \"australia\", \"tABle\")",
 "Basic Settings":"Opciones Básicas",
 "Advanced Settings":"Opciones Avanzados",
 "Recheck Text":"Volver a texto",
 "User Dictionary...":"Diccionario del Usuario...",
 "OK":"Aceptar",
 "User Dictionary Contents":"Contenido del Diccionario del Usuario",
 "User Dictionary":"Diccionario del Usuario",
 "Word:":"Palabra:",
 "Dictionary:":"Diccionario:",
 "Delete":"Eliminar",
 "Options...":"Opciones...",

 "Loading Dictionary...":"Cargando Diccionario..."
};

rsw_dialogValues.GERMAN = {
 "All":"Alle",
 "Ignore":"Ignorieren",
 "Ignore All":"Alle ignorieren",
 "Change":"Ändern",
 "Change All":"Alle ändern",
 "Add":"Hinzufügen",
 "Adding...":"Hinzufügen...",
 "Cancel":"Abbrechen",
 "Finish":"Ende",
 "Finished checking selection, would you like to check the rest of the text?":"Der ausgewählte Text ist überprüft worden. Wollen Sie auch den Rest des Textes überprüfen ?",
 "Finished Checking Selection":"Der ausgewählte Text ist überprüft worden.",
 "The spelling check is complete.":"Die Rechtschreibprüfung ist abgeschlossen.",
 "The Spelling Check Is Complete.":"Die Rechtschreibprüfung ist abgeschlossen.",
 "No Spelling Errors In Text.":"Es sind keine Fehler aufgetreten.",
 "Spelling":"Rechtschreibprüfung",
 "Check Spelling":"Rechtschreibprüfung",
 "Checking Document...":"Überprüfung des Dokumentes...",
 "Checking...":"Überprüfung...",
 "Not in Dictionary:":"Nicht im Wörterbuch:",
 "Not In Dictionary:":"Nicht im Wörterbuch:",
 "In Dictionary:":"Im Wörterbuch:",
 "Change To:":"Ändern In:",
 "Resume":"Weiter",
 "Suggestions:":"Vorschläge:",
 "Find Suggestions?":"Vorschläge suchen?",
 "Finding Suggestions...":"Vorschläge...",
 "No Suggestions.":"Keine Vorschläge",
 "No suggestions":"Keine vorschläge",
 "Spell checking rs_s3...":"Dokument prüfen...",
 "Remove duplicate word":"Doppelte Wörter entfernen",

 "Edit...":"Redigieren...",
 "Resume Editing":"Zusammenfassung Redigieren",

 "Undo":"Annulieren",

 "&Ignore":"&Ignorieren",
 "Ignore &All":"&Alle ignorieren",
 "&Resume":"&Weiter",
 "A&dd":"&Hinzufügen",
 "&Change":"Ä&ndern",
 "Chan&ge All":"Alle än&dern",
 "Canc&el":"Abbre&chen",

 
 "Check spelling as you type":"Rechtschreibung während der Eingabe überprüfen",
 "Always suggest corrections":"Immer Korrekturen vorschlagen",
 "Ignore internet addresses and emails":"Internet-Adressen und eMail ignorieren",
 "Ignore words with numbers":"Wörter mit Zahlen ignorieren",
 "Ignore words in UPPERCASE":"Wörter in GROSS-Schreibung ignorieren",
 "Suggest from main dictionary only":"Nur Wörter aus Haupt-Wörterbuch vorschlagen",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Falsche Groß/Kleinschreibung (zB. \"australien\",\"taBelle\") ignorieren",
 "Basic Settings":"Grundlegende Einstellungen",
 "Advanced Settings":"Erweiterte Einstellungen",
 "Recheck Text":"Text erneut prüfen",
 "User Dictionary...":"Benutzer-Wörterbuch...",
 "OK":"OK",
 "User Dictionary Contents":"Benutzer-Wörterbuch Inhalt",
 "User Dictionary":"Benutzer-Wörterbuch",
 "Word:":"Wort:",
 "Dictionary:":"Wörterbuch:",
 "Delete":"Löschen",
 "Options...":"Optionen...",

 "Loading Dictionary...":"Laden Wörterbuch..."
};

rsw_dialogValues.ITALIAN = {
 "All":"Tutto",
 "Ignore":"Ignora",
 "Ignore All":"Ignora tutto",
 "Change":"Cambia in",
 "Change All":"Cambia tutto",
 "Add":"Aggiungi",
 "Adding...":"Aggiunta...",
 "Cancel":"Chiudi",
 "Finish":"Terminato",
 "Finished checking selection, would you like to check the rest of the text?":"Il testo selezionato è stato verificato. Verifichi il resto del testo?",
 "Finished Checking Selection":"Il testo selezionato è stato verificato.",
 "The spelling check is complete.":"Controllo completato.",
 "The Spelling Check Is Complete.":"Controllo completato.",
 "No Spelling Errors In Text.":"Nessun errori nel testo.",
 "Spelling":"Verificatore ortografico",
 "Check Spelling":"Verificatore ortografico",
 "Checking Document...":"Controllo ortografico...",
 "Checking...":"Controllo...",
 "Not in Dictionary:":"Cambia in:",
 "Not In Dictionary:":"Cambia in:",
 "In Dictionary:":"Trovato nel Dizionario:",
 "Change To:":"Cambia in:",
 "Resume":"Continua",
 "Suggestions:":"Suggerimenti:",
 "Find Suggestions?":"Suggerimenti?",
 "Finding Suggestions...":"Sto cercando i suggerimenti...",
 "No Suggestions.":"Nessun suggerimento",
 "No suggestions":"Nessun suggerimento",
 "Spell checking rs_s3...":"Controllo ortografico...",
 "Remove duplicate word":"Rimuovi la parola duplicata",

 "Edit...":"Modifica...",
 "Resume Editing":"Torna all’Editor",

 "Undo":"Undo",

 "&Ignore":"&Ignora",
 "Ignore &All":"Ignora &tutto",
 "&Resume":"C&ontinui",
 "A&dd":"&Aggiungi",
 "&Change":"&Cambia in",
 "Chan&ge All":"Ca&mbia tutto",
 "Canc&el":"A&nnullamento",

 "Check spelling as you type":"Controlla ortografia durante la digitazione",
 "Always suggest corrections":"Suggerisca sempre le correzioni",
 "Ignore internet addresses and emails":"Ignora gli internet indirizzi ed i email del",
 "Ignore words with numbers":"Ignora parole con i numeri",
 "Ignore words in UPPERCASE":"Ignora parole in MAIUSCOLE",
 "Suggest from main dictionary only":"Suggerisca dal dizionario principale soltanto",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignora improprio caso (ad esempio, \"australia\", \"taVolo\")",
 "Basic Settings":"Impostazioni di Base",
 "Advanced Settings":"Impostazioni Avanzate",
 "Recheck Text":"Testo Ricontrolleremo",
 "User Dictionary...":"Dizionario Utente...",
 "OK":"OK",
 "User Dictionary Contents":"Sommario Dizionario Utente",
 "User Dictionary":"Dizionario Utente",
 "Word:":"Parola:",
 "Dictionary:":"Dizionario:",
 "Delete":"Eliminare",
 "Options...":"Opzioni...",

 "Loading Dictionary...":"Caricamento Dizionario..."
};

rsw_dialogValues.PORTUGUESE = {
 "All":"Tudo",
 "Ignore":"Ignore",
 "Ignore All":"Ignore Tudo",
 "Change":"Mude",
 "Change All":"Mude Tudo",
 "Add":"Adicione",
 "Adding...":"Adição...",
 "Cancel":"Cancelar",
 "Finish":"Batente",
 "Finished checking selection, would you like to check the rest of the text?":"A verificação ortográfica foi concluida, deseja começar do início do texto?",
 "Finished Checking Selection":"Verificação Ortográfica Concluida",
 "The spelling check is complete.":"A verificação de soletração está completa.",
 "The Spelling Check Is Complete.":"A Verificação De Soletração Está Completa.",
 "No Spelling Errors In Text.":"Nenhuns Erros De Soletração No Texto.",
 "Spelling":"Verificação Ortográfica",
 "Check Spelling":"Verifique A Ortografia",
 "Checking Document...":"Verificando O Original...",
 "Checking...":"Verificando...",
 "Not in Dictionary:":"Não Consta No Dicionário:",
 "Not In Dictionary:":"Não Consta No Dicionário:",
 "In Dictionary:":"No Dicionário:",
 "Change To:":"Mudança A:",
 "Resume":"Resumo",
 "Suggestions:":"Sugestões:",
 "Find Suggestions?":"Sugestões Do Achado?",
 "Finding Suggestions...":"Encontrando Sugestões...",
 "No Suggestions.":"Nenhumas Sugestões.",
 "No suggestions":"Nenhumas sugestões",
 "Spell checking rs_s3...":"Carregando verificador ortográfico...",
 "Remove duplicate word":"Remova a palavra duplicada",

 "Edit...":"Edite...",
 "Undo":"Anular",

 "Resume Editing":"Edição do resumo",

 "&Ignore":"I&gnorar",
 "Ignore &All":"Ignorar &Tudo",
 "&Resume":"&Resumo",
 "A&dd":"&Adicionar",
 "&Change":"&Mudar",
 "Chan&ge All":"Mudar T&udo",
 "Canc&el":"&Cancelar",


 "Check spelling as you type":"Verificar ortografia ao escrever",
 "Always suggest corrections":"Sugerir sempre correcções",
 "Ignore internet addresses and emails":"Ignorar endereços da Internet e correio electrónico",
 "Ignore words with numbers":"Ignorar palavras com números",
 "Ignore words in UPPERCASE":"Ignorar palavras em maiúsculas",
 "Suggest from main dictionary only":"Sugira do dicionário principal somente",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignorar impróprio caso (por exemplo. \"austrália\", \"taBela\")",
 "Basic Settings":"Ajustes Básicos",
 "Advanced Settings":"Ajustes Avançados",
 "Recheck Text":"Verific Novamente o Texto",
 "User Dictionary...":"Dicionário do Usuário...",
 "OK":"Aprovação",
 "User Dictionary Contents":"Dicionário do Usuário Conteúdo",
 "User Dictionary":"Dicionário do Usuário",
 "Word:":"Palavra:",
 "Dictionary:":"Dicionário:",
 "Delete":"Excluir",
 "Options...":"Opções...",

 "Loading Dictionary...":"Carregando Dicionário..."
};

rsw_dialogValues.DUTCH = {
 "All":"Allen",
 "Ignore":"Negeren",
 "Ignore All":"Alles negeren",
 "Change":"Wijzigen",
 "Change All":"Alles wijzigen",
 "Add":"Toevoegen",
 "Adding...":"bezig met toevoegen...",
 "Cancel":"Annuleren",
 "Finish":"Eindig",
 "Finished checking selection, would you like to check the rest of the text?":"Spellingscontrole van de selectie is voltooid. Wilt u de overige tekst controleren?",
 "Finished Checking Selection":"Spellingscontrole van de selectie is voltooid",
 "The spelling check is complete.":"De spellingscontrole is voltooid.",
 "The Spelling Check Is Complete.":"De Spellingscontrole is voltooid.",
 "No Spelling Errors In Text.":"De spellingscontrole heeft geen fouten gevonden.",
 "Spelling":"Spelling",
 "Check Spelling":"Spellingscontrole",
 "Checking Document...":"Bezig document te controleren...",
 "Checking...":"Bezig met controleren...",
 "Not in Dictionary:":"Niet in woordenboek:",
 "Not In Dictionary:":"Niet in woordenboek:",
 "In Dictionary:":"In woordenboek:",
 "Change To:":"Wijzigen in:",
 "Resume":"Hervatten",
 "Suggestions:":"Suggesties:",
 "Find Suggestions?":"Suggesties tonen?",
 "Finding Suggestions...":"Bezig met zoeken naar suggesties...",
 "No Suggestions.":"Geen suggesties.",
 "No suggestions":"Geen suggesties",
 "Spell checking rs_s3...":"Bezig met spellingscontrole...",
 "Remove duplicate word":"Verwijder herhaald woord",

 "Edit...":"Corrigeren...",
 "Undo":"Ongedaan maken",

 "Resume Editing":"Corrigeren hervatten",

 "&Ignore":"&Negeren",
 "Ignore &All":"&Alles negeren",
 "&Resume":"&Hervatten",
 "A&dd":"&Toevoegen",
 "&Change":"&Wijzigen",
 "Chan&ge All":"A&lles wijzigen",
 "Canc&el":"Annule&ren",

 "Check spelling as you type":"Spelling controleren terwijl u typt",
 "Always suggest corrections":"Altijd suggereren correcties",
 "Ignore internet addresses and emails":"Negeer internet adressen en e-mail",
 "Ignore words with numbers":"Negeer woorden met aantallen",
 "Ignore words in UPPERCASE":"Negeer woorden in IN HOOFDLETTERS",
 "Suggest from main dictionary only":"Suggestie uit voornaamste woordenboek alleen",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Negeer oneigenlijk geval (bijvoorbeeld. \"australië\", \"taBel\")",
 "Basic Settings":"Basis Instellingen",
 "Advanced Settings":"Geavanceerde Instellingen",
 "Recheck Text":"Controleer Tekst Opnieuw",
 "User Dictionary...":"Gebruiker Woordenboek...",
 "OK":"OK",
 "User Dictionary Contents":"Gebruiker Woordenboek inhoud",
 "User Dictionary":"Gebruiker Woordenboek",
 "Word:":"Woord:",
 "Dictionary:":"Woordenboek:",
 "Delete":"Schrap",
 "Options...":"Opties...",

 "Loading Dictionary...":"Laden Woordenboek..."
};

rsw_dialogValues.POLISH = {
 "All":"Wszystko",
 "Ignore":"Ignoruj",
 "Ignore All":"Ignoruj wszystko",
 "Change":"Zmień",
 "Change All":"Zmień wszystko",
 "Add":"Dodaj",
 "Adding...":"Dodawanie",
 "Cancel":"Anuluj",
 "Finish":"Zakończ",
 "Finished checking selection, would you like to check the rest of the text?":"Zakończono sprawdzanie zaznaczenia, czy chcesz sprawdzić pozostały tekst?",
 "Finished Checking Selection":"Zakończono sprawdzanie zaznaczenia",
 "The spelling check is complete.":"Zakończono Sprawdzanie pisowni.",
 "The Spelling Check Is Complete.":"Zakończono Sprawdzanie Pisowni.",
 "No Spelling Errors In Text.":"W tekście nie ma błędów pisowni.",
 "Spelling":"Pisownia",
 "Check Spelling":"Sprawdź Pisownię",
 "Checking Document...":"Sprawdzanie Dokumentu...",
 "Checking...":"Sprawdzanie...",
 "Not in Dictionary:":"Nie występuje w Słowniku:",
 "Not In Dictionary:":"Nie występuje w Słowniku:",
 "In Dictionary:":"W Słowniku:",
 "Change To:":"Zmień na:",
 "Resume":"Wznów",
 "Suggestions:":"Sugestie:",
 "Find Suggestions?":"Znajdź Sugestie:",
 "Finding Suggestions...":"Szukanie Sugestii...",
 "No Suggestions.":"Nie ma Sugestii.",
 "No suggestions":"Nie ma sugestii",
 "Spell checking rs_s3...":"Sprawdzanie pisowni dokumentu...",
 "Remove duplicate word":"Usuń podwójne wystąpienie słowa",

 "Edit...":"Edytuj...",
 "Undo":"Cofnij",

 "Resume Editing":"Wznów Edycję",
 "&Ignore":"&Ignoruj",
 "Ignore &All":"Ignoruj &Wszystko",
 "&Resume":"&Wznów",
 "&Add":"&Dodaj",
 "&Change":"&Zmień",
 "Chan&ge All":"Z&mień wszystko",
 "Canc&el":"&Przerwij",

 
 "Check spelling as you type":"Sprawdź pisownię podczas pisania",
 "Always suggest corrections":"Zawsze sugeruj poprawki",
 "Ignore internet addresses and emails":"Ignoruj adresy internetowe i e-maile",
 "Ignore words with numbers":"Ignoruj słowa z cyframi",
 "Ignore words in UPPERCASE":"Ignoruj słowa pisane WIELKIMI LITERAMI",
 "Suggest from main dictionary only":"Sugeruj wyłącznie z głównego słownika",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignoruj błędy pisowni wielkich liter (np. \"australia\", \"krzeSło\")",
 "Basic Settings":"Podstawowe ustawienia",
 "Advanced Settings":"Ustawienia Zaawansowane",
 "Recheck Text":"Sprawdź tekst ponownie",
 "User Dictionary...":"Słownik Użytkownika...",
 "OK":"Potwierdzam",
 "User Dictionary Contents":"Zawartość Słownika Użytkownika",
 "User Dictionary":"Słownik Użytkownika",
 "Word:":"Słowo:",
 "Dictionary:":"Słownik:",
 "Delete":"Usuń",
 "Options...":"Opcje...",
 "Loading Dictionary...":"Ładowanie Słownika..."
};

rsw_dialogValues.ENGLISH = {
 "All": "All",
 "Ignore": "Ignore",
 "Ignore All": "Ignore All",
 "Change": "Change",
 "Change All": "Change All",
 "Add": "Add",
 "Adding...": "Adding...",
 "Cancel": "Cancel",
 "Finish": "Finish",
 "Finished checking selection, would you like to check the rest of the text?": "Finished checking selection, would you like to check the rest of the text?",
 "Finished Checking Selection": "Finished Checking Selection",
 "The spelling check is complete.": "The spelling check is complete.",
 "The Spelling Check Is Complete.": "The Spelling Check Is Complete.",
 "No Spelling Errors In Text.": "No Spelling Errors In Text.",
 "Spelling": "Spelling",
 "Check Spelling": "Check Spelling",
 "Checking Document...": "Checking Document...",
 "Checking...": "Checking...",
 "Not in Dictionary:": "Not in Dictionary:",
 "Not In Dictionary:": "Not in Dictionary:",
 "In Dictionary:": "In Dictionary:",
 "Change To:": "Change To:",
 "Resume": "Resume",
 "Suggestions:": "Suggestions:",
 "Find Suggestions?": "Find Suggestions?",
 "Finding Suggestions...": "Finding Suggestions...",
 "No Suggestions.": "No Suggestions.",
 "No suggestions": "No suggestions",
 "Spell checking rs_s3...": "Spell checking rs_s3...",

 "Edit...": "Edit...",

 "Resume Editing": "Resume Editing",

 "Undo": "Undo",

 "&Ignore": "&Ignore",
 "Ignore &All": "Ignore &All",
 "&Resume": "&Resume",
 "A&dd": "A&dd",
 "&Change": "&Change",
 "Chan&ge All": "Chan&ge All",
 "Canc&el": "Canc&el",



 "Check spelling as you type": "Check spelling as you type",
 "Always suggest corrections": "Always suggest corrections",
 "Ignore internet addresses and emails": "Ignore internet addresses and emails",
 "Ignore words with numbers": "Ignore words with numbers",
 "Ignore words in UPPERCASE": "Ignore words in UPPERCASE",
 "Suggest from main dictionary only": "Suggest from main dictionary only",
 "Ignore improper case (eg. \"australia\", \"tABle\")": "Ignore improper case (eg. \"australia\", \"tABle\")",
 "Basic Settings": "Basic Settings",
 "Advanced Settings": "Advanced Settings",
 "Recheck Text": "Recheck Text",
 "User Dictionary...": "User Dictionary...",
 "OK": "OK",
 "User Dictionary Contents": "User Dictionary Contents",
 "User Dictionary": "User Dictionary",
 "Word:": "Word:",
 "Dictionary:": "Dictionary:",
 "Delete": "Delete",
 "Options...": "Options...",

 "Loading Dictionary...": "Loading Dictionary..."

};

rsw_dialogValues.RUSSIAN = {
 "All": "все",
 "Ignore": "Пропустить",
 "Ignore All": "Пропустить все",
 "Change": "Изменить",
 "Change All": "Изменить все",
 "Add": "Добавить",
 "Adding...": "Добавление...",
 "Cancel": "Отмена",
 "Finish": "Готово",
 "Finished checking selection, would you like to check the rest of the text?": "Проверка выделенного фрагмента завершена. Хотите проверить остальной текст?",
 "Finished Checking Selection": "Проверка выделенного фрагмента завершена",
 "The spelling check is complete.": "Проверка орфографии.",
 "The Spelling Check Is Complete.": "Проверка Oрфографии.",
 "No Spelling Errors In Text.": "Текст не содержит орфографических ошибок.",
 "Spelling": "Орфография",
 "Check Spelling": "Проверить орфографию",
 "Checking Document...": "Проверка документа...",
 "Checking...": "Проверка...",
 "Not in Dictionary:": "Нет в словаре:",
 "Not In Dictionary:": "Нет в Cловаре:",
 "In Dictionary:": "В Cловаре:",
 "Change To:": "Изменить на:",
 "Resume": "Продолжить",
 "Suggestions:": "Варианты:",
 "Find Suggestions?": "Найти варианты?",
 "Finding Suggestions...": "Поиск вариантов...",
 "No Suggestions.": "Нет вариантов.",
 "No suggestions": "Нет вариантов",
 "Spell checking rs_s3...": "Проверка орфографии в документе...",
 "Remove duplicate word": "Удалить дубликат слова",

 "Edit...": "Редактировать...",

 "Undo": "Отменить",

 "Resume Editing": "Продолжить редактирование",

 "&Ignore": "&Пропустить",
 "Ignore &All": "Пропустить &все",
 "&Resume": "&Продолжить",
 "A&dd": "&Добавить",
 "&Change": "&Изменить",
 "Chan&ge All": "Измен&ить все",
 "Canc&el": "Отме&на",



 "Check spelling as you type": "Проверять орфографию при вводе",
 "Always suggest corrections": "Всегда предлагать исправления",
 "Ignore internet addresses and emails": "Пропускать адреса Интернета и электронной почты",
 "Ignore words with numbers": "Пропускать слова с цифрами",
 "Ignore words in UPPERCASE": "Пропускать слова из ПРОПИСНЫХ БУКВ",
 "Suggest from main dictionary only": "Предлагать только из основного словаря",
 "Ignore improper case (eg. \"australia\", \"tABle\")": "Пропускать неправильный регистр (например: \"австралия\", \"сТОл\")",
 "Basic Settings": "Основные настройки",
 "Advanced Settings": "Расширенные настройки",
 "Recheck Text": "Проверить текст заново",
 "User Dictionary...": "Пользовательский словарь...",
 "OK": "ОК",
 "User Dictionary Contents": "Содержимое пользовательского словаря",
 "User Dictionary": "Пользовательский словарь",
 "Word:": "Слово:",
 "Dictionary:": "Словарь:",
 "Delete": "Удалить",
 "Options...": "Параметры...",

 "Loading Dictionary...": "Загрузка словаря..."
};




function SpellCheckUITextItems() {
 this.ignore;

}

function rsw_setUIText(language, item, newText) {
 var a = rsw_getLanguageArray(language);
 switch (item) {
 case rsS47[174]: a[0] = newText; break;
 case rsS47[175]: a[1] = newText; break;
 case rsS47[176]: a[2] = newText; break;
 case rsS47[177]: a[3] = newText; break;
 case rsS47[178]: a[4] = newText; break;
 case rsS47[179]: a[5] = newText; break;
 case rsS47[180]: a[6] = newText; break;
 case rsS47[181]: a[7] = newText; break;

 }
}

function rsw_getLanguageArray(lang) {
 for (var i = 0; i < rsw_menuOptionKeys.length; i++) {
 if (rsw_menuOptionKeys[i] == lang)
 return rsw_menuOptionValues[i];
 }
 return null;
}

function rsw_getParameterValue(textBox, param) {
 var searchObj;
 var pos = rsw_getTextBoxIndex(textBox);


 if (pos == -1 && textBox != rsS47[182]) return rsw_getParameterValue(rsS47[182], param); else {
 if (textBox == rsS47[182]) {
 searchObj = rsw_config_defaults;
 } else
 searchObj = rsw_config_textBoxValues[pos];

 var found = -1;
 for (var pp = 0; searchObj.keys && pp < searchObj.keys.length && found == -1; pp++) {
 if (searchObj.keys[pp] == param)
 found = pp;
 }
 if (found == -1) return rsw_getParameterValue(rsS47[182], param); else {
 return searchObj.values[found];
 }
 }
}

function rsw_getConfigurationObject(textBox) {
 var synthObject = {keys:[], values:[]};
 for (var i = 0; i < rsw_config_defaults.keys.length; i++) {
 synthObject.keys[synthObject.keys.length] = rsw_config_defaults.keys[i];
 synthObject.values[synthObject.values.length] = rsw_getParameterValue(textBox, rsw_config_defaults.keys[i]);
 }
 return synthObject;
}

function rsw_getTextBoxIndex(textBox) {
 for (var i = 0; i < rsw_config_textBoxKeys.length; i++) {
 if (rsw_config_textBoxKeys[i] == textBox) return i;
 }
 return -1;
}

function rsw_setParameterValue(textBox, param, value) {
 var pos;
 param = param.replace(/^\s+|\s+$/g, rsS47[17]); if (textBox != rsS47[182]) {

 pos = rsw_getTextBoxIndex(textBox);
 if (pos == -1) {
 rsw_config_textBoxKeys[rsw_config_textBoxKeys.length] = textBox;
 pos = rsw_config_textBoxKeys.length - 1;
 rsw_config_textBoxValues[pos] = {};
 }

 }

 var targ;
 if (textBox != rsS47[182])
 targ = rsw_config_textBoxValues[pos];
 else
 targ = rsw_config_defaults;

 var found = -1;

 for (var pp = 0; targ.keys && pp < targ.keys.length && found == -1; pp++) {
 if (targ.keys[pp] == param)
 found = pp;
 }

 if (!targ.keys) {
 targ.keys = new Array();
 targ.values = new Array();
 }

 if (found == -1) found = targ.keys.length;
 targ.keys[found] = param;
 targ.values[found] = value;

 if(typeof(rsw_scs)!=rsS47[5]){
 for (var i = 0; i < rsw_scs.length; i++) {
 if (textBox==rsS47[182] || rsw_scs[i].textBoxID == textBox.id) {
 rsw_scs[i].config = rsw_getConfigurationObject(rs_s3.getElementById(rsw_scs[i].textBoxID));
 if (param == rsS47[57]) {
 var langArray = rsw_getLanguageArray(value);
 if (langArray != null) {
 rsw_setSpellCheckerText(rsw_scs[i], langArray);
 
 }
 }
 }
 }
 }




}

function rsw_setSpellCheckerText(spellChecker, langArray) {
 spellChecker.ignoreText = langArray[0];
 spellChecker.ignoreAllText = langArray[1];
 spellChecker.addText = langArray[2];
 spellChecker.editText = langArray[3];
 spellChecker.changeAllText = langArray[4];
 spellChecker.removeDuplicateText = langArray[5];
 spellChecker.noSuggestionsText = langArray[6];
}

function rsw_isParentIsNoSpell(tb) {
 if (tb.getAttribute(rsS47[183]) == rsS47[29])
 return true;
 if (tb.parentElement != null)
 return rsw_isParentIsNoSpell(tb.parentElement);
 else if (typeof (tb.parentElement) == rsS47[5] && tb.parentNode != null)
 return rsw_isParentIsNoSpell(tb.parentNode);
 else
 return false;
}

function rsw_isElementVisible(tb) {
 var ifVis = false;
 if (rs_s3.getElementById(tb.id + rsS47[20]) != null) ifVis = rsw_isElementVisible(rs_s3.getElementById(tb.id + rsS47[20]));

 var compVis = rsw_getStyleProperty(tb, rsS47[184]);
 var compDis = rsw_getStyleProperty(tb, rsS47[185]);
 if (compVis == rsS47[186] || compDis == rsS47[187])
 return false || ifVis;
 if (compVis == rsS47[188] && !rsw_parentIsDisplayNone(tb)) return true;
 if (tb.parentElement != null)
 return rsw_isElementVisible(tb.parentElement) || ifVis;
 else if (typeof (tb.parentElement) == rsS47[5] && tb.parentNode != null)
 return rsw_isElementVisible(tb.parentNode) || ifVis;
 else
 return true;
}

function rsw_isElementVisibleOrInitialized(tb) {
 if (rs_s3.getElementById(tb.id + rsS47[20]) != null) return true;
 else{
 return rsw_isElementVisible(tb); 
 }
}

function rsw_parentIsDisplayNone(tb, count) {
 if (typeof (count) == rsS47[5]) count = 0;
 if (count > 30) return false;
 var compDis = rsw_getStyleProperty(tb, rsS47[185]);
 if(compDis==rsS47[187]) return true;
 if (tb.parentElement != null)
 return rsw_parentIsDisplayNone(tb.parentElement, ++count);

 return false;
}


rapidSpell.setServiceType = function (type){
 if (type.toLowerCase() === rsS47[189]) {
 rapidSpellExtension.useASMXService = false;
 rapidSpellExtension.useWCFService = true;
 rapidSpellExtension.useServlet = false;
 } else if (type.toLowerCase() === rsS47[190]) {
 rapidSpellExtension.useASMXService = true;
 rapidSpellExtension.useWCFService = false;
 rapidSpellExtension.useServlet = false;
 } else if (type.toLowerCase() === rsS47[191]) {
 rapidSpellExtension.useASMXService = false;
 rapidSpellExtension.useWCFService = false;
 rapidSpellExtension.useServlet = true;
 } else if(type.toLowerCase() === rsS47[39]) {
 if (typeof rapidSpell.dialog_setUseDivDialog !== rsS47[5]) {
 rapidSpell.dialog_setUseDivDialog(true);
 }
 rapidSpell.useAJAXWebService = true;
 rapidSpellExtension.useWCFService = false;
 rapidSpellExtension.useAPIController = true;
 rapidSpellExtension.serviceProxy.commonFolderUrl = rsS47[192];
 } 
};



var JSON; if (!JSON) { JSON = {} } (function () {
 function f(n) { return n < 10 ? "0" + n : n } if (typeof Date.prototype.toJSON !== "function") { Date.prototype.toJSON = function (key) { return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null };
																																						 String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function (key) { return this.valueOf() } } var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = { "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\" }, rep; function quote(string) { escapable.lastIndex = 0; return escapable.test(string) ? '"' + string.replace(escapable, function (a) { var c = meta[a]; return typeof c === "string" ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) }) + '"' : '"' + string + '"' } function str(key, holder) {
 var i, k, v, length, mind = gap, partial, value = holder[key]; if (value && typeof value === "object" && typeof value.toJSON === "function") { value = value.toJSON(key) } if (typeof rep === "function") { value = rep.call(holder, key, value) } switch (typeof value) {
 case "string": return quote(value); case "number": return isFinite(value) ? String(value) : "null"; case "boolean": case "null": return String(value); case "object": if (!value) { return "null" } gap += indent; partial = [];
 if (Object.prototype.toString.apply(value) === "[object Array]") { length = value.length; for (i = 0; i < length; i += 1) { partial[i] = str(i, value) || "null" } v = partial.length === 0 ? "[]" : gap ? "[\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "]" : "[" + partial.join(",") + "]"; gap = mind; return v } if (rep && typeof rep === "object") { length = rep.length; for (i = 0; i < length; i += 1) { if (typeof rep[i] === "string") { k = rep[i]; v = str(k, value); if (v) { partial.push(quote(k) + (gap ? ": " : ":") + v) } } } } else { for (k in value) { if (Object.prototype.hasOwnProperty.call(value, k)) { v = str(k, value); if (v) { partial.push(quote(k) + (gap ? ": " : ":") + v) } } } } v = partial.length === 0 ? "{}" : gap ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}" : "{" + partial.join(",") + "}"; gap = mind; return v
 }
 } if (typeof JSON.stringify !== "function") { JSON.stringify = function (value, replacer, space) { var i; gap = ""; indent = ""; if (typeof space === "number") { for (i = 0; i < space; i += 1) { indent += " " } } else { if (typeof space === "string") { indent = space } } rep = replacer; if (replacer && typeof replacer !== "function" && (typeof replacer !== "object" || typeof replacer.length !== "number")) { throw new Error("JSON.stringify") } return str("", { "": value }) } } if (typeof JSON.parse !== "function") { JSON.parse = function (text, reviver) { var j; function walk(holder, key) { var k, v, value = holder[key]; if (value && typeof value === "object") { for (k in value) { if (Object.prototype.hasOwnProperty.call(value, k)) { v = walk(value, k); if (v !== undefined) { value[k] = v } else { delete value[k] } } } } return reviver.call(holder, key, value) } text = String(text); cx.lastIndex = 0; if (cx.test(text)) { text = text.replace(cx, function (a) { return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) }) } if (/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) { j = eval("(" + text + ")"); return typeof reviver === "function" ? walk({ "": j }, "") : j } throw new SyntaxError("JSON.parse") } }
}());
var rsw_errorHandler = null;
var rapidSpellExtension = {
 useWCFService: true,
 useASMXService: false,
 useServlet: false,
 useAPIController: false,

 serviceProxy: new function () {
 var _I = this;
 this.isBusy = false;
 this.haveLogged = false;
 this.appendURLString = rsS47[17];
 this.commonFolderUrl = rsw_scriptLocation.substring(0, rsw_scriptLocation.length-1);



 this.invoke = function (method, data, callback, errorHandler, bare, POSTGET) {
 if(typeof errorHandler==rsS47[3])
 rsw_errorHandler = errorHandler;
 if (typeof (POSTGET) == rsS47[5])
 POSTGET = rsS47[193];
 if (rapidSpellExtension.useWCFService)
 this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl + rsS47[194];
 else if (rapidSpellExtension.useASMXService)
 this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl + rsS47[195];
 else if (rapidSpellExtension.useAPIController) this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl + rsS47[196]; else if (rapidSpellExtension.useServlet) {
 var pp = rapidSpellExtension.serviceProxy.commonFolderUrl.indexOf(rsS47[197]);
 this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl.substring(0, pp) + rsS47[198];
 }

 this.isBusy = true;


 var url = _I.serviceUrl + method + this.appendURLString;

 function htmlEncode(s) {
 return s.replace(/&/g, rsS47[14]).replace(/</g, rsS47[21])
 .replace(/>/g, rsS47[22]);
 }


 if (rapidSpellExtension.useASMXService) {
 var wrapdata = rsS47[199] + encodeURIComponent(htmlEncode(JSON.stringify(data)));
 if (!this.haveLogged)
 console.log(rsS47[200]);
 this.haveLogged = true;
 $.ajax({
 cache: false,
 url: url,
 data: wrapdata, type: POSTGET,
 processData: true,
 contentType: rsS47[201], timeout: 30000,
 dataType: rsS47[202], success:
 function (res) {
 if (!callback) return;

 var firstBrace = res.indexOf(rsS47[203]);
 var lastBrace = res.lastIndexOf(rsS47[204]);
 bare = true;
 var result = null;

 if (firstBrace > -1 && lastBrace > -1)
 result = JSON.parse(res.substring(firstBrace, lastBrace + 1));

 if (bare) {
 if (result.value == null) {
 alert(result.exception);
 } else {
 callback(result.value, rsw_errorHandler);
 }
 return;
 }

 for (var property in result) {
 callback(result[property], rsw_errorHandler);
 break;
 }
 },
 error: function (xhr, textstatus, message) {
 if (typeof rsw_errorHandler == rsS47[3])
 return rsw_errorHandler(xhr, textstatus, message);
 if (xhr.responseText) {
 var err = xhr.responseText; if (err)
 alert(err + rsS47[205] + this.url + rsS47[206] + this.url + rsS47[207]);
 else
 alert(rsS47[208]);
 } else if (textstatus) {
 if (textstatus == rsS47[209]) textstatus = rsS47[210];
 if (textstatus == rsS47[211]) {
 if (xhr.status == 404) {
 textstatus = xhr.status + ' error from server. \r\nTry calling (in Javascript) \r\n\r\nrapidSpell.commonFolderUrl = "/Keyoti_RapidSpell_Web_Common/";\r\n\r\nwith the correct path to the folder that contains RapidSpellService.svc and/or RapidSpellService.asmx\r\n';
 } else
 textstatus = xhr.status + rsS47[212];
 }
 alert(textstatus + rsS47[213] + this.url + rsS47[206] + this.url + rsS47[207]);
 }
 $(rsS47[214]).remove();
 return;
 }
 });
 } else {

 var json = JSON.stringify(data);
 if (!this.haveLogged) {
 if (!rapidSpellExtension.useAPIController) console.log(rsS47[215]);
 else console.log(rsS47[216]); }
 this.haveLogged = true;
 var ajDat = {
 url: url,

 type: POSTGET,


 success:
 function (res) {
 rapidSpellExtension.serviceProxy.isBusy = false;
 if (!callback) return;

 var result = JSON.parse(res);



 if (bare) {
 if (result.value == null) {
 alert(result.exception);
 } else {
 callback(result.value, rsw_errorHandler);
 }
 return;
 }

 if (rapidSpellExtension.useServlet) {
 if (result.error != null && result.error.length > 0) {
 alert(result.error);
 return;
 }
 callback(result, rsw_errorHandler);
 } else {
 if (typeof result[rsS47[217]] == rsS47[5]) { if (result.exception != null && result.exception.length > 0) {
 alert(result.exception);
 return;
 }
 callback(result.value, rsw_errorHandler); } else {
 for (var property in result) {
 if (result[property].exception != null && result[property].exception.length > 0) {
 alert(result[property].exception);
 return;
 }
 if (result[property].Exception != null && result[property].Exception.length > 0) {
 alert(result[property].Exception);
 return;
 }
 callback(result[property].value, rsw_errorHandler);
 break;
 }
 }
 }
 },
 error: function (xhr, textstatus, message) {
 if (typeof rsw_errorHandler == rsS47[3])
 return rsw_errorHandler(xhr, textstatus, message);
 if (xhr.status == 500 && xhr.responseText.length == 0) {
 alert(rsS47[218]);
 }
 rapidSpellExtension.serviceProxy.isBusy = false;
 if (typeof xhr.responseText !== rsS47[5] && xhr.responseText.indexOf(rsS47[219]) > -1) alert(rsS47[220]);
 if (xhr.responseText) {
 var err;
 try {
 err = JSON.parse(xhr.responseText);
 } catch (ee) {
 err = { Message: rsS47[221] + this.url + rsS47[206] + this.url + rsS47[207] + rsS47[222] + xhr.responseText };
 }
 if (err) {
 err.Message += rsS47[205] + this.url + rsS47[206] + this.url + rsS47[207];
 alert(err.Message);
 } else
 alert(rsS47[208] + rsS47[205] + this.url + rsS47[206] + this.url + rsS47[207]);
 } else if (textstatus) {
 if (textstatus == rsS47[209]) textstatus = rsS47[210];
 if (textstatus == rsS47[211]) {
 if (xhr.status == 404) {
 textstatus = xhr.status + ' error from server. \r\nTry calling (in Javascript) \r\n\r\nrapidSpellExtension.commonFolderUrl = "/Keyoti_RapidSpell_Web_Common/";\r\n\r\nwith the correct path to the folder that contains RapidSpellService.svc\r\n';
 } else
 textstatus = xhr.status + rsS47[212];
 }
 alert(textstatus + rsS47[213] + this.url + rsS47[206] + this.url + rsS47[207]);
 }
 $(rsS47[214]).remove();
 return;
 }
 };
 }

 if (rapidSpellExtension.useWCFService || rapidSpellExtension.useAPIController) { ajDat.data = json;
 ajDat.contentType = rsS47[223];
 ajDat.timeout = 30000;
 ajDat.dataType = rsS47[202];
 ajDat.processData = false;
 ajDat.cache = false;

 } else if (rapidSpellExtension.useServlet) {
 ajDat.data = { data: json };
 ajDat.timeout = 30000;
 ajDat.dataType = rsS47[202];
 ajDat.cache = false;
 }
 if (typeof ($) === rsS47[5]) alert(rsS47[224]);
 $.ajax(ajDat);
 };
 }
};











var rsw_RapidSpell_Launcher = true;
var rsw_warnNoTextBoxes = true;
if (!rsw_RapidSpell_Core) alert(rsS47[225]);
rapidSpell.dialog_popupURL = rsw_scriptLocation + rsS47[226];
rapidSpell.dialog_blankURL = null; 
rapidSpell.dialog_modal = false;
rapidSpell.dialog_width = 370;
rapidSpell.dialog_height = navigator.userAgent.indexOf(rsS47[37]) > -1 ? 430 : 400;
rapidSpell.dialog_default_width = rapidSpell.dialog_width;
rapidSpell.dialog_default_height = 400;

rapidSpell.dialog_left = 100;
rapidSpell.dialog_top = 100;
rapidSpell.dialog_documentDomain = rsS47[17];
rapidSpell.dialog_ignoreTextBoxIds = new Array();
rapidSpell.dialog_useDivDialog = false;
rapidSpell.dialog_closedInternally = false;
rapidSpell.dialog_div_dialog_position = { my: rsS47[227], at: rsS47[227], of: window };

rapidSpell.dialog_setUseDivDialog = function (v) {
 var oldOnload = onload;
 function loadJQueryUI() {
 if (typeof jQuery.ui == rsS47[5]) {
 rsw_loadHead(rsS47[228], rsS47[46] + rsS47[229], null);
 rsw_loadHead(rsS47[41], rsS47[46] + rsS47[230], null);
 }
 };
 function f(v){
 rapidSpell.useAJAXWebService = v;
 rapidSpell.dialog_useDivDialog = v;
 if (rapidSpell.dialog_useDivDialog) {

 rapidSpell.dialog_width = rapidSpell.dialog_default_width * 1.0;
 rapidSpell.dialog_height = rapidSpell.dialog_default_height * 1.15;
 if (/Edg/.test(navigator.userAgent)) {
 rapidSpell.dialog_height = rapidSpell.dialog_height * 1.05; }


 if (typeof jQuery == rsS47[5]) {

 
 rsw_loadHead(rsS47[41], rsS47[46] + rsS47[231], loadJQueryUI);

 } else {
 loadJQueryUI();
 }
 } else {
 rapidSpell.dialog_width = rapidSpell.dialog_default_width;
 rapidSpell.dialog_height = rapidSpell.dialog_default_height;
 }
 }

 if (rs_s3.readyState !== rsS47[181]) {

 onload = function () {
 if (typeof oldOnload === rsS47[3]) oldOnload();

 
 f(v);
 }
 } else {

 f(v);

 }
};

var rsw_mult_use_update = true;
var rsTCInt = new Object();



RapidSpell.prototype.dialog_spellCheck = rswm_RunSpellCheck;

function rsw_dialogOptionsClosed() {
 rsw_currentlyChecker = 0;
 if (rswm_PopUpWin != null && typeof rswm_PopUpWin.rsw_finish == rsS47[3]) rswm_PopUpWin.rsw_finish();
 setTimeout(function () { rswm_RunSpellCheck(true, rsw_passedOptionalIDs); }, 500);
}

function rsw_isTextBoxIgnoredDialog(tbId) {
 for (var i = 0; i < rapidSpell.dialog_ignoreTextBoxIds.length; i++)
 if (tbId == rapidSpell.dialog_ignoreTextBoxIds[i]) return true;
 return false;
}

function rsw_getStyleProperty(obj, IEStyleProp) {

 if (obj.currentStyle) { return obj.currentStyle[IEStyleProp];
 } else if (rs_s3.defaultView.getComputedStyle) { return rs_s3.defaultView.getComputedStyle(obj, null)[IEStyleProp]; } else {
 return null;
 }
}

function rsw_setup_SpellControls(optionalID) {
 if (typeof (optionalID) == rsS47[232]) rsw_setup_SpellControls_Array([optionalID]);
 else rsw_setup_SpellControls_Array(optionalID);
}

function rsw_setup_SpellControls_Array(optionalIDs){
 rsw_targetIDs = [];
 var myElements = [];
 var givenIDs = false;

 if (typeof (optionalIDs) != rsS47[5] && optionalIDs.length > 0) {
 givenIDs = true;
 for (var i = 0; i < optionalIDs.length; i++) {
 var el = rs_s3.getElementById(optionalIDs[i]);
 if (el != null) myElements[myElements.length] = el;
 }
 } else {
 for (var f = 0; f < rs_s3.forms.length; f++) {
 for (var g = 0; g < rs_s3.forms[f].elements.length; g++) {
 myElements[myElements.length] = rs_s3.forms[f].elements[g];
 }
 }
 }


 var optionalID;
 
 var more;
 
 
 for (var i = 0; i < myElements.length; i++) {
 var cobj = myElements[i];

 var idPtr = 0;
 if (typeof (optionalIDs) != rsS47[5] && optionalIDs.length > idPtr) 
 optionalID = optionalIDs[idPtr];

 more = true;
 while (more)
 {
 if ((typeof (optionalID) != rsS47[5] && cobj.id == optionalID) || typeof (optionalID) == rsS47[5]) {


 if ((((cobj.tagName == rsS47[24] && cobj.type.toLowerCase() == rsS47[202]) ||
 (cobj.tagName == rsS47[23]) || (cobj.tagName == rsS47[32])) &&
 (!rsw_ignoreReadyOnlyTextBoxes || !cobj.readOnly) &&
 (!rsw_ignoreDisabledTextBoxes || !cobj.disabled) && cobj.value != rsS47[17])
 && cobj.getAttribute(rsS47[183]) != rsS47[29] && !rsw_isParentIsNoSpell(cobj)
 && rsw_isElementVisible(cobj)
 && cobj.id!=rsS47[17]
 && !rsw_isTextBoxIgnoredDialog(cobj.id)
 ) {
 rsw_targetIDs[rsw_targetIDs.length] = cobj.id;
 } else if (givenIDs &&
 (!rsw_ignoreReadyOnlyTextBoxes || !cobj.readOnly) &&
 (!rsw_ignoreDisabledTextBoxes || !cobj.disabled) && cobj.value != rsS47[17] && cobj.id != rsS47[17]) {
 rsw_targetIDs[rsw_targetIDs.length] = cobj.id;
 }

 }
 more = (typeof (optionalIDs) != rsS47[5] && optionalIDs.length > ++idPtr);
 if (more) optionalID = optionalIDs[idPtr];
 }
 }

 if (rsw_targetIDs.length == 0 && typeof(optionalID)!=rsS47[5]) {
 rsw_targetIDs[rsw_targetIDs.length] = optionalID;
 }

 rsw_rapidSpellControls = [];
 for (var i = 0; i < rsw_targetIDs.length; i++) {
 if (typeof (rapidSpell.textInterfaceNeeded) == rsS47[3]) rsTCInt[rsS47[233] + i] = new rapidSpell.textInterfaceNeeded(rsw_targetIDs[i], rsS47[234]);
 else rsTCInt[rsS47[233] + i] = new RSAutomaticInterface(rsw_targetIDs[i]);
 
 
 rsw_rapidSpellControls[i] = rsS47[233] + i;
 }
}



function rsw_findTextBoxes() {


 var textareas = rs_s3.getElementsByTagName(rsS47[235]);
 var inputs = rs_s3.getElementsByTagName(rsS47[236]);
 for (var i = 0; i < textareas.length; i++) {
 if (!textareas[i].readOnly && !textareas[i].disabled && textareas[i].getAttribute(rsS47[183]) != rsS47[29] && !rsw_isParentIsNoSpell(textareas[i]))
 rsw_targetIDs[rsw_targetIDs.length] = textareas[i].id;
 }

 for (var i = 0; i < inputs.length; i++) {
 if (!inputs[i].readOnly && !inputs[i].disabled && inputs[i].type.toLowerCase() == rsS47[202] && inputs[i].getAttribute(rsS47[183]) != rsS47[29] && !rsw_isParentIsNoSpell(inputs[i]))
 rsw_targetIDs[rsw_targetIDs.length] = inputs[i].id;
 }

 for (var i = 0; i < rsw_targetIDs.length; i++) {
 if (typeof (rapidSpell.textInterfaceNeeded) == rsS47[3]) rsTCInt[rsS47[233] + i] = new rapidSpell.textInterfaceNeeded(rsw_targetIDs[i], rsS47[234]);
 else rsTCInt[rsS47[233] + i] = new RSAutomaticInterface(rsw_targetIDs[i]);
 
 rsw_rapidSpellControls[i] = rsS47[233] + i;
 }

 if (typeof (rsS47[237]) == rsS47[3]) rsw_oldOnLoad();
}

function RSStandardInterface(tbElementName) {
 this.tbName = tbElementName;
 this.getText = getText;
 this.setText = setText;
 function getText() {
 return rs_s3.getElementById(this.tbName).value;
 }
 function setText(text) {
 rs_s3.getElementById(this.tbName).value = text;
 }
}
function rsw_escQuotes(text) {
 var rx = new RegExp("\"", rsS47[11]);
 return text.replace(rx, rsS47[12]);
}
function rsw_escEntities(text) {
 var rx = new RegExp(rsS47[13], rsS47[11]);
 text = text.replace(rx, rsS47[14]);
 for (var i = 161; i <= 255; i++) {
 rx = new RegExp(String.fromCharCode(i), rsS47[11]);
 text = text.replace(rx, rsS47[238] + i + rsS47[239]);
 }
 return text;
}


function rsw_getrsw_spellBootString(interfaceObject) {
 var res = new String();
 var textBox = rs_s3.getElementById(interfaceObject.tbName);
 for(var i=0; i<rsw_config_defaults.keys.length; i++){
 var key = rsw_config_defaults.keys[i];
 var value = rsw_config_defaults.values[i];
 var cval = rsw_getParameterValue(textBox, key);
 if (cval != null) value = cval;
 if (key == rsS47[40]) value = false; res += rsS47[240] + key + rsS47[241] + value + rsS47[206];

 }
 return res;
 }


 function rsw_createSpellBoot(interfaceObject, interfaceObjectName) {
 rsw_spellBoot = "<html><head>"+
 (!rsw_isDocDomainSpec() ? '' : "<script type='text/javascript'>document.domain='" + rapidSpell.dialog_documentDomain + "';</script>") +
 "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'></head><body onload=\"if(navigator.userAgent.indexOf('MSIE') > -1)docu" + "ment.forms[0].submit();\"><font face='arial, helvetica' size=2>Spell checking docu" + "ment...</font><form action='" + rapidSpell.dialog_popupURL + "' method='post' ACCEPT-CHARSET='UTF-8'>";
																																						
 rsw_spellBoot += "<input type='hidden' name='docdomain' value='"+rapidSpell.dialog_documentDomain+"'><input type='hidden' name='FinishedListener' value='rswm_NotifyDone'><input type='hidden' name='InterfaceObject' value=\"" + interfaceObjectName + "\"><input type='hidden' name='textToCheck' value=\"" + rsw_escQuotes(rsw_escEntities(interfaceObject.getText())) + "\"><input type='hidden' name='mode' value='popup'><input type='hidden' name='callBack' value=''><input type='hidden' name='RswlClientID' value='r7a4z4'><input type='hidden' name='UseUpdate' value='" + (typeof (rsw_mult_use_update) != 'undefined' ? rsw_mult_use_update : '') + "'>";
																																						
 rsw_spellBoot += rsw_getrsw_spellBootString(interfaceObject);

 rsw_spellBoot += "<scri" + "pt type='text/javascript'>if(navigator.userAgent.indexOf('MSIE') == -1"+(rsw_isDocDomainSpec()?' || true':'')+")docu" + "ment.forms[0].submit();</scri" + "pt></form></body></html>";
																																						
 }

 function rsw_isDocDomainSpec(){
 return (rapidSpell.dialog_documentDomain!=null && rapidSpell.dialog_documentDomain.length>0);
 }

var rsw_spellBoot = rsS47[17];
function rsw_popUpCheckSpelling(interfaceObject, interfaceObjectName) {
 rsw_createSpellBoot(interfaceObject, interfaceObjectName);
 if (typeof (rsw_mult_use_update) != rsS47[5] && rsw_mult_use_update) RS_writeDoc(rswm_PopUpWin.addWordFrame); else RS_writeDoc(rswm_PopUpWin);
 rswm_PopUpWin.focus();
}
function RS_writeDoc(toWindow) {
 if(!rsw_isDocDomainSpec())toWindow.document.open();
 toWindow.document.write(rsw_spellBoot);
 if (!rsw_isDocDomainSpec()) toWindow.document.close();
}

function rsw_loadHead(element, src, callback) {
 var haveDoneCallBack = false;
 var script = rs_s3.createElement(element);
 if (element == rsS47[41]) {
 
 script.src = src;
 rs_s3.getElementsByTagName(rsS47[242])[0].appendChild(script);
 } else if (element == rsS47[228]) {
 script.href = src;
 script.setAttribute(rsS47[243], rsS47[244]);
 rs_s3.getElementsByTagName(rsS47[242])[0].appendChild(script);
 }

 script.onload = function () {
 if (callback != null && !haveDoneCallBack) {
 callback();
 haveDoneCallBack = true;
 }
 };
 script.onreadystatechange = function () {
 
 if (script.readyState === rsS47[245] || script.readyState === rsS47[181]) {
 if (!haveDoneCallBack && callback != null)
 callback();
 haveDoneCallBack = true;
 }
 
 }
}


var checking = false;
var rswm_PopUpWin;
var checkCompleted = true;
var rsw_currentlyChecking = 0;
var rsw_passedOptionalIDs = null;
function rswm_RunSpellCheck(buttonClick, optionalID) {
 rsw_passedOptionalIDs = optionalID;
 

 if (rapidSpell.dialog_useDivDialog) return rapidSpell._dialog_spellCheck2(rapidSpell.dialog_modal, optionalID);

 if (typeof (buttonClick) == rsS47[5]) buttonClick = true;
 if (buttonClick) {

 rsw_setup_SpellControls(optionalID);
 if (rsw_rapidSpellControls.length == 0) {
 rswm_NotifyDone(true);
 return;
 }
 }

 checkComplete = true;
 if (eval(rsS47[246] + rsw_rapidSpellControls[rsw_currentlyChecking] + '_SpellChecker)!="undefined"')) {
 eval(rsS47[247] + rsw_rapidSpellControls[rsw_currentlyChecking] + rsS47[248]);
 if (rsw_currentlyChecking == 0) {
 isOverlayed = false;
 for (var ch = 0; ch < rsw_rapidSpellControls.length; ch++) {
 eval(rsS47[249] + rsw_rapidSpellControls[ch] + rsS47[248]);
 if (cs == rsS47[250]) isOverlayed = true;
 }
 }
 if (isOverlayed && curState != rsS47[250]) {
 rswm_NotifyDone(true);
 } else {
 eval(rsw_rapidSpellControls[rsw_currentlyChecking] + rsS47[251]);
 }
 } else {
 try {
 if (rswm_PopUpWin != null && !rswm_PopUpWin.closed) { }
 } catch (e) {
 rswm_PopUpWin = null;
 }
 if (buttonClick && rswm_PopUpWin != null && !rswm_PopUpWin.closed) {
 rswm_PopUpWin.focus();
 } else {
 if (buttonClick) {
 checking = true;
 rsw_currentlyChecking = 0;
 }
 if (!(rsw_currentlyChecking > 0 && rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]].getText() == rsS47[17])) {
 rsw_broadcastEvent(rsS47[252], null, rs_s3.getElementById(rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]].tbName));
 rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]].hasRun = true;
 if (rapidSpell.dialog_modal && !rapidSpell.dialog_useDivDialog) {
 rapidSpell.setParameterValue(rsS47[182], rsS47[68], true);
 rapidSpell.setParameterValue(rsS47[182], rsS47[59], true);
 rsw_mult_use_update = false;
 rsw_createSpellBoot(rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]], rsS47[253] + rsw_rapidSpellControls[rsw_currentlyChecking] + rsS47[254]);
 


 rsw_modal_pair = [window, rsw_spellBoot];
 showModalDialog(rsw_modalHelperURL, rsw_modal_pair, rsS47[255] + (rapidSpell.dialog_height + 10) + rsS47[256] + (rapidSpell.dialog_width + 15) + rsS47[257] + (rapidSpell.dialog_left >= 0 ? rsS47[258] + rapidSpell.dialog_left + rsS47[259] : rsS47[17]) + (rapidSpell.dialog_top >= 0 ? rsS47[260] + rapidSpell.dialog_top + rsS47[259] : rsS47[17]) + rsS47[261]);
																																						
 if (rsw_chrome) {
 rsw_currentlyChecking = rsw_rapidSpellControls.length;
 }
 if (rsw_currentlyChecking < rsw_rapidSpellControls.length && checkCompleted)
 rswm_RunSpellCheck(false);
 

 } else{


 if (checking && (rswm_PopUpWin == null || rswm_PopUpWin.closed)) {
 if (rapidSpell.dialog_blankURL == null) rapidSpell.dialog_blankURL = rsw_resourceLocation + rsS47[262];
 if (rapidSpell.dialog_documentDomain != null && rapidSpell.dialog_documentDomain != rsS47[17] && rapidSpell.dialog_blankURL.indexOf(rsS47[263]) == -1) rapidSpell.dialog_blankURL += (rapidSpell.dialog_blankURL.indexOf(rsS47[264]) > -1 ? rsS47[13] : rsS47[264]) + rsS47[265] + rapidSpell.dialog_documentDomain;
																																						
 if (typeof (rsw_create_popup_window) == rsS47[3]) {
 rswm_PopUpWin = rsw_create_popup_window((rsw_isDocDomainSpec() ? (rapidSpell.dialog_blankURL) : rsS47[17]), rsS47[266], rsS47[267] + rapidSpell.dialog_left + rsS47[268] + rapidSpell.dialog_top + rsS47[269] + rapidSpell.dialog_width + rsS47[270] + rapidSpell.dialog_height);
																																						
 } else {
 if (rapidSpell.dialog_useDivDialog) {
 createDialogWin(rapidSpell.dialog_modal);
 } else {
 rswm_PopUpWin = rs_s2.open((rsw_isDocDomainSpec() ? (rapidSpell.dialog_blankURL) : rsS47[17]), rsS47[266], rsS47[267] + rapidSpell.dialog_left + rsS47[268] + rapidSpell.dialog_top + rsS47[269] + rapidSpell.dialog_width + rsS47[270] + rapidSpell.dialog_height);
																																						
 }
 }
 if(rsw_isDocDomainSpec())rsw_waitForLoad(rswm_PopUpWin);
 var oldUnload = rs_s2.onunload; rs_s2.onunload = function () { if (typeof (oldUnload) == rsS47[3]) oldUnload(); if (rswm_PopUpWin != null && !rsw_getParameterValue(rsS47[182], rsS47[73])) rswm_PopUpWin.close();
																																						 };

 }
 if (rswm_PopUpWin != null && !rswm_PopUpWin.closed) {
 rsw_mult_use_update = true && rsw_currentlyChecking > 0;
 rsw_popUpCheckSpelling(rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]], rsS47[253]+rsw_rapidSpellControls[rsw_currentlyChecking]+rsS47[254]);
 rsw_mult_use_update = false;
 }
 }
 } else rswm_NotifyDone(true);
 }
 }
}


function rsw_waitForLoad(win) {
 var i = 0;
 while (!win.loaded && i++ < 9900000) {
 }
}

function rswm_NotifyDone(rsw_spellCheckFinished) {
 
 var tb = rsw_rapidSpellControls.length == 0?rsS47[182]: rs_s3.getElementById(rsTCInt[rsw_rapidSpellControls[rsw_rapidSpellControls.length - 1]].tbName); var v = rsw_getParameterValue(tb, rsS47[40]);
 var showMesg = v == rsS47[29] || v==true;

 rsw_currentlyChecking++;
 checkCompleted = rsw_spellCheckFinished;
 if (rapidSpell.dialog_modal && !rapidSpell.dialog_useDivDialog) {
 if (rsw_spellCheckFinished && showMesg) alert(rsw_getLanguageArray(rsw_getParameterValue(tb, rsS47[57]))[7]);
 return;
 }

 

 if (rsw_currentlyChecking < rsw_rapidSpellControls.length && rsw_spellCheckFinished) {
 rsw_broadcastEvent(rsS47[271], null, rs_s3.getElementById(rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking-1]].tbName), rsw_spellCheckFinished);
 rswm_RunSpellCheck(false);
 } else {
 checking = false;
 if (rsw_spellCheckFinished && showMesg) {
 if (rswm_PopUpWin) {
 try { rswm_PopUpWin.alert(rsw_getLanguageArray(rsw_getParameterValue(tb, rsS47[57]))[7]); }
 catch (x) { alert(rsw_getLanguageArray(rsw_getParameterValue(tb, rsS47[57]))[7]) }
 } else alert(rsw_getLanguageArray(rsw_getParameterValue(tb, rsS47[57]))[7]);
 }
 if (rswm_PopUpWin && !rsw_getParameterValue(tb, rsS47[73])) rswm_PopUpWin.close();
 if (rsw_rapidSpellControls.length > rsw_currentlyChecking - 1) {
 rsw_broadcastEvent(rsS47[271], null, rs_s3.getElementById(rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking - 1]].tbName), rsw_spellCheckFinished);
 rsw_broadcastEvent(rsS47[272], null, null, rsw_spellCheckFinished);

 if (rapidSpell.dialog_useDivDialog) {
 if (!rsw_getParameterValue(rsS47[182], rsS47[73]))
 $(rsS47[273]).dialog(rsS47[274]);

 rswm_PopUpWin = null;
 }

 if (typeof (rsw_refreshUnderlines) == rsS47[3] && !rsw_ie9 && !rsw_msie11) rsw_refreshUnderlines(); } else {
 rsw_broadcastEvent(rsS47[271], null, null, rsw_spellCheckFinished);
 rsw_broadcastEvent(rsS47[272], null, null, rsw_spellCheckFinished);
 }
 
 rsw_currentlyChecking = 0;
 
 }
}



function RSAutomaticInterface(tbElementName) {

 this.tbName = tbElementName; this.getText = getText; this.setText = setText;
 this.identifyTarget = identifyTarget;
 this.target = null;
 this.targetContainer = null;
 this.searchedForTarget = false;
 this.targetIsPlain = true;
 this.showNoFindError = showNoFindError;
 this.finder = null;

 this.findContainer = findContainer;

 function findContainer() {
 this.identifyTarget();
 return this.targetContainer;
 }

 function showNoFindError() {
 alert(rsS47[18] + this.tbName + rsS47[19]);
 }

 function identifyTarget() {
 if (!this.searchedForTarget) {
 this.searchedForTarget = true;

 if (this.finder == null)
 this.finder = new RSW_EditableElementFinder();

 var plain = this.finder.findPlainTargetElement(this.tbName);
 var richs = this.finder.findRichTargetElements();

 if (plain == null && (richs == null || richs.length == 0) && !rsw_suppressWarnings) showNoFindError();
 else {

 if (richs == null || richs.length == 0) { this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 } else {


 if (plain == null && richs.length == 1) { this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[0][0]);
 this.targetContainer = richs[0][1];

 } else {
 
 var findIdentical = false;
 for (var rp = 0; rp < richs.length && !findIdentical; rp++)
 findIdentical = typeof (richs[rp][1].id) != rsS47[5] && richs[rp][1].id == this.tbName + rsS47[20];

 for (var rp = 0; rp < richs.length; rp++) {
 if (typeof (richs[rp][1].id) != rsS47[5] &&
 (
 (!findIdentical && richs[rp][1].id.indexOf(this.tbName) > -1) ||
 (findIdentical && richs[rp][1].id == this.tbName)
 )) {
 if (plain != null && richs[rp][1].id == plain.id + rsS47[20]) {
 this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 break;
 } else {
 this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[rp][0]);
 this.targetContainer = richs[rp][1];
 break;
 }
 }
 }

 if (this.target == null) { this.target = plain;
 this.targetIsPlain = true;
 this.targetContainer = plain;
 }
 }
 }
 }
 }
 }
 function getText() {
 this.identifyTarget();


 if (this.targetIsPlain)
 return this.target.value;
 else
 return this.target.innerHTML;
 }
 function setText(text) {
 this.identifyTarget();

 if (this.targetIsPlain) {
 var ver = rsw_getInternetExplorerVersion();
 if (ver > 0 && ver < 7) text = text.replace(/</g, rsS47[21]).replace(/>/g, rsS47[22]); 
 this.target.value = text;
 } else
 this.target.innerHTML = text;

 if (typeof (rsw_tbs) != rsS47[5]) {
 for (var i = 0; i < rsw_tbs.length; i++) {

 if (rsw_tbs[i].shadowTB.id == this.tbName) {
 if (rsw_tbs[i].updateIframe) { rsw_tbs[i].updateIframe(); }
 }
 }
 }
 }
}

function RSW_EditableElementFinder() {
 this.findPlainTargetElement = findPlainTargetElement;
 this.findRichTargetElements = findRichTargetElements;
 this.obtainElementWithInnerHTML = obtainElementWithInnerHTML;
 this.findEditableElements = findEditableElements;
 this.elementIsEditable = elementIsEditable;
 this.getEditableContentDocument = getEditableContentDocument;

 function findPlainTargetElement(elementID) {
 var rsw_elected = rs_s3.getElementById(elementID);

 if (rsw_elected != null && rsw_elected.tagName &&
 (rsw_elected.tagName.toUpperCase() == rsS47[23] || rsw_elected.tagName.toUpperCase() == rsS47[24])) {
 return rsw_elected;
 } else
 return null;
 }

 function findRichTargetElements(debugTextBox) {
 var editables = new Array();
 this.findEditableElements(document, editables, window, rsS47[17], debugTextBox);
 return editables;
 }

 function obtainElementWithInnerHTML(editable) {
 if (typeof (editable.innerHTML) != rsS47[5]) return editable;
 else
 if (typeof (editable.documentElement) != rsS47[5])
 return editable.documentElement;

 return null;
 }


 function findEditableElements(node, editables, parent, debugInset, debugTextBox) {
 try {
 var children = node.childNodes;
 var editableElement;

 if (debugTextBox)
 debugTextBox.value += debugInset + node.tagName;

 if ((editableElement = this.elementIsEditable(node)) != null ||
 (editableElement = this.getEditableContentDocument(node, debugTextBox)) != null
 ) {
 if (debugTextBox)
 debugTextBox.value += rsS47[25];
 editables[editables.length] = editableElement;
 }

 if (debugTextBox)
 debugTextBox.value += rsS47[26];

 for (var i = 0; i < children.length; i++) {
 this.findEditableElements(children[i], editables, node, debugInset + rsS47[27], debugTextBox);
 }
 } catch (e) {
 if (debugTextBox)
 debugTextBox.value += debugInset + rsS47[275] + e;
 }
 }

 function elementIsEditable(element) {
 if (
 (
 typeof (element.getAttribute) != rsS47[5] &&
 (
 element.getAttribute(rsS47[28]) == rsS47[29] ||
 element.getAttribute(rsS47[30]) == rsS47[31]
 )
 )
 ||
 (
 (element.contentEditable && element.contentEditable == true) ||
 (element.designMode && element.designMode.toLowerCase() == rsS47[31])
 )
 

 )
 return [element, element]; else return null;
 }

 function getEditableContentDocument(element, debugTextBox) {
 if (element.tagName && element.tagName == rsS47[32]) {
 var kids = new Array();
 if (element.contentWindow && element.contentWindow.document) {

 if (debugTextBox)
 debugTextBox.value += rsS47[33];

 this.findEditableElements(element.contentWindow.document, kids, element, rsS47[34], debugTextBox);


 if (kids.length > 0) { var editable = kids[0][0];
 if (typeof (editable.body) != rsS47[5])
 editable = editable.body;
 return [editable, element]; }
 }
 }
 return null;
 }
}







rapidSpell.dialog_createDialogWinLoader = function () {
 if ($(rsS47[214]).length == 0) {

 var loadLoc = rsw_resourceLocation + rsS47[276];
 if (rapidSpellExtension.useServlet)
 loadLoc = rsS47[277];

 $(rsS47[278]).append('<div id="rsw_dialogLoader"><img src="' + loadLoc + '" /></div>');
 
 $(rsS47[214]).css(rsS47[279], rsS47[280]);
 $(rsS47[214]).css(rsS47[281], Math.max(0, (($(window).height() - $(rsS47[214]).outerHeight()) / 2) +
 $(window).scrollTop()) + rsS47[282]);
 $(rsS47[214]).css(rsS47[283], Math.max(0, (($(window).width() - $(rsS47[214]).outerWidth()) / 2) +
 $(window).scrollLeft()) + rsS47[282]);
 }
};

rapidSpell.dialog_createDialogWin = function () {
 if ($(rsS47[273]).length == 0) {
 $(rsS47[284]).appendTo(rsS47[242]);

 var optionsSnippet = rsS47[17];
 if (rapidSpell.getParameterValue(rsS47[182], rsS47[83]) != rsS47[87] && rapidSpell.getParameterValue(rsS47[182], rsS47[83]) != false)
 optionsSnippet = '<input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[285]] + '" id="rsw_optionsButton" onclick="rsw_showOptions()" tabindex="10" name="rsw_optionsButton" />';
																																						

 $(rsS47[278]).append(
 '<div id="rsw_dialog" nospell="true" title="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[286]] + '" style="display:none;"> \
 <form id="spellCheckerForm" onsubmit="rsw_change(); return false;"> \
 <div id="rsw_fdtl"></div>\
 <div id="rsw_documentTextPanel"> \
 </div> \
 <div id="rsw_changePanel"> \
 <label for="rsw_word"><span>' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[287]] + '</span></label> \
 <input name="rsw_word" type="text" id="rsw_word" size="16" tabindex="4" />\
 <label for="rsw_suggestions"><span>' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[288]] + '</span></label> \
 <select name="rsw_suggestions" id="rsw_suggestions" size="6" onchange="rsw_changeSuggestions()" ondblclick="rsw_change()" tabindex="5">\
 <option value="No Suggestions.">' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[289]] + rsS47[290] + optionsSnippet + '\
 </div> \
 <div id="rsw_buttonPanel"> \
 <div> \
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[103]] + '" id="rsw_ignoreButton" onclick="rsw_ignoreCurrent()" tabindex="1" name="rsw_ignoreButton" />\
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[104]] + '" id="rsw_ignoreAllButton" onclick=" rsw_ignoreAllInstances()" tabindex="2" name="rsw_ignoreAllButton" /> \
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[105]] + '" id="rsw_addButton" onclick="rsw_addCurrent()" tabindex="3" name="rsw_addButton" /> \
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[291]] + '" id="rsw_changeButton" onclick=" rsw_change()" tabindex="6" name="rsw_changeButton" /> \
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[292]] + '" id="rsw_changeAllButton" onclick=" rsw_changeAll()" tabindex="7" name="rsw_changeAllButton" /> \
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[293]] + '" id="rsw_undoButton" onclick=" rsw_undoChange()" tabindex="8" name="rsw_undoButton" /> \
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[294]] + '" id="rsw_cancelButton" onclick=" rsw_finish(true)" tabindex="9" name="rsw_cancelButton" /> \
 </div> \
 </div> \
 </form> \
 <div id="rsw_optionsDialog"> \
 <h1 id="rsw_optionsHeader">' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[295]] + '</h1> \
 <label> \
 <input type="checkbox" id="IgnoreCapitalizedWords"/>' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[296]] + '</label>\
 <label><input type="checkbox" id="IgnoreWordsWithDigits"/>' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[297]] + '</label>\
 <label><input type="checkbox" id="IgnoreURLsAndEmailAddresses"/>' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[298]] + '</label>\
 <label><input type="checkbox" id="IgnoreCase"/>' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])]['Ignore improper case (eg. "australia", "tABle")'] + '</label>\
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[299]] + '" onclick=" rsw_saveOptions()"/>\
 <input type="button" value="' + rsw_dialogValues[rapidSpell.getParameterValue(rsS47[182], rsS47[57])][rsS47[300]] + '" onclick=" rsw_cancelOptions()"/></div>\
 <div id="rsw_optionsDialog_Backing"></div>\
 </div>'
 );
 }
 
 

};



rapidSpell._dialog_spellCheck2 = function (modal, optionalID) {
 rapidSpell.dialog_createDialogWinLoader();


 if (typeof optionalID === rsS47[5]) optionalID = [];

 rsw_setup_SpellControls(optionalID);
 if (rsw_rapidSpellControls.length == 0) {
 console.log(rsS47[301]);
 $(rsS47[214]).remove();
 rswm_NotifyDone(true);
 return;
 }
 
 rsw_cAed = [];
 rsw_iAed = [];
 rsw_ignoreWordIndexes = [];
 rsw_ignoreAllWords = [];
 rsw_hist = [];
 rsw_histPtr = 0;
 rsw_closeOptions();

 var spellParams = [];
 for (var c = 0; c < rsw_rapidSpellControls.length; c++) {
 spellParams[spellParams.length] = rsw_createSpellBootJSON(rsTCInt[rsw_rapidSpellControls[c]].getText(), rs_s3.getElementById(rsTCInt[rsw_rapidSpellControls[c]].tbName));
 }
 rsw_spellCheckForDialog(spellParams);
};





function rsw_escapeHTML(t) {
 if (typeof (t) != rsS47[232]) return t;
 var pos = -1;
 while ((pos = t.indexOf(rsS47[13], pos + 1)) > -1)
 t = t.substring(0, pos) + rsS47[14] + t.substring(pos + 1);


 var exp1 = new RegExp(rsS47[47]);
 while (exp1.test(t)) t = t.replace(exp1, rsS47[21]);

 var exp2 = new RegExp(rsS47[302]);
 while (exp2.test(t)) t = t.replace(exp2, rsS47[22]);
 return t;
}



var rsw_lastResponse;
var rsw_currentlyChecking;
var rsw_haveOpenedDialog = false;
function _rsJSONCallBackDialog(jsonData) {
 $(rsS47[214]).remove();

 rsw_lastResponse = jsonData;
 rsw_openerWindow = window;
 rsw_currentlyChecking = -1;
 rsw_haveOpenedDialog = false;
 rsw_checkNextTextBox();
}


function rsw_checkNextTextBox() {
 
 rsw_currentlyChecking++;
 rsw_currentWordIndex = -1;
 rsw_ignoreWordIndexes = [];
 
 rsw_badWords = rsw_lastResponse[rsw_currentlyChecking];
 rsw_interfaceObject = rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]];
 rsw_text = rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]].getText();
 rsw_showXMLTags = !(rapidSpell.getParameterValue(rs_s3.getElementById(rsw_interfaceObject.tbName), rsS47[6]) == rsS47[29] || rapidSpell.getParameterValue(rs_s3.getElementById(rsw_interfaceObject.tbName), rsS47[6]) == true);
																																						
 var dialog_willOpenDialogEventArgs = { forceOpenDialog : false};
 rsw_broadcastEvent(rsS47[303], null, rsw_badWords.length, dialog_willOpenDialogEventArgs, null);
 if (rsw_badWords.length > 0 || dialog_willOpenDialogEventArgs.forceOpenDialog) {

 var dialogIsOpen = false;
 try {
 dialogIsOpen = $(rsS47[273]).dialog(rsS47[304]);
 rsw_haveOpenedDialog = true;
 } catch (xx) { } if ($(rsS47[273]).length == 0 || dialogIsOpen == false)
 rapidSpell.dialog_createDialogWin();

 $(rsS47[273]).dialog({
 width: rapidSpell.dialog_width,
 height: rapidSpell.dialog_height,
 maxWidth: rapidSpell.dialog_width,
 maxHeight: rapidSpell.dialog_height,
 position: rapidSpell.dialog_div_dialog_position,
 modal: rapidSpell.dialog_modal,
 close: function (event, ui) {
 rsw_broadcastEvent(rsS47[272], null, null, rsw_spellCheckFinished);
 },
 open: function (event, ui) {
 rsw_deactivateButtons();

 var underLoc = rsw_resourceLocation + rsS47[305];
 if (rapidSpellExtension.useServlet)
 underLoc = rsS47[306];

 $(rsS47[307])
 .prop(rsS47[308], rsS47[309])
 .html(rsS47[310] + underLoc + rsS47[311])
 .appendTo(rsS47[242]);

 rsw_documentTextPanel.innerHTML = rsS47[17];

 $(rsS47[312]).find(rsS47[313]).remove();
 $(this).css(rsS47[314], rsS47[186]); $(this).parent().css(rsS47[315], 2500);
 }

 });



 if (rsw_currentlyChecking > 0) rsw_updateHistory();
 rsw_currentWordIndex = 0;
 for (var cAP = 0; cAP < rsw_cAed.length; cAP++) {
 var currCA = rsw_cAed[cAP].text;
 for (var i = 0; i < rsw_badWords.length; i++) {
 if (rsw_badWords[i].text == currCA) {
 rsw_duplicateWord = rsw_badWords[i].suggestions.length > 0 && rsw_badWords[i].suggestions[0] == rsw_removeDuplicateWordText;
 rsw_changeWord(i, rsw_cAed[cAP].r);
 rsw_ignoreWordIndexes[i] = true;
 }
 }
 }


 rsw_activateButtons();
 rsw_broadcastEvent(rsS47[252], null, rs_s3.getElementById(rsw_interfaceObject.tbName));
 rsw_refresh();
 rsw_activateButtons();
 } else {
 if (!rsw_haveOpenedDialog && rsw_currentlyChecking == rsw_rapidSpellControls.length-1) rsw_broadcastEvent(rsS47[272], null, null, true);
 rsw_finish();
 }
 }


var rsw_badWords;
var rsw_enableUndo = true; var rsw_noSuggestionsText = rsS47[289]; var rsw_newlineRule = rsS47[316]; var rsw_scriptFilterLevel = 15; var rsw_removeDuplicateWordText = rsS47[108]; var rsw_cssLink = rsS47[17];
																																						 var rsw_cssLinkURL = rsS47[17];
function rsw_finishedMessageJS() { };
function rsw_noErrorsMessageJS() { };
function changeNotifyCode(index) { rsw_callCorrectionNotifyListener(rsS47[317], rsw_badWords[index].start, rsw_text.substring(rsw_badWords[index].start, rsw_badWords[index].end), rs_s3.getElementById(rsS47[318]).value);
																																						; }
function addNotifyCode(index) { rsw_callAddNotifyListener(rsS47[319], rsw_badWords[index].start, rsw_text.substring(rsw_badWords[index].start, rsw_badWords[index].end), rs_s3.getElementById(rsS47[318]).value);
																																						; }
var rsw_addingText = rsS47[320];
var rsw_guiLanguage = rsS47[88];
var rsw_interfaceObject = rsTCInt[rsS47[321]];
function rsw_finish(closeWindow) {
 if (rsw_addingWord) { setTimeout(rsS47[322] + closeWindow + rsS47[323], 500); return; }


 if (rsw_openerWindow != null && !rsw_openerWindow.closed && rsw_interfaceObject && typeof (rsw_interfaceObject) != rsS47[324] && typeof (rsw_interfaceObject) != rsS47[5]) rsw_interfaceObject.setText(rsw_text);
																																						



 if (closeWindow) {
 rsw_close(closeWindow);
 } else {
 rsw_postFinishedEventToOpener();
 if (rsw_lastResponse.length > rsw_currentlyChecking + 1 && rsw_lastResponse[rsw_currentlyChecking + 1] != null) {
 rsw_checkNextTextBox();
 } else {

 rsw_close();

 var v = rsw_getParameterValue(rsS47[182], rsS47[40]);
 if (v == rsS47[29] || v == true) alert(rsw_getLanguageArray(rsw_getParameterValue(rsS47[182], rsS47[57]))[7]);
 }
 }

}
var rsw_defaultSettings = {}; rsw_defaultSettings[rsS47[75]] = true; rsw_defaultSettings[rsS47[61]] = false; rsw_defaultSettings[rsS47[56]] = false; rsw_defaultSettings[rsS47[325]] = false; var rsw_fieldDisplayTextLabelID = rsS47[326];
																																						
rsw_documentTextBoxStyle = rsS47[327];
rsw_mode = rsS47[328]; rsw_showXMLTags = true; rsw_callBack = rsS47[17]; rsw_userDicFile = rsS47[17]; rsw_hideImages = true;
function rsw_postFinishedEventToOpener() { rsw_broadcastEvent(rsS47[271], null, rs_s3.getElementById(rsTCInt[rsw_rapidSpellControls[rsw_currentlyChecking]].tbName), true); }var rsw_text = rsS47[329];




function rsw_spellCheckForDialog(params) {
 try {

 var req = false;

 rsw_ignoreWordIndexes = [];
 if (typeof rsw_haltProcesses !== rsS47[5] && rsw_haltProcesses) return;
 else if (typeof rsw_cancelCall !== rsS47[5] && rsw_cancelCall) rsw_cancelCall = false;

 if (typeof rsw_ignoreAllWords === rsS47[5]) rsw_ignoreAllWords = [];
 for(var i=0; i<params.length;i++){
 params[i][params[i].length] = { 'ParameterName': 'IAW', 'ParameterValue': rsw_ignoreAllWords.join("|") };
 }
 

 var data = { 'parametersArray': params };
 rapidSpellExtension.serviceProxy.invoke(rsS47[330], data, _rsJSONCallBackDialog);



 } catch (excep) { rsw_logException(excep); }

}



if (typeof (Sys) != rsS47[5] && typeof (Sys.Application) != rsS47[5]) Sys.Application.notifyScriptLoaded();






if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}

var rsw_popupLocation;
var rsw_iAed = new Array(), rsw_cAed = new Array();
var rsw_spellCheckFinished = false;
var rsw_duplicateWord = false;
var rsw_showXMLTags = true;
var rsw_userDicFile = rsS47[17];
var rsw_mode = rsS47[328];
var rsw_callBack = rsS47[17];
var rsw_currentWordIndex = 0;
var rsw_ignoreWordIndexes = new Array();
var rsw_documentTextBoxStyle = rsS47[331];
var rsw_hist = new Array();
var rsw_histPtr = 0;
var rsw_addingWord = false;
var rsw_refreshResetUnload = false;
var rsw_hideImages = true;


var rsw_keyStr = rsS47[332];

var rsw_options = [rsS47[61], rsS47[75], rsS47[325], rsS47[56]];

function rsw_showOptions() {
 rs_s3.getElementById(rsS47[333]).style.display = rsS47[334];
 rs_s3.getElementById(rsS47[335]).style.display = rsS47[334];
 var settings = rsw_loadOptions();
 for (var i = 0; i < rsw_options.length; i++) {
 rs_s3.getElementById(rsw_options[i]).checked = settings[rsw_options[i]];
 }
}

function rsw_close(forceClose) {
 if (typeof rsw_openerWindow.rapidSpell != rsS47[5] && rsw_openerWindow.rapidSpell.dialog_useDivDialog) {
 if (!rsw_getParameterValue(rsS47[182], rsS47[73]) || forceClose) {
 rsw_openerWindow.rapidSpell.dialog_closedInternally = true;
 try { rsw_openerWindow.$(rsS47[273]).dialog(rsS47[274]);
 } catch (xx) { }
 }
 } else
 top.close();
}

function rsw_loadOptions() {
 var r = {};
 for (var i = 0; i < rsw_options.length; i++) {
 var name = rsw_options[i];
 var setting = rsw_CookieJS.get(name);
 if (setting == null) {
 setting = rsw_defaultSettings[name];
 } else
 setting = setting == rsS47[29];
 r[name] = setting;
 }
 return r;
}

function rsw_saveOptions() {
 for (var i = 0; i < rsw_options.length; i++) {
 rsw_CookieJS.set({
 name: rsw_options[i], value: rs_s3.getElementById(rsw_options[i]).checked, path: '/', expires: '2038-01-19, 03:14:09 UTC',
 secure: rs_s2.location.href.indexOf('https:') == 0
 });
 }
 rsw_closeOptions();
 rsw_openerWindow.rsw_dialogOptionsClosed();
}

function rsw_closeOptions() {
 if(rs_s3.getElementById('rsw_optionsDialog_Backing')!=null)
 rs_s3.getElementById('rsw_optionsDialog_Backing').style.display = 'none';
 if (rs_s3.getElementById('rsw_optionsDialog') != null)
 rs_s3.getElementById('rsw_optionsDialog').style.display = 'none';
}

function rsw_cancelOptions() {
 rsw_closeOptions();
}

function rsw_decode64(input) {
 var output = "";
 var chr1, chr2, chr3;
 var enc1, enc2, enc3, enc4;
 var i = 0;

 do {
 enc1 = rsw_keyStr.indexOf(input.charAt(i++));
 enc2 = rsw_keyStr.indexOf(input.charAt(i++));
 enc3 = rsw_keyStr.indexOf(input.charAt(i++));
 enc4 = rsw_keyStr.indexOf(input.charAt(i++));

 chr1 = (enc1 << 2) | (enc2 >> 4);
 chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
 chr3 = ((enc3 & 3) << 6) | enc4;

 output = output + String.fromCharCode(chr1);

 if (enc3 != 64) {
 output = output + String.fromCharCode(chr2);
 }
 if (enc4 != 64) {
 output = output + String.fromCharCode(chr3);
 }
 } while (i < input.length);

 return output;
}

function rsw_callCorrectionNotifyListener(listener, a, b, c) {
 var f = rsw_decode64(listener);
 rsw_openerWindow[f](a, b, c, rsw_interfaceObject.tbName);
}

function rsw_callAddNotifyListener(listener, a, b, c) {
 var f = rsw_decode64(listener);
 rsw_openerWindow[f](a, b, c, rsw_interfaceObject.tbName);
}

function rsw_callFinishListener(listener, rsw_openerWindow) {
 eval("if (rsw_openerWindow!=null && !rsw_openerWindow.closed && rsw_openerWindow." + rsw_decode64(listener) + ") rsw_openerWindow." + rsw_decode64(listener) + "(rsw_spellCheckFinished)");
}

function rsw_onWordAdded() {
 rsw_addingWord = false;
}

function rsw_updateHistory() {
 if (rsw_enableUndo) {
 var curChecking = -1;
 if (rsw_openerWindow != null && !rsw_openerWindow.closed && typeof (rsw_openerWindow.rsw_currentlyChecking) != 'undefined') curChecking = rsw_openerWindow.rsw_currentlyChecking;
 var fieldDisEl = rs_s3.getElementById(rsw_fieldDisplayTextLabelID);
 var elHTML = "";
 if (fieldDisEl) elHTML = fieldDisEl.innerHTML;
 if (rsw_badWords.length > 0) {
 var ia = null;
 if (typeof (rsw_ignoreAllWords) !== 'undefined')
 ia = rsw_cp(rsw_ignoreAllWords);
 rsw_hist[rsw_histPtr] = [rsw_cp(rsw_ignoreWordIndexes), rsw_currentWordIndex, rsw_text, rsw_cp(rsw_badWords), rsw_interfaceObject, curChecking, rsw_getIndices(rsw_badWords), elHTML, rsw_cp(rsw_iAed), rsw_cp(rsw_cAed), rsw_showXMLTags, ia];
																																						
 rsw_histPtr++;
 }
 }
}
function rsw_undoChange() {
 rsw_activateButtons();
 if (rsw_histPtr > 0) {
 rsw_histPtr--;
 if (rsw_hist[rsw_histPtr][4] != rsw_interfaceObject) rsw_interfaceObject.setText(rsw_text);
 rsw_ignoreWordIndexes = rsw_hist[rsw_histPtr][0];
 rsw_currentWordIndex = rsw_hist[rsw_histPtr][1];
 rsw_text = rsw_hist[rsw_histPtr][2];
 rsw_badWords = rsw_hist[rsw_histPtr][3];
 rsw_interfaceObject = rsw_hist[rsw_histPtr][4];
 var curChecking = rsw_hist[rsw_histPtr][5];
 if (typeof (rsw_openerWindow != null && rsw_openerWindow.rsw_currentlyChecking) != 'undefined' && curChecking > -1) rsw_openerWindow.rsw_currentlyChecking = curChecking;
 rsw_setIndices(rsw_badWords, rsw_hist[rsw_histPtr][6]);
 var elHTML = rsw_hist[rsw_histPtr][7];
 var fieldDisEl = rs_s3.getElementById(rsw_fieldDisplayTextLabelID);
 if (fieldDisEl)
 fieldDisEl.innerHTML = elHTML;
 rsw_iAed = rsw_hist[rsw_histPtr][8];
 rsw_cAed = rsw_hist[rsw_histPtr][9];
 rsw_showXMLTags = rsw_hist[rsw_histPtr][10];

 if (typeof (rsw_ignoreAllWords) !== 'undefined') {
 rsw_ignoreAllWords = rsw_hist[rsw_histPtr][11];
 }

 rsw_hist.length = rsw_histPtr + 1;
 if (rsw_currentWordIndex < 0)
 rsw_undoChange();
 else
 rsw_refresh();
 }
}
function rsw_cp(ary) {
 var bry = new Array();
 for (var i = 0; i < ary.length; i++) bry[i] = ary[i];
 return bry;
}
function rsw_getIndices(bw) {
 var a = new Array();
 for (var i = 0; i < bw.length; i++)
 a[i] = [bw[i].start, bw[i].end];
 return a;
}
function rsw_setIndices(bw, a) {
 for (var i = 0; i < bw.length; i++) {
 bw[i].start = a[i][0];
 bw[i].end = a[i][1];
 }
 return a;
}
function rsw_change() {
 rsw_updateHistory();
 if (rsw_currentWordIndex < rsw_badWords.length) {
 rsw_changeWord(rsw_currentWordIndex);
 rsw_nextWord();
 }
}
function rsw_changeAll() {
 rsw_updateHistory();

 if (rsw_currentWordIndex < rsw_badWords.length) {
 var currentWord = rsw_badWords[rsw_currentWordIndex].text;


 var n = rsw_changeWord(rsw_currentWordIndex);
 rsw_cAed[rsw_cAed.length] = { text: currentWord, r: n };
 for (var i = rsw_currentWordIndex + 1; i < rsw_badWords.length; i++) {
 if (!rsw_ignoreWordIndexes[i] && rsw_badWords[i].text == currentWord) {
 rsw_changeWord(i);
 rsw_ignoreWordIndexes[i] = true;

 }
 }
 rsw_nextWord();
 }
}
function rsw_ignoreCurrent() {
 rsw_updateHistory();
 if (rsw_currentWordIndex < rsw_badWords.length) {
 rsw_nextWord();
 }
}
function rsw_ignoreAllInstances() {
 rsw_updateHistory();
 if (rsw_currentWordIndex < rsw_badWords.length) {
 var currentWord = rsw_badWords[rsw_currentWordIndex].text;
 rsw_iAed[rsw_iAed.length] = currentWord;
 if (typeof (rsw_ignoreAllWords) !== 'undefined') {
 rsw_ignoreAllWords[rsw_ignoreAllWords.length] = currentWord;
 }
 rsw_updateIgnoreIndexes(currentWord, rsw_currentWordIndex + 1);
 rsw_nextWord();
 }
}

function rsw_updateIgnoreIndexes(currentWord, fromIdx) {
 for (var i = fromIdx; i < rsw_badWords.length; i++) {
 if (!rsw_ignoreWordIndexes[i] && rsw_badWords[i].text == currentWord) {
 rsw_ignoreWordIndexes[i] = true;
 }
 }
}

function rsw_changeSuggestions() {
 var suggestion = rs_s3.getElementById('rsw_suggestions').options[document.getElementById('rsw_suggestions').selectedIndex].text;
 if (suggestion != rsw_noSuggestionsText) {
 rs_s3.getElementById('rsw_word').value = suggestion;
 }
}
function rsw_deactivateButtons() {
 if (rs_s3.getElementById('rsw_changeButton') != null)
 rs_s3.getElementById('rsw_changeButton').disabled = true;
 if (rs_s3.getElementById('rsw_changeAllButton') != null)
 rs_s3.getElementById('rsw_changeAllButton').disabled = true;
 if (rs_s3.getElementById('rsw_ignoreButton') != null)
 rs_s3.getElementById('rsw_ignoreButton').disabled = true;
 if (rs_s3.getElementById('rsw_ignoreAllButton') != null)
 rs_s3.getElementById('rsw_ignoreAllButton').disabled = true;
 if (rs_s3.getElementById('rsw_addButton') != null)
 rs_s3.getElementById('rsw_addButton').disabled = true;
}
function rsw_activateButtons() {

 if (rs_s3.getElementById('rsw_undoButton') != null)
 rs_s3.getElementById('rsw_undoButton').disabled = rs_s3.getElementById('rsw_undoButton').disabled = rsw_histPtr <= 0;
 if (rs_s3.getElementById('rsw_changeButton') != null)
 rs_s3.getElementById('rsw_changeButton').disabled = false;
 if (rs_s3.getElementById('rsw_changeAllButton') != null)
 rs_s3.getElementById('rsw_changeAllButton').disabled = false;
 if (rs_s3.getElementById('rsw_ignoreButton') != null)
 rs_s3.getElementById('rsw_ignoreButton').disabled = false;
 if (rs_s3.getElementById('rsw_ignoreAllButton') != null)
 rs_s3.getElementById('rsw_ignoreAllButton').disabled = false;
 if (rs_s3.getElementById('rsw_addButton') != null)
 rs_s3.getElementById('rsw_addButton').disabled = false;
}
function rsw_nextWord() {
 var f = true;
 while (rsw_currentWordIndex++ < rsw_badWords.length && rsw_ignoreWordIndexes[rsw_currentWordIndex]);
 
 

 if (rsw_currentWordIndex >= rsw_badWords.length) {
 rsw_deactivateButtons();
 }
 else {
 }
 rsw_refresh();
}
function rsw_convertTextToHtml(t) {
 if (typeof (rsw_textToHtml) != 'undefined') return rsw_textToHtml(t);
 if (rsw_hideImages) {
 t = t.replace(/<img[^>]*>/gi, "");
 }

 t = t.replace(/<iframe[^>]*>/gi, "");
 if (rsw_showXMLTags) {
 var ltexp = new RegExp("<");
 while (ltexp.test(t))
 t = t.replace(ltexp, "&lt;");
 var gtexp = new RegExp(">");
 while (gtexp.test(t)) t = t.replace(gtexp, "&gt;");


 var newlineexp = new RegExp(rsw_newlineRule);
 while (newlineexp.test(t))
 t = t.replace(newlineexp, "<br />");
 }
 return t;
}
var rsw_haveCopiedCSS = false;
var rsw_documentTextPanelIsDiv = false;
function rsw_refresh() {

 rsw_documentTextPanelIsDiv = rs_s3.getElementById('rsw_documentTextPanel').tagName == 'DIV';
 if (rsw_documentTextPanelIsDiv) rsw_documentTextPanel = rs_s3.getElementById('rsw_documentTextPanel');
 
 if (typeof rapidSpell != 'undefined') {
 var fdtl_text = rapidSpell.getParameterValue(rs_s3.getElementById(rsw_interfaceObject.tbName), 'FieldDisplayText');
 if (fdtl_text != null && fdtl_text != '' && rs_s3.getElementById('rsw_fdtl') != null) rs_s3.getElementById('rsw_fdtl').innerHTML = fdtl_text;
 }
 if (rs_s3.getElementById('rsw_undoButton') != null)rs_s3.getElementById('rsw_undoButton').disabled = rsw_histPtr <= 0;
 if (rsw_refreshResetUnload) {
 onunload = windowClosing;
 rsw_refreshResetUnload = false;
 }

 if (rsw_currentWordIndex == 0 && typeof(rsw_ignoreAllWords)!='undefined') {
 for (var i = 0; i < rsw_ignoreAllWords.length; i++) {
 rsw_updateIgnoreIndexes(rsw_ignoreAllWords[i], 0);
 }
 if (rsw_ignoreWordIndexes.length > 0 && rsw_ignoreWordIndexes[0] == true)
 return rsw_nextWord();
 }

 if (rsw_currentWordIndex < rsw_badWords.length) {
 rsw_spellCheckFinished = false;
 var html = ""; var script = "";
 
 script += "function getPageCoords (el) {\n";
 script += " var coords = {x: 0, y: 0};\n var dd='';";
 script += " do {\ndd+=el.tagName+' '+el.offsetLeft+' '+coords.x+'\\r\\n';";
 script += " coords.x += el.offsetLeft;\n";
 script += " coords.y += el.offsetTop;\n";
 script += "dd+='2 '+el.tagName+' '+el.offsetLeft+' '+coords.x+'\\r\\n'; }\n";
 script += " while ((el = el.offsetParent));\n";
 script += " return coords;\n";
 script += "}\n";
 script += "function scrollIntoView(el) {\n";
 script += " var coords = getPageCoords(el);\n";
 script += " rs_s2.scrollTo (coords.x, coords.y);\n";
 script += "}\n";
 html += rsw_ftr(rsw_convertTextToHtml(rsw_text.substring(0, rsw_badWords[rsw_currentWordIndex].start)), rsw_scriptFilterLevel);
 html += '<span id="highlight" class="badWordHighlight">';
 html += rsw_ftr(rsw_text.substring(rsw_badWords[rsw_currentWordIndex].start, rsw_badWords[rsw_currentWordIndex].end), rsw_scriptFilterLevel);
 html += '</span>';
 html += rsw_ftr(rsw_convertTextToHtml(rsw_text.substring(rsw_badWords[rsw_currentWordIndex].end, rsw_text.length)), rsw_scriptFilterLevel);
 if (!rsw_haveCopiedCSS && !rsw_documentTextPanelIsDiv) {
 var documentTextBoxStyleEl = rsw_documentTextPanel.document.createElement("style");
 documentTextBoxStyleEl.type = 'text/css';
 if (documentTextBoxStyleEl.styleSheet) {
 documentTextBoxStyleEl.styleSheet.cssText = rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "");
 } else {
 documentTextBoxStyleEl.appendChild(rsw_documentTextPanel.document.createTextNode(rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "")));
 }
 rsw_haveCopiedCSS = true;


 var scr = rsw_documentTextPanel.document.createElement("script");
 scr.type = 'text/javascript';
 if (typeof (scr.text) == 'string') {
 scr.text = script;
 } else {
 scr.appendChild(rsw_documentTextPanel.document.createTextNode(script));
 }

 try {
 var linkElement = rsw_documentTextPanel.document.createElement('LINK');
 linkElement.type = 'text/css';
 if (rsw_documentTextPanel.document.getElementsByTagName('head')[0].childNodes.length < 10) { rsw_documentTextPanel.document.getElementsByTagName('head')[0].appendChild(linkElement);
 linkElement.setAttribute('href', rsw_cssLinkURL);
 linkElement.setAttribute('rel', 'stylesheet');
 }
 } catch (x) {
 console.log(x);
 }


 rsw_documentTextPanel.document.getElementsByTagName("head")[0].appendChild(documentTextBoxStyleEl);
 rsw_documentTextPanel.document.getElementsByTagName("head")[0].appendChild(scr);
 }

 var documentTextPanelContentEl = rsw_documentTextPanelIsDiv ? rsw_documentTextPanel : rsw_documentTextPanel.document.body;


 documentTextPanelContentEl.innerHTML = html;
 if (!rsw_documentTextPanelIsDiv) {
 documentTextPanelContentEl.setAttribute('marginwidth', 4);
 documentTextPanelContentEl.setAttribute('marginheight', 4);
 documentTextPanelContentEl.setAttribute('topmargin', 4);
 documentTextPanelContentEl.setAttribute('leftmargin', 4);
 }

 
 
 try {
 if (!rsw_documentTextPanelIsDiv && rsw_documentTextPanel.scrollIntoView)
 rsw_documentTextPanel.scrollIntoView(rsw_documentTextPanel.document.getElementById("highlight"));
 if (rsw_documentTextPanelIsDiv) {
 var myElement = rs_s3.getElementById('highlight');
 rsw_documentTextPanel.scrollTop = myElement.offsetTop - myElement.offsetHeight - rsw_documentTextPanel.offsetTop;
 rsw_documentTextPanel.scrollLeft = myElement.offsetLeft;
 }
 } catch (EE) { }
 rs_s3.getElementById('rsw_suggestions').options.length = 0;
 var n = rsw_badWords[rsw_currentWordIndex].suggestions.length;
 if (n == 0) {
 rs_s3.getElementById('rsw_word').value = rsw_badWords[rsw_currentWordIndex].text;
 rs_s3.getElementById('rsw_suggestions').options[0] = new Option(rsw_noSuggestionsText);
 }
 else if (rsw_badWords[rsw_currentWordIndex].suggestions[0] == rsw_removeDuplicateWordText) {
 rs_s3.getElementById('rsw_suggestions').options[0] = new Option(rsw_badWords[rsw_currentWordIndex].suggestions[0]);
 rs_s3.getElementById('rsw_suggestions').selectedIndex = 0;
 rs_s3.getElementById('rsw_word').value = '';
 rsw_duplicateWord = true;
 }
 else {
 rs_s3.getElementById('rsw_word').value = rsw_badWords[rsw_currentWordIndex].suggestions[0];
 for (var i = 0; i < n; i++) {
 rs_s3.getElementById('rsw_suggestions').options[i] = new Option(rsw_badWords[rsw_currentWordIndex].suggestions[i]);
 }
 rs_s3.getElementById('rsw_suggestions').selectedIndex = 0;
 rsw_duplicateWord = false;
 }
 
 }
 else {
 var html = "";
 
 html += rsw_ftr(rsw_convertTextToHtml(rsw_text), rsw_scriptFilterLevel);
 

 if (!rsw_documentTextPanelIsDiv) {

 var documentTextBoxStyleEl = rsw_documentTextPanel.document.createElement("style");
 documentTextBoxStyleEl.type = 'text/css';
 if (documentTextBoxStyleEl.styleSheet) {
 documentTextBoxStyleEl.styleSheet.cssText = rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "");
 } else {
 documentTextBoxStyleEl.appendChild(rsw_documentTextPanel.document.createTextNode(rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "")));
 }



 try {
 var linkElement = rsw_documentTextPanel.document.createElement('LINK');
 linkElement.type = 'text/css';
 if (rsw_documentTextPanel.document.getElementsByTagName('head')[0].childNodes.length < 10) { rsw_documentTextPanel.document.getElementsByTagName('head')[0].appendChild(linkElement);
 linkElement.setAttribute('href', rsw_cssLinkURL);
 linkElement.setAttribute('rel', 'stylesheet');
 }
 } catch (x) {
 console.log(x);
 }



 rsw_documentTextPanel.document.getElementsByTagName("head")[0].appendChild(documentTextBoxStyleEl);
 }


 var documentTextPanelContentEl = rsw_documentTextPanelIsDiv ? rsw_documentTextPanel : rsw_documentTextPanel.document.body;


 documentTextPanelContentEl.innerHTML = html;
 if (!rsw_documentTextPanelIsDiv) {
 documentTextPanelContentEl.setAttribute('marginwidth', 4);
 documentTextPanelContentEl.setAttribute('marginheight', 4);
 documentTextPanelContentEl.setAttribute('topmargin', 4);
 documentTextPanelContentEl.setAttribute('leftmargin', 4);
 }
 
 rs_s3.getElementById('rsw_word').value = "";
 rs_s3.getElementById('rsw_suggestions').options.length = 0;
 rs_s3.getElementById('rsw_suggestions').options[0] = new Option(rsw_noSuggestionsText);
 if (rsw_badWords.length > 0) {
 rsw_finishedMessageJS();
 }
 else {
 rsw_noErrorsMessageJS();
 }
 rsw_spellCheckFinished = true;
 rsw_duplicateWord = false;
 rsw_finish();
 }
 if (typeof (onRefreshed) == 'function') onRefreshed();
}
function rsw_changeWord(index, replacement) {
 if (replacement)
 replacement = replacement;
 else
 replacement = rs_s3.getElementById('rsw_word').value;

 changeNotifyCode(index);
 var newText = "";
 if (rsw_duplicateWord && rs_s3.getElementById('rsw_word').value == '') {
 rsw_badWords[index].start--;
 }
 newText += rsw_text.substring(0, rsw_badWords[index].start);
 newText += replacement;
 newText += rsw_text.substring(rsw_badWords[index].end, rsw_text.length);
 rsw_moveWordOffsets(replacement.length - (rsw_badWords[index].end - rsw_badWords[index].start), index + 1);
 
 rsw_text = newText;

 return replacement;

}
function rsw_moveWordOffsets(delta, start) {
 for (i = start; i < rsw_badWords.length; i++) {
 rsw_badWords[i].start += delta;
 rsw_badWords[i].end += delta;
 }
}
function rsw_addCurrent() {
 var originalAddButtonText = "Add";
 var addBT = rs_s3.getElementById('rsw_addButton');
 rsw_addingWord = true;
 addNotifyCode(rsw_currentWordIndex);
 var currentWord = rsw_badWords[rsw_currentWordIndex].text;
 if (addBT) {
 originalAddButtonText = addBT.value;
 addBT.value = rsw_addingText;
 addBT.disabled = true;
 }
 
 if (typeof rapidSpellExtension != 'undefined' && typeof rapidSpellExtension.serviceProxy != 'undefined') {
rapidSpellExtension.serviceProxy.invoke('AddWord', { 'Word': rsw_badWords[rsw_currentWordIndex].text, 'GuiLanguage': rsw_guiLanguage, 'UserDictionaryFile': rapidSpell.getParameterValue('default', 'UserDictionaryFile') }, function () {
if (addBT) {
 addBT.value = originalAddButtonText;
 if (!rsw_spellCheckFinished)
 addBT.disabled = false;
 }
 rsw_onWordAdded();
 });
 } else {
 addWordFrame.location.href = rsw_popupLocation + (rsw_popupLocation.indexOf(rsS47[264]) > -1 ? rsS47[13] : rsS47[264]) + rsS47[336] + escape(rsw_userDicFile) + rsS47[337] + rsw_badWords[rsw_currentWordIndex].e + rsS47[338] + rsw_guiLanguage + rsS47[17];
																																						
 }
 rsw_ignoreAllInstances();
}
function rsw_ftr(tt, level) {
 switch (level) {
 case 1: return rsw_fsb(tt);
 break;
 case 2: return rsw_feh(tt);
 break;
 case 3: return rsw_ftr(rsw_ftr(tt, 2), 1);
 break;
 case 4: return rsw_fu(tt);
 break;
 case 5: return rsw_ftr(rsw_ftr(tt, 4), 1);
 break;
 case 6: return rsw_ftr(rsw_ftr(tt, 4), 2);
 break;
 case 7: return rsw_ftr(rsw_ftr(tt, 6), 1);
 break;
 case 8: return rsw_fb(tt);
 break;
 case 9: return rsw_ftr(rsw_ftr(tt, 8), 1);
 break;
 case 10: return rsw_ftr(rsw_ftr(tt, 8), 2);
 break;
 case 11: return rsw_ftr(rsw_ftr(tt, 10), 1);
 break;
 case 12: return rsw_ftr(rsw_ftr(tt, 8), 4);
 break;
 case 13: return rsw_ftr(rsw_ftr(tt, 12), 1);
 break;
 case 14: return rsw_ftr(rsw_ftr(tt, 12), 2);
 break;
 case 15: return rsw_fsb(rsw_feh(rsw_fu(rsw_fb(tt))));
 break;
 default: return tt;
 break;
 }
}
function rsw_fsb(tt) {
 var exp = new RegExp(rsS47[339] + rsS47[302], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[17]);
 var exp = new RegExp(rsS47[341], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[17]);
 var exp = new RegExp(rsS47[342], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[17]);
 var exp = new RegExp(rsS47[343], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[17]);
 return tt;
}
function rsw_feh(tt) {
 var exp = new RegExp(rsS47[344], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[345]);
 return tt;
}
function rsw_fu(tt) {
 var exp = new RegExp(rsS47[346], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[347]);
 return tt;
}
function rsw_fb(tt) {
 var exp = new RegExp(rsS47[348] + rsS47[302], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[17]);
 var exp = new RegExp(rsS47[349], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[17]);
 var exp = new RegExp(rsS47[350], rsS47[340]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS47[17]);
 return tt
}


(function (document, window) {
 rsS47[351];

 var rsw_CookieJS = {
 
 set: function (params) {
 var cookie = params.name + rsS47[352] + encodeURI(params.value) + rsS47[239];

 if (params.expires) {
 params.expires = new Date(new Date().getTime() +
 parseInt(params.expires, 10) * 1000 * 60 * 60 * 24);

 cookie += rsS47[353] + params.expires.toUTCString() + rsS47[239];
 }

 cookie += (params.path) ? rsS47[354] + params.path + rsS47[239] : rsS47[17];
 cookie += (params.domain) ? rsS47[355] + params.domain + rsS47[239] : rsS47[17];
 cookie += (params.secure) ? rsS47[356] : rsS47[17];
 cookie += (params.httpOnly) ? rsS47[357] : rsS47[17];

 rs_s3.cookie = cookie;
 },

 
 get: function (name) {
 var parts = rs_s3.cookie.split(name + rsS47[352]);

 if (parts.length >= 2) {
 return decodeURI(parts.pop().split(rsS47[239]).shift());
 }

 return; },

 
 getAll: function () {
 var cookies = {},
 allCookies = rs_s3.cookie,
 cookie;

 if (!allCookies) {
 return cookies;
 }

 var list = allCookies.split(rsS47[259]),
 len = list.length;

 while (len--) {
 cookie = list[len].split(rsS47[352]);

 cookies[cookie[0]] = decodeURI(cookie[1]);
 }

 return cookies;
 },

 
 keys: function () {
 var keys = [],
 allCookies = rs_s3.cookie;

 if (allCookies === rsS47[17]) {
 return keys;
 }

 var list = allCookies.split(rsS47[259]),
 len = list.length;

 while (len--) {
 var key = list[len].split(rsS47[352]);
 keys[len] = key[0];
 }

 return keys;
 },

 
 has: function (name) {
 if (this.get(name)) {
 return true;
 }

 return false;
 },

 
 deleteX: function (params) {
 if (this.get(params.name)) {
 this.set({
 name: params.name,
 value: rsS47[17],
 expires: -1,
 path: params.path,
 domain: params.domain
 });
 }
 },

 del: function () {
 if (console && console.warn) {
 console.warn(
 rsS47[358],
 rsS47[359]
 );
 }

 return this.deleteX.apply(this, arguments);
 }
 };

 if (typeof define === rsS47[3] && define.amd) {
 define([], function () {
 return rsw_CookieJS;
 });
 } else {
 rs_s2.rsw_CookieJS = rsw_CookieJS;
 }
}(document, window));


if (typeof (Sys) != rsS47[5] && typeof (Sys.Application) != rsS47[5]) Sys.Application.notifyScriptLoaded();











































































































































































































































































































































































































































































































































































































































































































































































/* ]]> */
rapidSpell.dialog_popupURL='a.rapidspellweb?t=d';
