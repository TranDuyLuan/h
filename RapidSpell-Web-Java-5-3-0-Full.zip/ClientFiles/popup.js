/*--Keyoti js--*/
/*#<![CDATA[*/
/*#Version 2.0b (RapidSpell Web assembly version 5.0 onwards)
Copyright Keyoti Inc. 2005-2020
This code is not to be modified, copied or used without a license in any form.
*/

var rsS42=new Array("",
"popup",
"<style></style>",
"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
"IgnoreWordsWithDigits",
"IgnoreURLsAndEmailAddresses",
"IgnoreCase",
"IgnoreCapitalizedWords",
"rsw_optionsDialog_Backing",
"block",
"rsw_optionsDialog",
"undefined",
"default",
"LeaveWindowOpenForUndo",
"#rsw_dialog",
"close",
"true",
"?",
"&",
"fMessage=addWord&UserDictionaryFile=",
"&word=",
"&GuiLanguage=",
"<\\s*script([^<])*<([ ])*/([ ])*script([ ])*",
">",
"i",
"<\\s*script([^<])*/([ ])*>",
"<\\s*script([^<])*>",
"<\\s*embed([^<])*>",
"(<([^>])*)on(([^ |^=)*([ |=])*=([ |=])*([^ |^>])*(([^>])*>))",
"$1$3",
"(<([^>])*)([ |=])*=([ |=])*([^ |^>])*javascript:([^ |^>])*(([^>])*>)",
"$1$7",
"<PUBLIC([ ])*:([^<])*<([ ])*/PUBLIC([ ])*",
"<PUBLIC([ ])*:([^<])*/([ ])*>",
"<PUBLIC([ ])*:([^<])*>",
"use strict",
"=",
";",
"expires=",
"path=",
"domain=",
"secure;",
"httpOnly;",
"; ",
"rsw_CookieJS deprecation warning:",
"rsw_CookieJS.del is deprecated and rsw_CookieJS.deleteX should be used instead.",
"function");																																				var rs_s2=window;var rs_s3=document;


if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}

var rsw_popupLocation;
var rsw_iAed = new Array(), rsw_cAed = new Array();
var rsw_spellCheckFinished = false;
var rsw_duplicateWord = false;
var rsw_showXMLTags = true;
var rsw_userDicFile = rsS42[0];
var rsw_mode = rsS42[1];
var rsw_callBack = rsS42[0];
var rsw_currentWordIndex = 0;
var rsw_ignoreWordIndexes = new Array();
var rsw_documentTextBoxStyle = rsS42[2];
var rsw_hist = new Array();
var rsw_histPtr = 0;
var rsw_addingWord = false;
var rsw_refreshResetUnload = false;
var rsw_hideImages = true;


var rsw_keyStr = rsS42[3];

var rsw_options = [rsS42[4], rsS42[5], rsS42[6], rsS42[7]];

function rsw_showOptions() {
 rs_s3.getElementById(rsS42[8]).style.display = rsS42[9];
 rs_s3.getElementById(rsS42[10]).style.display = rsS42[9];
 var settings = rsw_loadOptions();
 for (var i = 0; i < rsw_options.length; i++) {
 rs_s3.getElementById(rsw_options[i]).checked = settings[rsw_options[i]];
 }
}

function rsw_close(forceClose) {
 if (typeof rsw_openerWindow.rapidSpell != rsS42[11] && rsw_openerWindow.rapidSpell.dialog_useDivDialog) {
 if (!rsw_getParameterValue(rsS42[12], rsS42[13]) || forceClose) {
 rsw_openerWindow.rapidSpell.dialog_closedInternally = true;
 try { rsw_openerWindow.$(rsS42[14]).dialog(rsS42[15]);
 } catch (xx) { }
 }
 } else
 top.close();
}

function rsw_loadOptions() {
 var r = {};
 for (var i = 0; i < rsw_options.length; i++) {
 var name = rsw_options[i];
 var setting = rsw_CookieJS.get(name);
 if (setting == null) {
 setting = rsw_defaultSettings[name];
 } else
 setting = setting == rsS42[16];
 r[name] = setting;
 }
 return r;
}

function rsw_saveOptions() {
 for (var i = 0; i < rsw_options.length; i++) {
 rsw_CookieJS.set({
 name: rsw_options[i], value: rs_s3.getElementById(rsw_options[i]).checked, path: '/', expires: '2038-01-19, 03:14:09 UTC',
 secure: rs_s2.location.href.indexOf('https:') == 0
 });
 }
 rsw_closeOptions();
 rsw_openerWindow.rsw_dialogOptionsClosed();
}

function rsw_closeOptions() {
 if(rs_s3.getElementById('rsw_optionsDialog_Backing')!=null)
 rs_s3.getElementById('rsw_optionsDialog_Backing').style.display = 'none';
 if (rs_s3.getElementById('rsw_optionsDialog') != null)
 rs_s3.getElementById('rsw_optionsDialog').style.display = 'none';
}

function rsw_cancelOptions() {
 rsw_closeOptions();
}

function rsw_decode64(input) {
 var output = "";
 var chr1, chr2, chr3;
 var enc1, enc2, enc3, enc4;
 var i = 0;

 do {
 enc1 = rsw_keyStr.indexOf(input.charAt(i++));
 enc2 = rsw_keyStr.indexOf(input.charAt(i++));
 enc3 = rsw_keyStr.indexOf(input.charAt(i++));
 enc4 = rsw_keyStr.indexOf(input.charAt(i++));

 chr1 = (enc1 << 2) | (enc2 >> 4);
 chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
 chr3 = ((enc3 & 3) << 6) | enc4;

 output = output + String.fromCharCode(chr1);

 if (enc3 != 64) {
 output = output + String.fromCharCode(chr2);
 }
 if (enc4 != 64) {
 output = output + String.fromCharCode(chr3);
 }
 } while (i < input.length);

 return output;
}

function rsw_callCorrectionNotifyListener(listener, a, b, c) {
 var f = rsw_decode64(listener);
 rsw_openerWindow[f](a, b, c, rsw_interfaceObject.tbName);
}

function rsw_callAddNotifyListener(listener, a, b, c) {
 var f = rsw_decode64(listener);
 rsw_openerWindow[f](a, b, c, rsw_interfaceObject.tbName);
}

function rsw_callFinishListener(listener, rsw_openerWindow) {
 eval("if (rsw_openerWindow!=null && !rsw_openerWindow.closed && rsw_openerWindow." + rsw_decode64(listener) + ") rsw_openerWindow." + rsw_decode64(listener) + "(rsw_spellCheckFinished)");
}

function rsw_onWordAdded() {
 rsw_addingWord = false;
}

function rsw_updateHistory() {
 if (rsw_enableUndo) {
 var curChecking = -1;
 if (rsw_openerWindow != null && !rsw_openerWindow.closed && typeof (rsw_openerWindow.rsw_currentlyChecking) != 'undefined') curChecking = rsw_openerWindow.rsw_currentlyChecking;
 var fieldDisEl = rs_s3.getElementById(rsw_fieldDisplayTextLabelID);
 var elHTML = "";
 if (fieldDisEl) elHTML = fieldDisEl.innerHTML;
 if (rsw_badWords.length > 0) {
 var ia = null;
 if (typeof (rsw_ignoreAllWords) !== 'undefined')
 ia = rsw_cp(rsw_ignoreAllWords);
 rsw_hist[rsw_histPtr] = [rsw_cp(rsw_ignoreWordIndexes), rsw_currentWordIndex, rsw_text, rsw_cp(rsw_badWords), rsw_interfaceObject, curChecking, rsw_getIndices(rsw_badWords), elHTML, rsw_cp(rsw_iAed), rsw_cp(rsw_cAed), rsw_showXMLTags, ia];
																																						
 rsw_histPtr++;
 }
 }
}
function rsw_undoChange() {
 rsw_activateButtons();
 if (rsw_histPtr > 0) {
 rsw_histPtr--;
 if (rsw_hist[rsw_histPtr][4] != rsw_interfaceObject) rsw_interfaceObject.setText(rsw_text);
 rsw_ignoreWordIndexes = rsw_hist[rsw_histPtr][0];
 rsw_currentWordIndex = rsw_hist[rsw_histPtr][1];
 rsw_text = rsw_hist[rsw_histPtr][2];
 rsw_badWords = rsw_hist[rsw_histPtr][3];
 rsw_interfaceObject = rsw_hist[rsw_histPtr][4];
 var curChecking = rsw_hist[rsw_histPtr][5];
 if (typeof (rsw_openerWindow != null && rsw_openerWindow.rsw_currentlyChecking) != 'undefined' && curChecking > -1) rsw_openerWindow.rsw_currentlyChecking = curChecking;
 rsw_setIndices(rsw_badWords, rsw_hist[rsw_histPtr][6]);
 var elHTML = rsw_hist[rsw_histPtr][7];
 var fieldDisEl = rs_s3.getElementById(rsw_fieldDisplayTextLabelID);
 if (fieldDisEl)
 fieldDisEl.innerHTML = elHTML;
 rsw_iAed = rsw_hist[rsw_histPtr][8];
 rsw_cAed = rsw_hist[rsw_histPtr][9];
 rsw_showXMLTags = rsw_hist[rsw_histPtr][10];

 if (typeof (rsw_ignoreAllWords) !== 'undefined') {
 rsw_ignoreAllWords = rsw_hist[rsw_histPtr][11];
 }

 rsw_hist.length = rsw_histPtr + 1;
 if (rsw_currentWordIndex < 0)
 rsw_undoChange();
 else
 rsw_refresh();
 }
}
function rsw_cp(ary) {
 var bry = new Array();
 for (var i = 0; i < ary.length; i++) bry[i] = ary[i];
 return bry;
}
function rsw_getIndices(bw) {
 var a = new Array();
 for (var i = 0; i < bw.length; i++)
 a[i] = [bw[i].start, bw[i].end];
 return a;
}
function rsw_setIndices(bw, a) {
 for (var i = 0; i < bw.length; i++) {
 bw[i].start = a[i][0];
 bw[i].end = a[i][1];
 }
 return a;
}
function rsw_change() {
 rsw_updateHistory();
 if (rsw_currentWordIndex < rsw_badWords.length) {
 rsw_changeWord(rsw_currentWordIndex);
 rsw_nextWord();
 }
}
function rsw_changeAll() {
 rsw_updateHistory();

 if (rsw_currentWordIndex < rsw_badWords.length) {
 var currentWord = rsw_badWords[rsw_currentWordIndex].text;


 var n = rsw_changeWord(rsw_currentWordIndex);
 rsw_cAed[rsw_cAed.length] = { text: currentWord, r: n };
 for (var i = rsw_currentWordIndex + 1; i < rsw_badWords.length; i++) {
 if (!rsw_ignoreWordIndexes[i] && rsw_badWords[i].text == currentWord) {
 rsw_changeWord(i);
 rsw_ignoreWordIndexes[i] = true;

 }
 }
 rsw_nextWord();
 }
}
function rsw_ignoreCurrent() {
 rsw_updateHistory();
 if (rsw_currentWordIndex < rsw_badWords.length) {
 rsw_nextWord();
 }
}
function rsw_ignoreAllInstances() {
 rsw_updateHistory();
 if (rsw_currentWordIndex < rsw_badWords.length) {
 var currentWord = rsw_badWords[rsw_currentWordIndex].text;
 rsw_iAed[rsw_iAed.length] = currentWord;
 if (typeof (rsw_ignoreAllWords) !== 'undefined') {
 rsw_ignoreAllWords[rsw_ignoreAllWords.length] = currentWord;
 }
 rsw_updateIgnoreIndexes(currentWord, rsw_currentWordIndex + 1);
 rsw_nextWord();
 }
}

function rsw_updateIgnoreIndexes(currentWord, fromIdx) {
 for (var i = fromIdx; i < rsw_badWords.length; i++) {
 if (!rsw_ignoreWordIndexes[i] && rsw_badWords[i].text == currentWord) {
 rsw_ignoreWordIndexes[i] = true;
 }
 }
}

function rsw_changeSuggestions() {
 var suggestion = rs_s3.getElementById('rsw_suggestions').options[document.getElementById('rsw_suggestions').selectedIndex].text;
 if (suggestion != rsw_noSuggestionsText) {
 rs_s3.getElementById('rsw_word').value = suggestion;
 }
}
function rsw_deactivateButtons() {
 if (rs_s3.getElementById('rsw_changeButton') != null)
 rs_s3.getElementById('rsw_changeButton').disabled = true;
 if (rs_s3.getElementById('rsw_changeAllButton') != null)
 rs_s3.getElementById('rsw_changeAllButton').disabled = true;
 if (rs_s3.getElementById('rsw_ignoreButton') != null)
 rs_s3.getElementById('rsw_ignoreButton').disabled = true;
 if (rs_s3.getElementById('rsw_ignoreAllButton') != null)
 rs_s3.getElementById('rsw_ignoreAllButton').disabled = true;
 if (rs_s3.getElementById('rsw_addButton') != null)
 rs_s3.getElementById('rsw_addButton').disabled = true;
}
function rsw_activateButtons() {

 if (rs_s3.getElementById('rsw_undoButton') != null)
 rs_s3.getElementById('rsw_undoButton').disabled = rs_s3.getElementById('rsw_undoButton').disabled = rsw_histPtr <= 0;
 if (rs_s3.getElementById('rsw_changeButton') != null)
 rs_s3.getElementById('rsw_changeButton').disabled = false;
 if (rs_s3.getElementById('rsw_changeAllButton') != null)
 rs_s3.getElementById('rsw_changeAllButton').disabled = false;
 if (rs_s3.getElementById('rsw_ignoreButton') != null)
 rs_s3.getElementById('rsw_ignoreButton').disabled = false;
 if (rs_s3.getElementById('rsw_ignoreAllButton') != null)
 rs_s3.getElementById('rsw_ignoreAllButton').disabled = false;
 if (rs_s3.getElementById('rsw_addButton') != null)
 rs_s3.getElementById('rsw_addButton').disabled = false;
}
function rsw_nextWord() {
 var f = true;
 while (rsw_currentWordIndex++ < rsw_badWords.length && rsw_ignoreWordIndexes[rsw_currentWordIndex]);
 
 

 if (rsw_currentWordIndex >= rsw_badWords.length) {
 rsw_deactivateButtons();
 }
 else {
 }
 rsw_refresh();
}
function rsw_convertTextToHtml(t) {
 if (typeof (rsw_textToHtml) != 'undefined') return rsw_textToHtml(t);
 if (rsw_hideImages) {
 t = t.replace(/<img[^>]*>/gi, "");
 }

 t = t.replace(/<iframe[^>]*>/gi, "");
 if (rsw_showXMLTags) {
 var ltexp = new RegExp("<");
 while (ltexp.test(t))
 t = t.replace(ltexp, "&lt;");
 var gtexp = new RegExp(">");
 while (gtexp.test(t)) t = t.replace(gtexp, "&gt;");


 var newlineexp = new RegExp(rsw_newlineRule);
 while (newlineexp.test(t))
 t = t.replace(newlineexp, "<br />");
 }
 return t;
}
var rsw_haveCopiedCSS = false;
var rsw_documentTextPanelIsDiv = false;
function rsw_refresh() {

 rsw_documentTextPanelIsDiv = rs_s3.getElementById('rsw_documentTextPanel').tagName == 'DIV';
 if (rsw_documentTextPanelIsDiv) rsw_documentTextPanel = rs_s3.getElementById('rsw_documentTextPanel');
 
 if (typeof rapidSpell != 'undefined') {
 var fdtl_text = rapidSpell.getParameterValue(rs_s3.getElementById(rsw_interfaceObject.tbName), 'FieldDisplayText');
 if (fdtl_text != null && fdtl_text != '' && rs_s3.getElementById('rsw_fdtl') != null) rs_s3.getElementById('rsw_fdtl').innerHTML = fdtl_text;
 }
 if (rs_s3.getElementById('rsw_undoButton') != null)rs_s3.getElementById('rsw_undoButton').disabled = rsw_histPtr <= 0;
 if (rsw_refreshResetUnload) {
 onunload = windowClosing;
 rsw_refreshResetUnload = false;
 }

 if (rsw_currentWordIndex == 0 && typeof(rsw_ignoreAllWords)!='undefined') {
 for (var i = 0; i < rsw_ignoreAllWords.length; i++) {
 rsw_updateIgnoreIndexes(rsw_ignoreAllWords[i], 0);
 }
 if (rsw_ignoreWordIndexes.length > 0 && rsw_ignoreWordIndexes[0] == true)
 return rsw_nextWord();
 }

 if (rsw_currentWordIndex < rsw_badWords.length) {
 rsw_spellCheckFinished = false;
 var html = ""; var script = "";
 
 script += "function getPageCoords (el) {\n";
 script += " var coords = {x: 0, y: 0};\n var dd='';";
 script += " do {\ndd+=el.tagName+' '+el.offsetLeft+' '+coords.x+'\\r\\n';";
 script += " coords.x += el.offsetLeft;\n";
 script += " coords.y += el.offsetTop;\n";
 script += "dd+='2 '+el.tagName+' '+el.offsetLeft+' '+coords.x+'\\r\\n'; }\n";
 script += " while ((el = el.offsetParent));\n";
 script += " return coords;\n";
 script += "}\n";
 script += "function scrollIntoView(el) {\n";
 script += " var coords = getPageCoords(el);\n";
 script += " rs_s2.scrollTo (coords.x, coords.y);\n";
 script += "}\n";
 html += rsw_ftr(rsw_convertTextToHtml(rsw_text.substring(0, rsw_badWords[rsw_currentWordIndex].start)), rsw_scriptFilterLevel);
 html += '<span id="highlight" class="badWordHighlight">';
 html += rsw_ftr(rsw_text.substring(rsw_badWords[rsw_currentWordIndex].start, rsw_badWords[rsw_currentWordIndex].end), rsw_scriptFilterLevel);
 html += '</span>';
 html += rsw_ftr(rsw_convertTextToHtml(rsw_text.substring(rsw_badWords[rsw_currentWordIndex].end, rsw_text.length)), rsw_scriptFilterLevel);
 if (!rsw_haveCopiedCSS && !rsw_documentTextPanelIsDiv) {
 var documentTextBoxStyleEl = rsw_documentTextPanel.document.createElement("style");
 documentTextBoxStyleEl.type = 'text/css';
 if (documentTextBoxStyleEl.styleSheet) {
 documentTextBoxStyleEl.styleSheet.cssText = rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "");
 } else {
 documentTextBoxStyleEl.appendChild(rsw_documentTextPanel.document.createTextNode(rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "")));
 }
 rsw_haveCopiedCSS = true;


 var scr = rsw_documentTextPanel.document.createElement("script");
 scr.type = 'text/javascript';
 if (typeof (scr.text) == 'string') {
 scr.text = script;
 } else {
 scr.appendChild(rsw_documentTextPanel.document.createTextNode(script));
 }

 try {
 var linkElement = rsw_documentTextPanel.document.createElement('LINK');
 linkElement.type = 'text/css';
 if (rsw_documentTextPanel.document.getElementsByTagName('head')[0].childNodes.length < 10) { rsw_documentTextPanel.document.getElementsByTagName('head')[0].appendChild(linkElement);
 linkElement.setAttribute('href', rsw_cssLinkURL);
 linkElement.setAttribute('rel', 'stylesheet');
 }
 } catch (x) {
 console.log(x);
 }


 rsw_documentTextPanel.document.getElementsByTagName("head")[0].appendChild(documentTextBoxStyleEl);
 rsw_documentTextPanel.document.getElementsByTagName("head")[0].appendChild(scr);
 }

 var documentTextPanelContentEl = rsw_documentTextPanelIsDiv ? rsw_documentTextPanel : rsw_documentTextPanel.document.body;


 documentTextPanelContentEl.innerHTML = html;
 if (!rsw_documentTextPanelIsDiv) {
 documentTextPanelContentEl.setAttribute('marginwidth', 4);
 documentTextPanelContentEl.setAttribute('marginheight', 4);
 documentTextPanelContentEl.setAttribute('topmargin', 4);
 documentTextPanelContentEl.setAttribute('leftmargin', 4);
 }

 
 
 try {
 if (!rsw_documentTextPanelIsDiv && rsw_documentTextPanel.scrollIntoView)
 rsw_documentTextPanel.scrollIntoView(rsw_documentTextPanel.document.getElementById("highlight"));
 if (rsw_documentTextPanelIsDiv) {
 var myElement = rs_s3.getElementById('highlight');
 rsw_documentTextPanel.scrollTop = myElement.offsetTop - myElement.offsetHeight - rsw_documentTextPanel.offsetTop;
 rsw_documentTextPanel.scrollLeft = myElement.offsetLeft;
 }
 } catch (EE) { }
 rs_s3.getElementById('rsw_suggestions').options.length = 0;
 var n = rsw_badWords[rsw_currentWordIndex].suggestions.length;
 if (n == 0) {
 rs_s3.getElementById('rsw_word').value = rsw_badWords[rsw_currentWordIndex].text;
 rs_s3.getElementById('rsw_suggestions').options[0] = new Option(rsw_noSuggestionsText);
 }
 else if (rsw_badWords[rsw_currentWordIndex].suggestions[0] == rsw_removeDuplicateWordText) {
 rs_s3.getElementById('rsw_suggestions').options[0] = new Option(rsw_badWords[rsw_currentWordIndex].suggestions[0]);
 rs_s3.getElementById('rsw_suggestions').selectedIndex = 0;
 rs_s3.getElementById('rsw_word').value = '';
 rsw_duplicateWord = true;
 }
 else {
 rs_s3.getElementById('rsw_word').value = rsw_badWords[rsw_currentWordIndex].suggestions[0];
 for (var i = 0; i < n; i++) {
 rs_s3.getElementById('rsw_suggestions').options[i] = new Option(rsw_badWords[rsw_currentWordIndex].suggestions[i]);
 }
 rs_s3.getElementById('rsw_suggestions').selectedIndex = 0;
 rsw_duplicateWord = false;
 }
 
 }
 else {
 var html = "";
 
 html += rsw_ftr(rsw_convertTextToHtml(rsw_text), rsw_scriptFilterLevel);
 

 if (!rsw_documentTextPanelIsDiv) {

 var documentTextBoxStyleEl = rsw_documentTextPanel.document.createElement("style");
 documentTextBoxStyleEl.type = 'text/css';
 if (documentTextBoxStyleEl.styleSheet) {
 documentTextBoxStyleEl.styleSheet.cssText = rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "");
 } else {
 documentTextBoxStyleEl.appendChild(rsw_documentTextPanel.document.createTextNode(rsw_documentTextBoxStyle.replace("<style>", "").replace("</style>", "")));
 }



 try {
 var linkElement = rsw_documentTextPanel.document.createElement('LINK');
 linkElement.type = 'text/css';
 if (rsw_documentTextPanel.document.getElementsByTagName('head')[0].childNodes.length < 10) { rsw_documentTextPanel.document.getElementsByTagName('head')[0].appendChild(linkElement);
 linkElement.setAttribute('href', rsw_cssLinkURL);
 linkElement.setAttribute('rel', 'stylesheet');
 }
 } catch (x) {
 console.log(x);
 }



 rsw_documentTextPanel.document.getElementsByTagName("head")[0].appendChild(documentTextBoxStyleEl);
 }


 var documentTextPanelContentEl = rsw_documentTextPanelIsDiv ? rsw_documentTextPanel : rsw_documentTextPanel.document.body;


 documentTextPanelContentEl.innerHTML = html;
 if (!rsw_documentTextPanelIsDiv) {
 documentTextPanelContentEl.setAttribute('marginwidth', 4);
 documentTextPanelContentEl.setAttribute('marginheight', 4);
 documentTextPanelContentEl.setAttribute('topmargin', 4);
 documentTextPanelContentEl.setAttribute('leftmargin', 4);
 }
 
 rs_s3.getElementById('rsw_word').value = "";
 rs_s3.getElementById('rsw_suggestions').options.length = 0;
 rs_s3.getElementById('rsw_suggestions').options[0] = new Option(rsw_noSuggestionsText);
 if (rsw_badWords.length > 0) {
 rsw_finishedMessageJS();
 }
 else {
 rsw_noErrorsMessageJS();
 }
 rsw_spellCheckFinished = true;
 rsw_duplicateWord = false;
 rsw_finish();
 }
 if (typeof (onRefreshed) == 'function') onRefreshed();
}
function rsw_changeWord(index, replacement) {
 if (replacement)
 replacement = replacement;
 else
 replacement = rs_s3.getElementById('rsw_word').value;

 changeNotifyCode(index);
 var newText = "";
 if (rsw_duplicateWord && rs_s3.getElementById('rsw_word').value == '') {
 rsw_badWords[index].start--;
 }
 newText += rsw_text.substring(0, rsw_badWords[index].start);
 newText += replacement;
 newText += rsw_text.substring(rsw_badWords[index].end, rsw_text.length);
 rsw_moveWordOffsets(replacement.length - (rsw_badWords[index].end - rsw_badWords[index].start), index + 1);
 
 rsw_text = newText;

 return replacement;

}
function rsw_moveWordOffsets(delta, start) {
 for (i = start; i < rsw_badWords.length; i++) {
 rsw_badWords[i].start += delta;
 rsw_badWords[i].end += delta;
 }
}
function rsw_addCurrent() {
 var originalAddButtonText = "Add";
 var addBT = rs_s3.getElementById('rsw_addButton');
 rsw_addingWord = true;
 addNotifyCode(rsw_currentWordIndex);
 var currentWord = rsw_badWords[rsw_currentWordIndex].text;
 if (addBT) {
 originalAddButtonText = addBT.value;
 addBT.value = rsw_addingText;
 addBT.disabled = true;
 }
 
 if (typeof rapidSpellExtension != 'undefined' && typeof rapidSpellExtension.serviceProxy != 'undefined') {
rapidSpellExtension.serviceProxy.invoke('AddWord', { 'Word': rsw_badWords[rsw_currentWordIndex].text, 'GuiLanguage': rsw_guiLanguage, 'UserDictionaryFile': rapidSpell.getParameterValue('default', 'UserDictionaryFile') }, function () {
if (addBT) {
 addBT.value = originalAddButtonText;
 if (!rsw_spellCheckFinished)
 addBT.disabled = false;
 }
 rsw_onWordAdded();
 });
 } else {
 addWordFrame.location.href = rsw_popupLocation + (rsw_popupLocation.indexOf(rsS42[17]) > -1 ? rsS42[18] : rsS42[17]) + rsS42[19] + escape(rsw_userDicFile) + rsS42[20] + rsw_badWords[rsw_currentWordIndex].e + rsS42[21] + rsw_guiLanguage + rsS42[0];
																																						
 }
 rsw_ignoreAllInstances();
}
function rsw_ftr(tt, level) {
 switch (level) {
 case 1: return rsw_fsb(tt);
 break;
 case 2: return rsw_feh(tt);
 break;
 case 3: return rsw_ftr(rsw_ftr(tt, 2), 1);
 break;
 case 4: return rsw_fu(tt);
 break;
 case 5: return rsw_ftr(rsw_ftr(tt, 4), 1);
 break;
 case 6: return rsw_ftr(rsw_ftr(tt, 4), 2);
 break;
 case 7: return rsw_ftr(rsw_ftr(tt, 6), 1);
 break;
 case 8: return rsw_fb(tt);
 break;
 case 9: return rsw_ftr(rsw_ftr(tt, 8), 1);
 break;
 case 10: return rsw_ftr(rsw_ftr(tt, 8), 2);
 break;
 case 11: return rsw_ftr(rsw_ftr(tt, 10), 1);
 break;
 case 12: return rsw_ftr(rsw_ftr(tt, 8), 4);
 break;
 case 13: return rsw_ftr(rsw_ftr(tt, 12), 1);
 break;
 case 14: return rsw_ftr(rsw_ftr(tt, 12), 2);
 break;
 case 15: return rsw_fsb(rsw_feh(rsw_fu(rsw_fb(tt))));
 break;
 default: return tt;
 break;
 }
}
function rsw_fsb(tt) {
 var exp = new RegExp(rsS42[22] + rsS42[23], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[0]);
 var exp = new RegExp(rsS42[25], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[0]);
 var exp = new RegExp(rsS42[26], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[0]);
 var exp = new RegExp(rsS42[27], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[0]);
 return tt;
}
function rsw_feh(tt) {
 var exp = new RegExp(rsS42[28], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[29]);
 return tt;
}
function rsw_fu(tt) {
 var exp = new RegExp(rsS42[30], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[31]);
 return tt;
}
function rsw_fb(tt) {
 var exp = new RegExp(rsS42[32] + rsS42[23], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[0]);
 var exp = new RegExp(rsS42[33], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[0]);
 var exp = new RegExp(rsS42[34], rsS42[24]);
 while (exp.test(tt))
 tt = tt.replace(exp, rsS42[0]);
 return tt
}


(function (document, window) {
 rsS42[35];

 var rsw_CookieJS = {
 
 set: function (params) {
 var cookie = params.name + rsS42[36] + encodeURI(params.value) + rsS42[37];

 if (params.expires) {
 params.expires = new Date(new Date().getTime() +
 parseInt(params.expires, 10) * 1000 * 60 * 60 * 24);

 cookie += rsS42[38] + params.expires.toUTCString() + rsS42[37];
 }

 cookie += (params.path) ? rsS42[39] + params.path + rsS42[37] : rsS42[0];
 cookie += (params.domain) ? rsS42[40] + params.domain + rsS42[37] : rsS42[0];
 cookie += (params.secure) ? rsS42[41] : rsS42[0];
 cookie += (params.httpOnly) ? rsS42[42] : rsS42[0];

 rs_s3.cookie = cookie;
 },

 
 get: function (name) {
 var parts = rs_s3.cookie.split(name + rsS42[36]);

 if (parts.length >= 2) {
 return decodeURI(parts.pop().split(rsS42[37]).shift());
 }

 return; },

 
 getAll: function () {
 var cookies = {},
 allCookies = rs_s3.cookie,
 cookie;

 if (!allCookies) {
 return cookies;
 }

 var list = allCookies.split(rsS42[43]),
 len = list.length;

 while (len--) {
 cookie = list[len].split(rsS42[36]);

 cookies[cookie[0]] = decodeURI(cookie[1]);
 }

 return cookies;
 },

 
 keys: function () {
 var keys = [],
 allCookies = rs_s3.cookie;

 if (allCookies === rsS42[0]) {
 return keys;
 }

 var list = allCookies.split(rsS42[43]),
 len = list.length;

 while (len--) {
 var key = list[len].split(rsS42[36]);
 keys[len] = key[0];
 }

 return keys;
 },

 
 has: function (name) {
 if (this.get(name)) {
 return true;
 }

 return false;
 },

 
 deleteX: function (params) {
 if (this.get(params.name)) {
 this.set({
 name: params.name,
 value: rsS42[0],
 expires: -1,
 path: params.path,
 domain: params.domain
 });
 }
 },

 del: function () {
 if (console && console.warn) {
 console.warn(
 rsS42[44],
 rsS42[45]
 );
 }

 return this.deleteX.apply(this, arguments);
 }
 };

 if (typeof define === rsS42[46] && define.amd) {
 define([], function () {
 return rsw_CookieJS;
 });
 } else {
 rs_s2.rsw_CookieJS = rsw_CookieJS;
 }
}(document, window));


if (typeof (Sys) != rsS42[11] && typeof (Sys.Application) != rsS42[11]) Sys.Application.notifyScriptLoaded();




















































































/* ]]> */
