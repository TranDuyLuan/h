/*--Keyoti js--*/
/*#<![CDATA[*/
/*#(RapidSpell Web assembly version 4.0.0 onwards)
Copyright Keyoti Inc. 2005-2020
This code is not to be modified, copied or used without a license in any form.
*/

var rsS14=new Array("RapidSpell script v6.2.0a",
"RapidSpell:",
"-10000px",
"",
"rswinline",
"INACTIVE",
"RS_ContextMenuTable",
"RS_CMItemSeparator",
"RS_ContextMenuItem",
"RS_ContextMenuItem_AllSubItem",
"RS_ContextMenuItem_Disabled",
"oldBrowserBox",
"undefined",
"Mac",
"Gecko",
"Firefox",
"MSIE",
"Trident",
"Chrome",
"Safari",
"Edge/",
"AppleWebKit",
"NT 6.1",
"NT 6.2",
"\r",
"\n",
"MSIE 9.",
"MSIE 10.",
"CSS1Compat",
"type",
"hidden",
"tabindex",
"tabindexIF",
"function",
" | ",
"_IF",
"Microsoft Internet Explorer",
"MSIE ([0-9]{1,}[\.0-9]{0,})",
":",
" ",
"oldValue",
"_SHD",
"DIV",
"_D",
"class",
"style",
"display:none;width:1px; height:1px;",
"display:none;width:1px; height:1px;position:absolute;",
"none",
"pwHtmlBox",
"div",
"__RSFIX",
"absolute",
"IFRAME",
"textarea",
"border-box",
"string",
"%",
"px",
"BackCompat",
"Setting style.width in iframe ",
"px from ",
"Not Setting style.width in iframe ",
"scroll",
"bottom",
"marginTop",
"marginLeft",
"paddingLeft",
"paddingRight",
"borderLeftWidth",
"borderRightWidth",
"paddingTop",
"paddingBottom",
"borderTopWidth",
"borderBottomWidth",
"Couldn't copy style because source is null (",
") or target is null(",
")",
"BODY",
"webkit",
"zIndex",
"position",
"left",
"right",
"top",
"display",
"ms",
"resize",
"width",
"height",
"scrollbar",
"border",
"css",
"get",
"set",
"Moz",
"whiteSpace",
"word",
"text",
"remove",
"item",
"color",
"margin",
"clip",
"visibility",
"padding",
"line",
"lineHeight",
"table",
"max",
"min",
"blockSize",
"background",
"overflow",
"visible",
"backgroundColor",
"transparent",
"fontStyle",
"Cannot copy style from source textbox with id ",
" because getElementById returns null",
"Cannot copy style from target textbox with id ",
" because getElementById returns null, will try again",
"float",
"marginRight",
"marginBottom",
"borderBottom",
"borderTop",
"borderLeft",
"borderRight",
"borderBottomColor",
"borderTopColor",
"borderLeftColor",
"borderRightColor",
"borderBottomStyle",
"borderTopStyle",
"borderLeftStyle",
"borderRightStyle",
"borderRadius",
"borderLeftRadius",
"borderTopRadius",
"borderRightRadius",
"borderBottomRadius",
"borderTopLeftRadius",
"borderTopRightRadius",
"borderBottomLeftRadius",
"borderBottomRightRadius",
"-moz-border-radius",
"-webkit-border-radius",
"-khtml-border-radius",
"2px inset rgb(0, 0, 0)",
"0px",
"1px solid rgb(169, 169, 169)",
"overflowX",
"overflowY",
"text/xml",
"Msxml2.XMLHTTP",
"Microsoft.XMLHTTP",
"debug",
"\r\nMicrosoft.XMLHTTP not available",
"\r\n",
"Sending request to ",
"POST",
"Content-Type",
"text/xml; charset=UTF-8",
"application/xml",
"a",
".",
"b",
"<",
">",
"</",
"<input type=hidden name=",
" value='",
"'>",
"default",
"'",
"','",
"object",
"\r\nerror in rsw_spellCheckText ",
"Check",
"<form accept-charset='UTF-8' action='",
"' method='post'>",
"<input type='hidden' name='textToCheck' value=''><input type='hidden' name='IAW' value=''>",
"</form>",
"|",
"<r><resp>xml</resp><textToCheck>",
"</textToCheck><IAW>",
"</IAW>",
"</r>",
"?fiddlerParam=",
"[",
"]",
"Sorry, a textbox with ID=",
" couldn't be found - please check the TextComponentID or TextComponentName property.",
"&lt;",
"&gt;",
"No suggestions",
"Ignore All",
"All",
"Add",
"Edit...",
"Remove duplicate word",
"Checking...",
"Resume Editing",
"Check Spelling",
"No Spelling Errors In Text.",
"Sorry the server has failed to respond to the spell check request. Please check the URL set in the RapidSpellWebInlinePage property in the RapidSpellWebInline ctrl.",
"Textbox with ID=",
" could not be found, please check the TextComponentID property in the RapidSpell control.",
"regTB",
"rich",
"true",
"IgnoreXML",
"True",
"ACTIVE",
"starting check",
"queued ",
"spellcheckfinish",
"(true,-1)",
"ayt_spellcheckfinish",
"EDITING",
"()",
"TRANSITION-CHECKING",
"before:",
"\r\nafter:",
" **abort",
"setting caret",
"block",
"overlay",
"CHECKING",
"firefox",
"inline",
"inline-block",
"server responded ",
" errors",
"&nbsp;",
" **abort rsw_key_downed_flag. rsw_key_down_timeout=",
" flag=",
" lim=",
"caret at:",
",",
"reset caret2",
"(true,numberOfErrors)",
"Popping queued spell check tb. length ",
"id='resultContent'>",
"id='numberOfErrors'>",
"</div>",
"\r\nCallback, readyState:",
" status:",
"\r\nresponse text:",
"The page holding the RapidSpellWInlineHelper control couldn't be found, please check the URL in the RapidSpellWInlineHelperPage property, it should be set to the URL of the page holding the RapidSpellWInlineHelper control.",
"The page holding the RapidSpellWInlineHelper control returned a 500 server error - which means the page has an error, please visit the URL specified in the RapidSpellWInlineHelperPage to debug this page. ",
"(HINT: Most likely, you need to add validateRequest='false' to the Page directive if you are spell checking HTML content.)",
"There was a problem with the request, please check the URL set in the RapidSpellWInlineHelperPage property. Http Error Code: ",
"RapidSpell AJAX call was cancelled. Status code 0",
"There was a problem with the request. Http Error Code: ",
"BR",
"P",
"<fo",
"rm accept-charset='UTF-8' action='",
"<input type='hidden' name='action' value='add'>",
"UserDictionaryFile",
"<r><action>add</action><w>",
"</w><UserDictionaryFile>",
"</UserDictionaryFile></r>",
"The page holding the RapidSpellWInlineHelper control couldn't be found, please check the URL in the RapidSpellWInlineHelperPage property, it should be set to the URL of the page holding RapidSpellWInlineHelperPage.",
"The page holding the RapidSpellWInlineHelper control returned a 500 server error - which means the page has an error, please visit the URL specified in the RapidSpellWInlineHelperPage to debug this page. (HINT: Most likely, you need to add validateRequest='false' to the Page directive if you are spell checking HTML content.)",
"No server response (null).",
"id='errorContent'>",
"if (rsw_activeTextbox.recordCaretPos) rsw_activeTextbox.recordCaretPos();",
"ayt_contextmenushowing",
"ayt_contextmenushown",
"LABEL",
"setTimeout( function() { rsw_onFinish(",
", ",
");}, 100 ); ",
"ayt_textboxesinitialized",
"boolean",
"LINK",
"text/css",
"head",
"href",
"rel",
"stylesheet",
"rs_err_hl",
"className",
"onmouseup",
"correction",
"#edit",
"br",
"li",
"HTML",
"input",
"p",
"&",
"&amp;",
"keydown",
"rsw_activeTextbox.rsw_key_downed_within_lim=false;",
" DOWN ",
"placeholder",
"<span class='placeholder -moz-placeholder -ms-input-placeholder -webkit-input-placeholder'>",
"</span>",
"textedit",
"character",
"A",
"Subscript",
"span",
"suggestions",
"inside",
"\r\nRECORD A ",
"StartToEnd",
"\r\nRECORD B ",
"EndToEnd",
"sentence",
"\r\nRECORD CARET",
"\r\nSET CARET,",
" has\\r=",
"\r\nnew text=>",
"<== \r\n\r\nOLD=>",
"<==\r\n",
"MSIE 7",
"ayt_correction",
"keypress",
"unlink",
"keyup",
"mousedown",
"mouseup",
"dblclick",
"click",
" rsw_focused",
"focus",
"MSIE 6",
"contentEditable",
"change",
"false",
"blur",
"\r\nblur",
"\r\nSET CONTENT",
" & fromshadow=",
"<br />",
"<nobr>",
"</nobr>",
"MSIE 8",
"contextmenu",
"rsw_activeTextbox.pasting=true;rsw_activeTextbox.updateShadow();if(rsw_activeTextbox.maxlength>0){",
"rsw_setShadowTB(rsw_activeTextbox.shadowTB, rsw_activeTextbox.shadowTB.value.substring(0,rsw_activeTextbox.maxlength));}rsw_activeTextbox.recordCaretPos();rsw_activeTextbox.updateIframe();rsw_activeTextbox.resetCaretPos();rsw_activeTextbox.pasting=false;",
"paste",
"setTimeout( function() {try{ rsw_getTBSFromID('",
"').initialize(",
");}catch(exc){}}, ",
" ); ",
"spellcheck",
"display:inline-block; padding:0; line-height:1; position:absolute; visibility:hidden; font-size:1em",
"M",
"margin:0;",
"AutoUrlDetect",
"RS_MultiLineTB_Disabled",
"RS_MultiLineTB",
"RS_SingleLineTB_Disabled",
"RS_SingleLineTB",
"g",
"firefox/1.0",
"\r\nInnerHTML: ",
"nobr",
"UIEvents",
"<p>$1</p>",
"<p><BR></p>",
"<p style='margin:0px;'>$1</p>",
"/",
"off",
"on",
"setTimeout( function() { rsw_getTBSFromID('",
");}, 50 ); ",
");}catch(exc){}},50 ); ",
"fontSize",
"setTimeout( function() {try{ document.getElementById('",
"').contentDocument.body.contentEditable = true;} catch (exc){} }, 400 ); ",
"').contentDocument.designMode = 'On';} catch (exc){} }, 400 ); ",
"if(rsw_activeTextbox!=null&&rsw_activeTextbox.maxlength>0&&rsw_activeTextbox.shadowTB.value.length>rsw_activeTextbox.maxlength){rsw_activeTextbox.updateShadow();rsw_setShadowTB(rsw_activeTextbox.shadowTB, rsw_activeTextbox.shadowTB.value.substring(0,rsw_activeTextbox.maxlength));rsw_activeTextbox.updateIframe();}",
"multiline",
"yes",
"iframe.style.height",
"px'",
"id",
"nospell",
"td",
"value",
"inlineTB",
"<P style='margin:0px;'>",
"</P>",
"<br>",
"\t",
"<span class='tab'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>",
"#text",
"=",
"SCRIPT",
"Opera 5",
"Opera/5",
"^apos^",
"^qt^",
"#",
"changeall",
"subitem",
"remove duplicate",
"no_suggestions",
"-",
"edit",
"ignore_all",
"ShowAddItemAlways",
"add",
"RS_CM_DIV",
"RS_CM_IF",
"out",
"_Over",
"msie",
"<tr><td width='100%' ",
"colspan='1'",
"colspan='2'",
"</td>",
"<td>",
"</tr>",
"</table>",
"standard",
"', '",
"ayt_ignoringAll",
"ayt_ignoredAll",
"ayt_editingAll",
"ayt_adding",
"ayt_added",
"ayt_removingDuplicate",
"ayt_removedDuplicate",
"ayt_changingAll",
"ayt_changedAll",
"ayt_changing",
"ayt_changed",
"oncontextmenu",
"try{event.cancelBubble=true;event.preventDefault();}catch(e){}return false;",
"body",
"src",
"javascript: false;",
"scrolling",
"no",
"frameborder",
"0",
"position:absolute; top:0px; left:0px; display:none;",
"onTextBoxesInit(), rsw_ayt_initializing==",
"checkNext(), rsw_haltProcesses==",
" rsw_ayt_enabled==",
" this.stopped==",
"onFinish(), this.triggeredLast==",
"onFinish(), set rsw_ayt_initializing false",
"ayt_finished_initializing",
";",
"&amp",
"&nbsp",
"&lt",
"&gt",
"TEXTAREA",
"INPUT",
"designMode",
"*",
"rsw_ASPNETAJAX_OnInitializeRequest",
"rsw_ASPNETAJAX_OnEndRequest",
"rsw__init(true)",
"core",
"ShowFinishedMessage",
"script",
"Sorry, cannot find a script import named ",
".js, please do not rename any RapidSpell scripts.",
"RapidSpell-",
"blank.html",
"menu.css",
"rs_style.css",
"RapidSpellModalHelper.html",
"SuggestionsMethod",
"SeparateHyphenWords",
"IncludeUserDictionaryInSuggestions",
"IgnoreCapitalizedWords",
"GuiLanguage",
"LanguageParser",
"Modal",
"AllowAnyCase",
"IgnoreWordsWithDigits",
"ShowNoErrorsMessage",
"ShowXMLTags",
"AllowMixedCase",
"WarnDuplicates",
"DictFile",
"PopUpWindowName",
"CreatePopUpWindow",
"ConsiderationRange",
"LookIntoHyphenatedText",
"CheckCompoundWords",
"EnableUndo",
"LeaveWindowOpenForUndo",
"SSLFriendlyPage",
"IgnoreURLsAndEmailAddresses",
"IgnoreIncorrectSentenceCapitalization",
"IgnoreInEnglishLowerCaseI",
"SuggestSplitWords",
"CorrectionNotifyListener",
"MaximumNumberOfSuggestions",
"AddNotifyListener",
"EnableOptions",
"FieldDisplayText",
"~/user-dictionary.txt",
"HASHING_SUGGESTIONS",
"ENGLISH",
"80",
"rsw_ondialogcorrection",
"8",
"rsw_ondialogadd",
"dialog_correction",
"dialog_add",
"FRENCH",
"SPANISH",
"GERMAN",
"ITALIAN",
"PORTUGUESE",
"DUTCH",
"POLISH",
"RUSSIAN",
"Ignore",
"The spelling check is complete.",
"Ignorer",
"Ignorer Tout",
"Ajouter",
"Éditez...",
"Tout",
"Enlevez le mot double",
"Aucun",
"Fini.",
"Ignorar",
"Ignorar Todas",
"Agregar",
"Corrija...",
"Todas",
"Quite la palabra duplicada",
"Ningunas sugerencias",
"La verificación ortográfica ha finalizado.",
"Ignorieren",
"Alle ignorieren",
"Hinzufügen",
"Redigieren...",
"Alle",
"Doppelte Wörter entfernen",
"Keine vorschläge",
"Die Rechtschreibprüfung ist abgeschlossen.",
"Ignora",
"Ignora tutto",
"Aggiungi",
"Modifica...",
"Tutto",
"Rimuovi la parola duplicata",
"Nessun suggerimento",
"Controllo completato.",
"Ignore Tudo",
"Adicione",
"Edite...",
"Tudo",
"Remova a palavra duplicada",
"Nenhumas sugestões",
"A verificação de soletração está completa.",
"Negeren",
"Alles negeren",
"Toevoegen",
"Corrigeren...",
"Allen",
"Verwijder herhaald woord",
"Geen suggesties",
"De spellingscontrole is voltooid.",
"Ignoruj",
"Ignoruj wszystko",
"Dodaj",
"Edytuj...",
"Wszystko",
"Usuń podwójne wystąpienie słowa",
"Nie ma sugestii",
"Zakończono Sprawdzanie pisowni.",
"Пропустить",
"Пропустить все",
"Добавить",
"Редактировать...",
"все",
"Удалить дубликат слова",
"Нет вариантов",
"Проверка орфографии.",
"ignore",
"ignoreAll",
"changeAll",
"removeDuplicate",
"noSuggestions",
"complete",
"wcf",
"asmx",
"servlet",
"/api",
"/RapidSpellService.svc/",
"/RapidSpellService.asmx/",
"/RapidSpellAPI/",
"a.rapidspellweb",
"a.rapidspellweb?t=",
"data=",
"Using web service .NET 2",
"application/x-www-form-urlencoded",
"{",
"}",
"\r\nURL (click to get more error info): <a href='",
"</a>",
"Unknown server error.",
"timeout",
"Sorry the server has not responded, please try again.",
"error",
" error from server.",
"\r\n\r\nURL (click to get more error info): <a href='",
"#rsw_dialogLoader",
"Using WCF service .NET 4",
"Using API Controller",
"d",
"A 500 server error occurred.\r\n****\r\nIf you are referencing Keyoti.RapidSpellWeb.ASP.NETv2.DLL then you must call this Javascript on your page:\r\nrapidSpell.setServiceType('asmx');\r\n*****",
"Version:2.0",
"It appears that you are running .NET 2 on the server, therefore you must call this Javascript in your page:\r\n\r\nrapidSpell.setServiceType('asmx');\r\n\r\nDoing that will use the .NET 2 ASMX Web Service instead of .NET 4 WCF",
"URL (click to get more error info): <a href='",
"\r\n\r\n",
"application/json",
"jQuery is not present, please add the jQuery core script to this page if you wish to have rapidSpell.useAJAXWebService set true.",
"rswihelper.aspx",
"Please ensure that you include the RapidSpell-Core.js file in your page, before the RapidSpell-AYT.js file is imported.",
"visibility:",
"style.height",
"style.width",
"style.visibility",
"style.display",
"DOMAttrModified",
"rsw_checkValuesForChange()",
"rsw_setupTextBoxes",
"rsw_spellable",
"spellableLabel",
"SETUPTB:",
" reset to original display=",
" no original display known, going to default inline-block",
"rsw_waitStartAYT",
"rsw_startAYT ",
"rsw__initTB",
"link",
"fonts.googleapis",
"onload1",
"rswi1_button",
"20",
"Sorry the server has failed to respond to the spell check request. Please check the URL set in the RapidSpellWInlineHelperPage property in the RapidSpellWInline ctrl.",
"ayt",
"rsw_enableAsYouTypeTextBox",
"iframe",
"display:none; overflow-x:hidden;overflow-y:scroll; ",
"border-width:1px;border-color:#7F9DB9;border-style:solid;",
"height:1px;width:1px;",
"1",
"maxlength",
"#7F9DB9",
"#ABADB3",
"#E3E9EF",
"#707070",
"elementID",
"enabled",
"CssSheetURL",
"ifDoc.body.className",
"iframe.style.zIndex",
"ifDoc.body.style.backgroundColor",
"iframe.style.borderTopColor",
"iframe.style.borderBottomColor",
"iframe.style.borderLeftColor",
"iframe.style.borderRightColor",
"ifDoc.body.style.color",
"iframe.style.borderStyle",
"iframe.style.borderWidth",
"ifDoc.body.style.fontSize",
"ifDoc.body.style.fontWeight",
"ifDoc.body.style.fontStyle",
"ifDoc.body.style.fontFamily",
"ifDoc.body.style.textDecoration",
"textIsXHTML",
"ifDoc.body.style.border",
"_Disabled",
"solid",
"onload 2",
"visibility:hidden;",
"position:absolute; top:0px; left:0px; visibility:hidden;",
"rsw_onRSTextBoxesInit()",
"HTMLEvents",
"rs_AYT.onPause()",
"rsw_onRSTextBoxesInit",
"rsw_delayInit()",
"rsw_delayInit",
"rs_AYT.onTextBoxesInit()",
"white",
"SWITCHTB:",
" original display=",
"__SCROLLPOSITIONX",
"__SCROLLPOSITIONY",
"rsw_addTbFinish",
"setTimeout( function() { rsw_addTbFinish( ",
", '",
"');}, 50 ); ",
"auto");																																				var rs_s2=window;var rs_s3=document;




if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}
if (!window.rsw_consoleLog) rs_s2.rsw_consoleLog = function () { };
console.log(rsS14[0]);


var rsw_logToConsole = false;
function rsw_consoleLog(m, force) {
 if(rsw_logToConsole || force)
 console.log(rsS14[1]+m);
}


var rsw_boxSizingEnabled = true;
var rsw_leftHide = rsS14[2];
var rsw_supportAutoSize = false;
var rsw_absolutePositionStaticOverlay = false;
var rsw_copyFontColor = true;
var rsw_updatingShadow = false;
var rsw_spellCheckRunning = false;
var rsw_useBattleShipStyle = false;
var rsw_key_down_timeout = 150;
var rsw_inline_script_loaded = true;
var rsw_rs_styleURL = rsS14[3]; var rsw_rs_menu_styleURL = rsS14[3];
var rsw_config = new Array();
var rsw_tbs = new Array();
var rsw_scs = new Array();
var rsw_isASPX = true;
var rsw_copyLineHeight = true;
var rsw_activeTextbox;
var rsw_previouslyActiveTextbox;
var rsw_ASPNETAJAX_OnHandlersAdded = false;
var rsw_ayt_check = false;
var rsw_ayt_enabled = true;
var rsw_key_down_timer = null;
var rsw_contextMenu = null;
var rsw_lastRightClickedError;
var rsw_comIF = rs_s2.frames[rsS14[4]];
var rsw_inProcessTB;
var rsw_inProcessSC;
var rsw_spellBoot = rsS14[3];
var rsw_channel_state = rsS14[5]; var rsw_channel_timeout;
var RS_ContextMenuTable_Class = rsS14[6];
var RS_CMItemSeparator_Class = rsS14[7];
var RS_ContextMenuItem_Class = rsS14[8];
var RS_ContextMenuItem_AllSubItem_Class = rsS14[9];
var RS_ContextMenuItem_Disabled_Class = rsS14[10];
var rsw_debug = false;
var rsw_inProcessTBResetCaret = true;
var rsw_correctCaret = true;
var rsw_reconcileChanges = true;
var rsw_id_waitingToInitialize = null;
var rsw_overlayCSSClassName = rsS14[11];
var rsw_yScroll = null;
var rsw_isMac = typeof (navigator.userAgent) != rsS14[12] && navigator.userAgent.indexOf(rsS14[13]) > -1;
var rsw_spellCheckOnBlur = true;
var rsw_mozly = navigator.userAgent.indexOf(rsS14[14]) > -1;
var rsw_firefox = navigator.userAgent.indexOf(rsS14[15]) > -1;
var rsw_msie = navigator.userAgent.indexOf(rsS14[16]) > -1;
var rsw_msie11 = navigator.userAgent.indexOf(rsS14[16]) == -1 && navigator.userAgent.indexOf(rsS14[17])>-1;
var rsw_chrome = navigator.userAgent.indexOf(rsS14[18]) > -1;
var rsw_safari = navigator.userAgent.indexOf(rsS14[19]) > -1;
var rsw_msedge = navigator.userAgent.indexOf(rsS14[20]) > -1;
var rsw_applewebkit = navigator.userAgent.indexOf(rsS14[21]) > -1;
var rsw_compatibleBrowser = rsw_msie || rsw_mozly || rsw_chrome || rsw_applewebkit;
var rsw_W7 = navigator.userAgent.indexOf(rsS14[22]) > -1;
var rsw_W8 = navigator.userAgent.indexOf(rsS14[23]) > -1;
var rsw_MenuOnRightClick = true;

var rsw_newlineexp = new RegExp(rsw_msie?rsS14[24]:rsS14[25]);
var rsw_ffMaxLengthChecker;
var rsw_haltProcesses = false;
var rsw_cancelCall = false;
var rsw_suppressWarnings = rsw_suppressWarnings ? rsw_suppressWarnings : false;

var rsw_aux_oninit_handlers = new Array(); var rsw_ObjsToInit = new Array(); var RSWITextBox_DownLevels = new Array(); var rsw_showHorizScrollBarsInFF = false;
var rsw_autoFocusAfterAJAX = true;
var rsw_recalculateOverlayPosition = true;
var rsw_adjustOffsetSizeForStrict = true;
var rsw_ie9Standards = false;
var rsw_ie9;
try {
 rsw_ie9 = navigator.appVersion.indexOf(rsS14[26]) > -1 || navigator.appVersion.indexOf(rsS14[27]) > -1;
 rsw_ie9Standards = rsw_ie9 && rs_s3.compatMode == rsS14[28];
} catch (e) {
 rsw_logException(e);
}



function rsw_IeVersion() {
 var value = {
 IsIE: false,
 TrueVersion: 0,
 ActingVersion: 0,
 CompatibilityMode: false
 };

 var trident = navigator.userAgent.match(/Trident\/(\d+)/);
 if (trident) {
 value.IsIE = true;
 value.TrueVersion = parseInt(trident[1], 10) + 4;
 }

 var msie = navigator.userAgent.match(/MSIE (\d+)/);
 if (msie) {
 value.IsIE = true;
 value.ActingVersion = parseInt(msie[1]);
 } else {
 value.ActingVersion = value.TrueVersion;
 }

 if (value.IsIE && value.TrueVersion > 0 && value.ActingVersion > 0) {
 value.CompatibilityMode = value.TrueVersion != value.ActingVersion;
 }
 return value;
}

function rsw_unregisterTextBox(tbId) {
 if (typeof (rsw_tbs) == rsS14[12] || typeof (tbId) == rsS14[12]) return;
 for (var i = rsw_tbs.length - 1; i >= 0; i--) {
 if (rsw_tbs[i].shadowTBID === tbId) {
 if (rsw_scs[i] == rsw_tbs[i].spellChecker && i < rsw_scs.length) {
 rsw_scs[i] = null;
 rsw_scs.splice(i, 1);
 }
 if (rsw_activeTextbox == rsw_tbs[i])
 rsw_activeTextbox = null;
 if (rsw_inProcessTB == rsw_tbs[i])
 rsw_inProcessTB = null;

 if (rsw_inProcessSC == rsw_tbs[i])
 rsw_inProcessSC = null;

 rsw_tbs[i] = null;
 rsw_tbs.splice(i, 1);
 break;
 }
 }
}



function rsw_nextNonHiddenFormElement(_form, startIndex) {
 var i = startIndex;
 var type;
 while (i < _form.length) {
 type = _form[i].getAttribute(rsS14[29]);
 if (type == null || type.toLowerCase() != rsS14[30])
 return _form[i];
 else
 i++;
 }
 if (startIndex > 0)
 return rsw_nextNonHiddenFormElement(_form, 0);
 else
 return null;
}

function rsw_focusToNextField(tbs) {
 var currentTabIndex;
 if (!rsw_supportAutoSize) {
 currentTabIndex = tbs.shadowTB.getAttribute(rsS14[31]);
 } else {
 currentTabIndex = tbs.iframe.getAttribute(rsS14[31]);
 }
 var currentTabIndexP = null;

 if (currentTabIndex != null) currentTabIndexP = parseInt(currentTabIndex);

 if (currentTabIndex == null) {
 for (var i = 0; i < tbs.shadowTB.form.length; i++) {
 if (tbs.shadowTB.form[i] == tbs.shadowTB) {
 var targ = null;
 if (i + 1 < tbs.shadowTB.form.length)
 targ = rsw_nextNonHiddenFormElement(tbs.shadowTB.form, i + 1);

 if (targ != null) {
 rsw_focusTBSOrFormElement(targ);
 }
 
 return;
 }
 }
 } else {
 var nextUpIndex = Number.POSITIVE_INFINITY;
 var nextUpEl = null;
 var elementWith1TI = null;
 for (var i = 0; i < tbs.shadowTB.form.length; i++) {
 var ti;
 if (!rsw_supportAutoSize) {
 ti = parseInt(tbs.shadowTB.form[i].getAttribute(rsS14[31]));
 } else {
 ti = parseInt(tbs.shadowTB.form[i].getAttribute(rsS14[32]));
 if (ti === null || isNaN(ti))
 ti = parseInt(tbs.shadowTB.form[i].getAttribute(rsS14[31])); }



 if (ti > currentTabIndexP && ti < nextUpIndex) {
 nextUpIndex = ti;
 nextUpEl = tbs.shadowTB.form[i];
 }


 if (ti == 1)
 elementWith1TI = tbs.shadowTB.form[i];
 }

 if (nextUpEl!=null) {
 rsw_focusTBSOrFormElement(nextUpEl);
 return;
 }

 if (elementWith1TI != null) {
 rsw_focusTBSOrFormElement(elementWith1TI);
 } else {
 var targ = null;
 targ = rsw_nextNonHiddenFormElement(tbs.shadowTB.form, 0);

 if (targ != null) {
 rsw_focusTBSOrFormElement(targ);
 }
 }
 }
}

function rsw_focusTBSOrFormElement(targ) {
 var ntbs = rsw_getTBSFromID(targ.id);
 if (ntbs != null && typeof ntbs.focus == rsS14[33]) ntbs.focus();
 else targ.focus();
}


function rsw_logException(excep) {
 var extra = rsS14[3];
 
 rsw_consoleLog(excep.message + rsS14[34] + excep.name + rsS14[34] + extra, true);
}

function rsw_addTBConfig(config) {
 var found = false;
 for (var i = 0; rsw_config != null && i < rsw_config.length; i++) {
 if (rsw_config[i].values[0] == config.values[0]) { found = true;
 rsw_config[i] = config;
 }
 }
 if (!found)
 rsw_config[rsw_config.length] = config;
}

function rsw_refreshActiveTextbox() {
 if (rsw_activeTextbox != null && rsw_activeTextbox.iframe != null && !rsw_activeTextbox.isStatic) {
 rsw_activeTextbox.iframe = rs_s3.getElementById(rsw_activeTextbox.iframe.id);
 }
 return rsw_activeTextbox;
}

function rsw_getTBConfig(tbid) {
 for (var i = 0; i < rsw_config.length; i++) {
 if (rsw_config[i].values[0] == tbid + rsS14[35])
 return rsw_config[i];
 }
}


function rsw_getInternetExplorerVersion()
{
 var rv = -1; if (navigator.appName == rsS14[36]) {
 var ua = navigator.userAgent;
 var re = new RegExp(rsS14[37]);
 if (re.exec(ua) != null)
 rv = parseFloat(RegExp.$1);
 }
 return rv;
}

function rsw_debug_getTime() {
 var now = new Date();
 return now.getHours() + rsS14[38] + now.getMinutes() + rsS14[38] + now.getSeconds() + rsS14[38] + now.getMilliseconds() + rsS14[39];
}


function rsw_setShadowTB(shadow, value) {
 if (typeof (rsw_ignorePropertyChange) != rsS14[12]) rsw_ignorePropertyChange = true;
 if (typeof (rsw_detachMutationObserver) != rsS14[12]) rsw_detachMutationObserver(shadow);
 
 shadow.removeAttribute(rsS14[40]);
 shadow.value = value;
 if (typeof (rsw_ignorePropertyChange) != rsS14[12]) rsw_ignorePropertyChange = false;
 if (typeof (rsw_attachMutationObserver) != rsS14[12]) rsw_attachMutationObserver(shadow);
}







function rsw_getTBSFromID(id, copyStyle) {
 
 for (var i = 0; i < rsw_tbs.length; i++) {

 if (rsw_tbs[i].shadowTBID == id || rsw_tbs[i].shadowTBID == id+rsS14[41]) {

 return rsw_tbs[i];
 }
 }

 if (typeof rsw_isTextBoxSpellChecked == rsS14[33] && !rsw_isTextBoxSpellChecked(rs_s3.getElementById(id))) return null;

 var tbs = _createTBSForPlainTB(id, copyStyle);
 if (tbs != null) {
 rsw_tbs[rsw_tbs.length] = tbs;
 return rsw_tbs[rsw_tbs.length - 1];

 } else return null;


 }

function rsw_createBackUpPlainTBS(id) {
 try{
 var divElement = rs_s3.createElement(rsS14[42]);
 divElement.id = id + rsS14[43];
 divElement.setAttribute(rsS14[44], rsw_overlayCSSClassName); if (!rsw_absolutePositionStaticOverlay) {
 divElement.setAttribute(rsS14[45], rsS14[46]);
 rs_s3.getElementById(id).parentNode.insertBefore(divElement, rs_s3.getElementById(id));

 } else {
 divElement.setAttribute(rsS14[45], rsS14[47]);
 rs_s3.body.appendChild(divElement);
 }
 var myIFrame = rs_s3.getElementById(id + rsS14[43]);
 myIFrame.style.display = rsS14[48]; myIFrame.className = rsw_overlayCSSClassName;
 } catch (excep) { rsw_logException(excep); }

 return myIFrame;
}

function _createTBSForPlainTB(id, copyStyle) {
 if (rsw_haltProcesses) return;

 var myIFrame = rs_s3.getElementById(id + rsS14[43]);
 if (myIFrame == null && rs_s3.getElementById(id) != null) myIFrame = rsw_createBackUpPlainTBS(id);

 if (myIFrame == null) return null;

 var ptb = new OldIETB(myIFrame);
 var theTB = rs_s3.getElementById(id);

 try {
 if (theTB.name == rsS14[49] && theTB.parentNode.tagName.toLowerCase() == rsS14[50]) {
 theTB = theTB.parentNode;
 theTB.id = id + rsS14[51];
 }
 } catch (excep) { } 

 if (rsw_absolutePositionStaticOverlay || (theTB.style.position && theTB.style.position == rsS14[52])) {
 myIFrame.style.position = rsS14[52];
 rsw_updatePosition(myIFrame, theTB);


 
 }
 
 if (theTB.tagName.toUpperCase() == rsS14[53]) {
 rsw_auto_copyStyle(myIFrame.id, theTB.id);
 }



 myIFrame.style.backgroundColor = theTB.style.backgroundColor; 
 if (theTB.style.fontFamily)
 myIFrame.style.fontFamily = theTB.style.fontFamily;
 if (theTB.style.fontSize)
 myIFrame.style.fontSize = theTB.style.fontSize;

 ptb.initialize();


 if (copyStyle)
 rsw_copyComputedStyle(myIFrame, theTB);

 rsw_resetTBSSize(myIFrame, theTB.id);

 if (theTB.tagName.toLowerCase() != rsS14[54])
 ptb.multiline = false;

 return ptb;
}

function rsw_resetTBSSize(myIFrame, theTBid, isAYT) {
 var usingBorderSizing = false;
 if (typeof (myIFrame.style.boxSizing) != rsS14[12] && rsw_boxSizingEnabled) {
 myIFrame.style.boxSizing = rsS14[55];
 usingBorderSizing = true;
 }
 var tbWidth = rsw_getElementWidth(theTBid, myIFrame.id.indexOf(rsS14[43]) > -1); var theTB = rs_s3.getElementById(theTBid);
 if (typeof (tbWidth) == rsS14[56] && tbWidth.indexOf(rsS14[57]) > -1) {
 myIFrame.style.width = tbWidth;
 if (rsw_supportAutoSize) {
 setTimeout(function () { theTB.style.width = myIFrame.getBoundingClientRect().width + rsS14[58]; }, 5); myIFrame.contentWindow.onresize = function () {
 theTB.style.width = myIFrame.getBoundingClientRect().width + rsS14[58];
 rs_s2.width++; rs_s2.width--;
 };
 }
 } else {

 if (!usingBorderSizing && (((rs_s3.compatMode && rs_s3.compatMode != rsS14[59]) || (rsw_mozly && !rsw_msie11 && !rsw_chrome)) && rsw_adjustOffsetSizeForStrict)) {
 
 if(theTB.tagName.toUpperCase()==rsS14[53])
 tbWidth = rsw_adjustOffsetWidthForStrict(myIFrame, tbWidth);
 else
 tbWidth = rsw_adjustOffsetWidthForStrict(theTB, tbWidth);
 }


 if (tbWidth >= 0 && !(rsw_supportAutoSize && myIFrame.style.width.indexOf(rsS14[57]) > -1)) { 
 myIFrame.style.width = tbWidth + rsS14[58];

 if (rsw_chrome) {
 setTimeout(function () {
 myIFrame.style.width = (tbWidth + 1) + rsS14[58]; setTimeout(function () { myIFrame.style.width = tbWidth + rsS14[58] }, 50);
 }, 700);
 }
 
 rsw_consoleLog(rsS14[60] + tbWidth + rsS14[61] + myIFrame.style.width, false);
 } else 
 rsw_consoleLog(rsS14[62] + myIFrame.style.width, false);

 }

 var tbHeight = rsw_getElementHeight(theTBid, myIFrame.id.indexOf(rsS14[43]) > -1);

 if (typeof (tbHeight) == rsS14[56] && tbHeight.indexOf(rsS14[57]) > -1) {
 myIFrame.style.height = tbHeight;
 } else {
 
 if (!usingBorderSizing && (((rs_s3.compatMode && rs_s3.compatMode != rsS14[59]) || (rsw_mozly && !rsw_msie11 && !rsw_chrome)) && rsw_adjustOffsetSizeForStrict)) {
 if (theTB.tagName.toUpperCase() == rsS14[53])
 tbHeight = rsw_adjustOffsetHeightForStrict(myIFrame, tbHeight);
 else
 tbHeight = rsw_adjustOffsetHeightForStrict(theTB, tbHeight);
 
 }

 if (tbHeight < 26 && !isAYT) { tbHeight = 50;
 myIFrame.style.overflowX = rsS14[63];
 }

 
 if (tbHeight >= 0)
 myIFrame.style.height = tbHeight + rsS14[58];
 }
}



function rsw_updatePosition(targetElement, sourceElement) {
 if (!rsw_absolutePositionStaticOverlay && !(sourceElement.style.position && sourceElement.style.position == rsS14[52])) {
 targetElement.style.verticalAlign = rsS14[64]; } else {
 
 var marginDeltaY = 0, marginDeltaX = 0;
 
 if (((rs_s3.compatMode && rs_s3.compatMode != rsS14[59]) || rsw_mozly) && rsw_adjustOffsetSizeForStrict) {

 var tpTop = rsw_getStyleProperty(sourceElement, rsS14[65]);
 marginDeltaY = parseInt(tpTop.substring(0, tpTop.length - 2));
 var tpLeft = rsw_getStyleProperty(sourceElement, rsS14[66]);
 marginDeltaX = parseInt(tpLeft.substring(0, tpLeft.length - 2));

 }
 if (isNaN(marginDeltaX)) marginDeltaX = 0;
 if (isNaN(marginDeltaY)) marginDeltaY = 0;
 targetElement.style.left = (rsw_findPosX(sourceElement) - marginDeltaX) + rsS14[58];
 targetElement.style.top = (rsw_findPosY(sourceElement) - marginDeltaY) + rsS14[58];
 }
}

function rsw_adjustOffsetWidthForStrict(el, width) {

 try {
 var tpLeft = rsw_getStyleProperty(el, rsS14[67]);
 var tpRight = rsw_getStyleProperty(el, rsS14[68]);
 var pX = parseInt(tpLeft.substring(0, tpLeft.length - 2)) + parseInt(tpRight.substring(0, tpRight.length - 2));
 var tbLeft = rsw_getStyleProperty(el, rsS14[69]);
 var tbRight = rsw_getStyleProperty(el, rsS14[70]);
 var bX = parseInt(tbLeft.substring(0, tbLeft.length - 2)) + parseInt(tbRight.substring(0, tbRight.length - 2));
 if (isNaN(pX) || isNaN(bX)) return width;
 else {
 
 return width - pX - bX;
 }
 } catch (e) {
 rsw_logException(e);
 return width;
 }
}

function rsw_adjustOffsetHeightForStrict(el, height) {
 try {
 var tpTop = rsw_getStyleProperty(el, rsS14[71]);
 var tpBottom = rsw_getStyleProperty(el, rsS14[72]);
 var pY = parseInt(tpTop.substring(0, tpTop.length - 2)) + parseInt(tpBottom.substring(0, tpBottom.length - 2));
 var tbTop = rsw_getStyleProperty(el, rsS14[73]);
 var tbBottom = rsw_getStyleProperty(el, rsS14[74]);
 var bY = parseInt(tbTop.substring(0, tbTop.length - 2)) + parseInt(tbBottom.substring(0, tbBottom.length - 2));
 if (isNaN(pY) || isNaN(bY)) return height;
 else
 return height - pY - bY;
 } catch (e) {
 return height;
 }

}
function rsw_getStyleProperty(obj, IEStyleProp) {

 if (obj.currentStyle) { return obj.currentStyle[IEStyleProp];
 } else if (rs_s3.defaultView.getComputedStyle) { return rs_s3.defaultView.getComputedStyle(obj, null)[IEStyleProp]; } else {
 return null;
 }
}




function rsw_copyComputedStyle(tEl, sEl) {
 if (sEl == null || tEl == null) {
 rsw_consoleLog(rsS14[75] + (sEl == null) + rsS14[76] + (tEl == null) + rsS14[77]);
 return;
 }
 var col;

 var srcIsIFrame = sEl.tagName.toUpperCase() == rsS14[53];
 var tarIsIFrame = tEl.tagName.toUpperCase() == rsS14[53] || tEl.tagName.toUpperCase() == rsS14[78];
 var tarIsContentWindowBody = tEl.tagName.toUpperCase() == rsS14[78];
 var staticOverRich = srcIsIFrame && !tarIsIFrame;
 var ayt = tarIsIFrame;

 if (sEl.currentStyle)
 col = sEl.currentStyle;
 else if (rs_s3.defaultView && rs_s3.defaultView.getComputedStyle)
 col = rs_s3.defaultView.getComputedStyle(sEl, null);
 else
 return;
 
 for (sp in col) {
 if (isNaN(parseInt(sp))) { try {
 if (sp.indexOf(rsS14[79]) == -1 && sp != rsS14[80] && sp != rsS14[81] && sp != rsS14[82] && sp != rsS14[83] && sp != rsS14[84] && sp != rsS14[85] && sp.toLowerCase().indexOf(rsS14[86]) == -1 && sp != rsS14[87]
 && sp != rsS14[64] && sp != rsS14[88] && sp != rsS14[89] && sp.indexOf(rsS14[90]) == -1 && sp.indexOf(rsS14[91]) == -1
 && sp.indexOf(rsS14[92]) == -1 && sp.indexOf(rsS14[44]) == -1 && sp.indexOf(rsS14[93]) == -1 && sp.indexOf(rsS14[94]) == -1
 && sp.indexOf(rsS14[95]) == -1 && sp.indexOf(rsS14[96]) == -1 && sp.indexOf(rsS14[97]) == -1
 && sp.indexOf(rsS14[98]) == -1 && sp.indexOf(rsS14[99]) == -1 && sp.indexOf(rsS14[100]) == -1 && (rsw_copyFontColor || sp!=rsS14[101])
 && ((!staticOverRich && !ayt) || sp.indexOf(rsS14[102]) == -1)
 && sp.indexOf(rsS14[103]) == -1 && sp.indexOf(rsS14[104]) == -1 && ((!staticOverRich && !ayt) || sp.indexOf(rsS14[105]) == -1) 
 && (sp.indexOf(rsS14[106]) == -1 || sp==rsS14[107]) && sp.indexOf(rsS14[108]) == -1 && sp.indexOf(rsS14[109]) == -1 && sp.indexOf(rsS14[110]) == -1 && sp.indexOf(rsS14[111]) == -1
 && (!tarIsContentWindowBody || sp.indexOf(rsS14[112])==-1)
 ) {
 var v = rsw_getStyleProperty(sEl, sp);
 if (typeof (v) != rsS14[12] && v != rsS14[3] && v != null
 && (rsw_copyLineHeight || sp!=rsS14[107])
 && (sp.indexOf(rsS14[113]) == -1 || v != rsS14[114] || (rsw_firefox && !ayt))
 && (sp.indexOf(rsS14[115]) == -1 || v != rsS14[116]) && !(rsw_msie11 && (sp == rsS14[101] || sp==rsS14[117]) && sEl.placeholder.length > 0 && sEl.value.length == 0) ) {
 tEl.style[sp] = v;

 
 }
 }

 } catch (ex) { rsw_logException(ex);
 }
 }
 }
 if (rsw_firefox)
 tEl.style.overflowY = rsS14[63];

 if (typeof (tEl.style.boxSizing) != rsS14[12]) {
 tEl.style.boxSizing = rsS14[55];
 }


 }



function rsw_auto_copyStyle(iframeId, tbId) {
 
 var shtb = rs_s3.getElementById(tbId);
 var ifr = rs_s3.getElementById(iframeId);
 if (shtb == null) {
 rsw_consoleLog(rsS14[118] + tbId +rsS14[119]);
 }
 if ( ifr == null || ifr.contentWindow == null || ifr.contentWindow.document == null || ifr.contentWindow.document.body ==null) {
 rsw_consoleLog(rsS14[120] + iframeId + rsS14[121]);
 setTimeout(function () { rsw_auto_copyStyle(iframeId, tbId); }, 100);
 return;
 }
 var ignorePosition = shtb.style.left == rsw_leftHide;
 var isOverlay = ifr.tagName.toUpperCase() == rsS14[42];

 try {
 if (!isOverlay) {
 if (shtb.style.zIndex)
 ifr.style.zIndex = shtb.style.zIndex;
 
 if (!rsw_mozly && !rsw_chrome && !rsw_applewebkit) {

 rsw_copyComputedStyle(ifr.contentWindow.document.body, shtb);
 } else {
 rsw_copyComputedStyle(ifr, shtb);
 if (ifr.contentWindow) rsw_copyComputedStyle(ifr.contentWindow.document.body, shtb);
 }

 if (!ignorePosition) {
 ifr.style.position = shtb.style.position;
 ifr.style.left = shtb.style.left;
 ifr.style.top = shtb.style.top;
 }
 }
 var col = null;
 if (shtb.tagName.toUpperCase() == rsS14[53] && shtb.contentWindow) {
 if (shtb.currentStyle)
 col = shtb.contentWindow.document.body.currentStyle;
 else if (shtb.contentWindow.document.defaultView && shtb.contentWindow.document.defaultView.getComputedStyle)
 col = shtb.contentWindow.document.defaultView.getComputedStyle(shtb.contentWindow.document.body, null);
 } else {
 if (shtb.currentStyle)
 col = shtb.currentStyle;
 else if (rs_s3.defaultView && rs_s3.defaultView.getComputedStyle)
 col = rs_s3.defaultView.getComputedStyle(shtb, null);
 }

 if (col != null && !isOverlay) {
 var borderStyles = [rsS14[122], rsS14[81], rsS14[82],
 rsS14[71], rsS14[67], rsS14[68], rsS14[72], rsS14[66], rsS14[65], rsS14[123], rsS14[124],
 rsS14[84], rsS14[91], rsS14[125], rsS14[126], rsS14[127], rsS14[128], rsS14[74],
 rsS14[73], rsS14[69], rsS14[70], rsS14[129], rsS14[130], rsS14[131], rsS14[132], rsS14[133],
 rsS14[134], rsS14[135], rsS14[136], rsS14[137], rsS14[138], rsS14[139], rsS14[140], rsS14[141],
 rsS14[142], rsS14[143], rsS14[142], rsS14[143],
 rsS14[144], rsS14[145],
 rsS14[146], rsS14[147], rsS14[148]];
 for (var v = 0; v < borderStyles.length; v++) {
 if (col[borderStyles[v]]) {
 if (!(rsw_msie && rsw_getInternetExplorerVersion() <= 9 && borderStyles[v].indexOf(rsS14[91]) > -1
 && col[rsS14[134]] == rsS14[48]
 ) && 
 !( rsw_chrome && borderStyles[v].indexOf(rsS14[91]) > -1
 && col[rsS14[91]] == rsS14[149]
 )
 &&
 (!(ignorePosition && (borderStyles[v] == rsS14[81] || borderStyles[v] == rsS14[82] || borderStyles[v] == rsS14[84])))
 ) {
 if (borderStyles[v] != rsS14[82] || col[borderStyles[v]] != rsS14[150]) ifr.style[borderStyles[v]] = col[borderStyles[v]];
 
 }
 }
 }

 } else if (!isOverlay) {

 if (shtb.style.border) {
 ifr.style.border = shtb.style.border;

 if (shtb.style.border == rsS14[149] && rsw_mozly) ifr.style.border = rsS14[151]; }

 } else {
 ifr.style[rsS14[105]] = rsS14[3];
 ifr.style[rsS14[67]] = col[rsS14[67]].substring(0, col[rsS14[67]].length - 2) + col[rsS14[66]].substring(0, col[rsS14[66]].length - 2) + rsS14[58];
 ifr.style[rsS14[68]] = col[rsS14[68]].substring(0, col[rsS14[68]].length - 2) + col[rsS14[123]].substring(0, col[rsS14[123]].length - 2) + rsS14[58];
 ifr.style[rsS14[71]] = col[rsS14[71]].substring(0, col[rsS14[71]].length - 2) + col[rsS14[65]].substring(0, col[rsS14[65]].length - 2) + rsS14[58];
 ifr.style[rsS14[72]] = col[rsS14[72]].substring(0, col[rsS14[72]].length - 2) + col[rsS14[124]].substring(0, col[rsS14[124]].length - 2) + rsS14[58];
 ifr.style[rsS14[152]] = rsS14[30];
 ifr.style[rsS14[153]] = rsS14[63];
 }

 } catch (excep) {
 rsw_logException(excep);

 }



}




var rsw_http_request = false;

function rsw_createRequest() {
 if (rsw_haltProcesses) return;

 rsw_http_request = false;

 if (rs_s2.XMLHttpRequest) { 
 rsw_http_request = new XMLHttpRequest();
 if (rsw_http_request.overrideMimeType) {
 rsw_http_request.overrideMimeType(rsS14[154]);
 }

 } else if (rs_s2.ActiveXObject) { 
 try {
 rsw_http_request = new ActiveXObject(rsS14[155]);
 } catch (e) {
 try {
 rsw_http_request = new ActiveXObject(rsS14[156]);
 } catch (e) { if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[158]; rsw_logException(e); }
 }
 }

 return rsw_http_request;
}

function rsw_sendRequest(req, url, paramXML, callBack, synchronous) {
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[160]+url+rsS14[39];
 req.onreadystatechange = callBack;

 
 req.open(rsS14[161], url, !synchronous);
 req.setRequestHeader(rsS14[162], rsS14[163]);

 if (!rsw_ie9Standards && typeof (DOMParser) != rsS14[12] && navigator.userAgent.indexOf(rsS14[19]) == -1) { var domParser = new DOMParser();
 var xmlDocument = domParser.parseFromString(paramXML, rsS14[164]);
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[165];
 req.send(xmlDocument);
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[166];
 } else {
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[167];
 req.send(paramXML);
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[166];
 }

 if (synchronous) {

 }
}


function RapidSpellCheckerClient(helperPageURL) {
 this.Check = Check;
 this.AddWord = AddWord;

 this.userCallback = null;
 this.result = null;
 this.generateResult = generateResult;
 this.createErrorHTML = createErrorHTML;
 this.createErrorMouseUp = createErrorMouseUp;
 this.textChecked = null;

 this.OnSpellCheckCallBack = OnSpellCheckCallBack;
 this.rapidSpellWebPage = helperPageURL;
 this.getSpellBootString = getSpellBootString;
 this.config;
 this.useXMLHTTP = true;
 this.getParameterValue = getParameterValue;
 this.setParameterValue = setParameterValue;

 function getParameterValue(param) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 return this.config.values[pp];
 }
 }

 function setParameterValue(param, value) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 this.config.values[pp] = value;
 }
 }


 function getSpellBootString(xml) {
 var res = new String();
 if (xml) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 var val = rsw_escapeHTML(this.config.values[pp]);
 res += rsS14[168] + this.config.keys[pp] + rsS14[169] + val + rsS14[170] + this.config.keys[pp] + rsS14[169];
 }
 } else {

 for (var pp = 0; pp < this.config.keys.length; pp++) {
 res += rsS14[171] + this.config.keys[pp] + rsS14[172] + this.config.values[pp] + rsS14[173];
 }
 }
 return res;
 }
 

 function Check(text, asynchronousCallback, errorCallback) {
 var blocking = true;
 if (typeof (asynchronousCallback) == rsS14[33]) {
 blocking = false;
 this.userCallback = asynchronousCallback;
 } else
 this.userCallback = null;

 rsw_inProcessSC = this;
 this.textChecked = text;
 rsw_spellCheckText(text, true, blocking, rsS14[174], errorCallback);

 if (blocking) { _rsXMLCallBack();
 return this.result;
 }
 }

 function AddWord(word, errorCallback) {
 rsw_inProcessSC = this;
 rsw_serverAdd(word, errorCallback);
 }

 function OnSpellCheckCallBack(response, numberOfErrors) {
 this.result = this.generateResult(response, numberOfErrors);
 if (this.userCallback != null)
 this.userCallback(this.result);

 }

 function unescapeEntities(text) {
 return rsw_unescapeHTML(text);

 }

 function createErrorMouseUp(suggestions) {

 var suggestionList = rsS14[3];
 if (suggestions.length > 0) {
 suggestionList = rsS14[175];
 for (var i = 0; i < suggestions.length; i++) {
 var reg1 = new RegExp("'", "g");
 var reg2 = new RegExp("\"", "g");
 suggestionList += suggestions[i].replace(/\\/g, "\\\\").replace(reg1, "^apos^").replace(reg2, "^qt^");
 if (i < suggestions.length - 1)
 suggestionList += rsS14[176];
 }
 suggestionList += rsS14[175];
 }
 return suggestionList;

 }

 function createErrorHTML(word, suggestions) {
 var mouseup = createErrorMouseUp(suggestions);

 var html = "<span class='rs_err_hl' onmouseup=\"" + mouseup + "\" oncontextmenu=\"try{event.cancelBubble=true;event.preventDefault();}catch(e){}return false;\">" + word + "</span>";
 return html;
 }


 function generateResult(response, numberOfErrors, forceIgnoreXML) {
 
 
 response = unescapeEntities(response);

 var result = new RapidSpellChecker_Result();
 result.originalText = this.textChecked;
 result.numberOfErrors = numberOfErrors;

 var errorReg = /<span class=[^>]* onmouseup="rsw_showMenu\(([^\]]*\]),this,event\)[^>]*>([^<]*)<\/span>/g;
 
 var match;
 var lengthToDiscard = 0;
 var wordStart = 0;
 result.errorPositionArray = new Array();
 while ((match = errorReg.exec(response)) != undefined) {
 var sugs = rsw_getSuggestionsArray(match[1]);
 for (var s = 0; s < sugs.length; s++) {
 sugs[s] = rsw_decodeSuggestionItem(sugs[s]);
 }
 wordStart = match.index - lengthToDiscard;
 result.errorPositionArray[result.errorPositionArray.length] = { start: wordStart,
 end: match[2].length + wordStart,
 word: match[2],
 suggestions: sugs
 };

 lengthToDiscard += errorReg.lastIndex - match.index - match[2].length;
 }

 return result;
 }
}

function RapidSpellChecker_Result() {
 this.originalText;
 this.numberOfErrors;
 this.errorPositionArray;
}



function rsw_spellCheck() {
 rsw_spellCheckText(rsw_inProcessSC.tbInterface.getText(), rsw_inProcessSC.useXMLHTTP, false, rs_s3.getElementById(rsw_inProcessSC.tbInterface.tbName));
}

function rsw_spellCheckText(textToCheck, useXmlHttp, synchronous, textBoxForParams, _optionalErrorCallback) {
 try{
 var rsw_useXMLHttpReq = useXmlHttp;
 var req = false;

 if (rsw_haltProcesses) return;
 else if (rsw_cancelCall) rsw_cancelCall = false;


 if (typeof (rapidSpellExtension) == rsS14[177] && (rapidSpellExtension.useWCFService || rapidSpellExtension.useAPIController) && typeof(rapidSpell) == rsS14[177] && rapidSpell.useAJAXWebService) { 
 var params = rsw_createSpellBootJSON(textToCheck, textBoxForParams);


 params[params.length] = { 'ParameterName': 'IAW', 'ParameterValue': rsw_ignoreAllWords.join("|") };
 try {
 rapidSpellExtension.rsw_sc = rsw_inProcessSC;
 } catch (error) {
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[178] + error;
 rsw_logException(error);
 }

 var data = {'textToCheck':textToCheck, 'parameters':params};
 rapidSpellExtension.serviceProxy.invoke(rsS14[179], data, _rsJSONCallBack, _optionalErrorCallback);

 } else {

 if (rsw_useXMLHttpReq) req = rsw_createRequest();

 if (!req) { rsw_comIF = rs_s2.frames[rsS14[4]];
 rsw_spellBoot = rsS14[180] + rsw_inProcessSC.rapidSpellWebPage + rsS14[181];
 rsw_spellBoot += rsS14[182];
 rsw_spellBoot += rsw_inProcessSC.getSpellBootString(false);
 rsw_spellBoot += rsS14[183];

 if (rsw_comIF.document.body)
 rsw_comIF.document.body.innerHTML = rsw_spellBoot;
 else {
 rsw_comIF.document.open();
 rsw_comIF.document.write(rsw_spellBoot);
 }
 rsw_comIF.document.forms[0].textToCheck.value = textToCheck;
 rsw_comIF.document.forms[0].IAW.value = rsw_ignoreAllWords.join(rsS14[184]);
 rsw_comIF.document.forms[0].submit();

 } else { var paramString = new String();
 var text = rsw_escapeHTML(textToCheck);
 paramString = rsS14[185] + text + rsS14[186] + rsw_ignoreAllWords.join(rsS14[184]) + rsS14[187] + rsw_inProcessSC.getSpellBootString(true) + rsS14[188];
 try {
 req.rsw_sc = rsw_inProcessSC;
 } catch (error) {
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[178] + error;
 rsw_logException(error);
 }
 if (typeof (rsw_fiddler_debug) != rsS14[12] && rsw_fiddler_debug)
 rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage + rsS14[189] + textToCheck, paramString, _rsXMLCallBack, synchronous);
 else
 rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage, paramString, _rsXMLCallBack, synchronous);
 }
 }
 } catch (excep) { rsw_logException(excep); }

}

function rsw_getSuggestionsArray(handlerCode) {
 var suggsClean = handlerCode;
 if(suggsClean.indexOf(rsS14[190])>-1)
 suggsClean = suggsClean.substring(suggsClean.indexOf(rsS14[190]) + 1, suggsClean.indexOf(rsS14[191]));
 if (suggsClean.length > 1) {
 suggsClean = suggsClean.substring(1, suggsClean.length - 1); }
 var resArray = suggsClean.split(rsS14[176]);
 if (resArray.length == 1 && resArray[0] == rsS14[3]) return [];
 else return resArray;
}


function RSStandardInterface(tbElementName) {
 this.tbName = tbElementName;
 this.getText = getText;
 this.setText = setText;
 function getText() {
 var t = rs_s3.getElementById(tbElementName).value;
 if (t.indexOf(rsS14[24]) == -1) {
 var rx = new RegExp("\n", "g");
 t = t.replace(rx, "\r\n");
 }
 return t;
 }
 function setText(text) {
 rs_s3.getElementById(tbElementName).value = (text);
 if (rsw_tbs != null) {
 for (var i = 0; i < rsw_tbs.length; i++) {
 if (rsw_tbs[i].shadowTB.id == this.tbName) {
 if (rsw_tbs[i].updateIframe) { rsw_tbs[i].updateIframe(); rsw_tbs[i].focus(); }
 }
 }
 }
 }
}


function RSAutomaticInterface(tbElementName) {

 this.tbName = tbElementName; this.getText = getText; this.setText = setText;
 this.identifyTarget = identifyTarget;
 this.target = null;
 this.targetContainer = null;
 this.searchedForTarget = false;
 this.targetIsPlain = true;
 this.showNoFindError = showNoFindError;
 this.finder = null;

 this.findContainer = findContainer;

 function findContainer() {
 this.identifyTarget();
 return this.targetContainer;
 }

 function showNoFindError() {
 alert(rsS14[192] + this.tbName + rsS14[193]);
 }

 function identifyTarget() {
 if (!this.searchedForTarget) {
 this.searchedForTarget = true;

 if (this.finder == null)
 this.finder = new RSW_EditableElementFinder();

 var plain = this.finder.findPlainTargetElement(this.tbName);
 var richs = this.finder.findRichTargetElements();

 if (plain == null && (richs == null || richs.length == 0) && !rsw_suppressWarnings) showNoFindError();
 else {

 if (richs == null || richs.length == 0) { this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 } else {


 if (plain == null && richs.length == 1) { this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[0][0]);
 this.targetContainer = richs[0][1];

 } else {
 var findIdentical = false;
 for (var rp = 0; rp < richs.length && !findIdentical; rp++)
 findIdentical = typeof (richs[rp][1].id) != rsS14[12] && richs[rp][1].id == this.tbName + rsS14[35];

 for (var rp = 0; rp < richs.length; rp++) {
 if (typeof (richs[rp][1].id) != rsS14[12] &&
 (
 (!findIdentical && richs[rp][1].id.indexOf(this.tbName) > -1) ||
 (findIdentical && richs[rp][1].id == this.tbName)
 )) {
 if (plain != null && richs[rp][1].id == plain.id + rsS14[35]) {
 this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 break;
 } else {
 this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[rp][0]);
 this.targetContainer = richs[rp][1];
 break;
 }
 }
 }

 

 if (this.target == null) { this.target = plain;
 this.targetIsPlain = true;
 this.targetContainer = plain;
 }
 }
 }
 }
 }
 }
 function getText() {
 try {
 this.identifyTarget();


 if (this.targetIsPlain)
 return this.target.value;
 else
 return this.target.innerHTML;
 } catch (excep) { rsw_logException(excep); return rsS14[3];}
 }
 function setText(text) {
 try{
 this.identifyTarget();


 if (this.targetIsPlain) {
 var ver = rsw_getInternetExplorerVersion();
 if (ver > 0 && ver < 7) text = text.replace(/</g, rsS14[194]).replace(/>/g, rsS14[195]); 
 this.target.value = text;
 } else
 this.target.innerHTML = text;

 if (typeof (rsw_tbs) != rsS14[12]) {
 for (var i = 0; i < rsw_tbs.length; i++) {

 if (rsw_tbs[i].shadowTB.id == this.tbName) {
 if (rsw_tbs[i].updateIframe) { rsw_tbs[i].updateIframe(); 
 }
 }
 }
 }
 } catch (excep) { rsw_logException(excep); }
 }
}


function SpellChecker(textBoxID) {

 this.state; this.getTBS = getTBS;
 this.textBoxID = textBoxID;
 this.rsw_tbs = null;
 this.OnSpellButtonClicked = OnSpellButtonClicked;
 this.OnSpellCheckCallBack = OnSpellCheckCallBack;
 this.finishedListener;
 this.leaveStaticSpellCheckListener;
 this.enterStaticSpellCheckListener;
 this.tbInterface = new RSStandardInterface(textBoxID);
 this.config; this.getSpellBootString = getSpellBootString;
 this.buttonID;
 this.getParameterValue = getParameterValue;
 this.setParameterValue = setParameterValue;
 this.showNoSpellingErrorsMesg = true;
 this.enterEditModeWhenNoErrors = true;
 this.noSuggestionsText = rsS14[196];
 this.ignoreAllText = rsS14[197];
 this.showChangeAllItem = false;
 this.changeAllText = rsS14[198];
 this.addText = rsS14[199];
 this.editText = rsS14[200];
 this.removeDuplicateText = rsS14[201];
 this.buttonTextSpellChecking = rsS14[202];
 this.buttonTextSpellMode = rsS14[203];
 this.buttonText = rsS14[204];
 this.noSpellingErrorsText = rsS14[205];
 this.changeButtonTextWithState = true;
 this.showAddMenuItem = true;
 this.showIgnoreAllMenuItem = true;
 this.showEditMenuItem = true;
 this.responseTimeout = 20; this.responseTimeoutMessage = rsS14[206];
 this.hasRunFieldID;
 this.OnTextBoxDoubleClicked = OnTextBoxDoubleClicked;
 this.doubleClickSwitchesMode = true;
 this.onLeaveEdit = onLeaveEdit;
 this.onEnterEdit = onEnterEdit;
 this.useXMLHTTP;
 this.ignoreXML = false;
 this.copyComputedStyleToOverlay = true;
 this.overlayCSSClassName = rsS14[11];
 this.hasRun = false;

 function OnTextBoxDoubleClicked() {
 if (this.doubleClickSwitchesMode)
 this.OnSpellButtonClicked(true);
 }

 function getSpellBootString(xml, json) {
 var res = new String();
 if (xml) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 var val;
 if(typeof(this.config.values[pp])==rsS14[56])
 val = rsw_escapeHTML(this.config.values[pp]);
 else 
 val = this.config.values[pp].toString();
 res += rsS14[168] + this.config.keys[pp] + rsS14[169] + val + rsS14[170] + this.config.keys[pp] + rsS14[169];
 }
 } else if (json) {
 res = [];
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 var val;
 if (typeof (this.config.values[pp]) == rsS14[56])
 val = rsw_escapeHTML(this.config.values[pp]);
 else
 val = this.config.values[pp].toString();
 res[res.length] = { 'ParameterName': this.config.keys[pp], 'ParameterValue': val };
 }
 } else {

 for (var pp = 0; pp < this.config.keys.length; pp++) {
 res += rsS14[171] + this.config.keys[pp] + rsS14[172] + this.config.values[pp] + rsS14[173];
 }
 }
 return res;
 }

 function getParameterValue(param) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 return this.config.values[pp];
 }
 }

 function setParameterValue(param, value) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 this.config.values[pp] = value;
 }
 }

 function getTBS() {
 if (rsw_haltProcesses) return;

 if (this.rsw_tbs == null) {
 var el = rs_s3.getElementById(this.textBoxID);
 if (el == null && !rsw_suppressWarnings) alert(rsS14[207] + this.textBoxID + rsS14[208]);
 else if (el != null) {

 rsw_overlayCSSClassName = this.overlayCSSClassName;
 this.rsw_tbs = rsw_getTBSFromID(this.textBoxID, this.copyComputedStyleToOverlay);

 if (this.rsw_tbs == null) return null;

 this.rsw_tbs.spellChecker = this;

 if (this.rsw_tbs.isStatic) {
 this.state = rsS14[209];
 } else
 this.state = rsS14[210];
 }
 } else {
 if (rsw_inProcessTB !=null && rsw_inProcessTB.iframe != null) {
 rsw_inProcessTB.iframe = rs_s3.getElementById(rsw_inProcessTB.iframe.id);
 if (rsw_inProcessTB.iframe == null) {
 var n = _createTBSForPlainTB(rsw_inProcessTB.shadowTBID, true);
 if(n!=null)
 rsw_inProcessTB.iframe = n.iframe;

 }
 }
 }

 if (this.rsw_tbs != null && this.rsw_tbs.isStatic && rsw_recalculateOverlayPosition) {
 rsw_updatePosition(this.rsw_tbs.iframe, this.rsw_tbs.shadowTB);
 }
 if (this.rsw_tbs != null && this.rsw_tbs.isStatic) this.rsw_tbs.targetIsPlain = !this.ignoreXML;
 return this.rsw_tbs;
 }

 var rsw_spellCheckQueue = [];

 function OnSpellButtonClicked(quietFinish, dontResetCaretPosition) {
 rsw_spellCheckRunning = true;
 if (rsw_haltProcesses) { rsw_spellCheckRunning = false; return; }
 
 this.hasRun = true; if (this.hasRunFieldID && rs_s3.getElementById(this.hasRunFieldID))
 rs_s3.getElementById(this.hasRunFieldID).value = rsS14[211];
 if (typeof (this.tbInterface.findContainer) != rsS14[12]) {
 this.textBoxID = this.tbInterface.findContainer().id;
 if (!this.tbInterface.targetIsPlain) {
 this.setParameterValue(rsS14[212], rsS14[213]);
 if (typeof rapidSpell !== rsS14[12] && typeof rapidSpell.setParameterValue === rsS14[33])
 rapidSpell.setParameterValue(rs_s3.getElementById(this.textBoxID), rsS14[212], rsS14[213]);
 this.ignoreXML = true;
 }
 } else if (!this.tbInterface.targetIsPlain) {
 this.setParameterValue(rsS14[212], rsS14[213]);
 if (typeof rapidSpell !== rsS14[12] && typeof rapidSpell.setParameterValue === rsS14[33])
 rapidSpell.setParameterValue(rs_s3.getElementById(this.textBoxID), rsS14[212], rsS14[213]);
 this.ignoreXML = true;
 }
 rsw_inProcessTB = this.getTBS();

 if (rsw_inProcessTB == null) { rsw_spellCheckRunning = false; return; }

 if (!rsw_inProcessTB.enabled && (typeof (rsw_ignoreDisabledBoxes) != rsS14[12] && rsw_ignoreDisabledBoxes)) { rsw_spellCheckRunning = false; return; }

 

 

 rsw_inProcessTB.spellChecker = this; rsw_inProcessSC = this;
 if (this.state == rsS14[209] || this.state == rsS14[210]) {
 if (rsw_channel_state == rsS14[5]) {
 rsw_channel_state = rsS14[214];
 clearTimeout(rsw_channel_timeout);
 var lc_SD6F5S67DF576SD57F6S76F576S576E5R76WE5675WE76R76W567SD5F76SD56F7576E76W5R76EW5757 = rsS14[3];
 var timeoutFn = 'if(rsw_channel_state == "ACTIVE" && !rsw_suppressWarnings){alert("' + this.responseTimeoutMessage + '");rsw_channel_state = "INACTIVE";}';
 rsw_channel_timeout = setTimeout(timeoutFn, this.responseTimeout * 1000);

 rsw_inProcessTBResetCaret = !dontResetCaretPosition;


 if (typeof (rsw_inProcessTB.recordCaretPos) != rsS14[12]) rsw_inProcessTB.recordCaretPos();


 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[215];
 rsw_spellCheck();
 if (this.state == rsS14[209]) {
 rsw_resetTBSSize(rsw_inProcessTB.iframe, this.textBoxID); this.onLeaveEdit();
 }

 } else {
 rsw_spellCheckQueue[rsw_spellCheckQueue.length] = [rsw_inProcessTB, rsw_inProcessSC];
 rsw_consoleLog(rsS14[216] + rsw_inProcessTB.shadowTBID);
 }

 } else { 
 rsw_inProcessTB.updateShadow();
 rsw_inProcessTB.iframe.style.display = rsS14[48];
 rsw_inProcessTB.shadowTB.style.display = rsw_inProcessTB.shadowTBDisplay;
 
 this.state = rsS14[209];
 try {
 if (typeof (rsw_inProcessTB.shadowTB.focus) != rsS14[12])
 rsw_inProcessTB.shadowTB.focus();
 } catch (ee) {
 rsw_logException(ee);
 }
 this.onEnterEdit();

 rsw_broadcastToListeners(rsS14[217]);
 if (this.finishedListener != null && this.finishedListener != rsS14[3] && !quietFinish) {
 eval(this.finishedListener + rsS14[218]);
 }
 
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[219],rsw_inProcessTB, true, -1);
 if (typeof (rswm_auto_NotifyDone) == rsS14[33] && !quietFinish) rswm_auto_NotifyDone(true, -1);
 }
 if(!rsw_ayt_initializing )rsw_hideCM();
 }


 function onEnterEdit() {
 if (rs_s2.rsw_inline_button_OnStateChanged && this.changeButtonTextWithState) {
 rsw_inline_button_OnStateChanged(rsS14[220], rsw_inProcessSC.buttonID, this.buttonTextSpellChecking, this.buttonTextSpellMode, this.buttonText);
 }
 if (this.leaveStaticSpellCheckListener != null && this.leaveStaticSpellCheckListener != rsS14[3])
 eval(this.leaveStaticSpellCheckListener + rsS14[221]);
 }

 function onLeaveEdit() {
 if (rs_s2.rsw_inline_button_OnStateChanged && this.changeButtonTextWithState) {
 rsw_inline_button_OnStateChanged(rsS14[222], rsw_inProcessSC.buttonID, this.buttonTextSpellChecking, this.buttonTextSpellMode, this.buttonText);
 }
 if (this.enterStaticSpellCheckListener != null && this.enterStaticSpellCheckListener != rsS14[3])
 eval(this.enterStaticSpellCheckListener + rsS14[221]);
 }

 this.reconcileChange = reconcileChange;
 function reconcileChange(beforeS, afterS) { if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[223] + beforeS + rsS14[224] + afterS;
 var dif = RSW_diff(beforeS, afterS);
 if (dif.position == -1)
 return [beforeS, false];
 else if (dif.vector > 0) { return [this.insertAtVisible(beforeS, dif.addedText, dif.position), true];
 } else if (dif.vector < 0) {
 return [afterS, true];
 }
 else return [beforeS, false];
 }

 this.insertAtVisible = insertAtVisible;
 function insertAtVisible(str, addition, pos) {
 var cs = new RSW_VisibleCharSeq(str);
 return cs.insertAtVisible(addition, pos);
 }

 var rsw_OnSpellCheckCallBack_vars_text;
 var rsw_OnSpellCheckCallBack_vars_innerHTMLLength;
 var rsw_OnSpellCheckCallBack_vars_haveResetFocus;


 var rsw_tempClient = new RapidSpellCheckerClient();
 function OnSpellCheckCallBack_Breather(scOptional) {
 
 if (rsw_haltProcesses) return;

 var workingWithTB = rsw_inProcessTB;

 if (typeof scOptional !== rsS14[12]) {
 workingWithTB = scOptional.getTBS();
 }

 if (workingWithTB == null) return;


 if (rsw_OnSpellCheckCallBack_vars_innerHTMLLength != workingWithTB.getContent().length) {
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[225];
 return;
 }



 if (typeof (workingWithTB.insertErrorHighlights) != rsS14[12]) {

 workingWithTB.insertErrorHighlights(rsw_tempClient.generateResult(rsw_OnSpellCheckCallBack_vars_text, rsw_OnSpellCheckCallBack_vars_numErrors, rsw_inProcessSC.ignoreXML), rsw_tempClient);
 } else
 workingWithTB.setContent(rsw_OnSpellCheckCallBack_vars_text);

 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[226];

 if (typeof (workingWithTB.insertErrorHighlights) == rsS14[12] && typeof (workingWithTB.resetCaretPos) != rsS14[12] && rsw_inProcessTBResetCaret) workingWithTB.resetCaretPos();

 rsw_OnSpellCheckCallBack_vars_haveResetFocus = true;

 if (workingWithTB.isStatic) {
 workingWithTB.shadowTBDisplay = rsw_getStyleProperty(workingWithTB.shadowTB, rsS14[85]);
 if (workingWithTB.shadowTB.tagName == rsS14[53]) workingWithTB.iframe.style.display = rsS14[227];
 else {
 workingWithTB.iframe.style.display = workingWithTB.shadowTBDisplay;
 }

 if(!rsw_absolutePositionStaticOverlay)
 workingWithTB.shadowTB.style.display = rsS14[48];
 if (rsw_inProcessSC.state == rsS14[209]) {
 rsw_inProcessSC.state = rsS14[228];
 if (rs_s2.rsw_inline_button_OnStateChanged && rsw_inProcessSC.changeButtonTextWithState) {
 rsw_inline_button_OnStateChanged(rsS14[229], rsw_inProcessSC.buttonID, rsw_inProcessSC.buttonTextSpellChecking, rsw_inProcessSC.buttonTextSpellMode, rsw_inProcessSC.buttonText);
 }
 }

 if (navigator.userAgent.toLowerCase().indexOf(rsS14[230]) > -1 && workingWithTB.iframe.style.display == rsS14[231]) {
 workingWithTB.iframe.style.display = rsS14[232];
 }
 } 

 }

 function OnSpellCheckCallBack(text, numberOfErrors) {
 
 var workingTB = this.getTBS();
 var workingSC = this;
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[233] + numberOfErrors + rsS14[234];

 try {
 


 rsw_channel_state = rsS14[5];
 clearTimeout(rsw_channel_timeout);

 if (rsw_cancelCall) { rsw_cancelCall = false; return; }

 workingTB.isDirty = false;
 rsw_OnSpellCheckCallBack_vars_haveResetFocus = false;
 workingTB.rsw_key_downed_flag = false; var innerHTMLLength = workingTB.getContent().length;

 if (numberOfErrors > 0) {



 if (!workingTB.isStatic && !workingTB.noReconcile) {
 if (rsw_haltProcesses) return;

 if (typeof (workingTB.insertErrorHighlights) == rsS14[12]) { var curText = workingSC.tbInterface.getText(); if (rsw_mozly) {
 curText = curText.replace(/\r\n/g, rsS14[25]);
 curText = curText.replace(/\r/g, rsS14[25]);
 text = text.replace(/\r\n/g, rsS14[25]);
 text = text.replace(/\r/g, rsS14[25]);
 }
 if (!workingSC.ignoreXML) {
 if (curText.indexOf(rsS14[235]) > -1) rsw_reconcileChanges = false; }
 
 
 var rec = this.reconcileChange(text, curText);
 text = rec[0];
 if (rec[1] && !rsw_reconcileChanges) return; }

 if (workingTB.rsw_key_downed_flag || workingTB.rsw_key_downed_within_lim) {
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[236] + rsw_key_down_timeout+rsS14[237]+workingTB.rsw_key_downed_flag +rsS14[238]+ workingTB.rsw_key_downed_within_lim;
 return;
 }

 if (typeof (workingTB.recordCaretPos) != rsS14[12]) workingTB.recordCaretPos();
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[239] + workingTB.caretBL + rsS14[240] + workingTB.caretBT;

 }
 
 rsw_OnSpellCheckCallBack_vars_text = text;
 rsw_OnSpellCheckCallBack_vars_innerHTMLLength = innerHTMLLength;
 rsw_OnSpellCheckCallBack_vars_numErrors = numberOfErrors;

 if (rsw_ayt_check && !rsw_ayt_initializing) setTimeout(function () { OnSpellCheckCallBack_Breather(); }, 10);
 else OnSpellCheckCallBack_Breather(this); 


 } else {

 if (workingSC.showNoSpellingErrorsMesg)
 alert(workingSC.noSpellingErrorsText);

 if (workingSC.state == rsS14[209]) {
 workingSC.onEnterEdit();
 }

 }

 if (!workingTB.isStatic && !rsw_ayt_initializing && rsw_inProcessTBResetCaret) {
 }

 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsS14[241];
 if (numberOfErrors > 0 && !rsw_OnSpellCheckCallBack_vars_haveResetFocus && typeof (workingTB.resetCaretPos) != rsS14[12] && rsw_inProcessTBResetCaret && !rsw_ayt_check) workingTB.resetCaretPos();


 rsw_broadcastToListeners(rsS14[217]);
 if (workingSC.finishedListener != null && workingSC.finishedListener != rsS14[3]) {
 eval(workingSC.finishedListener + rsS14[242]);
 }
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[219], workingTB, true, numberOfErrors);
 if (typeof (rswm_auto_NotifyDone) == rsS14[33]) rswm_auto_NotifyDone(true, numberOfErrors);

 } catch (e) {
 rsw_spellCheckRunning = false;
 rsw_logException(e);
 }
 rsw_spellCheckRunning = false;


 while (rsw_spellCheckQueue.length > 0 && rsw_spellCheckQueue[0] == null)
 rsw_spellCheckQueue.splice(0, 1);
 if (rsw_spellCheckQueue.length > 0) {
 rsw_consoleLog(rsS14[243] + rsw_spellCheckQueue.length);
 rsw_inProcessTB = rsw_spellCheckQueue[0][0];
 rsw_spellCheckQueue.splice(0, 1);
 rsw_spellCheckTextBox(rsw_inProcessTB);
 
 
 }
 }

}

function _rsJSONCallBack(jsonData, errorHandler) {
 _rsProcessResponseText(jsonData, errorHandler);
}

function _rsProcessResponseText(responseText, errorHandler) {
 rsw_showXMLResponseError(responseText, errorHandler);
 var rcs = responseText.indexOf(rsS14[244]) + 19;
 var rns = responseText.indexOf(rsS14[245]) + 20;
 var rce = responseText.lastIndexOf(rsS14[246], rns);
 var rne = responseText.indexOf(rsS14[246], rns);

 var responseContent = responseText.substring(rcs, rce);
 if (responseContent.indexOf(rsS14[24]) == -1) {
 var pos = -2;
 while ((pos = responseContent.indexOf(rsS14[25], pos + 2)) > -1)
 responseContent = responseContent.substring(0, pos) + rsS14[159] + responseContent.substring(pos + 1);
 }


 _rsCallBack(responseContent, responseText.substring(rns, rne), rsw_http_request);
}

function _rsXMLCallBack() {
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[247] + rsw_http_request.readyState + (rsw_http_request.readyState<=3?rsS14[3]:rsS14[248] + rsw_http_request.status);
 if (rsw_http_request.readyState == 4) {
 if (rsw_http_request.status == 200) {
 var responseText = rsw_http_request.responseText;
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[249] + responseText;
 _rsProcessResponseText(responseText);

 } else if (rsw_http_request.status == 404 && !rsw_suppressWarnings) {
 alert(rsS14[250]);
 } else if (rsw_http_request.status == 500 && !rsw_suppressWarnings) {
 alert(rsS14[251] + (rsw_isASPX ? rsS14[252] : rsS14[3]));
 } else if (rsw_http_request.status == 405 && !rsw_suppressWarnings) {
 alert(rsS14[253] + rsw_http_request.status);
 } else if (!rsw_suppressWarnings) {
 if (rsw_http_request.status == 0) {
 rs_s2.rsw_consoleLog(rsS14[254]);
 } else 
 alert(rsS14[255] + rsw_http_request.status);
 }
 }
}

function _rsCallBack(text, numberOfErrors, request) {
 
 if (request.rsw_sc) request.rsw_sc.OnSpellCheckCallBack(text, numberOfErrors);
 else if (rsw_inProcessSC) rsw_inProcessSC.OnSpellCheckCallBack(text, numberOfErrors);
}

function rsw_countCharactersTo(elements, toElement) {
 var count = 0;
 var found = false;
 for (var i = 0; i < elements.length && !found; i++) {
 if (elements[i] == toElement || elements[i].parentNode == toElement) { return [count, true];
 }
 else {
 if (elements[i].childNodes.length == 0) {
 if (elements[i].nodeValue == null) {
 if (elements[i].nodeName == rsS14[256] || elements[i].nodeName == rsS14[42] || elements[i].nodeName == rsS14[257]) count += 1;
 } else
 count += elements[i].nodeValue.length;

 } else {
 
 res = rsw_countCharactersTo(elements[i].childNodes, toElement);
 count += res[0];
 found = res[1];

 if (!found && rsw_tagAddsNewline(elements[i])) count += 1;

 }
 }
 }
 return [count, found];
}

function rsw_getAbsSel(range, len, contentElements, findRangeEnd) {
 var i;
 var r = new Array();
 r[0] = len;
 r[1] = false;
 r[2] = false; var tarContainer = findRangeEnd ? range.endContainer : range.startContainer;
 var tarOffset = findRangeEnd ? range.endOffset : range.startOffset;
 var numberOfElementsToCount = contentElements.length;
 
 var result = rsw_countCharactersTo(contentElements, tarContainer);
 if (tarContainer.nodeType == Node.TEXT_NODE) {
 
 len = result[0] + tarOffset;
 } else {
 len = result[0];
 result = rsw_countCharactersTo(tarContainer.childNodes, tarContainer.childNodes[tarOffset]);
 len += result[0];
 }
 r[1] = true;
 r[2] = true;
 r[0] = len;
 return r;
}


function rsw_findEl(index, elements, r) {
 var count = 0;
 if (index == 0) {
 r[2] = elements[0];
 r[3] = 0;
 r[4] = false; r[1] = true;
 }
 for (var i = 0; i < elements.length && count<index; i++) {
 

 if (i > 0 && (elements[i-1].nodeName==rsS14[42] || elements[i-1].nodeName==rsS14[257]))
 count++;


 var countBeforeThisElement = count;



 if (elements[i].childNodes.length == 0) {
 if (elements[i].nodeValue != null) count += elements[i].nodeValue.length;
 } else {
 if (index != count) count += rsw_findEl(index - count, elements[i].childNodes, r);
 }

 

 if (count >= index && r.length == 0) {
 r[2] = elements[i];
 r[3] = index - countBeforeThisElement;
 r[4] = elements[i].nodeName == rsS14[256]; r[1] = true;
 return count;
 } 
 
 
 }
 
 return count;
}




function rsw_serverAdd(word, errorCallback) {

 
 if (typeof (rapidSpellExtension) == rsS14[177] && (rapidSpellExtension.useWCFService || rapidSpellExtension.useAPIController) && typeof (rapidSpell) == rsS14[177] && rapidSpell.useAJAXWebService) { rapidSpellExtension.serviceProxy.invoke('AddWord', { 'Word': word, 'GuiLanguage': 'ENGLISH', 'UserDictionaryFile': rapidSpell.getParameterValue('default', 'UserDictionaryFile') }, function () { }, errorCallback);
 
 

 } else {


 try {
 var rsw_useXMLHttpReq = rsw_inProcessSC.useXMLHTTP;
 var req = false;

 if (rsw_useXMLHttpReq) req = rsw_createRequest();

 if (!req) { rsw_comIF = rs_s2.frames[rsS14[4]];
 var boot = rsS14[3];
 boot += rsS14[258] + rsS14[259] + rsw_inProcessSC.rapidSpellWebPage + rsS14[181] +
 rsS14[260] +
 "<input type='hidden' name='w' value=''><input type='hidden' name='UserDictionaryFile' value=\"\"></form>";

 if (rsw_comIF.document.body)
 rsw_comIF.document.body.innerHTML = boot;
 else {
 rsw_comIF.document.open();
 rsw_comIF.document.write(boot);
 }
 rsw_comIF.document.forms[0].w.value = word;
 rsw_comIF.document.forms[0].UserDictionaryFile.value = rsw_inProcessSC.getParameterValue(rsS14[261]);
 rsw_comIF.document.forms[0].submit();

 } else { var paramString = new String();
 paramString = rsS14[262] + rsw_escapeHTML(word) + rsS14[263] + rsw_escapeHTML(rsw_inProcessSC.getParameterValue(rsS14[261])) + rsS14[264];
 rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage, paramString, rsw_serverAddCallback, false);
 }
 } catch (excep) { rsw_logException(excep); }
 }

}

function rsw_serverAddCallback() {
 if (rsw_http_request.readyState == 4) {
 if (rsw_http_request.status == 200) {
 rsw_showXMLResponseError(rsw_http_request.responseText);
 } else if (rsw_http_request.status == 404 && !rsw_suppressWarnings) {
 alert(rsS14[265]);
 } else if (rsw_http_request.status == 500 && !rsw_suppressWarnings) {
 alert(rsS14[266]);
 } else if (rsw_http_request.status == 405 && !rsw_suppressWarnings) {
 alert(rsS14[253] + rsw_http_request.status);
 } else if (!rsw_suppressWarnings) {
 alert(rsS14[255] + rsw_http_request.status);
 }
 }
}

function rsw_showXMLResponseError(responseText, errorHandler) {
 if (responseText == null)
 rsw_consoleLog(rsS14[267], true);
 else {
 var rcs = responseText.indexOf(rsS14[268]) + 18;
 if (rcs > 17) {
 var rce = responseText.indexOf(rsS14[246], rcs);
 if (typeof errorHandler == rsS14[33])
 errorHandler(responseText.substring(rcs, rce));
 else
 alert(responseText.substring(rcs, rce));
 }
 }
}


function rsw_showMenu(menuItems, element, e) {
 try {
 rsw_refreshActiveTextbox();
 function isRightClick(e) {
 var rightclick;
 if (!e) var e = rs_s2.event;
 if (e.which) rightclick = (e.which == 3 || e.which == 93);
 else if (e.button) rightclick = (e.button == 2);
 else if (e.keyCode) rightclick = e.keyCode == 93;
 return rightclick;
 }



 rsw_lastRightClickedError = element;
 
 var atbs = rsw_getTBSHoldingElement(element);

 if (atbs.focus && !atbs.isFocused) {
 var yScroll = null;
 if (atbs.iframe && typeof (atbs.iframe.contentWindow) != rsS14[12])
 yScroll = rsw_getScrollY(atbs.iframe.contentWindow);
 atbs.focus();
 if (yScroll != null) rsw_setScrollY(atbs.iframe.contentWindow, yScroll);
 }
 rsw_activeTextbox = atbs;


 
 setTimeout(rsS14[269], 200);

 if (rsw_isMac) rsw_MenuOnRightClick = false;

 try {
 if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) rsw_MenuOnRightClick = false;
 } catch (e) { }

 if (!rsw_MenuOnRightClick && (e.button == 1 || e.button == 0)) { rsw_showCM(element, menuItems, e);
 } else if (rsw_MenuOnRightClick && isRightClick(e)) {
 rsw_showCM(element, menuItems, e);
 }
 } catch (excep) { rsw_logException(excep); }

 return false;
}

function rsw_getTBSHoldingElement(element) {
 for (var i = 0; i < rsw_tbs.length; i++) if (rsw_tbs[i].containsElement(element))
 return rsw_tbs[i];
}

function rsw_getScrollX(windowEl) {
 if (windowEl.pageYOffset) {
 return windowEl.pageXOffset;

 }
 else if (windowEl.document.documentElement && windowEl.document.documentElement.scrollTop)
 {
 return windowEl.document.documentElement.scrollLeft;
 }
 else if (windowEl.document.body) {
 return windowEl.document.body.scrollLeft;
 }
}

function rsw_getClientWidth(windowEl) {
 if (windowEl.innerHeight) return windowEl.innerWidth;
 else if (windowEl.document.documentElement && rs_s3.documentElement.clientHeight) return windowEl.document.documentElement.clientWidth;
 else if (rs_s3.body) return windowEl.document.body.clientWidth;
}

function rsw_getClientHeight(windowEl) {
 if (windowEl.innerHeight) return windowEl.innerHeight;
 else if (windowEl.document.documentElement && rs_s3.documentElement.clientHeight)
 return windowEl.document.documentElement.clientHeight;
 else if (rs_s3.body) return windowEl.document.body.clientHeight;
}


function rsw_getScrollY(windowEl) {
 if (windowEl.pageYOffset) return windowEl.pageYOffset;
 else if (windowEl.document.documentElement && windowEl.document.documentElement.scrollTop)
 return windowEl.document.documentElement.scrollTop;
 else if (windowEl.document.body) { 
 return windowEl.document.body.scrollTop;
 }
}


function rsw_setScrollY(windowEl, scrollY) {
 windowEl.scrollTo(0, scrollY);
 
}

function rsw_showCM(element, menuItems, event) {
 rsw_refreshActiveTextbox();

 rsw_contextMenu = new RS_ContextMenu(element, menuItems, rsw_activeTextbox);
 rsw_contextMenu.x = rsw_activeTextbox.getAbsX(element, event) + 20;
 rsw_contextMenu.y = rsw_activeTextbox.getAbsY(element, event) + 20;
 

 if (typeof (rsw_getContextMenuOffsetX) == rsS14[33])
 rsw_contextMenu.x += rsw_getContextMenuOffsetX(rsw_contextMenu.x, element, rsw_activeTextbox, event);
 if (typeof (rsw_getContextMenuOffsetY) == rsS14[33])
 rsw_contextMenu.y += rsw_getContextMenuOffsetY(rsw_contextMenu.y, element, rsw_activeTextbox, event);

 
 var winWidth = rsw_getClientWidth(this) + rsw_getScrollX(this);
 if (rsw_contextMenu.x + 220 > winWidth)
 rsw_contextMenu.x = winWidth - 240 - 10; 
 if (typeof (rsw_broadcastEvent) == rsS14[33])
 rsw_broadcastEvent(rsS14[270], rsw_contextMenu, rsw_activeTextbox, event, element);

 rsw_contextMenu.show();

 if (typeof (rsw_broadcastEvent) == rsS14[33])
 rsw_broadcastEvent(rsS14[271], rsw_contextMenu, rsw_activeTextbox, event, element);


 var menuHeight = rsw_getElementHeight(rsw_contextMenu.CMelement.id);
 var winHeight = rsw_getClientHeight(this) + rsw_getScrollY(this);
 if (rsw_contextMenu.y + menuHeight > winHeight) {
 rsw_contextMenu.y = winHeight - menuHeight - 10;
 }

 if (rsw_contextMenu.x <= 0)
 rsw_contextMenu.x = 1;

 if (rsw_contextMenu.y <= 0)
 rsw_contextMenu.y = 1;
 
 rsw_contextMenu.moveCMElement();
}





function rsw__resize() {
 for (var i = 0; i < rsw_tbs.length; i++) {
 if (rsw_tbs[i].isStatic) {
 rsw_updatePosition(rs_s3.getElementById(rsw_tbs[i].iframe.id), rsw_tbs[i].shadowTB);
 }
 }
}

function rsw_setSettings(tbs) {

 if (typeof (tbs.tbConfig) != rsS14[12] && tbs.tbConfig != null && tbs.tbConfig.keys != null) {
 for (var pp = 3; pp < tbs.tbConfig.keys.length; pp++) {
 try {
 if (!rsw_useBattleShipStyle || tbs.tbConfig.keys[pp].indexOf(rsS14[91]) == -1) { var c;
 var parts = tbs.tbConfig.keys[pp].split(rsS14[166]);
 if (parts.length == 1) {
 tbs[parts[0]] = tbs.tbConfig.values[pp];
 } else if (parts.length == 2) {
 tbs[parts[0]][parts[1]] = tbs.tbConfig.values[pp];
 } else if (parts.length == 3) {
 tbs[parts[0]][parts[1]][parts[2]] = tbs.tbConfig.values[pp];
 } else if (parts.length == 4) {
 tbs[parts[0]][parts[1]][parts[2]][parts[3]] = tbs.tbConfig.values[pp];
 }

 }
 } catch (e) {
 rsw_logException(e);
 }
 }

 var tbHeight = rsw_getElementHeight(tbs.iframe.id);
 if (tbHeight < 26 && tbs.multiline) { tbHeight = 36;
 tbs.iframe.style.height = tbHeight + rsS14[58];
 }

 tbs.updateIframe();
 try{
 if (tbs.iframe) {
 tbs.iframe.contentWindow.rsw_showMenu = rsw_showMenu;
 }
 } catch (excep) { rsw_logException(excep); }
 }

}

function rsw__unhook() {

 for (var i = 0; rsw_tbs != null && i < rsw_tbs.length; i++) {
 if (rsw_tbs[i] != null)
 rsw_tbs[i].unhook();
 }
}

function rsw__init(fromAJAXEnd) {
 if (rsw_haltProcesses) return;



 for (var ptr = 0; ptr < rsw_config.length; ptr++) {
 if (rsw_haltProcesses) return;

 var tbConfig = rsw_config[ptr];

 var myIFrame = rs_s3.getElementById(tbConfig.values[0]);

 if (myIFrame == null) { rsw_config.splice(ptr, 1); for (var sp = 0; sp < rsw_scs.length; sp++) {
 if (rsw_scs[sp].textBoxID + rsS14[35] == tbConfig.values[0]) rsw_scs.splice(sp, 1);
 }
 ptr--; continue;
 }

 if (myIFrame.nodeName.toUpperCase() === rsS14[272]) {
 rsw_tbs[ptr] = new LabelTB(myIFrame, true);
 } else {

 if (rsw_chrome || rsw_applewebkit)
 rsw_tbs[ptr] = new MozlyTB(myIFrame, true);
 else if (rsw_mozly)
 rsw_tbs[ptr] = new MozlyTB(myIFrame, true);
 else
 rsw_tbs[ptr] = new IETB(myIFrame, true);
 }
 rsw_tbs[ptr].enabled = tbConfig.values[1];
 rsw_tbs[ptr].CssSheetURL = tbConfig.values[2];

 try {
 rsw_tbs[ptr].tbConfig = tbConfig;
 rsw_tbs[ptr].initialize();

 } catch (ex) {
 rsw_logException(ex);
 }

 }


 rsw_activeTextbox = rsw_tbs[0];
 
 rsw_onFinish(fromAJAXEnd, 0);

}

function rsw_onFinish(fromAJAXEnd, attempts) {
 if (rsw_haltProcesses) return;
 if (!attempts) attempts = 0;
 if (rsw_id_waitingToInitialize != null && attempts < 100) {
 attempts++;
 eval(rsS14[273] + fromAJAXEnd + rsS14[274] + attempts + rsS14[275]);
 return;
 }

 
 if (fromAJAXEnd && rsw_autoFocusAfterAJAX) {
 if (rsw_tbs.length > 0) {
 var first = rsw_tbs[0];
 try{
 first.focus();
 } catch (x) {
 rsw_logException(x);
 }
 }
 }

 
 if (rs_s2.RS_OnTextBoxesInitialized)
 RS_OnTextBoxesInitialized();

 for (var h = 0; h < rsw_ObjsToInit.length; h++) {
 rsw_ObjsToInit[h].Init();
 }

 for (var h = 0; h < rsw_aux_oninit_handlers.length; h++) {
 eval(rsw_aux_oninit_handlers[h]);
 }

 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[276], null);
}

function rsw_spellCheckTextBox(textBox, optionalButton) {
 var found = false;
 if (textBox != null) {
 if (typeof (textBox.isStatic) == rsS14[277]) {
 for (var i = 0; i < rsw_scs.length; i++) {
 if (rsw_scs[i]!=null && rsw_scs[i].textBoxID == textBox.shadowTB.id && textBox.isDirty) {
 if (rsw_scs[i].rsw_tbs != null && rsw_scs[i].rsw_tbs.shadowTB != null && rsw_scs[i].rsw_tbs.shadowTB != textBox) {
 if (typeof (textBox.ifDoc != rsS14[12]))
 rsw_scs[i].rsw_tbs.shadowTB = rs_s3.getElementById(rsw_scs[i].rsw_tbs.shadowTBID);
 else
 rsw_scs[i].rsw_tbs.shadowTB = textBox; rsw_scs[i].tbInterface.searchedForTarget = false;
 }
 if (typeof (optionalButton) != rsS14[12]) rsw_scs[i].buttonID = optionalButton.id;
 rsw_scs[i].OnSpellButtonClicked();
 found = true;
 } else if (rsw_scs[i] != null && rsw_scs[i].textBoxID == textBox.shadowTB.id) found = true;
 }
 } else {
 for (var i = 0; i < rsw_scs.length; i++) {
 if (rsw_scs[i] != null && rsw_scs[i].textBoxID == textBox.id) {
 if (rsw_scs[i].rsw_tbs != null && rsw_scs[i].rsw_tbs.shadowTB != null && rsw_scs[i].rsw_tbs.shadowTB != textBox) {
 if (typeof (textBox.ifDoc != rsS14[12]))
 rsw_scs[i].rsw_tbs.shadowTB = rs_s3.getElementById(rsw_scs[i].rsw_tbs.shadowTBID);
 else
 rsw_scs[i].rsw_tbs.shadowTB = textBox; rsw_scs[i].tbInterface.searchedForTarget = false;
 }
 if (typeof (optionalButton) != rsS14[12]) rsw_scs[i].buttonID = optionalButton.id;
 rsw_scs[i].OnSpellButtonClicked();
 found = true;
 }
 }
 }
 }
 if (!found && typeof (rsw_addTextBoxSpellChecker) == rsS14[33]) { rsw_addTextBoxSpellChecker(textBox, true, 0);
 if (rsw_scs[rsw_scs.length - 1] != null) {
 if (typeof (optionalButton) != rsS14[12]) rsw_scs[rsw_scs.length - 1].buttonID = optionalButton.id;
 rsw_scs[rsw_scs.length - 1].OnSpellButtonClicked();
 }
 }
}


function rsw_createLink(contentWindowDoc, CssSheetURL) {
 var linkElement = contentWindowDoc.createElement(rsS14[278]);
 linkElement.type = rsS14[279];

 var url = (typeof (CssSheetURL) == rsS14[12] || CssSheetURL == rsS14[3]) ? rsw_rs_styleURL : CssSheetURL;
 contentWindowDoc.getElementsByTagName(rsS14[280])[0].appendChild(linkElement);
 linkElement.setAttribute(rsS14[281], url); linkElement.setAttribute(rsS14[282], rsS14[283]);
 

 }

function rsw_updateActiveTextbox(activeElement) {
 
 var o = rsw_getTBSFromElement(activeElement);
 if (o != null) {
 rsw_previouslyActiveTextbox = rsw_activeTextbox;
 rsw_activeTextbox = o;
 }

}

function rsw_getTBSFromElement(activeElement) {
 for (var i = 0; i < rsw_tbs.length; i++) {
 if (activeElement == rsw_tbs[i].ifDoc || activeElement == rsw_tbs[i].iframe
 || (rsw_tbs[i].iframe != null && typeof (rsw_tbs[i].iframe.contentWindow) != rsS14[12] && activeElement == rsw_tbs[i].iframe.contentWindow)
 || (rsw_tbs[i].iframe != null && typeof (rsw_tbs[i].iframe.contentWindow) != rsS14[12] && rsw_tbs[i].iframe.contentWindow != null && rsw_tbs[i].iframe.contentWindow.document != null && activeElement == rsw_tbs[i].iframe.contentWindow.document.documentElement)) {
 return rsw_tbs[i];
 }
 }
 return null;
}


function rsw_ignoreAll(error) {
 try{
 var errorText = error.innerHTML.replace(/<[^>]+>/g, rsS14[3]);
 var tError;
 for (var i = 0; i<rsw_tbs.length; i++) {
 rsw_ignoreAllTB(errorText, rsw_tbs[i]);
 }
 } catch (excep) { rsw_logException(excep); }
}

function rsw_ignoreAllTB(errorText, tb) {
 try{
 var errors = tb.getSpanElements();

 var changeIndexes = new Array();
 for (var i = 0; i < errors.length; i++) {
 tError = errors[i].innerHTML.replace(/<[^>]+>/g, rsS14[3]);
 if (errors[i].className == rsS14[284] && tError == errorText) {
 
 rsw_dehighlight(errors[i]);
 rsw_addIgnoreAllWord(errorText);
 i--;
 }
 }
 } catch (excep) { rsw_logException(excep); }

 }

function rsw_dehighlight(errorNode) {
 try {
 errorNode.removeNode(false);
 } catch (e) {
 errorNode.removeAttribute(rsS14[44]); errorNode.removeAttribute(rsS14[285]); errorNode.setAttribute(rsS14[286], rsS14[3]); }
}

function rsw_getTargetElement(e) {
 var relTarg;
 if (!e) var e = rs_s2.event;
 if (e.relatedTarget) relTarg = e.relatedTarget;
 else if (e.fromElement) relTarg = e.fromElement;
 return relTarg;
}


function rsw_edit(error) {
 try{
 rsw_activeTextbox.createEditBox(error);
 rsw_activeTextbox.OnCorrection(new RSW_CorrectionEvent(rsS14[287], error.innerHTML.replace(/<[^>]+>/g, rsS14[3]), rsS14[288]));
 } catch (excep) { rsw_logException(excep); }
}

function rsw_inlineTB_onBlur() {
 rsw_refreshActiveTextbox();
 rsw_activeTextbox.updateShadow();
}

function rsw_inlineTB_onkeypress(e) {
 var ev;
 if (typeof (e) != rsS14[12])
 ev = e;
 else
 ev = event;

 if (ev && ev.keyCode) {
 if (ev.keyCode == 13) {
 if (ev.preventDefault) ev.preventDefault();
 return false;
 }
 }
 return true;
}

function rsw_add(error) {
 try{
 rsw_refreshActiveTextbox();
 var errorText = rsw_innerHTMLToText(error.innerHTML);
 rsw_ignoreAll(error);
 rsw_inProcessSC = rsw_activeTextbox.spellChecker;
 rsw_serverAdd(errorText);
 } catch (excep) { rsw_logException(excep); }
}

function rsw_innerHTMLToText(html) {
 return html.replace(/<[^>]+>/g, rsS14[3]);
}


function rsw_innerText(node, lastElementInCollection, lastElementInCollectionIsBR) {
 var t = rsS14[3];
 var innerT;

 if (node.nodeName.toLowerCase() == rsS14[289])
 t = rsS14[159];

 if (node.nodeName.toLowerCase() == rsS14[290])
 t = String.fromCharCode(8226);

 var nV = null;
 try {
 nV = node.nodeValue; } catch (er) { }

 if (node.childNodes.length == 0) {
 if (nV && node.nodeType == 3) {

 if (rsw_activeTextbox != null && (rsw_activeTextbox.pasting )) {
 innerT = nV.replace(/\n/g, rsS14[39]).replace(/\r/g, rsS14[3]); } else
 innerT = nV.replace(/\n/g, rsS14[3]).replace(/\r/g, rsS14[3]); 

 while (rsw_newlineexp.test(innerT))
 innerT = innerT.replace(rsw_newlineexp, rsS14[3]);


 t += innerT; }
 } else {
 for (var i = 0; i < node.childNodes.length; i++)
 t += rsw_innerText(node.childNodes[i]);

 if (node.nodeName.toLowerCase() == rsS14[290]) t += rsS14[159];
 }
 if(!node.scopeName || (node.scopeName==rsS14[3] || node.scopeName==rsS14[291])){
 if (node.nodeName.toLowerCase() == rsS14[292])
 t += node.value;
 if (node.nodeName.toLowerCase() == rsS14[293] && !rsw_nodeHasTrailingBR(node) && !lastElementInCollection && (rsw_activeTextbox == null || rsw_activeTextbox.isStatic || node.parentElement == null || node.parentElement.nodeName.toLowerCase() != rsS14[50]) )
 t += rsS14[159];
 if (node.nodeName.toLowerCase() == rsS14[50] && !lastElementInCollection )
 t += rsS14[159];
 }
 return t;
}


function rsw_tagAddsNewline(node) {
 if (node && node.nodeName && (node.nodeName.toLowerCase() == rsS14[293] || node.nodeName.toLowerCase() == rsS14[50])) {
 return !rsw_nodeHasTrailingBR(node);
 }
 return false;
}

function rsw_nodeHasTrailingBR(node) {
 var textContent = false;
 for (var i = node.childNodes.length - 1; i >= 0; i--) {
 if (node.childNodes[i].childNodes.length > 0) {
 return rsw_nodeHasTrailingBR(node.childNodes[i]);
 } else {
 textContent |= rsw_nodeContainsText(node.childNodes[i]);
 if (node.childNodes[i].nodeName.toLowerCase() == rsS14[289]) 
 return !textContent;
 } 
 }
 return false;
}

function rsw_nodeContainsBR(node) {
 var contains = false;
 for (var i = 0; i < node.childNodes.length; i++) {
 contains = contains || node.childNodes[i].nodeName.toLowerCase() == rsS14[289];
 if (rsw_nodeContainsText(node.childNodes[i])) return false; }
 return contains;
}

function rsw_nodeContainsText(node) {
 if (node.nodeValue != null && node.nodeValue.length > 0) return true;
 for (var i = 0; i < node.childNodes.length; i++) {
 if (rsw_nodeContainsText(node.childNodes[i])) return true;
 }
 return false;
}

function rsw_stringContainsWhitespaceOnly(t) {
 for(var i=0; i<t.length; i++)
 if( !/\s/.test(t.charAt(i))) return false;
 return true;
}

var rsw_ignoreAllWords = new Array();
function rsw_addIgnoreAllWord(word) {
 var found = false;
 for (var i = 0; i < rsw_ignoreAllWords.length; i++)
 if (rsw_ignoreAllWords[i] == word)
 found = true;

 if (!found)
 rsw_ignoreAllWords[rsw_ignoreAllWords.length] = word;

}

function rsw_changeTo(error, replacement) {
 try{
 rsw_refreshActiveTextbox();
 var orig = rsw_activeTextbox.getShadowText();
 rsw_activeTextbox.changeTo(error, replacement);
 rsw_activeTextbox.updateShadow();

 rsw_activeTextbox.OnCorrection(new RSW_CorrectionEvent(rsS14[287], error.innerHTML.replace(/<[^>]+>/g, rsS14[3]), replacement, orig));
 } catch (excep) { rsw_logException(excep); }
}

function rsw_changeAllTo(error, replacement) {
 try{
 rsw_refreshActiveTextbox();
 var errorText = error.innerHTML.replace(/<[^>]+>/g, rsS14[3]);
 var tError;
 var errors = rsw_activeTextbox.getSpanElements();
 for (var i = 0; i < errors.length; i++) {
 tError = errors[i].innerHTML.replace(/<[^>]+>/g, rsS14[3]);
 if (errors[i].className == rsS14[284] && tError == errorText) {
 rsw_changeTo(errors[i], replacement);
 i--;
 }
 }
 } catch (excep) { rsw_logException(excep); }
}


function rsw_escapeHTML(t) {
 if (typeof (t) != rsS14[56]) return t;
 var pos = -1;
 while ((pos = t.indexOf(rsS14[294], pos + 1)) > -1)
 t = t.substring(0, pos) + rsS14[295] + t.substring(pos + 1);


 var exp1 = new RegExp(rsS14[168]);
 while (exp1.test(t)) t = t.replace(exp1, rsS14[194]);

 var exp2 = new RegExp(rsS14[169]);
 while (exp2.test(t)) t = t.replace(exp2, rsS14[195]);
 return t;
}

function rsw_unescapeHTML(t) {
 var pos = -1;
 while ((pos = t.indexOf(rsS14[295], pos + 1)) > -1)
 t = t.substring(0, pos) + rsS14[294] + t.substring(pos + 5);


 var exp1 = new RegExp(rsS14[194]);
 while (exp1.test(t)) t = t.replace(exp1, rsS14[168]);

 var exp2 = new RegExp(rsS14[195]);
 while (exp2.test(t)) t = t.replace(exp2, rsS14[169]);
 return t;
}








function RSWITextBox(controlClientID) {
 this.shadowTBID = controlClientID;
 this._getTBS = _getTBS;
 this._onKeyDown = _onKeyDown;
 this._onKeyUp = _onKeyUp;
 this._onKeyPress = _onKeyPress;
 this._onCorrection = _onCorrection;
 this._onPaste = _onPaste;
 this._onContextMenu = _onContextMenu;
 this._onBlur = _onBlur;
 this._onFocus = _onFocus;
 this._onMouseDown = _onMouseDown;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onMouseUp = _onMouseUp;
 this.tbs = null;
 rsw_ObjsToInit[rsw_ObjsToInit.length] = this;
 this.Init = Init;


 function Init() {
 this._getTBS();
 }

 function _getTBS() {
 if (this.tbs == null) {
 this.tbs = rsw_getTBSFromID(this.shadowTBID, false);
 this.tbs.repObj = this; }

 return this.tbs;
 }

 function _onKeyDown(e) { if (typeof (this.OnKeyDown) == rsS14[33]) this.OnKeyDown(this, e); }
 function _onKeyUp(e) { if (typeof (this.OnKeyUp) == rsS14[33]) this.OnKeyUp(this, e); }
 function _onKeyPress(e) { if (typeof (this.OnKeyPress) == rsS14[33]) this.OnKeyPress(this, e); }
 function _onCorrection(e) { if (typeof (this.OnCorrection) == rsS14[33]) this.OnCorrection(this, e); }
 function _onPaste(e) { if (typeof (this.OnPaste) == rsS14[33]) this.OnPaste(this, e); }
 function _onContextMenu(e) { if (typeof (this.OnContextMenu) == rsS14[33]) this.OnContextMenu(this, e); }
 function _onBlur(e) { if (typeof (this.OnBlur) == rsS14[33]) this.OnBlur(this, e); }
 function _onFocus(e) { if (typeof (this.OnFocus) == rsS14[33]) this.OnFocus(this, e); }
 function _onMouseDown(e) { if (typeof (this.OnMouseDown) == rsS14[33]) this.OnMouseDown(this, e); }
 function _onMouseUp(e) { if (typeof (this.OnMouseUp) == rsS14[33]) this.OnMouseUp(this, e); }
 function _onClick(e) { if (typeof (this.OnClick) == rsS14[33]) this.OnClick(this, e); }
 function _onDblClick(e) { if (typeof (this.OnDblClick) == rsS14[33]) this.OnDblClick(this, e); }


 this.GetText = GetText;
 this.SetText = SetText;
 this.OnKeyDown;
 this.OnKeyUp;
 this.OnKeyPress;
 this.OnCorrection;
 this.OnPaste;
 this.OnContextMenu;
 this.OnBlur;
 this.OnFocus;
 this.OnMouseDown;
 this.OnMouseUp;
 this.OnClick;
 this.GetNumberOfErrors = GetNumberOfErrors;
 this.Focus = Focus;
 this.SetDisabled = SetDisabled;
 this.Select = Select;

 function SetDisabled(disabled) {
 var tbs = this._getTBS();
 return tbs.setDisabled(disabled);
 }

 function Select() {
 var tbs = this._getTBS();
 tbs.select();
 }

 function GetText() {
 var tbs = this._getTBS();
 return tbs.shadowTB.value;
 }

 function SetText(text) {
 var tbs = this._getTBS();

 rsw_setShadowTB(tbs.shadowTB, text);
 
 tbs.updateIframe();

 }

 function GetNumberOfErrors() {
 var tbs = this._getTBS();
 return tbs.getNumberOfErrors();
 }

 function Focus() {
 var tbs = this._getTBS();
 return tbs.focus();
 }

}



function RSWITextBox_DownLevel(controlClientID) {
 this.shadowTBID = controlClientID;
 this._getTBS = _getTBS;
 this._onKeyDown = _onKeyDown;
 this._onKeyUp = _onKeyUp;
 this._onKeyPress = _onKeyPress;
 this._onCorrection = _onCorrection;
 this._onPaste = _onPaste;
 this._onContextMenu = _onContextMenu;
 this._onBlur = _onBlur;
 this._onFocus = _onFocus;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this.tbs = null;
 rsw_ObjsToInit[rsw_ObjsToInit.length] = this;

 RSWITextBox_DownLevels[RSWITextBox_DownLevels.length] = this;
 this.Init = Init;
 this.shadowTB; this._getShadowTB = _getShadowTB;

 function Init() {
 this._getShadowTB().onkeydown = this._onKeyDown;
 this._getShadowTB().onkeyup = this._onKeyUp;
 this._getShadowTB().onkeypress = this._onKeyPress;
 this._getShadowTB().onpaste = this._onPaste;
 this._getShadowTB().oncontextmenu = this._onContextMenu;
 this._getShadowTB().onblur = this._onBlur;
 this._getShadowTB().onfocus = this._onFocus;
 this._getShadowTB().onmouseup = this._onMouseUp;
 this._getShadowTB().onmousedown = this._onMouseDown;
 this._getShadowTB().onclick = this._onClick;
 this._getShadowTB().ondblclick = this._onDblClick;

 }

 function _getShadowTB() {
 if (this.shadowTB == null) this.shadowTB = rs_s3.getElementById(this.shadowTBID);
 return this.shadowTB;
 }

 function _getTBS() {
 if (this.tbs == null) {
 this.tbs = rsw_getTBSFromID(this.shadowTBID, false);
 this.tbs.repObj = this; }

 return this.tbs;
 }

 function _tb(e) {
 if (e)
 return _findRSWITextBox_DownLevel(e.target.id);
 else
 return _findRSWITextBox_DownLevel(event.srcElement.id);
 }
 function _findRSWITextBox_DownLevel(id) {
 for (var i = 0; i < RSWITextBox_DownLevels.length; i++) {
 if (RSWITextBox_DownLevels[i].shadowTBID == id) return RSWITextBox_DownLevels[i];
 }
 return null;
 }

 function _onKeyDown(e) { var tb = _tb(e); if (typeof (tb.OnKeyDown) == rsS14[33]) tb.OnKeyDown(tb, e != null ? e : event); }
 function _onKeyUp(e) { var tb = _tb(e); if (typeof (tb.OnKeyUp) == rsS14[33]) tb.OnKeyUp(tb, e != null ? e : event); }
 function _onKeyPress(e) { var tb = _tb(e); if (typeof (tb.OnKeyPress) == rsS14[33]) tb.OnKeyPress(tb, e != null ? e : event); }
 function _onCorrection(e) { var tb = _tb(e); if (typeof (tb.OnCorrection) == rsS14[33]) tb.OnCorrection(tb, e != null ? e : event); }
 function _onPaste(e) { var tb = _tb(e); if (typeof (tb.OnPaste) == rsS14[33]) tb.OnPaste(tb, e != null ? e : event); }
 function _onContextMenu(e) { var tb = _tb(e); if (typeof (tb.OnContextMenu) == rsS14[33]) tb.OnContextMenu(tb, e != null ? e : event); }
 function _onBlur(e) { var tb = _tb(e); if (typeof (tb.OnBlur) == rsS14[33]) tb.OnBlur(tb, e != null ? e : event); }
 function _onFocus(e) { var tb = _tb(e); if (typeof (tb.OnFocus) == rsS14[33]) tb.OnFocus(tb, e != null ? e : event); }
 function _onMouseDown(e) { var tb = _tb(e); if (typeof (tb.OnMouseDown) == rsS14[33]) tb.OnMouseDown(tb, e != null ? e : event); }
 function _onMouseUp(e) { var tb = _tb(e); if (typeof (tb.OnMouseUp) == rsS14[33]) tb.OnMouseUp(tb, e != null ? e : event); }
 function _onClick(e) { var tb = _tb(e); if (typeof (tb.OnClick) == rsS14[33]) tb.OnClick(tb, e != null ? e : event); }
 function _onDblClick(e) { var tb = _tb(e); if (typeof (tb.OnClick) == rsS14[33]) tb.OnDblClick(tb, e != null ? e : event); }


 this.GetText = GetText;
 this.SetText = SetText;
 this.OnKeyDown;
 this.OnKeyUp;
 this.OnKeyPress;
 this.OnCorrection;
 this.OnPaste;
 this.OnContextMenu;
 this.OnBlur;
 this.OnFocus;
 this.OnMouseDown;
 this.OnMouseUp;
 this.GetNumberOfErrors = GetNumberOfErrors;
 this.Focus = Focus;
 this.SetDisabled = SetDisabled;
 this.Select = Select;
 this.OnClick;
 function Select() {
 this._getShadowTB().select();
 }


 function SetDisabled(disabled) {
 this._getShadowTB().disabled = disabled;
 }


 function GetText() {
 return this._getShadowTB().value;
 }

 function SetText(text) {
 this._getShadowTB().value = text;
 }

 function GetNumberOfErrors() {
 var tbs = this._getTBS();
 return tbs.getNumberOfErrors();
 }

 function Focus() {
 return this._getShadowTB().focus();
 }

}


function rsw_broadcastToListeners(eventType, evt, tb) { rsw_refreshActiveTextbox();
 if (eventType == rsS14[296]) {
 rsw_activeTextbox.rsw_key_downed_flag = true;
 rsw_activeTextbox.rsw_key_downed_within_lim = true;
 if (rsw_key_down_timer != null) clearTimeout(rsw_key_down_timer);
 rsw_key_down_timer = setTimeout(rsS14[297], rsw_key_down_timeout);
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[159] + rsw_debug_getTime() + rsw_activeTextbox.shadowTBID+rsS14[298] + String.fromCharCode(rsw_activeTextbox.iframe.contentWindow.event.keyCode);
																																						
 }

 if (rs_s2._INT_notifyTextBoxListeners)
 _INT_notifyTextBoxListeners(eventType, evt, tb);

 if (rs_s2._notifyTextBoxListeners)
 _notifyTextBoxListeners(eventType, evt);
}






function RSW_IntEvent(eventType) { this.type = eventType; }
function RSW_CorrectionEvent(eventType, errorWord, replacement, oldText) { this.type = eventType; this.errorWord = errorWord, this.replacement = replacement; this.originalText = oldText; }



function IETB(iframeEl, editable) {
 this.skipAYTUpdates = false;
 this.iframe = iframeEl;
 this.editable = editable;
 this.ifDoc; this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onKeyUp = _onKeyUp;
 this._onKeyDown = _onKeyDown;
 this._onPaste = _onPaste;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onContextMenu = _onContextMenu;
 this._onFocus = _onFocus;
 this._onBlur = _onBlur;
 this.focus = focus;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = false;
 this.getContentText = getContentText;
 this.selectedErrorNode = selectedErrorNode;
 this.containsElement = containsElement;
 this.multiline = true;
 this.enabled = true;
 this.maxlength = 0;
 this.shadowTB;
 this.shadowTBID;
 this.updateIframe = updateIframe;
 this.updateShadow = updateShadow;
 this.getShadowText = getShadowText;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.oldOnBlur;
 this.oldOnFocus;
 this.isDirty = false;
 this.recordCaretPos = recordCaretPos;
 this.resetCaretPos = resetCaretPos;
 this.setCaretPos = setCaretPos;
 this.caretBL;
 this.caretBT;
 this.selectedText;
 this.CssSheetURL;
 this.getNumberOfErrors = getNumberOfErrors;
 this.textIsXHTML;
 this.unhook = unhook; this.repObj = null;
 this.setDisabled = setDisabled;
 this.select = select;
 this.isFocused = false;
 this.insertErrorHighlights = insertErrorHighlights;
 this.attachEvents = attachEvents;
 this.isVisible = isVisible;
 this.container = container;
 this.isShowingPlaceholder = false;
 this.placeHolderText = null;
 this.submitOnEnterForSingleLine = true;
 this.showPlaceholder = function () {
 if (this.placeHolderText == null)
 this.placeHolderText = this.shadowTB.getAttribute(rsS14[299]);

 if (this.placeHolderText != null && this.placeHolderText.length > 0 && this.getShadowText().length == 0) {
 this.isShowingPlaceholder = true;
 this.setContent(rsS14[300] + this.placeHolderText + rsS14[301]);
 
 }
 };
 this.hidePlaceholder = function () {
 if (this.isShowingPlaceholder) {
 this.setContent(rsS14[3]);
 this.isShowingPlaceholder = false;
 }
 };



 this.currentEventDefaultPrevent = false;
 this.preventDefaultCurrentEvent = function () {
 this.currentEventDefaultPrevent = true;
 }
 this.processDefaultPrevented = function (event) {
 if (this.currentEventDefaultPrevent) {
 event.preventDefault();
 event.cancelBubble = true;
 }
 this.currentEventDefaultPrevent = false;
 }

 function container() {
 if (this.iframe != null) {
 if(this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }

 function isVisible() {
 try{
 
 if (this.iframe == null) return false;
 var rect = this.iframe.getBoundingClientRect();
 return rect.left != 0 || rect.top != 0 || rect.bottom != 0 || rect.right != 0;
 } catch (excep) { rsw_logException(excep); return false;}
 }

 function select() {
 this.focus();

 var r = this.ifDoc.selection.createRange();
 r.expand(rsS14[302]);
 r.select();
 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS14[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); return 0;}
 }

 function insertErrorHighlights(result, client) {

 try {




 var selection = this.ifDoc.selection;
 var selRange = selection.createRange().duplicate();
 var bookmark = selRange.getBookmark();
 var range; 
 var numRs;
 var content = this.getContentText();

 var calibration = -1;
 range = this.ifDoc.body.createTextRange().duplicate();
 range.collapse(true);

 var contentChar;
 var rangeCharCode;
 var contentCharCode;
 var lookingForLeadingSpace = false;


 
 var start = 0;
 var k = 0;
 var numberOfChars = 0;
 for (var i = 0; i < result.errorPositionArray.length; i++) {
 
 if (i > 0) start = result.errorPositionArray[i - 1].start;

 lookingForLeadingSpace = result.errorPositionArray[i].word.charAt(0) == rsS14[39];

 if (lookingForLeadingSpace) result.errorPositionArray[i].start++;

 for (var j = start; j <= result.errorPositionArray[i].start; j++) {

 contentCharCode = content.charCodeAt(j);
 if (
 (contentCharCode > 0x20 && contentCharCode < 0x7f) || contentCharCode > 0xA1

 ) numberOfChars++;
 }



 

 
 do {

 range.moveEnd(rsS14[303], 1);
 rangeCharCode = range.text.charCodeAt(0);
 if ((rangeCharCode > 0x20 && rangeCharCode < 0x7f) || rangeCharCode > 0xA1) k++;


 range.move(rsS14[303], 1);

 } while (k < numberOfChars);

 if (lookingForLeadingSpace)
 range.move(rsS14[303], -2); else
 range.move(rsS14[303], -1); 
 var startRangeParent = range.parentElement();

 if (lookingForLeadingSpace)
 delta = -1;
 else
 delta = 0;
 range.moveEnd(rsS14[303], (result.errorPositionArray[i].end - result.errorPositionArray[i].start) - delta);

 var rangeParent = range.parentElement();
 if (rangeParent.nodeName == rsS14[304]) {
 rangeParent.removeNode(false); rangeParent = range.parentElement();
 }

 if (rangeParent != null && (rangeParent.getAttribute(rsS14[44]) == null || rangeParent.getAttribute(rsS14[44]) != rsS14[284]) && range.text == result.errorPositionArray[i].word) {
 if (startRangeParent.getAttribute(rsS14[44]) == rsS14[284]) startRangeParent.removeNode(false); 
 range.execCommand(rsS14[305], false);
 var span = this.ifDoc.createElement(rsS14[306]);
 span.setAttribute(rsS14[285], rsS14[284]); span.setAttribute(rsS14[44], rsS14[284]); 
 var mouseup = client.createErrorMouseUp(result.errorPositionArray[i].suggestions);
 span.setAttribute(rsS14[307], mouseup);

 
 span.onmouseup = function () { rsw_clickedSpan = this; };

 

 span.attachEvent(rsS14[286], function () { if (rsw_clickedSpan != null) { var suggsClean = rsw_clickedSpan.getAttribute(rsS14[307]); rsw_showMenu(rsw_getSuggestionsArray(suggsClean), rsw_clickedSpan, arguments[0]);
																																						 } rsw_clickedSpan = null; }); span.oncontextmenu = function () { try { event.cancelBubble = true; event.preventDefault(); } catch (e) { } return false; };
 var italic = range.parentElement();
 italic.applyElement(span, rsS14[308]);
 italic.removeNode(false);

 
 }
 }

 
 } catch (e) {
 }
 }


 function recordCaretPos() {
 
 try {
 var selection = this.ifDoc.selection;
 var range = selection.createRange().duplicate();
 

 if (rsw_ie9) {

 var start = 0, end = 0, normalizedValue, textInputRange, len, endRange;
 el = this.ifDoc;
 
 this.origTextInRange = this.getContentText();
 len = this.origTextInRange.length;
 normalizedValue = this.origTextInRange.replace(/\r\n/g, rsS14[25]); textInputRange = this.ifDoc.body.createTextRange();

 var ie = IeVersion();
 if(ie.TrueVersion==9) textInputRange.moveToBookmark(range.getBookmark());


 endRange = this.ifDoc.body.createTextRange();
 endRange.collapse(false);

 

 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[309] + textInputRange.text + rsS14[39] + textInputRange.compareEndPoints(rsS14[310], endRange);
 if (textInputRange.compareEndPoints(rsS14[310], endRange) > -1) {
 start = end = len;
 } else {
 start = -textInputRange.moveStart(rsS14[303], -len);
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[311] + textInputRange.compareEndPoints(rsS14[312], endRange);
 if (textInputRange.compareEndPoints(rsS14[312], endRange) > -1) {
 end = len;
 } else {
 end = -textInputRange.moveEnd(rsS14[303], -len);
 end += normalizedValue.slice(0, end).split(rsS14[25]).length - 1;
 }


 }



 this.cursorPosition = start;
 } else {

 range.moveStart(rsS14[313], -9000000);

 this.origTextInRange = range.text.replace(/\n/g, rsS14[3]);
 
 this.cursorPosition = this.origTextInRange.length;

 }



 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[314] + this.cursorPosition;
 } catch (excep) { if (rsw_debug) rsw_logException(excep); }
 }

 function setCaretPos(characterIndex) {
 var selection = this.ifDoc.selection;
 var newRange = selection.createRange();
 newRange.move(rsS14[313], -9000000);
 newRange.moveStart(rsS14[303], characterIndex);
 newRange.collapse(false);
 newRange.select();
 }

 function resetCaretPos() {

 try {
 var selection = this.ifDoc.selection;
 var newRange = selection.createRange();
 newRange.move(rsS14[313], -9000000);
 var o = newRange.moveEnd(rsS14[303], this.cursorPosition);
 var ignNewL = this.origTextInRange.replace(/\r/g, rsS14[3]);
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[315] + o + rsS14[316] + newRange.text.indexOf(rsS14[24]) + rsS14[317] + newRange.text.replace(/\r\n/g, rsS14[25]) + rsS14[318] + ignNewL + rsS14[319];
																																						 ;
 var moveAmount = 1;
 
 
 if (navigator.userAgent.indexOf(rsS14[320]) > -1)
 newRange.moveStart(rsS14[303], this.cursorPosition); else
 newRange.collapse(false);
 newRange.select();

 } catch (excep) { if (rsw_debug) rsw_logException(excep); }

 }

 

 
 



 function OnCorrection(e) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e);



 rsw_broadcastToListeners(rsS14[287], e);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[321], rsw_activeTextbox, e);
 }

 function focus() {
 try{
 this.iframe.contentWindow.focus();
 } catch (excep) { rsw_logException(excep); } try { this.iframe.focus(); } catch (e) { }
 try {
 this.iframe.contentWindow.focus();
 } catch (excep) { rsw_logException(excep); } this.isFocused = true;

 try {
 var caret = this.ifDoc.selection.createRange();
 correctCaret(caret);
 } catch (excep) { rsw_logException(excep); }
 }


 function containsElement(element) {
 return element.ownerDocument == this.ifDoc;
 }


 function selectedErrorNode() {
 rsw_refreshActiveTextbox();
 try {
 var selection = rsw_activeTextbox.ifDoc.selection;
 var parentEl = selection.createRange().parentElement();



 if (parentEl.className == rsS14[284])
 return parentEl;
 else {

 if (parentEl.children.length > 0 && parentEl.children[parentEl.children.length - 1].className==rsS14[284]) {
 var r = this.ifDoc.body.createTextRange();
 r.moveToElementText(parentEl.children[parentEl.children.length - 1]);
 var r2 = selection.createRange();
 if (r.compareEndPoints(rsS14[312], r2) == 0) {
 return parentEl.children[parentEl.children.length - 1];
 } else {
 r2.moveStart(rsS14[303], r.compareEndPoints(rsS14[312], r2));
 if (r2.text == rsS14[175]) return parentEl.children[parentEl.children.length - 1]; }
 }
 return null;
 }
 } catch (excep) { rsw_logException(excep); 
 return null;
 }
 }

 function getAbsX(element, event) {
 
 try {
 return element.getBoundingClientRect().left + rsw_activeTextbox.iframe.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 }

 function getAbsY(element, event) {
 
 try{
 return element.getBoundingClientRect().top + rsw_activeTextbox.iframe.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); }
 }

 function changeTo(error, replacement) {
 try {
 var repl = this.ifDoc.createTextNode(replacement);
 error.parentNode.replaceChild(repl, error);
 } catch (e) {
 return null;
 }
 }

 function getSpanElements() {
 return this.ifDoc.getElementsByTagName(rsS14[306]);
 }


 function _onKeyPress() {
 
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 rsw_hideCM();

 var evt = null;

 try{
 evt = rsw_activeTextbox.iframe.contentWindow.event;
 } catch (excep) { rsw_logException(excep); }



 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);


 if (evt != null && evt.keyCode == 13 && !rsw_activeTextbox.multiline) {
 evt.returnValue = false;
 if (rsw_activeTextbox.submitOnEnterForSingleLine)
 rsw_activeTextbox.shadowTB.form.submit();
 } else if (evt != null && evt.keyCode == 13) {
 
 }

 rsw_activeTextbox.isDirty = true;

 if (rsw_activeTextbox.maxlength > 0) {
 if (rsw_activeTextbox.getContentText().replace(/\r/g, rsS14[3]).replace(/\n/g, rsS14[3]).length >= rsw_activeTextbox.maxlength)
 evt.returnValue = false;
 }

 try{
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyPress(rsw_activeTextbox.iframe.contentWindow.event);
 


 rsw_broadcastToListeners(rsS14[322], rsw_activeTextbox.iframe.contentWindow.event);


 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[322], rsw_activeTextbox, event);



 } catch (excep) { rsw_logException(excep); }

 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[322], rsw_activeTextbox, evt);
 if(rsw_activeTextbox!=null)rsw_activeTextbox.processDefaultPrevented(evt);
 }


 function _onKeyDown() {
 
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 try{
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyDown(rsw_activeTextbox.iframe.contentWindow.event);

 var event = rsw_activeTextbox.iframe.contentWindow.event;
 if (event != null && ((event.keyCode >= 33 && event.keyCode <= 40) || event.keyCode == 13) && rsw_contextMenu != null && rsw_contextMenu.isVisible) {
 event.cancelBubble = true;
 if(rsw_contextMenu!=null)rsw_contextMenu.onkeydown(event);
 return false;
 }
 if (event != null && event.keyCode == 13 && !rsw_activeTextbox.multiline) {
 event.preventDefault();
 event.cancelBubble = true; 
 return;
 }

 rsw_activeTextbox.lastKeyDown = event.keyCode;

 rsw_broadcastToListeners(rsS14[296], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[296], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[296], rsw_activeTextbox, event);

 } catch (x) { rsw_consoleLog(x.message + rsS14[34] + x.name + rsS14[34] + x.toString(), true); }
 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function _onKeyUp() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 var evt = rsw_activeTextbox.iframe.contentWindow.event;
 if (evt.keyCode != 93 && (!(evt.keyCode >= 33 && evt.keyCode <= 40))) rsw_hideCM();

 if (!rsw_ie9) rsw_activeTextbox.ifDoc.body.createTextRange().execCommand(rsS14[323]); 
 if (evt == null || (!(evt.keyCode >= 33 && evt.keyCode <= 40) && evt.keyCode != 93)) { var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);

 }





 if (evt.keyCode == 93) {

 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS14[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, errorNode, evt);
 }
 } catch (ex) {
 rsw_logException(ex);
 }
 }
 return;
 }
 if (evt != null && ((evt.keyCode >= 33 && evt.keyCode <= 40) || evt.keyCode == 13) && rsw_contextMenu != null && rsw_contextMenu.isVisible) { return;
 }




 rsw_activeTextbox.updateShadow();

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyUp(evt);


 rsw_broadcastToListeners(rsS14[324], evt);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[324], rsw_activeTextbox, evt);

 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[324], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[292], rsw_activeTextbox, event);

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(evt);
 }



 function _onMouseDown() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;

 if (rsw_activeTextbox == null) { if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS14[12])
 rsw_updateActiveTextbox(this.document);
 else
 rsw_updateActiveTextbox(this);
 }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(rsw_activeTextbox.iframe.contentWindow.event);

 rsw_hideCM();

 var activeElement;
 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS14[12])
 activeElement = this.document;
 else
 activeElement = this;

 rsw_broadcastToListeners(rsS14[325], rsw_activeTextbox.iframe.contentWindow.event, rsw_getTBSFromElement(activeElement));


 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[325], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 rsw_activeTextbox.updateShadow();
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 function _onMouseUp() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(rsw_activeTextbox.iframe.contentWindow.event);


 rsw_broadcastToListeners(rsS14[326], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[326], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 function _onDblClick() {
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[327], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }


 function _onClick() {
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 
 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[328], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 this.textAtFocus=rsS14[3];
 function _onFocus(event, circle) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;

 

 if ((typeof (rsw_useIFrameMenuBacker) == rsS14[12] || rsw_useIFrameMenuBacker) && !rsw_activeTextbox.isFocused) rsw_hideCM();


 rsw_activeTextbox.updateShadow();
 


 rsw_updateActiveTextbox(this); 
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;

 if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS14[12]) {
 rsw_yScroll = rsw_getScrollY(rsw_activeTextbox.iframe.contentWindow);
 rsw_activeTextbox.ifDoc.body.className += rsS14[329];
 }


 rsw_activeTextbox.hidePlaceholder();

 rsw_activeTextbox.isFocused = true;

 if (rsw_correctCaret) {
 var caret = rsw_activeTextbox.ifDoc.selection.createRange();
 correctCaret(caret);
 }
 
 rsw_broadcastToListeners(rsS14[330], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[330], rsw_activeTextbox, event);

 if (navigator.userAgent.indexOf(rsS14[320]) > -1 || navigator.userAgent.indexOf(rsS14[331]) > -1) {
 rsw_activeTextbox.ifDoc.body.setAttribute(rsS14[332], rsS14[211]);
 if (rsw_yScroll != null) rsw_setScrollY(rsw_activeTextbox.iframe.contentWindow, rsw_yScroll ); }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onFocus(new RSW_IntEvent(rsS14[330]));

 if (rsw_activeTextbox.oldOnFocus && rsw_activeTextbox.oldOnFocus != rsw_activeTextbox._onFocus && !circle) rsw_activeTextbox.oldOnFocus(event, true);

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function _onBlur(event, circle) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rs_s3.activeElement != null && rs_s3.activeElement.id != rsw_activeTextbox.iframe.id) {
 rsw_activeTextbox.isFocused = false;
 rsw_activeTextbox.rsw_key_downed_within_lim = false; rsw_activeTextbox.updateShadow();

 rsw_activeTextbox.ifDoc.body.className = rsw_activeTextbox.ifDoc.body.className.replace(/(?:^|\s)rsw_focused(?!\S)/g, rsS14[3]);
 }
 
 function callOnchange(event, textbox)
 {
 return function () {
 
 try {
 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[333], textbox);
 else if (typeof (textbox.shadowTB.onchange) == rsS14[33]) textbox.shadowTB.onchange(event);
 } catch (x) { }
 }
 }

 
 if (rsw_activeTextbox != null && rsw_activeTextbox.textAtFocus != rsw_activeTextbox.shadowTB.value && (rsw_contextMenu == null || !rsw_contextMenu.isVisible)) {
 setTimeout(callOnchange(event, rsw_activeTextbox), 0);
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;
 }
 

 if (navigator.userAgent.indexOf(rsS14[320]) > -1 || navigator.userAgent.indexOf(rsS14[331]) > -1) rsw_activeTextbox.ifDoc.body.setAttribute(rsS14[332], rsS14[334]);

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onBlur(new RSW_IntEvent(rsS14[335]));

 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[336];
 if (rsw_activeTextbox != null && rsw_activeTextbox.isAYT && rsw_spellCheckOnBlur) rsw_spellCheckTextBox(rsw_activeTextbox);

 rsw_broadcastToListeners(rsS14[335], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[335], rsw_activeTextbox, event);


 if (rsw_activeTextbox != null && rsw_activeTextbox.oldOnBlur && rsw_activeTextbox.oldOnBlur != rsw_activeTextbox._onBlur && !circle) rsw_activeTextbox.oldOnBlur(event, true);

 rsw_activeTextbox.showPlaceholder();
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function setContent(content, contentIsFromShadow) {
 try {
 if (contentIsFromShadow) this.hidePlaceholder();
 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[337] + content + rsS14[338] + contentIsFromShadow;
 var pos = -1;
 var ppos = 0;
 var t = rsS14[3];
 while ((pos = content.indexOf(rsS14[25], pos + 1)) > -1) {
 if (pos > ppos + 2) {
 
 if (content.substring(pos - 1, pos) == rsS14[24])
 t += content.substring(ppos, pos - 1) + rsS14[339];
 else
 t += content.substring(ppos, pos) + rsS14[339];


 } else {
 if (content.charAt(ppos) != rsS14[24])
 t += content.substring(ppos, pos) + rsS14[339]; else
 t += rsS14[339];

 }
 ppos = pos + 1;
 }

 

 
 if ((ppos < content.length || ppos == 0) && !rsw_ie9Standards) {
 } else if (ppos == content.length) { 
 } else {

 }

 t += content.substring(ppos, content.length);


 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);
 ppos = pos;
 }

 t = rsS14[340] + t + rsS14[341];
 } else {

 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {
 if (pos + 1 < t.length && (t.charAt(pos + 1) == rsS14[39] || (pos > 4 && t.charAt(pos - 1) == rsS14[169] && t.substring(pos - 5, pos - 1) != rsS14[306]))) { opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);

 }
 ppos = pos;
 }
 }
 
 }
 if (this.ifDoc!=null && this.ifDoc.body != null) this.ifDoc.body.innerHTML = t;



 

 

 if (!contentIsFromShadow && this.ifDoc != null && this.ifDoc.body != null) this.updateShadow();
 } catch (excep) { rsw_logException(excep); }
 }

 function correctCaret(caret) {

 if (caret.text.length == 0 && caret.moveStart(rsS14[303], -1) < 0) {
 caret.select();
 caret.moveStart(rsS14[303], 1);
 caret.select();
 caret.collapse(true);
 }
 caret.select();

 }

 function getContent() {
 try{
 return this.ifDoc.body.innerHTML;
 } catch (excep) { rsw_logException(excep); return rsS14[3];}
 }


 function getContentText() {
 if (this.ifDocElement == null || this.isShowingPlaceholder) return rsS14[3];
 var contentElements;
 for(var i=0; i<this.ifDocElement.childNodes.length;i++)
 if (this.ifDocElement.childNodes[i].tagName==rsS14[78]) contentElements = this.ifDocElement.childNodes[i].childNodes;
 var contents = rsS14[3];
 if (contentElements == null) return rsS14[3];
 for (var i = 0; i < contentElements.length; i++) {
 var nV = null;
 try {
 nV = contentElements[i].nodeValue; } catch (er) { }
 if (nV)
 contents += nV;
 else if (contentElements[i].nodeName.toLowerCase() == rsS14[289] && i < contentElements.length - 1) contents += rsS14[159];
 else if (contentElements[i].nodeName.toLowerCase() == rsS14[292])
 contents += contentElements[i].value;
 else contents += rsw_innerText(contentElements[i],
 i == contentElements.length - 1, contentElements[contentElements.length - 1].nodeName.toLowerCase() == rsS14[289]); 
 
 
 }
 

 return contents;
 }



 
 function _onContextMenu() {
 var returnV = true;
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(rsw_activeTextbox.iframe.contentWindow.event);

 if (rsw_activeTextbox.lastKeyDown && rsw_activeTextbox.lastKeyDown == 93) {
 var e = rsw_activeTextbox.iframe.contentWindow.event;
 e.cancelBubble = true;
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS14[307]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 e.keyCode = 93;
 rsw_showMenu(suggestions, errorNode, e);
 returnV = false;
 }
 } catch (ex) {

 }
 }
 } else if (navigator.userAgent.indexOf(rsS14[320]) > -1 || navigator.userAgent.indexOf(rsS14[342]) > -1) {
 if(rsw_activeTextbox.selectedErrorNode()!=null){
 returnV = false; }
 }



 rsw_broadcastToListeners(rsS14[343], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[343], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);
 } catch (excep) { rsw_logException(excep); }
 return returnV;
 }

 function _onPaste() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onPaste(rsw_activeTextbox.iframe.contentWindow.event);
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);
 setTimeout(rsS14[344] +
 rsS14[345], 300);

 rsw_broadcastToListeners(rsS14[346], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[346], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 function initialize(attempts) {
 try{


 var ifID;
 if (!this.iframe)
 ifID = this.tbConfig.values[0];
 else
 ifID = this.iframe.id;

 this.shadowTBID = ifID.substring(0, ifID.length - 3); this.shadowTB = rs_s3.getElementById(this.shadowTBID);

 


 if (rsw_id_waitingToInitialize == null) rsw_id_waitingToInitialize = ifID;
 if (!attempts) attempts = 0;
 try {
 if ((!this.iframe.contentWindow.loaded && attempts < 100) || attempts == 0 || rsw_id_waitingToInitialize != ifID) { var time = 50;
 attempts++;
 eval(rsS14[347] + this.shadowTBID + rsS14[348] + attempts + rsS14[349] + time + rsS14[350]);
 return;
 }
 } catch (xx) {
 var time = 50;
 attempts++;
 eval(rsS14[347] + this.shadowTBID + rsS14[348] + attempts + rsS14[349] + time + rsS14[350]);
 return;
 }
 rsw_id_waitingToInitialize = null;
 
 this.ifDoc = this.iframe.contentWindow.document;

 this.iframe.contentWindow.document.documentElement.setAttribute(rsS14[351], false);

 this.ifDocElement = this.iframe.contentWindow.document.documentElement;

 function getDefaultFontSize(pa) {
 pa = pa || rs_s3.body;
 var who = rs_s3.createElement(rsS14[50]);

 who.style.cssText = rsS14[352];

 who.appendChild(rs_s3.createTextNode(rsS14[353]));
 pa.appendChild(who);
 var fs = [who.offsetWidth, who.offsetHeight];
 try{
 pa.removeChild(who);
 } catch (x) { } return fs;
 }


 this.iframe.contentWindow.document.documentElement.style.fontSize = getDefaultFontSize(this.shadowTB.parentElement)[1]+rsS14[58];
 
 rsw_createLink(this.ifDoc, this.CssSheetURL);

 this.ifDoc.styleSheets[0].addRule(rsS14[257], rsS14[354]);

 if (this.enabled) {
 
 if (this.editable) { this.ifDoc.body.setAttribute(rsS14[332], rsS14[211]);
 }

 this.attachEvents();

 }

 rsw_setSettings(this);

 if (this.enabled) 
 this.showPlaceholder();

 } catch (excep) { rsw_logException(excep); }

 
 }

 function attachEvents() {
 if (this.ifDocElement.onmousedown != this._onMouseDown) {
 this.ifDocElement.onmousedown = this._onMouseDown;
 this.ifDocElement.onmouseup = this._onMouseUp;
 this.ifDocElement.onclick = this._onClick;
 this.ifDocElement.ondblclick = this._onDblClick;
 this.ifDocElement.onkeypress = this._onKeyPress;
 this.ifDocElement.onkeydown = this._onKeyDown;
 this.ifDocElement.onkeyup = this._onKeyUp;
 this.ifDocElement.onpaste = this._onPaste;
 }

 if (this._onFocus != this.iframe.onfocus) {
 this.oldOnFocus = this.iframe.onfocus;
 this.iframe.onfocus = this._onFocus;

 this.oldOnBlur = this.iframe.onblur;
 this.iframe.onblur = this._onBlur;
 this.ifDoc.oncontextmenu = this._onContextMenu;
 }

 try {
 rs_s3.execCommand(rsS14[355], false, false); } catch (exc) { }
 }

 function setDisabled(disabled) {
 try{
 this.ifDoc.body.setAttribute(rsS14[332], !disabled);

 this.enabled = !disabled;

 if (this.enabled) this.attachEvents();

 if (typeof (rsw_ignoreDisabledBoxes) != rsS14[12] && rsw_ignoreDisabledBoxes && disabled) 
 this.updateIframe();

 if (this.enabled) this.attachEvents();

 if (this.multiline) {
 if (disabled) this.ifDoc.body.className = rsS14[356];
 else this.ifDoc.body.className = rsS14[357];
 } else {
 if (disabled) this.ifDoc.body.className = rsS14[358];
 else this.ifDoc.body.className = rsS14[359];
 }
 } catch (excep) { rsw_logException(excep); }
 }

 function unhook() {
 this.ifDoc.body.setAttribute(rsS14[332], rsS14[334]);


 this.ifDocElement.onmousedown = null;
 this.ifDocElement.onmouseup = null;
 this.ifDocElement.onclick = null;
 this.ifDocElement.onkeypress = null;
 this.ifDocElement.onkeydown = null;
 this.ifDocElement.onkeyup = null;
 this.ifDocElement.onpaste = null;



 this.oldOnFocus = null;
 this.iframe.onfocus = null;

 this.oldOnBlur = null;
 this.iframe.onblur = null;
 this.ifDoc.oncontextmenu = null;

 }


 function updateIframe() {
 if (this.textIsXHTML)
 this.setContent((this.shadowTB.value), true);
 else
 this.setContent(rsw_escapeHTML(this.shadowTB.value), true);

 }

 function updateShadow() {
 
 var reg = new RegExp(String.fromCharCode(160), rsS14[360]);
 rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS14[39]));

 
 }

 function getShadowText() {

 return this.shadowTB.value;
 }

}
























function MozlyTB(iframeEl, editable) {
 this.skipAYTUpdates = false;
 this.iframe = iframeEl;
 this.editable = editable;
 this.ifDoc; this.designMode;
 this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onKeyUp = _onKeyUp;
 this._onKeyDown = _onKeyDown;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 
 this._onFocus = _onFocus;
 this.isFocused = false;
 this._onBlur = _onBlur;
 this._onPaste = _onPaste;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onContextMenu = _onContextMenu;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = false;
 this.getContentText = getContentText;
 this.selectedErrorNode = selectedErrorNode;
 this.containsElement = containsElement;
 this.focus = focus;
 this.multiline = false;
 this.enabled = true;
 this.maxlength = 0;
 this.shadowTB;
 this.updateIframe = updateIframe;
 this.updateShadow = updateShadow;
 this.getShadowText = getShadowText;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.isWrappedInNOBR = false;
 this.oldOnBlur;
 this.oldOnFocus;
 this.isDirty = false;
 this.recordCaretPos = recordCaretPos;
 this.resetCaretPos = resetCaretPos;
 this.setCaretPos = setCaretPos;
 this.selOffset;
 this.selOffsetEnd;
 this.CssSheetURL;
 
 this.getNumberOfErrors = getNumberOfErrors;
 this.textIsXHTML;
 this.unhook = unhook;
 this.repObj = null;
 this.setDisabled = setDisabled;
 this.select = select;
 this.attachEvents = attachEvents;
 this.isVisible = isVisible;
 this.recordCaretPosAppleWebKit = recordCaretPosAppleWebKit;
 this.resetCaretPosAppleWebKit = resetCaretPosAppleWebKit;
 this.container = container;
 this.submitOnEnterForSingleLine = true;
 this.isShowingPlaceholder = false;
 this.placeHolderText = null;


 this.currentEventDefaultPrevent = false;
 this.preventDefaultCurrentEvent = function () {
 this.currentEventDefaultPrevent = true;
 }
 this.processDefaultPrevented = function (event) {
 if (this.currentEventDefaultPrevent) {
 event.preventDefault();
 event.cancelBubble = true;
 }
 this.currentEventDefaultPrevent = false;
 }

 this.showPlaceholder = function () {
 if (this.placeHolderText == null)
 this.placeHolderText = this.shadowTB.getAttribute(rsS14[299]);

 if (this.placeHolderText != null && this.placeHolderText.length > 0 && this.getShadowText().length == 0) {
 this.isShowingPlaceholder = true;
 this.setContent(rsS14[300] + this.placeHolderText + rsS14[301]);
 
 }
 };
 this.hidePlaceholder = function () {
 if (this.isShowingPlaceholder) {
 this.setContent(rsS14[3]);
 this.isShowingPlaceholder = false;
 }
 };


 function container() {
 if (this.iframe != null) {
 if (this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }
 


 this.walk = function (container, range, isStart, index) {
 if (container.nodeType != Node.TEXT_NODE && container.childNodes.length > 0) {
 var gobbledLength = 0;
 for (var c = 0; c < container.childNodes.length; c++) {

 var newGobbledLength = this.walk(container.childNodes[c], range, isStart, index - gobbledLength);
 if (newGobbledLength == index - gobbledLength) return index;
 else gobbledLength = newGobbledLength;
 }
 return gobbledLength;
 } else {
 var rangeText = container.nodeValue;
 if (rangeText != null && (rangeText.length > index || (rangeText.length == index && !isStart))) {
 if (isStart)
 range.setStart(container, index);
 else
 range.setEnd(container, index);

 return index;
 } else {
 if (rangeText == null) return 0;
 else {
 if (container.nextSibling != null && rangeText.length == index) {
 if (isStart) {
 if (container.nextSibling.childNodes.length > 0) {
 for (var z = 0; z < container.nextSibling.childNodes.length; z++) {
 if (container.nextSibling.childNodes[z].nodeType == Node.TEXT_NODE) {
 range.setStart(container.nextSibling.childNodes[z], 0);
 break;
 }
 }

 } else range.setStart(container.nextSibling, 0);
 }

 }

 return rangeText.length;
 }
 }
 }


 };

 
 

 function isVisible() {
 
 try {
 if (this.iframe == null) return false;
 var rect = this.iframe.getBoundingClientRect();
 return rect.left != 0 || rect.top != 0 || rect.width != 0 || rect.height != 0;
 } catch (excep) { rsw_logException(excep); return false;}
 }


 function select() {
 try{
 this.focus();
 if (this.getContentText().length > 0) {
 var sel = this.iframe.contentWindow.getSelection();
 var range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;
 range.setStartBefore(contentElements[0]);
 range.setEndAfter(contentElements[contentElements.length - 1]);
 }
 } catch (excep) { rsw_logException(excep); }
 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS14[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); }
 }

 
 
 
 

 function recordCaretPos() {
 

 try {
 var sel = this.iframe.contentWindow.getSelection();
 var range = sel.getRangeAt(0);
 var len = 0;
 var contentElements = this.ifDoc.body.childNodes;
 this.selOffset = rsw_getAbsSel(range, len, contentElements)[0];
 this.selOffsetEnd = rsw_getAbsSel(range, len, contentElements, true)[0];
 } catch (excep) { if (rsw_debug) rsw_logException(excep); }
 
 }

 function recordCaretPosAppleWebKit() {
 try{
 var oWin = this.iframe.contentWindow;
 var sel = oWin.getSelection();

 this._previous_range = new Object();
 this._previous_range.baseNode = sel.baseNode;
 this._previous_range.baseOffset = sel.baseOffset;
 this._previous_range.extentNode = sel.extentNode;
 this._previous_range.extentOffset = sel.extentOffset;
 } catch (excep) { if (rsw_debug) rsw_logException(excep); }
 
 
 }

 function resetCaretPosAppleWebKit() {
 try{
 var oWin = this.iframe.contentWindow;
 var sel = oWin.getSelection();
 sel.setBaseAndExtent(this._previous_range.baseNode,
 this._previous_range.baseOffset,
 this._previous_range.extentNode,
 this._previous_range.extentOffset);

 } catch (excep) { rsw_logException(excep); }
 }

 function setCaretPos(characterIndex) {
 this.selOffset = characterIndex;
 this.selOffsetEnd = characterIndex;
 this.resetCaretPos();
 }

 function resetCaretPos() {
 
 

 
 try {
 var sel = this.iframe.contentWindow.getSelection();
 var range;
 if(sel.rangeCount==0) range = this.iframe.contentWindow.document.createRange();
 else range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;



 
 var absRange = new Array();
 var absRangeEnd = new Array();
 rsw_findEl(this.selOffset, contentElements, absRange);
 rsw_findEl(this.selOffsetEnd, contentElements, absRangeEnd);


 if (absRange.length == 0)
 range.setStartAfter(contentElements[contentElements.length - 1]);

 if (absRangeEnd.length == 0)
 range.setEndAfter(contentElements[contentElements.length - 1]);
 

 if (absRange.length > 0) {
 if (absRange[4])
 range.setStartAfter(absRange[2]);
 else
 range.setStart(absRange[2], absRange[3]);
 }

 if (absRangeEnd.length > 0) {
 if (absRangeEnd[4])
 range.setEndAfter(absRangeEnd[2]);
 else
 range.setEnd(absRangeEnd[2], absRangeEnd[3]);
 }



 if (this.isFocused && (rsw_chrome || rsw_applewebkit || rsw_msie11)) {
 sel.removeAllRanges();
 sel.addRange(range);
 }
 } catch (e) {
 try {
 var range; if (sel.rangeCount == 0) range = this.iframe.contentWindow.document.createRange();
 else range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;
 var lastElPtr = contentElements.length - 1;
 while (!contentElements[lastElPtr].nodeValue && lastElPtr > 0) {
 lastElPtr--;
 }
 range.setEnd(contentElements[lastElPtr], contentElements[lastElPtr].nodeValue.length);
 range.setStart(contentElements[lastElPtr], contentElements[lastElPtr].nodeValue.length);
 if (rsw_chrome || rsw_applewebkit) {
 sel.removeAllRanges();
 sel.addRange(range);
 }
 } catch (ex) {
 }
 }
 
 }





 function OnCorrection(e) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e);

 rsw_broadcastToListeners(rsS14[287], e);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[321], rsw_activeTextbox, e);

 
 }


 function focus() {
 try{
 this.iframe.contentWindow.focus();
 this.isFocused = true;
 } catch (excep) { rsw_logException(excep); }
 }




 function containsElement(element) {
 return element.ownerDocument == this.ifDoc;
 }

 function selectedErrorNode() {
 rsw_refreshActiveTextbox();
 try {
 var selection = rsw_activeTextbox.iframe.contentWindow.getSelection();
 if (selection.anchorNode!= null && selection.anchorNode.parentNode.className == rsS14[284])
 return selection.anchorNode.parentNode;
 else if (selection.anchorNode != null && selection.anchorNode.parentNode != null) {
 
 var parentEl = selection.anchorNode.parentNode;
 for (var i = 0; parentEl.children.length > i; i++) {
 if (parentEl.children[i].className == rsS14[284]) {
 var r = this.ifDoc.createRange();
 r.selectNode(parentEl.children[i]);
 r.setEndAfter(selection.anchorNode);
 if (r.toString().charAt(r.toString().length - 2) == rsS14[175]) return parentEl.children[i];
 }
 }
 
 }
 
 
 return null;
 } catch (e) {
 return null;
 }
 }


 function getAbsX(element, event) {
 
 try{
 return element.getBoundingClientRect().left + rsw_activeTextbox.iframe.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 }

 function getAbsY(element, event) {
 try{
 return element.getBoundingClientRect().top + rsw_activeTextbox.iframe.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }


 function changeTo(error, replacement) {
 var repl = this.ifDoc.createTextNode(replacement);
 if(error.parentNode!=null)
 error.parentNode.replaceChild(repl, error);
 }


 function getSpanElements() {
 return this.ifDoc.getElementsByTagName(rsS14[306]);
 }
 
 function getContentText() {
 
 if (this.isShowingPlaceholder) return rsS14[3];
 var text;
 if (!rsw_msie11 && !rsw_msedge && this.ifDoc.body.innerText && !rsw_mozly) { text = this.ifDoc.body.innerText;
 if (text.charAt(text.length - 1) == rsS14[25]) text = text.substring(0, text.length - 1);
 return text;
 }
 
 var contentElements = this.ifDoc.body.childNodes;

 

 var contents = rsS14[3];
 var innerT = rsS14[3];
 for (var i = 0; i < contentElements.length; i++) {

 innerT = rsw_innerText(contentElements[i]);

 if (contentElements[i].nodeName.toLowerCase() == rsS14[292])
 contents += contentElements[i].value;
 else if ((contentElements[i].nodeName.toLowerCase() != rsS14[289] || i < contentElements.length - 1)
 ) {


 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS14[25]) innerT = innerT.substring(0, innerT.length - 1);
 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS14[24]) innerT = innerT.substring(0, innerT.length - 1);
 
 contents += innerT;
 }

 }

 

 
 


 
 
 contents = contents.replace(/\r\n/g, "\n");
 


 return contents;
 }

 function _onDblClick(event) {
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[327], rsw_activeTextbox, event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }



 function _onClick(event) {
 
 
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;

 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[328], rsw_activeTextbox, event);

 if (navigator.userAgent.toLowerCase().indexOf(rsS14[361]) == -1 && navigator.userAgent.toLowerCase().indexOf(rsS14[230]) > -1) {
 if (typeof event != rsS14[12]) {
 try {
 var omu = event.target.attributes[rsS14[286]];
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;

 

 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 } catch (ex) {

 }
 }
 }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);

 }



 function _onKeyPress(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 rsw_hideCM();



 var evt = event;

 if (evt != null && evt.keyCode == 13 && !rsw_activeTextbox.multiline) {
 event.preventDefault();
 event.cancelBubble = true;
 if (rsw_activeTextbox.submitOnEnterForSingleLine)
 rsw_activeTextbox.shadowTB.form.submit();
 }

 if (evt != null && evt.keyCode == 9) {
 
 }

 rsw_activeTextbox.isDirty = true;

 if (rsw_activeTextbox.maxlength > 0) {
 if (
 evt.keyCode != 8 && evt.keyCode != 46 && (evt.keyCode < 33 || evt.keyCode > 40) && rsw_activeTextbox.getContentText().replace(/\r/g, rsS14[3]).replace(/\n/g, rsS14[3]).length >= rsw_activeTextbox.maxlength) {
 event.preventDefault();
 event.cancelBubble = true;
 return;
 }
 }

 if (rsw_debug) rs_s3.getElementById(rsS14[157]).value += rsS14[362]+rsw_activeTextbox.ifDoc.body.innerHTML+rsS14[38];
 if (!rsw_activeTextbox.multiline && rsw_activeTextbox.getContentText() == rsS14[159]) {
 var els = rsw_activeTextbox.ifDoc.getElementsByTagName(rsS14[363]);
 for (var xi = 0; xi < els.length; xi++) {
 els[xi].parentNode.removeChild(els[xi]);
 }
 }

 

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyPress(event);

 rsw_broadcastToListeners(rsS14[322], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[322], rsw_activeTextbox, event);


 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[322], rsw_activeTextbox, event);



 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function _onKeyDown(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyDown(event);

 if ((rsw_chrome || rsw_safari) && event != null && event.keyCode == 9) {
 event.preventDefault();
 event.cancelBubble = true;
 rsw_focusToNextField(rsw_activeTextbox);
 }
 
 if (event != null && ((event.keyCode >= 33 && event.keyCode <= 40) || event.keyCode == 13) && rsw_contextMenu!=null && rsw_contextMenu.isVisible) { event.preventDefault();
 event.cancelBubble = true;
 if (rsw_contextMenu != null) rsw_contextMenu.onkeydown(event);
 return;
 }
 if (event != null && event.keyCode == 13 && !rsw_activeTextbox.multiline) {
 event.preventDefault();
 event.cancelBubble = true;
 if (rsw_contextMenu != null) rsw_contextMenu.onkeydown(event);
 return;
 }


 rsw_activeTextbox.lastKeyDown = event.keyCode;

 rsw_broadcastToListeners(rsS14[296],event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[296], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[296], rsw_activeTextbox, event);



 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 this.textAtFocus;
 function _onFocus(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (!rsw_activeTextbox.isFocused) rsw_hideCM();
 rsw_activeTextbox.updateShadow();


 

 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS14[12])
 rsw_updateActiveTextbox(this.document); else
 rsw_updateActiveTextbox(this); 
 
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;


 if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS14[12]) {
 rsw_activeTextbox.ifDoc.body.className += rsS14[329];
 }


 rsw_activeTextbox.hidePlaceholder();
 rsw_activeTextbox.isFocused = true;

 if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS14[12]) {
 rsw_activeTextbox.ifDoc.body.focus();
 }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onFocus(event);

 rsw_broadcastToListeners(rsS14[330], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[330], rsw_activeTextbox, event);
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);

 }

 function _onBlur(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 rsw_activeTextbox.isFocused = false;
 rsw_activeTextbox.rsw_key_downed_within_lim = false; rsw_activeTextbox.updateShadow();

 rsw_activeTextbox.ifDoc.body.className = rsw_activeTextbox.ifDoc.body.className.replace(/(?:^|\s)rsw_focused(?!\S)/g, rsS14[3]);

 
 if (rsw_activeTextbox.textAtFocus != rsw_activeTextbox.shadowTB.value && (rsw_contextMenu == null || !rsw_contextMenu.isVisible)) {

 var evt = rs_s3.createEvent(rsS14[364]);
 evt.initUIEvent(rsS14[333], event.canBubble, event.cancelable, event.view,
 event.detail);
 rsw_activeTextbox.shadowTB.dispatchEvent(evt);
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;
 }

 if (rsw_activeTextbox.isAYT && rsw_spellCheckOnBlur)
 rsw_spellCheckTextBox(rsw_activeTextbox);
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onBlur(event);

 rsw_broadcastToListeners(rsS14[335], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[335], rsw_activeTextbox, event);

 rsw_activeTextbox.showPlaceholder();

 } catch (excep) { rsw_logException(excep); }

 
 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function _onKeyUp(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (event == null || (!(event.keyCode >= 33 && event.keyCode <= 40) && event.keyCode!=93 )) { var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);
 }

 if (event.keyCode == 93) {
 if (!rsw_msie11) {
 
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS14[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, errorNode, event);
 }
 } catch (ex) {

 }
 }
 }
 return;
 }
 if (event != null && ((event.keyCode >= 33 && event.keyCode <= 40) || event.keyCode == 13) && rsw_contextMenu!=null && rsw_contextMenu.isVisible) { return;
 }

 rsw_activeTextbox.updateShadow();

 if (!rsw_activeTextbox.multiline && rsw_activeTextbox.ifDoc.body.innerHTML == rsS14[25]) rsw_activeTextbox.ifDoc.body.innerHTML = rsS14[3];

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyUp(event);

 rsw_broadcastToListeners(rsS14[324], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[324], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[324], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS14[33])
 rsw_fireEventInShadow(rsS14[292], rsw_activeTextbox, event);

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function _onPaste(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox!=null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onPaste(event);
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);
 setTimeout(rsS14[344] +
 rsS14[345], 300);

 rsw_broadcastToListeners(rsS14[346], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[346], rsw_activeTextbox, event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);

 }

 function _onMouseDown(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if( !(event.which==3 || (event.which==1 && !rsw_MenuOnRightClick))) rsw_hideCM();

 if (rsw_activeTextbox == null) { if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS14[12])
 rsw_updateActiveTextbox(this.document);
 else
 rsw_updateActiveTextbox(this);
 }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(event);


 var activeElement;
 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS14[12])
 activeElement = this.document;
 else
 activeElement = this;

 rsw_broadcastToListeners(rsS14[325], event, rsw_getTBSFromElement(activeElement));
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[325], rsw_activeTextbox, event);
 rsw_activeTextbox.updateShadow();

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function _onMouseUp(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(event);

 if (rsw_msie11) { if (typeof event != rsS14[12]) {
 try {
 var omu = event.target.attributes[rsS14[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 }
 } catch (ex) {

 }
 }
 }

 rsw_broadcastToListeners(rsS14[326], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[326], rsw_activeTextbox, event);

 

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function setContent(content, contentIsFromShadow) {
 try {
 if (contentIsFromShadow) this.hidePlaceholder();
 var t = content + rsS14[25];

 

 if (this.multiline) {
 
 
 t = t.replace(/(.*?)\n/g, rsS14[365]);
 t = t.replace(/<p><\/p>/g, rsS14[366]);

 } else {
 if (rsw_msie11) {
 t = t.replace(/(.*?)\n/g, rsS14[367]);
 t = t.replace(/<p><\/p>/g, rsS14[366]);
 }
 }

 var newlineexp = new RegExp(rsS14[24]);
 while (newlineexp.test(t))
 t = t.replace(newlineexp, rsS14[3]);


 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;

 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS14[235] + t.substring(pos + 1);
 ppos = pos;
 }
 if (t.length == 0 || t==rsS14[25])
 t = rsS14[3];
 else {
 this.isWrappedInNOBR = true;
 }

 
 } else {
 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {

 if (pos + 1 < t.length &&
 (
 t.charAt(pos + 1) == rsS14[39] ||
 (pos > 4 && t.charAt(pos - 1) == rsS14[169] && t.substring(pos - 5, pos - 1) != rsS14[306])
 ||
 (pos + 3 < t.length && t.charAt(pos + 1) == rsS14[168] && t.charAt(pos + 2) == rsS14[368] && t.charAt(pos + 3) == rsS14[293])
 ||
 (pos >= 3 && t.charAt(pos - 1) == rsS14[169] && t.charAt(pos - 2) == rsS14[293])
 )
 ) { opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);

 
 }
 ppos = pos;
 }
 }
 
 
 }

 if(this.ifDoc!=null && this.ifDoc.body!=null) this.ifDoc.body.innerHTML = t;


 


 if(!contentIsFromShadow && this.ifDoc != null && this.ifDoc.body != null)this.updateShadow();
 } catch (excep) { rsw_logException(excep); }
 }

 function getContent() {
 try{
 return this.ifDoc.body.innerHTML;
 } catch (excep) { rsw_logException(excep); }
 }

 function setDisabled(disabled) {
 try{


 if (disabled) {
 this.unhook(true);
 if (rsw_msie11)
 this.iframe.contentDocument.body.contentEditable = false;
 else
 this.iframe.contentDocument.designMode = rsS14[369];
 } else {
 this.attachEvents(true);
 if (rsw_msie11)
 this.iframe.contentDocument.body.contentEditable = true;
 else this.iframe.contentDocument.designMode = rsS14[370];
 }


 this.enabled = !disabled;

 if (typeof (rsw_ignoreDisabledBoxes) != rsS14[12] && rsw_ignoreDisabledBoxes && disabled)
 this.updateIframe();

 if (this.multiline) {
 if (disabled) this.ifDoc.body.className = rsS14[356];
 else this.ifDoc.body.className = rsS14[357];
 } else {
 if (disabled) this.ifDoc.body.className = rsS14[358];
 else this.ifDoc.body.className = rsS14[359];
 }
 } catch (excep) { rsw_logException(excep); }
 }

 
 function _onContextMenu(e) {
 rsw_refreshActiveTextbox();
 
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(e);

 if (rsw_MenuOnRightClick && rsw_contextMenu!=null && rsw_contextMenu.isVisible) {
 e.cancelBubble = true;
 e.preventDefault();
 }

 if (rsw_activeTextbox.lastKeyDown && rsw_activeTextbox.lastKeyDown == 93) {
 e.cancelBubble = true;
 e.preventDefault();
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS14[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, errorNode, e);
 }
 } catch (ex) {

 }
 }
 }

 rsw_broadcastToListeners(rsS14[343], e);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[343], rsw_activeTextbox, e);
 }


 function initialize(attempts) {
 try{
 rsw_refreshActiveTextbox();
 var ifID = this.iframe.id;
 this.shadowTBID = ifID.substring(0, ifID.length - 3); this.shadowTB = rs_s3.getElementById(this.shadowTBID);



 if (rsw_id_waitingToInitialize == null) rsw_id_waitingToInitialize = ifID;
 if (!attempts) attempts = 0;
 try {
 if (!this.iframe.contentWindow.loaded && attempts < 100) { attempts++;
 eval(rsS14[371] + this.shadowTBID + rsS14[348] + attempts + rsS14[372]);
 return;
 }
 } catch (xx) {
 attempts++;
 eval(rsS14[347] + this.shadowTBID + rsS14[348] + attempts + rsS14[373]);
 return;
 }

 rsw_id_waitingToInitialize = null;
 
 this.ifDoc = this.iframe.contentWindow.document;

 this.iframe.contentWindow.document.documentElement.setAttribute(rsS14[351], false);

 this.ifDocElement = this.iframe.contentWindow.document.documentElement;

 
 function getDefaultFontSize(pa) {
 pa = pa || rs_s3.body;
 var who = rs_s3.createElement(rsS14[50]);

 who.style.cssText = rsS14[352];

 who.appendChild(rs_s3.createTextNode(rsS14[353]));
 pa.appendChild(who);
 var fs = [who.offsetWidth, who.offsetHeight];
 pa.removeChild(who);
 return fs;
 }
 
 this.iframe.contentWindow.document.documentElement.style.fontSize = rsw_getStyleProperty(this.iframe.parentElement, rsS14[374]);
 
 rsw_createLink(this.ifDoc, this.CssSheetURL);

 
 


 if (this.enabled) {
 

 if (this.editable) {
 
 if (rsw_msie11){ eval(rsS14[375] + this.iframe.id + rsS14[376]);
 } else {

 eval(rsS14[375] + this.iframe.id + rsS14[377]);
 }
 this.attachEvents();
 }
 }



 rsw_setSettings(this);

 if (this.enabled)
 this.showPlaceholder();

 if (rsw_ffMaxLengthChecker == null && this.maxlength > 0)
 rsw_ffMaxLengthChecker = setInterval(rsS14[378], 300);

 } catch (excep) { rsw_logException(excep); }


 }

 this._onFrameFocus = function (e) {
 if (rsw_msie11) {
 
 setTimeout(function () {
 var tbs = rsw_getTBSFromID(e.target.id.substring(0, e.target.id.length - 3));
 if (!tbs.isFocused) {
 rs_s2.focus();
 tbs.focus();
 }
 }, 0);
 }
 };


 function attachEvents(allButClick) {
 try{

 this.ifDoc.addEventListener(rsS14[325], this._onMouseDown, false);
 this.ifDoc.addEventListener(rsS14[326], this._onMouseUp, false);


 if (rsw_chrome) this.ifDocElement.addEventListener(rsS14[322], this._onKeyPress, false);
 else
 this.ifDoc.addEventListener(rsS14[322], this._onKeyPress, false);


 if (rsw_chrome) this.ifDocElement.addEventListener(rsS14[296], this._onKeyDown, false);
 else
 this.ifDoc.addEventListener(rsS14[296], this._onKeyDown, false);


 this.ifDoc.addEventListener(rsS14[324], this._onKeyUp, false);
 this.ifDoc.addEventListener(rsS14[343], this._onContextMenu, false);
 if (!rsw_chrome && !rsw_applewebkit && !rsw_msie11) {
 this.iframe.addEventListener(rsS14[330], this._onFrameFocus, false);
 this.ifDoc.addEventListener(rsS14[330], this._onFocus, false);
 this.ifDoc.addEventListener(rsS14[335], this._onBlur, false);
 } else {
 this.iframe.addEventListener(rsS14[330], this._onFrameFocus, false);
 this.iframe.contentWindow.addEventListener(rsS14[330], this._onFocus, false);
 this.iframe.contentWindow.addEventListener(rsS14[335], this._onBlur, false);
 }
 this.iframe.contentWindow.document.addEventListener(rsS14[346], this._onPaste, false);
 
 

 if (!allButClick) {
 this.ifDoc.addEventListener(rsS14[328], this._onClick, false);
 this.ifDoc.addEventListener(rsS14[327], this._onDblClick, false);
 }


 if (typeof (this.tbConfig) != rsS14[12] && this.tbConfig != null && this.tbConfig.keys != null) {
 for (var v = 0; v < this.tbConfig.keys.length; v++)
 if (this.tbConfig.keys[v] == rsS14[379])
 this.multiline = this.tbConfig.values[v];

 if (!this.multiline && rsw_showHorizScrollBarsInFF) {
 this.iframe.scrolling = rsS14[380];
 for (var v = 0; v < this.tbConfig.keys.length; v++) {
 if (this.tbConfig.keys[v] == rsS14[381]) {
 var hstr = parseInt(this.tbConfig.values[v].substring(1, this.tbConfig.values[v].length - 3), 10) + 22;
 if (hstr < 50)
 this.tbConfig.values[v] = rsS14[175] + hstr + rsS14[382];

 }
 }

 }
 }
 } catch (excep) { rsw_logException(excep); }

 }

 function unhook(allButClick) {
 this.ifDoc.removeEventListener(rsS14[325], this._onMouseDown, false);
 this.ifDoc.removeEventListener(rsS14[326], this._onMouseUp, false);
 this.ifDoc.removeEventListener(rsS14[322], this._onKeyPress, false);
 this.ifDoc.removeEventListener(rsS14[296], this._onKeyDown, false);
 this.ifDoc.removeEventListener(rsS14[324], this._onKeyUp, false);
 this.ifDoc.removeEventListener(rsS14[343], this._onContextMenu, false);
 this.ifDoc.removeEventListener(rsS14[330], this._onFocus, false);
 this.ifDoc.removeEventListener(rsS14[335], this._onBlur, false);

 if (!allButClick) {
 this.ifDoc.removeEventListener(rsS14[328], this._onClick, false);
 this.ifDoc.removeEventListener(rsS14[327], this._onDblClick, false);
 }
 }


 function updateIframe() {
 if (this.textIsXHTML)
 this.setContent((this.shadowTB.value), true);
 else
 this.setContent(rsw_escapeHTML(this.shadowTB.value), true);

 
 }
 function updateShadow() {
 
 var reg = new RegExp(String.fromCharCode(160), rsS14[360]);
 rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS14[39]));


 
 
 }

 function getShadowText() {
 return this.shadowTB.value;
 }

}







function LabelTB(iframeEl, editable) {
 this.isLabel = true;
 this.skipAYTUpdates = true;
 this.iframe = iframeEl;
 this.editable = editable;
 this.ifDoc; this.designMode;
 this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onKeyUp = _onKeyUp;
 this._onKeyDown = _onKeyDown;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 this.noReconcile = true;
 this._onFocus = _onFocus;
 this.isFocused = false;
 this._onBlur = _onBlur;
 this._onPaste = _onPaste;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onContextMenu = _onContextMenu;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = false;
 this.getContentText = getContentText;
 this.selectedErrorNode = selectedErrorNode;
 this.containsElement = containsElement;
 this.focus = focus;
 this.multiline = false;
 this.enabled = true;
 this.maxlength = 0;
 this.shadowTB;
 this.updateIframe = updateIframe;
 this.updateShadow = updateShadow;
 this.getShadowText = getShadowText;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.isWrappedInNOBR = false;
 this.oldOnBlur;
 this.oldOnFocus;
 this.isDirty = false;
 this.recordCaretPos = recordCaretPos;
 this.resetCaretPos = resetCaretPos;
 this.setCaretPos = setCaretPos;
 this.selOffset;
 this.selOffsetEnd;
 this.CssSheetURL;
 this.targetIsPlain = false;
 this.getNumberOfErrors = getNumberOfErrors;
 this.textIsXHTML;
 this.unhook = unhook;
 this.repObj = null;
 this.setDisabled = setDisabled;
 this.select = select;
 this.attachEvents = attachEvents;
 this.isVisible = isVisible;
 this.recordCaretPosAppleWebKit = recordCaretPosAppleWebKit;
 this.resetCaretPosAppleWebKit = resetCaretPosAppleWebKit;
 this.container = container;

 function container() {
 if (this.iframe != null) {
 if (this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }

 this.walk = function (container, range, isStart, index) {
 if (container.nodeType != Node.TEXT_NODE && container.childNodes.length > 0) {
 var gobbledLength = 0;
 for (var c = 0; c < container.childNodes.length; c++) {

 var newGobbledLength = this.walk(container.childNodes[c], range, isStart, index - gobbledLength);
 if (newGobbledLength == index - gobbledLength) return index;
 else gobbledLength = newGobbledLength;
 }
 return gobbledLength;
 } else {
 var rangeText = container.nodeValue;
 if (rangeText != null && (rangeText.length > index || (rangeText.length == index && !isStart))) {
 if (isStart)
 range.setStart(container, index);
 else
 range.setEnd(container, index);

 return index;
 } else {
 if (rangeText == null) return 0;
 else {
 if (container.nextSibling != null && rangeText.length == index) {
 if (isStart) {
 if (container.nextSibling.childNodes.length > 0) {
 for (var z = 0; z < container.nextSibling.childNodes.length; z++) {
 if (container.nextSibling.childNodes[z].nodeType == Node.TEXT_NODE) {
 range.setStart(container.nextSibling.childNodes[z], 0);
 break;
 }
 }

 } else range.setStart(container.nextSibling, 0);
 }

 }

 return rangeText.length;
 }
 }
 }


 };

 

 function isVisible() {
 
 try {
 if (this.iframe == null) return false;
 var rect = this.iframe.getBoundingClientRect();
 return rect.left != 0 || rect.top != 0 || rect.width != 0 || rect.height != 0;
 } catch (excep) { rsw_logException(excep); return false;}
 }


 function select() {
 try{
 this.focus();
 if (this.getContentText().length > 0) {
 var sel = this.iframe.contentWindow.getSelection();
 var range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;
 range.setStartBefore(contentElements[0]);
 range.setEndAfter(contentElements[contentElements.length - 1]);
 }
 } catch (excep) { rsw_logException(excep); }

 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS14[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); }
 }

 
 
 
 

 function recordCaretPos() {

 
 }

 function recordCaretPosAppleWebKit() {
 
 }

 function resetCaretPosAppleWebKit() {
 
 }

 function setCaretPos(characterIndex) {
 
 }

 function resetCaretPos() {
 
 
 
 }





 function OnCorrection(e) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e);

 rsw_broadcastToListeners(rsS14[287], e);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[321], rsw_activeTextbox, e);
 }


 function focus() {


 }




 function containsElement(element) {
 var p = element;
 while ((p = p.parentNode) != null) {
 if (p.id == this.ifDoc.id) return true;
 }
 return false;
 }

 function selectedErrorNode() {
 rsw_refreshActiveTextbox();
 try {
 var selection = rsw_activeTextbox.iframe.contentWindow.getSelection();
 if (selection.anchorNode!= null && selection.anchorNode.parentNode.className == rsS14[284])
 return selection.anchorNode.parentNode;
 else if (selection.anchorNode != null && selection.anchorNode.parentNode != null) {
 
 var parentEl = selection.anchorNode.parentNode;
 for (var i = 0; parentEl.children.length > i; i++) {
 if (parentEl.children[i].className == rsS14[284]) {
 var r = this.ifDoc.createRange();
 r.selectNode(parentEl.children[i]);
 r.setEndAfter(selection.anchorNode);
 if (r.toString().charAt(r.toString().length - 2) == rsS14[175]) return parentEl.children[i];
 }
 }
 
 }
 
 
 return null;
 } catch (e) {
 return null;
 }
 }


 function getAbsX(element, event) {
 try{
 return element.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }

 function getAbsY(element, event) {
 try{
 return element.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }


 function changeTo(error, replacement) {
 var repl = rs_s3.createTextNode(replacement);
 error.parentNode.replaceChild(repl, error);
 }


 function getSpanElements() {
 return rs_s3.getElementById(this.ifDoc.id).getElementsByTagName(rsS14[306]);
 }
 
 function getContentText() {
 

 var text;
 if (!rsw_msie11 && this.ifDoc.innerText) { text = this.ifDoc.innerText;
 if (text.charAt(text.length - 1) == rsS14[25]) text = text.substring(0, text.length - 1);
 return text;
 }
 
 var contentElements = this.ifDoc.childNodes;

 

 var contents = rsS14[3];
 var innerT = rsS14[3];
 for (var i = 0; i < contentElements.length; i++) {

 innerT = rsw_innerText(contentElements[i]);

 if (contentElements[i].nodeName.toLowerCase() == rsS14[292])
 contents += contentElements[i].value;
 else if ((contentElements[i].nodeName.toLowerCase() != rsS14[289] || i < contentElements.length - 1)
 ) {


 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS14[25]) innerT = innerT.substring(0, innerT.length - 1);
 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS14[24]) innerT = innerT.substring(0, innerT.length - 1);
 
 contents += innerT;
 }

 }

 

 
 


 
 
 contents = contents.replace(/\r\n/g, "\n");
 


 return contents;
 }


 function _onDblClick(event) {
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onDblClick(event);
 }

 function _onClick(event) {
 
 
 if (navigator.userAgent.toLowerCase().indexOf(rsS14[361]) == -1 && navigator.userAgent.toLowerCase().indexOf(rsS14[230]) > -1) {
 if (typeof event != rsS14[12]) {
 try {
 var omu = errorNode.attributes[rsS14[286]];
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;


 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 } catch (ex) {

 }
 }
 }

 

 }



 function _onKeyPress(event) {
 
 }


 function _onKeyDown(event) {
 
 }

 function _onFocus(event) {
 
 }

 function _onBlur(event) {
 
 }


 function _onKeyUp(event) {
 
 }

 function _onPaste(event) {
 
 }

 function _onMouseDown(event) {
 rsw_refreshActiveTextbox();
 rsw_hideCM();

 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS14[12])
 rsw_updateActiveTextbox(this.document);
 else
 rsw_updateActiveTextbox(this);

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(event);

 rsw_broadcastToListeners(rsS14[325], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[325], rsw_activeTextbox, event);
 rsw_activeTextbox.updateShadow();
 }

 function _onMouseUp(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(event);

 if (rsw_msie11) { if (typeof event != rsS14[12]) {
 try {
 var omu = event.target.attributes[rsS14[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS14[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 }
 } catch (ex) {

 }
 }
 }

 rsw_broadcastToListeners(rsS14[326], event);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[326], rsw_activeTextbox, event);

 
 }


 function setContent(content, contentIsFromShadow) {
 try {
 var ignoredRegex = /<!--rs_ignored-->/;
 var arr;

 var ptr = 0;
 if (this.spellChecker.tbInterface.ignoredRegions.length > 0) {
 while (ignoredRegex.test(content))
 content = content.replace(ignoredRegex, this.spellChecker.tbInterface.ignoredRegions[ptr++]);
 }
 var t = content;
 

 if (this.multiline) {
 
 t = t.replace(/(.*?)\n/g, rsS14[365]);
 t = t.replace(/<p><\/p>/g, rsS14[366]);

 }

 var newlineexp = new RegExp(rsS14[24]);
 while (newlineexp.test(t))
 t = t.replace(newlineexp, rsS14[3]);


 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;

 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS14[235] + t.substring(pos + 1);
 ppos = pos;
 }
 if (t.length == 0 || t==rsS14[25])
 t = rsS14[3];
 else {
 this.isWrappedInNOBR = true;
 }

 
 } else {
 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {

 if (pos + 1 < t.length &&
 (
 t.charAt(pos + 1) == rsS14[39] ||
 (pos > 4 && t.charAt(pos - 1) == rsS14[169] && t.substring(pos - 5, pos - 1) != rsS14[306])
 ||
 (pos + 3 < t.length && t.charAt(pos + 1) == rsS14[168] && t.charAt(pos + 2) == rsS14[368] && t.charAt(pos + 3) == rsS14[293])
 ||
 (pos >= 3 && t.charAt(pos - 1) == rsS14[169] && t.charAt(pos - 2) == rsS14[293])
 )
 ) { opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);

 
 }
 ppos = pos;
 }
 }
 
 
 }

 if(this.ifDoc!=null && this.ifDoc!=null) this.ifDoc.innerHTML = t;




 if(!contentIsFromShadow && this.ifDoc != null)this.updateShadow();
 } catch (excep) { rsw_logException(excep); }
 }

 function getContent() {
 try{
 return this.ifDoc.innerHTML;
 } catch (excep) { rsw_logException(excep); }
 }

 function setDisabled(disabled) {
 
 }

 
 function _onContextMenu(e) {
 rsw_refreshActiveTextbox();
 
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(e);

 if (rsw_MenuOnRightClick && rsw_contextMenu.isVisible) {
 e.cancelBubble = true;
 e.preventDefault();
 }



 rsw_broadcastToListeners(rsS14[343], e);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[343], rsw_activeTextbox, e);
 }


 function initialize(attempts) {
 rsw_refreshActiveTextbox();
 this.id = this.iframe.id;
 this.shadowTBID = this.iframe.id+rsS14[41]; if ( (this.shadowTB=document.getElementById(this.shadowTBID)) == null) {
 var input = rs_s3.createElement(rsS14[292]);
 input.type = rsS14[98];
 input.style.display = rsS14[48];
 input.setAttribute(rsS14[383], this.shadowTBID);
 input.setAttribute(rsS14[384], rsS14[211]);
 input.id = this.shadowTBID;
 rs_s3.documentElement.appendChild(input);
 this.shadowTB = input; }
 
 this.ifDoc = this.iframe;


 this.ifDocElement = this.ifDoc;

 this.attachEvents();
 
 }

 this.addEvent = function (evnt, elem, func) {
 if (elem.addEventListener) elem.addEventListener(evnt, func, false);
 else if (elem.attachEvent) { elem.attachEvent(rsS14[370] + evnt, func);
 }
 else { elem[evnt] = func;
 }
 };

 this.removeEvent = function (evnt, elem, func) {
 if (elem.removeEventListener) elem.removeEventListener(evnt, func, false);
 else if (elem.detachEvent) { elem.detachEvent(rsS14[370] + evnt, func);
 }
 else { elem[evnt] = null;
 }
 };

 function attachEvents() {


 this.addEvent(rsS14[325], this.ifDoc, this._onMouseDown);
 this.addEvent(rsS14[326], this.ifDoc, this._onMouseUp);
 this.addEvent(rsS14[343], this.ifDoc, this._onContextMenu);

 }

 

 function unhook() {
 this.removeEvent(rsS14[325], this.ifDoc, this._onMouseDown);
 this.removeEvent(rsS14[326], this.ifDoc, this._onMouseUp);
 this.removeEvent(rsS14[343], this.ifDoc, this._onContextMenu);
 
 }


 function updateIframe() {
 if (this.textIsXHTML)
 this.setContent((this.shadowTB.value), true);
 else
 this.setContent(rsw_escapeHTML(this.shadowTB.value), true);

 
 }
 function updateShadow() {
 
 var reg = new RegExp(String.fromCharCode(160), rsS14[360]);
 rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS14[39]));


 
 
 }

 function getShadowText() {
 return this.shadowTB.value;
 }

}











































































































































































































































function OldIETB(iframe) {
 this.iframe = iframe; this.ifDoc; this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onPaste = _onPaste;
 this._onMouseDown = _onMouseDown;
 this._onContextMenu = _onContextMenu;
 this._onDblClick = _onDblClick;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = true;
 this.createEditBox = createEditBox;
 this.getContentText = getContentText;
 this.containsElement = containsElement;
 this.getShadowText = getShadowText;
 this.updateShadow = updateShadow;
 this.multiline = true;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.getNumberOfErrors = getNumberOfErrors;
 this.getContentCleanHTML = getContentCleanHTML;
 this.targetIsPlain = true; this.unhook = unhook;
 this.resetCaretPos = unimplementedFunction;
 this.recordCaretPos = unimplementedFunction;
 this.container = container;

 function container() {
 if (this.iframe != null) {
 if (this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }

 function unimplementedFunction() { }

 function containsElement(element) {
 var p;
 if (element == this.iframe) return true;

 while ((p = element.parentNode)) {
 if (p == this.iframe)
 return true;
 element = p;
 }

 return false;
 }

 function getAbsX(element, ev) {
 try{
 return element.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }

 function getAbsY(element, ev) {
 try{
 return element.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }

 function changeTo(error, replacement) {
 var repl = rs_s3.createTextNode(replacement);
 error.parentNode.replaceChild(repl, error);
 }

 function findElementsCell(element) {
 var p = element;
 while ((p = p.parentNode) != null && p.tagName.toLowerCase() != rsS14[385]) { }
 return p;
 }

 function createEditBox(error) {
 try{
 var width = error.offsetWidth;
 var repl = rs_s3.createElement(rsS14[292]);
 repl.setAttribute(rsS14[386], rsw_innerHTMLToText(error.innerHTML));
 repl.setAttribute(rsS14[44], rsS14[387]);
 repl.onkeypress = rsw_inlineTB_onkeypress;


 repl.onblur = rsw_inlineTB_onBlur;
 repl.style.width = width * 1.8;
 error.parentNode.replaceChild(repl, error);




 var scrollTop = this.iframe.scrollTop;
 repl.focus();
 this.iframe.scrollTop = scrollTop;
 } catch (excep) { rsw_logException(excep); }
 }


 function getSpanElements() {
 return this.iframe.getElementsByTagName(rsS14[306]);
 }


 function _onKeyPress() {

 rsw_hideCM();
 rsw_broadcastToListeners(rsS14[322]);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[322], null, null);
 }

 function _onMouseDown() {

 rsw_hideCM();
 rsw_broadcastToListeners(rsS14[325]);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[325], null, null);
 }

 function _onDblClick() {
 rsw_getTBSHoldingElement(this).spellChecker.OnTextBoxDoubleClicked();

 rsw_broadcastToListeners(rsS14[327]);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[327], null, null);
 }

 function setContent(content) {
 try {

 
 if (this.targetIsPlain) {
 var pos = -1;
 var ppos = 0;
 var t = rsS14[3];
 while ((pos = content.indexOf(rsS14[25], pos + 1)) > -1) {
 if (pos > ppos + 2) {
 if (content.substring(pos - 1, pos) == rsS14[24])
 t += rsS14[388] + content.substring(ppos, pos - 1) + rsS14[389];
 else
 t += rsS14[388] + content.substring(ppos, pos) + rsS14[389];
 } 
 else
 t += content.substring(ppos, pos) + rsS14[390]; 
 ppos = pos;
 }

 if (ppos < content.length - 1)
 t += rsS14[388] + content.substring(ppos, content.length) + rsS14[389];


 var flag = false;
 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS14[235] + t.substring(pos + 1);
 ppos = pos;
 }

 t = rsS14[340] + t + rsS14[341];
 

 } else {
 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS14[39], pos + 1)) > -1) {
 if (pos + 1 < t.length && t.charAt(pos + 1) == rsS14[39]) {
 opener = t.lastIndexOf(rsS14[168], pos);
 closer = t.lastIndexOf(rsS14[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { 
 if (flag)
 t = t.substring(0, pos) + rsS14[235] + t.substring(pos + 1);
 else
 t = t.substring(0, pos) + rsS14[39] + t.substring(pos + 1);
 flag = !flag;
 }
 ppos = pos;
 }
 }
 }


 var tabexp = new RegExp(rsS14[391]);
 while (tabexp.test(t))
 t = t.replace(tabexp, rsS14[392]);



 this.iframe.innerHTML = t;
 } else
 this.iframe.innerHTML = content;

 } catch (excep) { rsw_logException(excep); }

 }

 function getContent() {
 try{
 return this.iframe.innerHTML;
 } catch (excep) { rsw_logException(excep); }
 }

 function getContentCleanHTML() {
 

 
 rsw_processedNodes = new Array();

 var nodes = this.iframe.childNodes;
 var out = rsS14[3];
 for (var i = 0; i < nodes.length; i++) {

 out += rsw_cleanHTML(nodes[i]);
 }
 return out;


 }

 function isNodeKnownToBeProcessed(node) {
 if (rsw_processedNodes == null || typeof (node.sourceIndex) == rsS14[12]) return false;

 for (var i = 0; i < rsw_processedNodes.length; i++) {
 if (node.sourceIndex == rsw_processedNodes[i]) return true;
 }
 return false;
 }

 var rsw_processedNodes = null;

 function rsw_cleanHTML(node) {
 try{
 var t = rsS14[3];
 var styleInAttr = false;
 var quote = '"';

 if (isNodeKnownToBeProcessed(node)) return t;
 if (rsw_processedNodes != null && typeof (node.sourceIndex) != rsS14[12])
 rsw_processedNodes.push(node.sourceIndex);

 if (node.nodeName.toLowerCase() != rsS14[393] && node.nodeName.toLowerCase() != rsS14[292]
 && !(node.nodeName.toLowerCase() == rsS14[306] && node.className == rsS14[284])
 ) {


 t += rsS14[168] + node.nodeName + rsS14[39]; 
 for (var att = 0; node.attributes!=null && att < node.attributes.length; att++) {
 if (node.attributes[att].nodeValue) {
 styleInAttr = styleInAttr || node.attributes[att].nodeName.toLowerCase() == rsS14[45];
 if (node.attributes[att].nodeValue!=null && typeof(node.attributes[att].nodeValue.indexOf)==rsS14[33] && node.attributes[att].nodeValue.indexOf(rsS14[175]) > -1) quote = '"';
 else quote = rsS14[175];
 t += node.attributes[att].nodeName + rsS14[394] + quote + node.attributes[att].nodeValue + quote + rsS14[39];
 }
 }
 if (typeof (node.style) != rsS14[12] && !styleInAttr) {
 t += "style=\"";
 t += node.style.cssText;
 t += "\" ";
 }



 if (node.childNodes.length == 0 && !node.nodeValue && node.nodeName!=rsS14[53] && node.nodeName!=rsS14[395])
 t += rsS14[368];
 t += rsS14[169];
 }


 if (node.childNodes.length == 0) {

 if (node.nodeValue) {

 t += node.nodeValue.replace(rsS14[168], rsS14[194]).replace(rsS14[169], rsS14[195]);
 }

 if (node.value) {

 t += node.value.replace(rsS14[168], rsS14[194]).replace(rsS14[169], rsS14[195]);
 }

 } else {
 for (var i = 0; i < node.childNodes.length; i++)
 t += rsw_cleanHTML(node.childNodes[i]);

 }

 if (node.nodeName.toLowerCase() != rsS14[393] && node.nodeName.toLowerCase() != rsS14[292]
 && !(node.nodeName.toLowerCase() == rsS14[306] && node.className == rsS14[284])
 && !(node.childNodes.length == 0 && !node.nodeValue && node.nodeName != rsS14[53] && node.nodeName != rsS14[395])
 )
 t += rsS14[170] + node.nodeName + rsS14[169];

 return t;
 } catch (excep) { rsw_logException(excep); return rsS14[3];}
 }



 
 function getContentText() {

 var contentElements = this.iframe.childNodes;
 var contents = rsS14[3];


 for (var i = 0; i < contentElements.length; i++) {
 var nV = null;
 try {
 nV = contentElements[i].nodeValue; } catch (er) { }
 if (nV) contents += nV.replace(/\n/g, rsS14[3]).replace(/\r/g, rsS14[3]); 
 else if (contentElements[i].nodeName.toLowerCase() == rsS14[289] && i < contentElements.length - 1) contents += rsS14[159];
 else if (contentElements[i].nodeName.toLowerCase() == rsS14[292])
 contents += contentElements[i].value;
 else contents += rsw_innerText(contentElements[i],
 i == contentElements.length - 1, contentElements[contentElements.length - 1].nodeName.toLowerCase() == rsS14[289]); }
 

 var t = contents;
 while (rsw_newlineexp.test(t))
 t = t.replace(rsw_newlineexp, rsS14[3]);
 contents = t;




 return contents;

 }


 
 function _onContextMenu() {

 rsw_broadcastToListeners(rsS14[343]);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[343], null, null);
 return false;
 }

 function _onPaste() {
 rsw_broadcastToListeners(rsS14[346]);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[346], null, null);
 }

 function getShadowText() {
 return this.shadowTB.value;
 }


 function updateShadow() {
 if (this.targetIsPlain)
 this.spellChecker.tbInterface.setText(this.getContentText());
 else
 this.spellChecker.tbInterface.setText(this.getContentCleanHTML());

 }

 function initialize() {

 this.iframe.onmousedown = this._onMouseDown;
 this.iframe.ondblclick = this._onDblClick;



 var ifID = this.iframe.id;
 this.shadowTBID = ifID.substring(0, ifID.length - 2); this.shadowTB = rs_s3.getElementById(this.shadowTBID);

 }

 function unhook() {
 this.iframe.onmousedown = null;
 this.iframe.ondblclick = null;
 }

 function OnCorrection(e) {
 if (this.getNumberOfErrors() == 0) {
 if (this.spellChecker.enterEditModeWhenNoErrors) {
 this.spellChecker.OnSpellButtonClicked(true);
 }
 }
 rsw_broadcastToListeners(rsS14[287]);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[321], null, e);
 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS14[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); }
 }

}




function rsw_getElementHeight(Elem, isoverlay) {
 var op5 = (navigator.userAgent.indexOf(rsS14[396]) != -1)
 || (navigator.userAgent.indexOf(rsS14[397]) != -1);


 if (rs_s3.layers) {
 var elem = rsw_getObjNN4(document, Elem);
 return elem.clip.height;
 } else {
 if (rs_s3.getElementById) {
 var elem = rs_s3.getElementById(Elem);
 } else if (rs_s3.all) {
 var elem = rs_s3.all[Elem];
 }
 if (op5) {
 xPos = elem.style.pixelHeight;
 } else {
 
 xPos = elem.offsetHeight;

 }

 if (!isoverlay && elem.style != null && elem.style.height != null && elem.style.height.indexOf(rsS14[57]) > -1)
 return elem.style.height; 
 return xPos;
 }
}
function rsw_getObjNN4(obj, name) {
 var x = obj.layers;
 var foundLayer;
 for (var i = 0; i < x.length; i++) {
 if (x[i].id == name)
 foundLayer = x[i];
 else if (x[i].layers.length)
 var tmp = rsw_getObjNN4(x[i], name);
 if (tmp) foundLayer = tmp;
 }
 return foundLayer;
}

function rsw_getElementWidth(Elem, isoverlay) {
 var op5 = (navigator.userAgent.indexOf(rsS14[396]) != -1)
 || (navigator.userAgent.indexOf(rsS14[397]) != -1);

 if (rs_s3.layers) {
 var elem = rsw_getObjNN4(document, Elem);
 return elem.clip.width;
 } else {
 if (rs_s3.getElementById) {
 var elem = rs_s3.getElementById(Elem);
 } else if (rs_s3.all) {
 var elem = rs_s3.all[Elem];
 }
 if (op5) {
 xPos = elem.style.pixelWidth;
 } else {
 
 xPos = elem.offsetWidth;

 }

 var compWidth = rsw_getStyleProperty(elem, rsS14[88]);
 if (((compWidth == null || compWidth == rsS14[3]) && elem.style != null) || (!rsw_msie && elem.style != null))
 compWidth = elem.style.width;

 if (!isoverlay && compWidth != null && compWidth.indexOf(rsS14[57]) > -1)
 return compWidth;
 return xPos;
 }
}

function rsw_findPosX(obj) {
 var curleft = 0;
 var isFirefox = navigator.userAgent.toLowerCase().indexOf(rsS14[230]) > -1;
 
 if (typeof (obj.offsetParent) != rsS14[12] && obj.offsetParent) {
 while (obj.offsetParent) {
 var tBW = rsw_getStyleProperty(obj, rsS14[69]);
 curleft += obj.offsetLeft + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0); ;
 if (obj.parentNode.scrollLeft)
 curleft -= obj.parentNode.scrollLeft;
 obj = obj.offsetParent;
 }
 var tBW = rsw_getStyleProperty(obj, rsS14[69]);
 curleft += obj.offsetLeft + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0); ;
 }
 else if (obj.x)
 curleft += obj.x;




 return curleft;

 
}

function rsw_findPosY(obj) {
 var curtop = 0;
 var isFirefox = navigator.userAgent.toLowerCase().indexOf(rsS14[230]) > -1;
 
 if (typeof (obj.offsetParent) != rsS14[12] && obj.offsetParent) {
 while (obj.offsetParent) {
 var tBW = rsw_getStyleProperty(obj, rsS14[73]);

 curtop += obj.offsetTop + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0);
 if (obj.parentNode.scrollTop)
 curtop -= obj.parentNode.scrollTop;
 obj = obj.offsetParent;

 }
 var tBW = rsw_getStyleProperty(obj, rsS14[73]);
 curtop += obj.offsetTop + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0);
 }
 else if (obj.y)
 curtop += obj.y;


 return curtop;

 
 
}








function rsw_decodeSuggestionItem(item) {
 return unescape(item).replace(rsS14[398], rsS14[175]).replace(rsS14[399], "\"");
}


function RS_ContextMenu(errorElement, suggestions, textBox) {
 this.suggestions = suggestions;
 this.CMItems = new Array();
 this.x = 0;
 this.y = 0;
 this.CMelement = null;
 this.textBox = textBox;
 this.show = show;
 this.setCMContent = setCMContent;
 this.hide = hide;
 this.setVisible = setVisible;
 this.isVisible = false;
 this.moveCMElement = moveCMElement;
 this.getContentHtml = getContentHtml;
 this.addItems = addItems;
 this.addItems();

 function addItems() {
 var newSuggs = new Array();
 var errorText = errorElement.textContent ? errorElement.textContent : errorElement.innerText;
 var errorLength = errorText.length;
 for (var i = 0; i < this.suggestions.length; i++) {
 if (this.suggestions[i].indexOf(rsS14[400]) == 0 || this.textBox.maxlength == 0 || typeof(this.textBox.maxlength)==rsS14[12] || rsw_decodeSuggestionItem(this.suggestions[i]).length - errorLength + this.textBox.getContentText().length <= this.textBox.maxlength)
 newSuggs[newSuggs.length] = this.suggestions[i];
 }
 this.suggestions = newSuggs;

 var isCapitalCorrection = false;
 if (this.suggestions.length == 1) {
 isCapitalCorrection = this.suggestions[0].toLowerCase() == errorText && this.suggestions[0].charAt(0).toUpperCase() == this.suggestions[0].charAt(0);
 }

 var isDuplicateWordErr = false;
 for (i = 0; i < this.suggestions.length; i++) {
 if (this.suggestions[i].indexOf(rsS14[400]) < 0) {
 this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement,
 rsw_decodeSuggestionItem(this.suggestions[i]),
 escape(this.suggestions[i]),
 rsS14[333]
 );
 if (this.textBox.spellChecker.showChangeAllItem) {
 this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement,
 unescape(this.textBox.spellChecker.changeAllText),
 escape(this.suggestions[i]),
 rsS14[401], rsS14[402]
 );
 }
 } else {
 this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.removeDuplicateText,
 escape(this.suggestions[i].substring(1)),
 rsS14[403]
 );
 isDuplicateWordErr = true;
 }

 }

 if (this.suggestions.length == 0) {
 this.CMItems[0] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.noSuggestionsText,
 rsS14[196],
 rsS14[404]
 );

 i = 1;
 } else {
 i = this.CMItems.length;
 }


 if (!isDuplicateWordErr || this.textBox.isStatic) {
 this.CMItems[i] = new RS_ContextMenuItem(errorElement,
 rsS14[405],
 rsS14[405],
 rsS14[405]
 );
 }


 if (this.textBox.isStatic) {
 if (this.textBox.spellChecker.showEditMenuItem) {
 this.CMItems[i + 1] = new RS_ContextMenuItem(errorElement, this.textBox.spellChecker.editText,
 rsS14[200],
 rsS14[406]
 );

 i++;
 }
 }

 if (!isDuplicateWordErr) {
 if (this.textBox.spellChecker.showIgnoreAllMenuItem) {
 this.CMItems[i + 1] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.ignoreAllText,
 rsS14[197],
 rsS14[407]
 );
 } else i--;
 var thisUD = null;
 var overrideUD = false;
 if(typeof (rsw_getParameterValue) == rsS14[33]){
 thisUD = rsw_getParameterValue(this.textBox.shadowTB, rsS14[261]);
 overrideUD = thisUD == null || thisUD == rsS14[3];
 }
 var ShowAddItemAlways = false;
 if (typeof (rsw_getParameterValue) == rsS14[33]) 
 ShowAddItemAlways = rsw_getParameterValue(this.textBox.shadowTB, rsS14[408]);
 
 if (((this.textBox.spellChecker.showAddMenuItem && !overrideUD) || ShowAddItemAlways) && !isCapitalCorrection) {
 this.CMItems[i + 2] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.addText,
 rsS14[199],
 rsS14[409]
 );
 }
 }

 
 if (rs_s3.getElementById(rsS14[410]) == null)
 rsw_create_menu_div();

 this.CMelement = rs_s3.getElementById(rsS14[410]);
 this.CMIFelement = rs_s3.getElementById(rsS14[411]);
 


 this.setVisible(false);
 }

 this.onkeydown = function (e) {
 if (rsw_contextMenu.isVisible) {
 if (typeof(event)!=rsS14[12] && event !=null) e = event;
 var menuItems = rsw_contextMenu.getMenuItems();
 var i = rsw_contextMenu.getCurrentHighlightedItemIndex(menuItems);
 if (i >= 0)
 RS_CMItemHighlight(menuItems[i], rsS14[412]);

 if (e.keyCode == 40) {
 if (i + 1 == menuItems.length) i = -1;
 while (menuItems[++i].className == RS_ContextMenuItem_Disabled_Class) {
 if (i == menuItems.length) i = 0;
 }

 

 RS_CMItemHighlight(menuItems[i], rsS14[3]);
 } else if (e.keyCode == 38) {
 if (i <= 0) i = menuItems.length;
 while (menuItems[--i].className == RS_ContextMenuItem_Disabled_Class) {
 if (i == -1) i = menuItems.length - 1;
 }
 
 RS_CMItemHighlight(menuItems[i], rsS14[3]);
 }
 if (e.keyCode == 13 && i > -1 && i < menuItems.length) {
 menuItems[i].click();
 }
 }
 };

 this.getMenuItems = function () {
 return this.CMelement.getElementsByTagName(rsS14[306]);
 };

 this.getCurrentHighlightedItemIndex = function (menuItems) {
 for (var i = 0; i < menuItems.length; i++) {
 if (menuItems[i].className == RS_ContextMenuItem_Class + rsS14[413])
 return i;
 }
 return -1;

 };


 function show() {
 if (typeof(this.textBox.enabled)!=rsS14[12] && !this.textBox.enabled) return;
 
 this.setVisible(true);
 this.moveCMElement();
 this.setCMContent(this.getContentHtml());
 if (typeof (rsw_useIFrameMenuBacker) == rsS14[12] || rsw_useIFrameMenuBacker) {
 if (navigator.userAgent.toLowerCase().indexOf(rsS14[414]) > -1 && !rsw_isMac) { this.CMIFelement.style.left = this.x + rsS14[58];
 this.CMIFelement.style.top = this.y + rsS14[58];
 this.CMIFelement.style.height = (rsw_getElementHeight(rsS14[410]) - 4) + rsS14[58]; this.CMIFelement.style.width = (rsw_getElementWidth(rsS14[410]) - 4) + rsS14[58];
 }
 }

 }

 function hide() {
 try{
 this.setVisible(false);

 this.CMelement.innerHTML = rsS14[3];
 } catch (excep) { rsw_logException(excep); }
 }

 function setCMContent(s) {
 try{
 this.CMelement.innerHTML = s;
 } catch (excep) { rsw_logException(excep); }

 }




 function setVisible(visible) {
 this.CMelement.style.visibility = visible ? rsS14[114] : rsS14[30];

 
 if (typeof (rsw_useIFrameMenuBacker) == rsS14[12] || rsw_useIFrameMenuBacker) {
 if (navigator.userAgent.toLowerCase().indexOf(rsS14[414]) > -1 && !rsw_isMac) {
 this.CMIFelement.style.visibility = visible ? rsS14[114] : rsS14[30];
 this.CMIFelement.style.display = visible ? rsS14[227] : rsS14[48];
 }
 }
 this.isVisible = visible;
 }

 function moveCMElement() {

 this.CMelement.style.left = this.x + rsS14[58];
 this.CMelement.style.top = this.y + rsS14[58];
 if (typeof (rsw_useIFrameMenuBacker) == rsS14[12] || rsw_useIFrameMenuBacker) {
 
 if (navigator.userAgent.toLowerCase().indexOf(rsS14[414]) > -1 && !rsw_isMac) {
 this.CMIFelement.style.left = this.x + rsS14[58];
 this.CMIFelement.style.top = this.y + rsS14[58];
 }
 }
 }

 function getContentHtml() {
 var s = "<table class=\"" + RS_ContextMenuTable_Class + "\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
 var hasSubMenu = false;
 for (var i = 0; i < this.CMItems.length; i++) {
 hasSubMenu = i < this.CMItems.length - 1 && this.CMItems[i + 1].type == rsS14[402];
 s += rsS14[415] + (hasSubMenu ? rsS14[416] : rsS14[417]) + rsS14[169];
 s += this.CMItems[i].getContentHtml();
 s += rsS14[418];

 if (hasSubMenu) {
 i++;
 s += rsS14[419] +
 this.CMItems[i].getContentHtml()
 + rsS14[418];
 }
 s += rsS14[420];
 }
 s += rsS14[421];
 return s;
 }
}




function RS_ContextMenuItem(e, unescapedValue, escapedValue, action, type) {
 this.unescapedValue = unescapedValue;
 this.escapedValue = escapedValue;
 this.action = action;
 this.getContentHtml = getContentHtml;
 this.type = type ? type : rsS14[422];

 function getContentHtml() {


 var s;
 if (this.unescapedValue != rsS14[405] && this.action != rsS14[404]) {
 s = "<span class=\"" +
 (this.type == rsS14[422] ?
 RS_ContextMenuItem_Class :
 RS_ContextMenuItem_AllSubItem_Class
 )
 + "\" "
 + " onclick=\"RS_CMItemClicked( '" + this.escapedValue + rsS14[423] + this.action + "') ;\""
 + " onMouseOut=\" RS_CMItemHighlight(this, 'out');\" "
 + " onMouseOver=\"RS_CMItemHighlight(this, 'over'); \" "
 + rsS14[169] + this.unescapedValue + rsS14[301];




 } else if (this.action == rsS14[404]) {
 s = "<span class=\"" + RS_ContextMenuItem_Disabled_Class + "\" "
 + rsS14[169] + this.unescapedValue + rsS14[301];

 } else {
 s = "<hr class=\"" + RS_CMItemSeparator_Class + "\"/>";
 }
 return s;
 }

 
}





function RS_CMItemHighlight(e, type) {
 try{
 var p = e.className.indexOf(rsS14[413]);
 if (type == rsS14[412]) {
 if (p > 0) e.className = e.className.substring(0, p);
 } else {
 if (p == -1) e.className = e.className + rsS14[413];
 }
 } catch (excep) { rsw_logException(excep); }
}



function RS_CMItemClicked(replacement, action) {
 
 try{
 rsw_refreshActiveTextbox();
 var yScroll = null;
 if (typeof(rsw_activeTextbox.iframe.contentWindow) != rsS14[12])
 yScroll = rsw_getScrollY(rsw_activeTextbox.iframe.contentWindow);

 replacement = unescape(replacement).replace(rsS14[398], rsS14[175]).replace(rsS14[399], "\"");
 if (action == rsS14[407]) {
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[424], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_ignoreAll(rsw_lastRightClickedError);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[425], rsw_activeTextbox, rsw_lastRightClickedError);
 } else if (action == rsS14[406]) {
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[426], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_edit(rsw_lastRightClickedError);

 } else if (action == rsS14[409]) {
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[427], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_add(rsw_lastRightClickedError);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[428], rsw_activeTextbox, rsw_lastRightClickedError);
 } else if (action == rsS14[403]) {
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[429], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_changeTo(rsw_lastRightClickedError, rsS14[3]);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[430], rsw_activeTextbox, rsw_lastRightClickedError);
 } else if (action == rsS14[401]) {
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[431], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 rsw_changeAllTo(rsw_lastRightClickedError, replacement);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[432], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 } else {
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[433], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 rsw_changeTo(rsw_lastRightClickedError, replacement);
 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[434], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 }

 rsw_hideCM();
 if (rsw_activeTextbox.focus && !rsw_activeTextbox.isFocused) {
 



 rsw_activeTextbox.focus();

 if (rsw_activeTextbox.resetCaretPos)
 rsw_activeTextbox.resetCaretPos();

 if(yScroll!=null)
 rsw_setScrollY(rsw_activeTextbox.iframe.contentWindow, yScroll);


 }
 } catch (excep) { rsw_logException(excep); }


}

function rsw_hideCM() {


 if (rsw_contextMenu) {

 rsw_contextMenu.hide();

 }
}


function rsw_create_menu_div() {

 
 var divElement = rs_s3.createElement(rsS14[42]);
 divElement.id = rsS14[410];
 divElement.setAttribute(rsS14[435], rsS14[436]);
 try {
 divElement.oncontextmenu = function () { try { event.cancelBubble = true; event.preventDefault(); } catch (e) { } return false; };
 } catch (e) { }
 
 rs_s3.getElementsByTagName(rsS14[437])[0].appendChild(divElement);


 if (navigator.userAgent.toLowerCase().indexOf(rsS14[414]) > -1) {
 var ifElement = rs_s3.createElement(rsS14[53]);
 ifElement.id = rsS14[411];
 ifElement.setAttribute(rsS14[438], rsS14[439]);
 ifElement.setAttribute(rsS14[440], rsS14[441]);
 ifElement.setAttribute(rsS14[442], rsS14[443]);
 ifElement.setAttribute(rsS14[45], rsS14[444]);
 rs_s3.getElementsByTagName(rsS14[437])[0].appendChild(ifElement);
 }
 }


var rsw_ayt_initializing = false;
function RapidSpell_Web_AsYouType() {


 this.triggeredLast = false;
 this.checkerCurrentlyInitializing = 0;
 this.onTextBoxesInit = onTextBoxesInit;
 this.checkNext = checkNext;
 this.onFinish = onFinish;
 this.onPause = onPause;
 this.checkAsYouTypeOnPageLoad = true;
 this.stop = stop;
 this.start = start;
 this.stopped = false;

 function start() {
 this.stopped = false;
 }
 function stop() {
 this.stopped = true;
 }

 function onPause() {
 rsw_refreshActiveTextbox();
 if (!this.stopped && typeof (rsw_activeTextbox) != rsS14[12] && rsw_activeTextbox != null && rsw_activeTextbox.spellChecker != null) {
 rsw_activeTextbox.updateShadow();
 rsw_activeTextbox.spellChecker.OnSpellButtonClicked();
 }
 }


 function onTextBoxesInit() {
 
 rsw_consoleLog(rsS14[445] + rsw_ayt_initializing);

 if (!rsw_ayt_initializing) {
 rsw_ayt_initializing = true;
 rsw_ayt_check = true;
 if (!this.checkNext())
 rsw_ayt_initializing = false;
 }
 }

 function checkNext() {
 if (rsw_haltProcesses || !rsw_ayt_enabled || this.stopped) {
 rsw_consoleLog(rsS14[446] + rsw_haltProcesses + rsS14[447] + rsw_ayt_enabled + rsS14[448] + this.stopped);
 rsw_ayt_initializing = false; this.checkerCurrentlyInitializing++; this.onFinish();
 }
 if (rsw_scs.length > this.checkerCurrentlyInitializing) {
 var tbs = rsw_scs[this.checkerCurrentlyInitializing].getTBS();
 if (tbs != null && (tbs.isStatic || !tbs.isVisible() || tbs.skipAYTUpdates)) { this.checkerCurrentlyInitializing++;
 this.onFinish();
 } else if (tbs!=null){
 if (this.checkAsYouTypeOnPageLoad)
 rsw_scs[this.checkerCurrentlyInitializing].OnSpellButtonClicked();

 this.checkerCurrentlyInitializing++;

 if (!this.checkAsYouTypeOnPageLoad)
 this.onFinish();

 tbs.isAYT = true;
 }
 }
 return this.checkerCurrentlyInitializing < rsw_scs.length;
 }

 function onFinish() {

 rsw_consoleLog(rsS14[449] + this.triggeredLast);
 if (rsw_ayt_initializing && this.triggeredLast) { rsw_consoleLog(rsS14[450]);
 rsw_ayt_initializing = false;
 
 

 if (typeof (_notifySpellCheckListeners) != rsS14[12])
 _notifySpellCheckListeners(rsS14[451]);
 }

 if (rsw_ayt_initializing) {
 this.triggeredLast = !this.checkNext();
 if (this.triggeredLast) rsw_ayt_initializing = false;
 }

 }
}


String.prototype.rsw_reverse = function () { return this.split(rsS14[3]).reverse().join(rsS14[3]); };

function RSW_Diff(p, v, a) {
 this.position = p;
 this.vector = v;
 this.addedText = a;
}



function RSW_VisibleCharSeq(str) {
 this.str = str;
 this.length = str.length;
 this.allVisible = false;
 this.reverse = reverse;
 this.isReversed = false;
 function reverse() {
 this.str = this.str.rsw_reverse();
 this.isReversed = !this.isReversed;
 }

 this.insertAtVisible = insertAtVisible;
 function insertAtVisible(addition, pos) {
 return this.visibleSubstring(0, pos) + addition + this.visibleSubstring(pos, this.visibleLength());
 }

 this.toString = toString;
 function toString() {
 return this.str;
 }

 this.visibleSubstring = visibleSubstring;
 function visibleSubstring(start, end) {

 var visiChars = 0;
 var inTag = false;
 var inEnt = false;
 var sub = rsS14[3];
 var includeTags = true;
 var tagOpen = this.isReversed ? rsS14[169] : rsS14[168];
 var tagClose = this.isReversed ? rsS14[168] : rsS14[169];
 var entOpen = this.isReversed ? rsS14[452] : rsS14[294];
 var entClose = this.isReversed ? rsS14[294] : rsS14[452];

 for (var i = 0; i < this.str.length; i++) {

 

 if (this.str.charAt(i) == tagOpen && !inTag && !this.allVisible) inTag = true;
 if (this.str.charAt(i) == entOpen && !inTag && !inEnt && !this.allVisible) {
 var closer = this.str.indexOf(entClose, i);
 if (closer > -1 && closer - i < 9) {
 inEnt = true;
 if (visiChars >= start && visiChars < end) {
 var entity = this.str.substring(i, closer);
 if (entity == rsS14[453]) sub += rsS14[294];
 if (entity == rsS14[454]) sub += rsS14[39];
 if (entity == rsS14[455]) sub += rsS14[168];
 if (entity == rsS14[456]) sub += rsS14[169];
 }
 visiChars++;
 }
 }

 if (includeTags && inTag && visiChars >= start && visiChars <= end) sub += this.str.charAt(i);

 if (!inTag && !inEnt) {
 if ( 
 visiChars >= start && visiChars < end) sub += this.str.charAt(i);
 visiChars++;
 }

 if (this.str.charAt(i) == tagClose && inTag) inTag = false;
 if (this.str.charAt(i) == entClose && inEnt) inEnt = false;
 }
 return sub;
 }

 this.lastDiffI = 0;
 this.lastDiffPos = 0;

 this.visibleCharAt = visibleCharAt;
 function visibleCharAt(pos) {
 var startI = 0;
 var visiChars = 0;
 var tagOpen = this.isReversed ? rsS14[169] : rsS14[168];
 var tagClose = this.isReversed ? rsS14[168] : rsS14[169];
 var entOpen = this.isReversed ? rsS14[452] : rsS14[294];
 var entClose = this.isReversed ? rsS14[294] : rsS14[452];
 var entityChar;
 if (pos > this.lastDiffPos) {
 startI = this.lastDiffI;
 visiChars = this.lastDiffPos;
 }



 var inTag = false;
 var inEnt = false;
 for (var i = startI; i < this.str.length; i++) {
 if (this.str.charAt(i) == tagOpen && !inTag && !this.allVisible) inTag = true;
 if (this.str.charAt(i) == entOpen && !inTag && !inEnt && !this.allVisible) {
 var closer = this.str.indexOf(entClose, i);
 if (closer > -1 && closer - i < 9) {
 inEnt = true;

 var entity = this.str.substring(i, closer);
 if (entity == rsS14[453]) entityChar = rsS14[294];
 if (entity == rsS14[454]) entityChar = rsS14[39];
 if (entity == rsS14[455]) entityChar = rsS14[168];
 if (entity == rsS14[456]) entityChar = rsS14[169];

 if (visiChars == pos) return entityChar;
 visiChars++;
 }
 }


 if (!inTag && !inEnt) {
 if (visiChars == pos) {
 this.lastDiffI = i;
 this.lastDiffPos = visiChars;

 if (this.str.charAt(i) == String.fromCharCode(160)) return rsS14[39];

 if (this.str.charAt(i) == rsS14[24]) return rsS14[25];




 return this.str.charAt(i);
 }

 visiChars++;
 }



 if (this.str.charAt(i) == tagClose && inTag) inTag = false;
 if (this.str.charAt(i) == entClose && inEnt) inEnt = false;
 }
 }

 this.visibleLength = visibleLength;
 function visibleLength() {
 
 var visiChars = 0;
 var inTag = false;
 var inEnt = false;

 for (var i = 0; i < this.str.length; i++) {
 if (this.str.charAt(i) == rsS14[168] && !inTag && !this.allVisible) inTag = true;
 if (this.str.charAt(i) == rsS14[294] && !inTag && !inEnt && !this.allVisible) {
 var closer = this.str.indexOf(rsS14[452], i);
 if (closer > -1 && closer - i < 9) {
 inEnt = true;
 visiChars++; }
 }

 if (!inTag && !inEnt) {
 visiChars++;
 }

 if (this.str.charAt(i) == rsS14[169] && inTag) inTag = false;
 if (this.str.charAt(i) == rsS14[452] && inEnt) inEnt = false;
 }
 return visiChars;
 }


}

function RSW_diff(beforeS, afterS) {
 var cs = -1;
 var ce = -1;
 var scanLength = 0;
 var before = new RSW_VisibleCharSeq(beforeS);

 var after = new RSW_VisibleCharSeq(afterS);
 after.allVisible = true;

 var beforeVisiLen = before.visibleLength();
 var afterVisiLen = after.visibleLength();

 for (var i = 0; i < beforeVisiLen && cs < 0; i++)
 if (!(i >= afterVisiLen || after.visibleCharAt(i) == before.visibleCharAt(i))) cs = i;
 

 if (cs == -1 && afterVisiLen != beforeVisiLen) cs = beforeVisiLen;

 
 after.reverse();
 before.reverse();

 
 for (var i = 0; i < afterVisiLen && ce < 0; i++)
 if (i >= (beforeVisiLen - cs) || !(i >= beforeVisiLen || after.visibleCharAt(i) == before.visibleCharAt(i))) ce = (afterVisiLen - i);

 if (ce == -1) ce = afterVisiLen;

 var vector = ce - cs;

 if (vector == 0) vector = afterVisiLen - beforeVisiLen;


 after.reverse(); 
 return new RSW_Diff(cs, vector, after.visibleSubstring(cs, ce));
}




function RSW_EditableElementFinder() {
 this.findPlainTargetElement = findPlainTargetElement;
 this.findRichTargetElements = findRichTargetElements;
 this.obtainElementWithInnerHTML = obtainElementWithInnerHTML;
 this.findEditableElements = findEditableElements;
 this.elementIsEditable = elementIsEditable;
 this.getEditableContentDocument = getEditableContentDocument;

 function findPlainTargetElement(elementID) {
 var rsw_elected = rs_s3.getElementById(elementID);

 if (rsw_elected != null && rsw_elected.tagName &&
 (rsw_elected.tagName.toUpperCase() == rsS14[457] || rsw_elected.tagName.toUpperCase() == rsS14[458])) {
 return rsw_elected;
 } else
 return null;
 }

 function findRichTargetElements(debugTextBox) {
 var editables = new Array();
 this.findEditableElements(document, editables, window, rsS14[3], debugTextBox);
 return editables;
 }

 function obtainElementWithInnerHTML(editable) {
 try{
 if (typeof (editable.innerHTML) != rsS14[12]) return editable;
 else
 if (typeof (editable.documentElement) != rsS14[12])
 return editable.documentElement;

 return null;
 } catch (excep) { rsw_logException(excep); }
 }


 function findEditableElements(node, editables, parent, debugInset, debugTextBox) {
 var children = node.childNodes;
 var editableElement;

 
 if ((editableElement = this.elementIsEditable(node)) != null ||
 (editableElement = this.getEditableContentDocument(node, debugTextBox)) != null
 ) {
 editables[editables.length] = editableElement;
 }

 
 for (var i = 0; i < children.length; i++) {
 this.findEditableElements(children[i], editables, node, debugInset + rsS14[39], debugTextBox);
 }

 }

 function elementIsEditable(element) {
 if (
 (
 typeof (element.getAttribute) != rsS14[12] &&
 (
 element.getAttribute(rsS14[332]) == rsS14[211] ||
 element.getAttribute(rsS14[459]) == rsS14[370]
 )
 )
 ||
 (
 (element.contentEditable && element.contentEditable == true) ||
 (element.designMode && element.designMode.toLowerCase() == rsS14[370])
 )
 

 )
 return [element, element]; else return null;
 }

 function getEditableContentDocument(element, debugTextBox) {
 if (element.tagName && element.tagName == rsS14[53]) {
 var kids = new Array();
 try{
 if (element.contentWindow && element.contentWindow.document) {

 
 this.findEditableElements(element.contentWindow.document, kids, element, rsS14[460], debugTextBox);


 if (kids.length > 0) { var editable = kids[0][0];
 if (typeof (editable.body) != rsS14[12])
 editable = editable.body;
 return [editable, element]; }
 }
 } catch (ex) {
 }
 }
 return null;
 }
}





var rsw_require_init = true;
function rsw_ASPNETAJAX_OnInitializeRequest(sender, eventArgs) {
 rsw_consoleLog(rsS14[461]);
 rsw_cancelCall = true;
 rsw_haltProcesses = true;
 rsw_require_init = true;

 for (var i = 0; i < rsw_scs.length; i++) {
 if (rsw_scs[i] != null) {
 if (rsw_scs[i].state == rsS14[228] || (rsw_scs[i].state == rsS14[210] && typeof (rapidSpell) == rsS14[177])) {
 if (rsw_scs[i].rsw_tbs != null) {
 rsw_scs[i].rsw_tbs.updateShadow();
 rsw_scs[i].rsw_tbs.iframe.style.display = rsS14[48];

 if (rsw_scs[i].rsw_tbs.iframe.parentNode != null)
 rsw_scs[i].rsw_tbs.iframe.parentNode.removeChild(rsw_scs[i].rsw_tbs.iframe); 
 if (rsw_supportAutoSize) {
 rsw_scs[i].rsw_tbs.shadowTB.style.position = rsw_scs[i].rsw_tbs.shadowTBPosition;
 rsw_scs[i].rsw_tbs.shadowTB.style.left = rsw_scs[i].rsw_tbs.shadowTBLeft;
 if (typeof (rsw_scs[i].rsw_tbs.shadowTBTabIndex) != rsS14[12] && rsw_scs[i].rsw_tbs.shadowTBTabIndex != null)
 rsw_scs[i].rsw_tbs.shadowTB.setAttribute(rsS14[31], rsw_scs[i].rsw_tbs.shadowTBTabIndex);
 }
 if (typeof rsw_scs[i].rsw_tbs.shadowTBDisplay === rsS14[12]) {
 rsw_scs[i].rsw_tbs.shadowTBDisplay = rsS14[231];
 }
 rsw_scs[i].rsw_tbs.shadowTB.style.display = rsw_scs[i].rsw_tbs.shadowTBDisplay;
 }
 }
 rsw_scs[i].rsw_tbs = null;

 }
 
 }
 rsw_tbs = new Array();
 rsw_scs = new Array(); 
 rsw_config = new Array(); rsw_ObjsToInit = new Array();
}

function rsw_ASPNETAJAX_OnEndRequest(sender, eventArgs) {
 rsw_consoleLog(rsS14[462]);
 rsw_haltProcesses = false;
 try {
 rsw_createLink(document, rsw_rs_menu_styleURL);
 rsw_createLink(document, rsw_rs_styleURL);
 } catch (ex) { }

 if (typeof (attachInitHandler) != rsS14[12])
 attachInitHandler();

 if (rsw_require_init) {
 if (typeof (rsw_autoCallRSWInit) == rsS14[12] || rsw_autoCallRSWInit)
 setTimeout(rsS14[463], 200);
 }

 rsw_require_init = false;


}



















if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}

var rsw_mozly = navigator.userAgent.indexOf(rsS14[14]) > -1 ;
var rsw_msie = navigator.userAgent.indexOf(rsS14[16]) > -1 ; 
var rsw_chrome = navigator.userAgent.indexOf(rsS14[18]) > -1;
var rsw_applewebkit = navigator.userAgent.indexOf(rsS14[21]) > -1;

if(typeof(RapidSpell)==rsS14[12])RapidSpell = function () {
 };

RapidSpell.prototype.getConfigurationObject = rsw_getConfigurationObject;
RapidSpell.prototype.setParameterValue = rsw_setParameterValue;
RapidSpell.prototype.getParameterValue = rsw_getParameterValue;
RapidSpell.prototype.addEventListener = rsw_addEventListener;
RapidSpell.prototype.removeEventListener = rsw_removeEventListener;

RapidSpell.prototype.enableNETCore = function () {
 rapidSpell.setServiceType(rsS14[464]);
};

var rsw_eventListeners = [];

function rswEventListener(eventName, listener) {
 this.eventName = eventName;
 this.listener = listener;
}

function rsw_addEventListener(eventName, listenerFunction) {
 rsw_eventListeners[rsw_eventListeners.length] = new rswEventListener(eventName, listenerFunction);
}

function rsw_removeEventListener(eventName, listenerFunction) {
 var foundAt=-1;
 for (var i = 0; foundAt==-1 && i < rsw_eventListeners.length; i++) {
 if(rsw_eventListeners[i].listener==listenerFunction && rsw_eventListeners[i].eventName==eventName)
 foundAt=i;
 }
 if(foundAt>-1)
 rsw_eventListeners.splice(foundAt, 1);
}

function rsw_broadcastEvent(eventName, source, data1, data2, data3, data4, data5) {
 for (var i = 0; i < rsw_eventListeners.length; i++) {
 if (rsw_eventListeners[i].eventName == eventName)
 rsw_eventListeners[i].listener(source, data1, data2, data3, data4, data5);
 }
}
function rsw_createSpellBootJSON(text, textBoxForConfig) { var bootParams = [];
 bootParams[bootParams.length] = { 'ParameterName': 'textToCheck', 'ParameterValue': text }; rsw_getrsw_spellBootStringJSON(bootParams, textBoxForConfig);
 return bootParams;
}


function rsw_getrsw_spellBootStringJSON(paramObj, textBox) {
 var res = new String();
 

 for (var i = 0; i < rsw_config_defaults.keys.length; i++) {
 var key = rsw_config_defaults.keys[i];
 var value = rsw_config_defaults.values[i];
 var cval = rsw_getParameterValue(textBox, key);
 if (cval != null) value = cval;
 if (key == rsS14[465]) value = false;
 if (typeof (paramObj) != rsS14[12]) paramObj[paramObj.length] = { 'ParameterName': key, 'ParameterValue': value };
 }
 return res;
}




function rsw_getScriptLocation(name) {
 if (typeof rsw_presetScriptLocation === rsS14[12]) {
 var scripts = rs_s3.getElementsByTagName(rsS14[466]);
 var l;

 for (var i = 0; i < scripts.length; i++) {
 if ((l = scripts[i].src.indexOf(name)) > -1) {
 return scripts[i].src.substring(0, l);
 }
 }
 if (!rsw_suppressWarnings) {
 alert(rsS14[467] + name + rsS14[468]);
 }
 } else {
 return rsw_presetScriptLocation;
 }
}

var rsw_scriptLocation = rsw_getScriptLocation(rsS14[469]);
var rsw_resourceLocation = rsw_scriptLocation;
var rapidSpell = rapidSpell ? rapidSpell : new RapidSpell();

rapidSpell.useAJAXWebService = false;

var rsw_iever = rsw_getInternetExplorerVersion();
var rsw_thisBrowserOnlyFilename = ((rsw_iever > 0 && rsw_iever < 8) || (rsw_iever > 0 && rsw_iever < 10 && rs_s3.compatMode == rsS14[59])) && rsw_scriptLocation.charAt(0) != rsS14[368];

var rsw_RapidSpell_Core=true;
var rsw_ignoreDisabledTextBoxes = true;
var rsw_ignoreReadyOnlyTextBoxes = true;
var rsw_blankLocation = '<%= WebResource("blank.html") %>'.indexOf(rsS14[168]) > -1 ? rsw_resourceLocation + rsS14[470] : '<%= WebResource("blank.html") %>';
if (rsw_thisBrowserOnlyFilename) {
 rsw_rs_menu_styleURL = '<%= WebResource("menu-net2.css") %>'.indexOf(rsS14[168]) > -1 ? rsS14[471] : '<%= WebResource("menu-net2.css") %>';
 rsw_rs_styleURL = '<%= WebResource("rs_style-net2.css") %>'.indexOf(rsS14[168]) > -1 ? rsS14[472] : '<%= WebResource("rs_style-net2.css") %>';
} else {
 rsw_rs_menu_styleURL = ('<%= WebResource("menu-net2.css") %>'.indexOf(rsS14[168]) > -1 ? rsw_resourceLocation + rsS14[471] : '<%= WebResource("menu-net2.css") %>');
 rsw_rs_styleURL = ('<%= WebResource("rs_style-net2.css") %>'.indexOf(rsS14[168]) > -1 ? rsw_resourceLocation + rsS14[472] : '<%= WebResource("rs_style-net2.css") %>'); 
}
rsw_modalHelperURL = '<%= WebResource("RapidSpellModalHelperNET2.html") %>'.indexOf(rsS14[168]) > -1 ? rsw_resourceLocation + rsS14[473] : '<%= WebResource("RapidSpellModalHelperNET2.html") %>';
var rsw_targetIDs = new Array();
var rsw_rapidSpellControls = new Array();
var rsw_config_textBoxKeys = new Array();
var rsw_config_textBoxValues = new Array();
var rsw_config_defaults = { keys: [rsS14[261], rsS14[474], rsS14[475], rsS14[476], rsS14[212], rsS14[477], rsS14[478],
 rsS14[479], rsS14[480], rsS14[481], rsS14[482], rsS14[465], rsS14[483], rsS14[484], rsS14[485],
 rsS14[486], rsS14[487], rsS14[488], rsS14[489], rsS14[490], rsS14[491], rsS14[492], rsS14[493],
 rsS14[494], rsS14[495], rsS14[496], rsS14[497], rsS14[498], rsS14[499],
 rsS14[500], rsS14[501], rsS14[408], rsS14[502], rsS14[503], rsS14[504]],
 values: [rsS14[505], rsS14[506], rsS14[334], rsS14[211], rsS14[334], rsS14[334], rsS14[507],
 rsS14[507], rsS14[334], rsS14[334], rsS14[334], rsS14[211], rsS14[334], rsS14[334], rsS14[334],
 rsS14[211], rsS14[3], rsS14[3], rsS14[334], rsS14[508], rsS14[211], rsS14[334], rsS14[211],
 false, rsw_blankLocation, rsS14[211], rsS14[334], rsS14[334], rsS14[211],
 rsS14[509], rsS14[510], false, rsS14[511], rsS14[211], rsS14[3]]
};

function rsw_ondialogcorrection(a, b, c, tbName) {
 rsw_broadcastEvent(rsS14[512], null, rs_s3.getElementById(tbName), a, b, c);
}

function rsw_ondialogadd(a, b, c, tbName) {
 rsw_broadcastEvent(rsS14[513], null, rs_s3.getElementById(tbName), a, b, c);
}

var rsw_menuOptionKeys = [rsS14[507], rsS14[514], rsS14[515], rsS14[516], rsS14[517], rsS14[518], rsS14[519], rsS14[520], rsS14[521]];
var rsw_menuOptionValues = [
 [rsS14[522], rsS14[197], rsS14[199], rsS14[200], rsS14[198], rsS14[201], rsS14[196], rsS14[523]],
 [rsS14[524], rsS14[525], rsS14[526], rsS14[527], rsS14[528], rsS14[529], rsS14[530], rsS14[531]],
 [rsS14[532], rsS14[533], rsS14[534], rsS14[535], rsS14[536], rsS14[537], rsS14[538], rsS14[539]],
 [rsS14[540], rsS14[541], rsS14[542], rsS14[543], rsS14[544], rsS14[545], rsS14[546], rsS14[547]],
 [rsS14[548], rsS14[549], rsS14[550], rsS14[551], rsS14[552], rsS14[553], rsS14[554], rsS14[555]],
 [rsS14[522], rsS14[556], rsS14[557], rsS14[558], rsS14[559], rsS14[560], rsS14[561], rsS14[562]],
 [rsS14[563], rsS14[564], rsS14[565], rsS14[566], rsS14[567], rsS14[568], rsS14[569], rsS14[570]],
 [rsS14[571], rsS14[572], rsS14[573], rsS14[574], rsS14[575], rsS14[576], rsS14[577], rsS14[578]],
 [rsS14[579], rsS14[580], rsS14[581], rsS14[582], rsS14[583], rsS14[584], rsS14[585], rsS14[586]]
 ];
var rsw_dialogValues = {
 "FRENCH":{ 
 "Ignore":"Ignorer",
 "Ignore All":"Ignorer Tout",
 "All":"Tout",
 "Change":"Remplacer",
 "Change All":"Remp. Tout",
 "Add":"Ajouter",
 "Adding...":"s’ajouter..",
 "Cancel":"Annuler",
 "Finish":"Terminer",
 "Finished checking selection, would you like to check the rest of the text?":"Choix fini de vérification. Vérifiez le reste du texte?",
 "Finished Checking Selection":"Choix fini de vérification.",
 "The spelling check is complete.":"Fini.",
 "The Spelling Check Is Complete.":"Fini.",
 "No Spelling Errors In Text.":"Aucunes Erreurs.",
 "Spelling":"Correcteur orthographique",
 "Check Spelling":"Correcteur Orthographique",
 "Checking Document...":"Vérifiant Le Document...",
 "Checking...":"Vérifiant...",
 "Not In Dictionary:":"Non Trouvé",
 "Not in Dictionary:":"Non Trouvé",
 "In Dictionary:":"Trouvé",
 "Change To:":"Non Trouvé",
 "Resume":"Continuez",
 "Suggestions:":"Suggestions:",
 "Find Suggestions?":"Suggérer?",
 "Finding Suggestions...":"Recherche...",
 "No Suggestions.":"Aucun",
 "No suggestions":"Aucun",
 "Spell checking rs_s3...":"Vérification de l'orthographe du rs_s3...",
 "Remove duplicate word":"Enlevez le mot double",
 "Edit...":"Éditez...",
 "Undo":"Défaites",


 "Resume Editing":"Reprendre édition",

 "&Ignore":"&Ignorer",
 "Ignore &All":"Ignorer &Tout",
 "&Resume":"Continue&z",
 "A&dd":"&Ajouter",
 "&Change":"&Remplacer",
 "Chan&ge All":"Remp. T&out",
 "Canc&el":"Annul&er",

 
 "Check spelling as you type":"Vérifier l’orthographe en cours de frappe",
 "Always suggest corrections":"Suggestions du dictionnaire principal uniquement",
 "Ignore internet addresses and emails":"Ignorer les adresses internet et les courriels",
 "Ignore words with numbers":"Ignorer les mots contenant des nombres",
 "Ignore words in UPPERCASE":"Ignorer les mots en MAJUSCULES",
 "Suggest from main dictionary only":"Suggérez du dictionnaire principal seulement",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignorez le cas inexact (eg. \"l’australie\", \"tABle\")",
 "Basic Settings":"Paramètres de base",
 "Advanced Settings":"Paramètres avancés",
 "Recheck Text":"Revérifier le texte",
 "User Dictionary...":"Dictionnaires personnels...",
 
 "OK":"OK",

 "User Dictionary Contents":"Contenu de Dictionnaire D’utilisateur",
 "User Dictionary":"Dictionnaire D’utilisateur",
 "Word:":"Mot:",
 "Dictionary:":"Dictionnaire:",
 "Delete":"Supprimer",
 "Options...":"Options...",

 "Loading Dictionary...":"Chargement Dictionnaire..."
 }};
rsw_dialogValues.SPANISH = {
 "All":"Todas",
 "Ignore":"Ignorar",
 "Ignore All":"Ignorar Todas",
 "Change":"Cambiar",
 "Change All":"Cambiar Todos",
 "Add":"Agregar",
 "Adding...":"Adición...",
 "Cancel":"Cancelar",
 "Finish":"Acabar",
 "Finished checking selection, would you like to check the rest of the text?":"Selección acabada. ¿Verifique el resto del texto?",
 "Finished Checking Selection":"Selección acabada.",
 "The spelling check is complete.":"La verificación ortográfica ha finalizado.",
 "The Spelling Check Is Complete.":"La verificación ortográfica ha finalizado.",
 "No Spelling Errors In Text.":"No se encontraron errores.",
 "Spelling":"Corregir Ortografía",
 "Check Spelling":"Corregir Ortografía",
 "Checking Document...":"Comprobación Del Documento...",
 "Checking...":"Comprobación...",
 "Not in Dictionary:":"Palabra mal escrita",
 "Not In Dictionary:":"Palabra mal escrita",
 "In Dictionary:":"En Diccionario",
 "Change To:":"Palabra mal escrita",
 "Resume":"Continúe",
 "Suggestions:":"Sugerencias:",
 "Find Suggestions?":"¿Sugerencias?",
 "Finding Suggestions...":"Encontrar sugerencias...",
 "No Suggestions.":"Ningunas sugerencias",
 "No suggestions":"Ningunas sugerencias",
 "Spell checking rs_s3...":"Comprobación del deletreo el texto...",
 "Remove duplicate word":"Quite la palabra duplicada",

 "Edit...":"Corrija...",

 "Undo":"Deshaga",

 "Resume Editing":"Reasumir el corregir",

 "&Ignore":"&Ignorar",
 "Ignore &All":"Ignorar &Todas",
 "&Resume":"C&ontinúe",
 "A&dd":"&Agregar",
 "&Change":"&Cambiar",
 "Chan&ge All":"Cambia&r Todos",
 "Canc&el":"Cance&lar",


 
 "Check spelling as you type":"Revisar ortografía mientras escribe",
 "Always suggest corrections":"Sugiera siempre las correcciones",
 "Ignore internet addresses and emails":"No haga caso de las direcciones de Internet y email",
 "Ignore words with numbers":"No haga caso de las palabras con números",
 "Ignore words in UPPERCASE":"Omitir Palabras en UPPERCASE",
 "Suggest from main dictionary only":"Sugiera del diccionario principal solamente",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Omitir caso incorrecto (eg. \"australia\", \"tABle\")",
 "Basic Settings":"Opciones Básicas",
 "Advanced Settings":"Opciones Avanzados",
 "Recheck Text":"Volver a texto",
 "User Dictionary...":"Diccionario del Usuario...",
 "OK":"Aceptar",
 "User Dictionary Contents":"Contenido del Diccionario del Usuario",
 "User Dictionary":"Diccionario del Usuario",
 "Word:":"Palabra:",
 "Dictionary:":"Diccionario:",
 "Delete":"Eliminar",
 "Options...":"Opciones...",

 "Loading Dictionary...":"Cargando Diccionario..."
};

rsw_dialogValues.GERMAN = {
 "All":"Alle",
 "Ignore":"Ignorieren",
 "Ignore All":"Alle ignorieren",
 "Change":"Ändern",
 "Change All":"Alle ändern",
 "Add":"Hinzufügen",
 "Adding...":"Hinzufügen...",
 "Cancel":"Abbrechen",
 "Finish":"Ende",
 "Finished checking selection, would you like to check the rest of the text?":"Der ausgewählte Text ist überprüft worden. Wollen Sie auch den Rest des Textes überprüfen ?",
 "Finished Checking Selection":"Der ausgewählte Text ist überprüft worden.",
 "The spelling check is complete.":"Die Rechtschreibprüfung ist abgeschlossen.",
 "The Spelling Check Is Complete.":"Die Rechtschreibprüfung ist abgeschlossen.",
 "No Spelling Errors In Text.":"Es sind keine Fehler aufgetreten.",
 "Spelling":"Rechtschreibprüfung",
 "Check Spelling":"Rechtschreibprüfung",
 "Checking Document...":"Überprüfung des Dokumentes...",
 "Checking...":"Überprüfung...",
 "Not in Dictionary:":"Nicht im Wörterbuch:",
 "Not In Dictionary:":"Nicht im Wörterbuch:",
 "In Dictionary:":"Im Wörterbuch:",
 "Change To:":"Ändern In:",
 "Resume":"Weiter",
 "Suggestions:":"Vorschläge:",
 "Find Suggestions?":"Vorschläge suchen?",
 "Finding Suggestions...":"Vorschläge...",
 "No Suggestions.":"Keine Vorschläge",
 "No suggestions":"Keine vorschläge",
 "Spell checking rs_s3...":"Dokument prüfen...",
 "Remove duplicate word":"Doppelte Wörter entfernen",

 "Edit...":"Redigieren...",
 "Resume Editing":"Zusammenfassung Redigieren",

 "Undo":"Annulieren",

 "&Ignore":"&Ignorieren",
 "Ignore &All":"&Alle ignorieren",
 "&Resume":"&Weiter",
 "A&dd":"&Hinzufügen",
 "&Change":"Ä&ndern",
 "Chan&ge All":"Alle än&dern",
 "Canc&el":"Abbre&chen",

 
 "Check spelling as you type":"Rechtschreibung während der Eingabe überprüfen",
 "Always suggest corrections":"Immer Korrekturen vorschlagen",
 "Ignore internet addresses and emails":"Internet-Adressen und eMail ignorieren",
 "Ignore words with numbers":"Wörter mit Zahlen ignorieren",
 "Ignore words in UPPERCASE":"Wörter in GROSS-Schreibung ignorieren",
 "Suggest from main dictionary only":"Nur Wörter aus Haupt-Wörterbuch vorschlagen",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Falsche Groß/Kleinschreibung (zB. \"australien\",\"taBelle\") ignorieren",
 "Basic Settings":"Grundlegende Einstellungen",
 "Advanced Settings":"Erweiterte Einstellungen",
 "Recheck Text":"Text erneut prüfen",
 "User Dictionary...":"Benutzer-Wörterbuch...",
 "OK":"OK",
 "User Dictionary Contents":"Benutzer-Wörterbuch Inhalt",
 "User Dictionary":"Benutzer-Wörterbuch",
 "Word:":"Wort:",
 "Dictionary:":"Wörterbuch:",
 "Delete":"Löschen",
 "Options...":"Optionen...",

 "Loading Dictionary...":"Laden Wörterbuch..."
};

rsw_dialogValues.ITALIAN = {
 "All":"Tutto",
 "Ignore":"Ignora",
 "Ignore All":"Ignora tutto",
 "Change":"Cambia in",
 "Change All":"Cambia tutto",
 "Add":"Aggiungi",
 "Adding...":"Aggiunta...",
 "Cancel":"Chiudi",
 "Finish":"Terminato",
 "Finished checking selection, would you like to check the rest of the text?":"Il testo selezionato è stato verificato. Verifichi il resto del testo?",
 "Finished Checking Selection":"Il testo selezionato è stato verificato.",
 "The spelling check is complete.":"Controllo completato.",
 "The Spelling Check Is Complete.":"Controllo completato.",
 "No Spelling Errors In Text.":"Nessun errori nel testo.",
 "Spelling":"Verificatore ortografico",
 "Check Spelling":"Verificatore ortografico",
 "Checking Document...":"Controllo ortografico...",
 "Checking...":"Controllo...",
 "Not in Dictionary:":"Cambia in:",
 "Not In Dictionary:":"Cambia in:",
 "In Dictionary:":"Trovato nel Dizionario:",
 "Change To:":"Cambia in:",
 "Resume":"Continua",
 "Suggestions:":"Suggerimenti:",
 "Find Suggestions?":"Suggerimenti?",
 "Finding Suggestions...":"Sto cercando i suggerimenti...",
 "No Suggestions.":"Nessun suggerimento",
 "No suggestions":"Nessun suggerimento",
 "Spell checking rs_s3...":"Controllo ortografico...",
 "Remove duplicate word":"Rimuovi la parola duplicata",

 "Edit...":"Modifica...",
 "Resume Editing":"Torna all’Editor",

 "Undo":"Undo",

 "&Ignore":"&Ignora",
 "Ignore &All":"Ignora &tutto",
 "&Resume":"C&ontinui",
 "A&dd":"&Aggiungi",
 "&Change":"&Cambia in",
 "Chan&ge All":"Ca&mbia tutto",
 "Canc&el":"A&nnullamento",

 "Check spelling as you type":"Controlla ortografia durante la digitazione",
 "Always suggest corrections":"Suggerisca sempre le correzioni",
 "Ignore internet addresses and emails":"Ignora gli internet indirizzi ed i email del",
 "Ignore words with numbers":"Ignora parole con i numeri",
 "Ignore words in UPPERCASE":"Ignora parole in MAIUSCOLE",
 "Suggest from main dictionary only":"Suggerisca dal dizionario principale soltanto",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignora improprio caso (ad esempio, \"australia\", \"taVolo\")",
 "Basic Settings":"Impostazioni di Base",
 "Advanced Settings":"Impostazioni Avanzate",
 "Recheck Text":"Testo Ricontrolleremo",
 "User Dictionary...":"Dizionario Utente...",
 "OK":"OK",
 "User Dictionary Contents":"Sommario Dizionario Utente",
 "User Dictionary":"Dizionario Utente",
 "Word:":"Parola:",
 "Dictionary:":"Dizionario:",
 "Delete":"Eliminare",
 "Options...":"Opzioni...",

 "Loading Dictionary...":"Caricamento Dizionario..."
};

rsw_dialogValues.PORTUGUESE = {
 "All":"Tudo",
 "Ignore":"Ignore",
 "Ignore All":"Ignore Tudo",
 "Change":"Mude",
 "Change All":"Mude Tudo",
 "Add":"Adicione",
 "Adding...":"Adição...",
 "Cancel":"Cancelar",
 "Finish":"Batente",
 "Finished checking selection, would you like to check the rest of the text?":"A verificação ortográfica foi concluida, deseja começar do início do texto?",
 "Finished Checking Selection":"Verificação Ortográfica Concluida",
 "The spelling check is complete.":"A verificação de soletração está completa.",
 "The Spelling Check Is Complete.":"A Verificação De Soletração Está Completa.",
 "No Spelling Errors In Text.":"Nenhuns Erros De Soletração No Texto.",
 "Spelling":"Verificação Ortográfica",
 "Check Spelling":"Verifique A Ortografia",
 "Checking Document...":"Verificando O Original...",
 "Checking...":"Verificando...",
 "Not in Dictionary:":"Não Consta No Dicionário:",
 "Not In Dictionary:":"Não Consta No Dicionário:",
 "In Dictionary:":"No Dicionário:",
 "Change To:":"Mudança A:",
 "Resume":"Resumo",
 "Suggestions:":"Sugestões:",
 "Find Suggestions?":"Sugestões Do Achado?",
 "Finding Suggestions...":"Encontrando Sugestões...",
 "No Suggestions.":"Nenhumas Sugestões.",
 "No suggestions":"Nenhumas sugestões",
 "Spell checking rs_s3...":"Carregando verificador ortográfico...",
 "Remove duplicate word":"Remova a palavra duplicada",

 "Edit...":"Edite...",
 "Undo":"Anular",

 "Resume Editing":"Edição do resumo",

 "&Ignore":"I&gnorar",
 "Ignore &All":"Ignorar &Tudo",
 "&Resume":"&Resumo",
 "A&dd":"&Adicionar",
 "&Change":"&Mudar",
 "Chan&ge All":"Mudar T&udo",
 "Canc&el":"&Cancelar",


 "Check spelling as you type":"Verificar ortografia ao escrever",
 "Always suggest corrections":"Sugerir sempre correcções",
 "Ignore internet addresses and emails":"Ignorar endereços da Internet e correio electrónico",
 "Ignore words with numbers":"Ignorar palavras com números",
 "Ignore words in UPPERCASE":"Ignorar palavras em maiúsculas",
 "Suggest from main dictionary only":"Sugira do dicionário principal somente",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignorar impróprio caso (por exemplo. \"austrália\", \"taBela\")",
 "Basic Settings":"Ajustes Básicos",
 "Advanced Settings":"Ajustes Avançados",
 "Recheck Text":"Verific Novamente o Texto",
 "User Dictionary...":"Dicionário do Usuário...",
 "OK":"Aprovação",
 "User Dictionary Contents":"Dicionário do Usuário Conteúdo",
 "User Dictionary":"Dicionário do Usuário",
 "Word:":"Palavra:",
 "Dictionary:":"Dicionário:",
 "Delete":"Excluir",
 "Options...":"Opções...",

 "Loading Dictionary...":"Carregando Dicionário..."
};

rsw_dialogValues.DUTCH = {
 "All":"Allen",
 "Ignore":"Negeren",
 "Ignore All":"Alles negeren",
 "Change":"Wijzigen",
 "Change All":"Alles wijzigen",
 "Add":"Toevoegen",
 "Adding...":"bezig met toevoegen...",
 "Cancel":"Annuleren",
 "Finish":"Eindig",
 "Finished checking selection, would you like to check the rest of the text?":"Spellingscontrole van de selectie is voltooid. Wilt u de overige tekst controleren?",
 "Finished Checking Selection":"Spellingscontrole van de selectie is voltooid",
 "The spelling check is complete.":"De spellingscontrole is voltooid.",
 "The Spelling Check Is Complete.":"De Spellingscontrole is voltooid.",
 "No Spelling Errors In Text.":"De spellingscontrole heeft geen fouten gevonden.",
 "Spelling":"Spelling",
 "Check Spelling":"Spellingscontrole",
 "Checking Document...":"Bezig document te controleren...",
 "Checking...":"Bezig met controleren...",
 "Not in Dictionary:":"Niet in woordenboek:",
 "Not In Dictionary:":"Niet in woordenboek:",
 "In Dictionary:":"In woordenboek:",
 "Change To:":"Wijzigen in:",
 "Resume":"Hervatten",
 "Suggestions:":"Suggesties:",
 "Find Suggestions?":"Suggesties tonen?",
 "Finding Suggestions...":"Bezig met zoeken naar suggesties...",
 "No Suggestions.":"Geen suggesties.",
 "No suggestions":"Geen suggesties",
 "Spell checking rs_s3...":"Bezig met spellingscontrole...",
 "Remove duplicate word":"Verwijder herhaald woord",

 "Edit...":"Corrigeren...",
 "Undo":"Ongedaan maken",

 "Resume Editing":"Corrigeren hervatten",

 "&Ignore":"&Negeren",
 "Ignore &All":"&Alles negeren",
 "&Resume":"&Hervatten",
 "A&dd":"&Toevoegen",
 "&Change":"&Wijzigen",
 "Chan&ge All":"A&lles wijzigen",
 "Canc&el":"Annule&ren",

 "Check spelling as you type":"Spelling controleren terwijl u typt",
 "Always suggest corrections":"Altijd suggereren correcties",
 "Ignore internet addresses and emails":"Negeer internet adressen en e-mail",
 "Ignore words with numbers":"Negeer woorden met aantallen",
 "Ignore words in UPPERCASE":"Negeer woorden in IN HOOFDLETTERS",
 "Suggest from main dictionary only":"Suggestie uit voornaamste woordenboek alleen",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Negeer oneigenlijk geval (bijvoorbeeld. \"australië\", \"taBel\")",
 "Basic Settings":"Basis Instellingen",
 "Advanced Settings":"Geavanceerde Instellingen",
 "Recheck Text":"Controleer Tekst Opnieuw",
 "User Dictionary...":"Gebruiker Woordenboek...",
 "OK":"OK",
 "User Dictionary Contents":"Gebruiker Woordenboek inhoud",
 "User Dictionary":"Gebruiker Woordenboek",
 "Word:":"Woord:",
 "Dictionary:":"Woordenboek:",
 "Delete":"Schrap",
 "Options...":"Opties...",

 "Loading Dictionary...":"Laden Woordenboek..."
};

rsw_dialogValues.POLISH = {
 "All":"Wszystko",
 "Ignore":"Ignoruj",
 "Ignore All":"Ignoruj wszystko",
 "Change":"Zmień",
 "Change All":"Zmień wszystko",
 "Add":"Dodaj",
 "Adding...":"Dodawanie",
 "Cancel":"Anuluj",
 "Finish":"Zakończ",
 "Finished checking selection, would you like to check the rest of the text?":"Zakończono sprawdzanie zaznaczenia, czy chcesz sprawdzić pozostały tekst?",
 "Finished Checking Selection":"Zakończono sprawdzanie zaznaczenia",
 "The spelling check is complete.":"Zakończono Sprawdzanie pisowni.",
 "The Spelling Check Is Complete.":"Zakończono Sprawdzanie Pisowni.",
 "No Spelling Errors In Text.":"W tekście nie ma błędów pisowni.",
 "Spelling":"Pisownia",
 "Check Spelling":"Sprawdź Pisownię",
 "Checking Document...":"Sprawdzanie Dokumentu...",
 "Checking...":"Sprawdzanie...",
 "Not in Dictionary:":"Nie występuje w Słowniku:",
 "Not In Dictionary:":"Nie występuje w Słowniku:",
 "In Dictionary:":"W Słowniku:",
 "Change To:":"Zmień na:",
 "Resume":"Wznów",
 "Suggestions:":"Sugestie:",
 "Find Suggestions?":"Znajdź Sugestie:",
 "Finding Suggestions...":"Szukanie Sugestii...",
 "No Suggestions.":"Nie ma Sugestii.",
 "No suggestions":"Nie ma sugestii",
 "Spell checking rs_s3...":"Sprawdzanie pisowni dokumentu...",
 "Remove duplicate word":"Usuń podwójne wystąpienie słowa",

 "Edit...":"Edytuj...",
 "Undo":"Cofnij",

 "Resume Editing":"Wznów Edycję",
 "&Ignore":"&Ignoruj",
 "Ignore &All":"Ignoruj &Wszystko",
 "&Resume":"&Wznów",
 "&Add":"&Dodaj",
 "&Change":"&Zmień",
 "Chan&ge All":"Z&mień wszystko",
 "Canc&el":"&Przerwij",

 
 "Check spelling as you type":"Sprawdź pisownię podczas pisania",
 "Always suggest corrections":"Zawsze sugeruj poprawki",
 "Ignore internet addresses and emails":"Ignoruj adresy internetowe i e-maile",
 "Ignore words with numbers":"Ignoruj słowa z cyframi",
 "Ignore words in UPPERCASE":"Ignoruj słowa pisane WIELKIMI LITERAMI",
 "Suggest from main dictionary only":"Sugeruj wyłącznie z głównego słownika",
 "Ignore improper case (eg. \"australia\", \"tABle\")":"Ignoruj błędy pisowni wielkich liter (np. \"australia\", \"krzeSło\")",
 "Basic Settings":"Podstawowe ustawienia",
 "Advanced Settings":"Ustawienia Zaawansowane",
 "Recheck Text":"Sprawdź tekst ponownie",
 "User Dictionary...":"Słownik Użytkownika...",
 "OK":"Potwierdzam",
 "User Dictionary Contents":"Zawartość Słownika Użytkownika",
 "User Dictionary":"Słownik Użytkownika",
 "Word:":"Słowo:",
 "Dictionary:":"Słownik:",
 "Delete":"Usuń",
 "Options...":"Opcje...",
 "Loading Dictionary...":"Ładowanie Słownika..."
};

rsw_dialogValues.ENGLISH = {
 "All": "All",
 "Ignore": "Ignore",
 "Ignore All": "Ignore All",
 "Change": "Change",
 "Change All": "Change All",
 "Add": "Add",
 "Adding...": "Adding...",
 "Cancel": "Cancel",
 "Finish": "Finish",
 "Finished checking selection, would you like to check the rest of the text?": "Finished checking selection, would you like to check the rest of the text?",
 "Finished Checking Selection": "Finished Checking Selection",
 "The spelling check is complete.": "The spelling check is complete.",
 "The Spelling Check Is Complete.": "The Spelling Check Is Complete.",
 "No Spelling Errors In Text.": "No Spelling Errors In Text.",
 "Spelling": "Spelling",
 "Check Spelling": "Check Spelling",
 "Checking Document...": "Checking Document...",
 "Checking...": "Checking...",
 "Not in Dictionary:": "Not in Dictionary:",
 "Not In Dictionary:": "Not in Dictionary:",
 "In Dictionary:": "In Dictionary:",
 "Change To:": "Change To:",
 "Resume": "Resume",
 "Suggestions:": "Suggestions:",
 "Find Suggestions?": "Find Suggestions?",
 "Finding Suggestions...": "Finding Suggestions...",
 "No Suggestions.": "No Suggestions.",
 "No suggestions": "No suggestions",
 "Spell checking rs_s3...": "Spell checking rs_s3...",

 "Edit...": "Edit...",

 "Resume Editing": "Resume Editing",

 "Undo": "Undo",

 "&Ignore": "&Ignore",
 "Ignore &All": "Ignore &All",
 "&Resume": "&Resume",
 "A&dd": "A&dd",
 "&Change": "&Change",
 "Chan&ge All": "Chan&ge All",
 "Canc&el": "Canc&el",



 "Check spelling as you type": "Check spelling as you type",
 "Always suggest corrections": "Always suggest corrections",
 "Ignore internet addresses and emails": "Ignore internet addresses and emails",
 "Ignore words with numbers": "Ignore words with numbers",
 "Ignore words in UPPERCASE": "Ignore words in UPPERCASE",
 "Suggest from main dictionary only": "Suggest from main dictionary only",
 "Ignore improper case (eg. \"australia\", \"tABle\")": "Ignore improper case (eg. \"australia\", \"tABle\")",
 "Basic Settings": "Basic Settings",
 "Advanced Settings": "Advanced Settings",
 "Recheck Text": "Recheck Text",
 "User Dictionary...": "User Dictionary...",
 "OK": "OK",
 "User Dictionary Contents": "User Dictionary Contents",
 "User Dictionary": "User Dictionary",
 "Word:": "Word:",
 "Dictionary:": "Dictionary:",
 "Delete": "Delete",
 "Options...": "Options...",

 "Loading Dictionary...": "Loading Dictionary..."

};

rsw_dialogValues.RUSSIAN = {
 "All": "все",
 "Ignore": "Пропустить",
 "Ignore All": "Пропустить все",
 "Change": "Изменить",
 "Change All": "Изменить все",
 "Add": "Добавить",
 "Adding...": "Добавление...",
 "Cancel": "Отмена",
 "Finish": "Готово",
 "Finished checking selection, would you like to check the rest of the text?": "Проверка выделенного фрагмента завершена. Хотите проверить остальной текст?",
 "Finished Checking Selection": "Проверка выделенного фрагмента завершена",
 "The spelling check is complete.": "Проверка орфографии.",
 "The Spelling Check Is Complete.": "Проверка Oрфографии.",
 "No Spelling Errors In Text.": "Текст не содержит орфографических ошибок.",
 "Spelling": "Орфография",
 "Check Spelling": "Проверить орфографию",
 "Checking Document...": "Проверка документа...",
 "Checking...": "Проверка...",
 "Not in Dictionary:": "Нет в словаре:",
 "Not In Dictionary:": "Нет в Cловаре:",
 "In Dictionary:": "В Cловаре:",
 "Change To:": "Изменить на:",
 "Resume": "Продолжить",
 "Suggestions:": "Варианты:",
 "Find Suggestions?": "Найти варианты?",
 "Finding Suggestions...": "Поиск вариантов...",
 "No Suggestions.": "Нет вариантов.",
 "No suggestions": "Нет вариантов",
 "Spell checking rs_s3...": "Проверка орфографии в документе...",
 "Remove duplicate word": "Удалить дубликат слова",

 "Edit...": "Редактировать...",

 "Undo": "Отменить",

 "Resume Editing": "Продолжить редактирование",

 "&Ignore": "&Пропустить",
 "Ignore &All": "Пропустить &все",
 "&Resume": "&Продолжить",
 "A&dd": "&Добавить",
 "&Change": "&Изменить",
 "Chan&ge All": "Измен&ить все",
 "Canc&el": "Отме&на",



 "Check spelling as you type": "Проверять орфографию при вводе",
 "Always suggest corrections": "Всегда предлагать исправления",
 "Ignore internet addresses and emails": "Пропускать адреса Интернета и электронной почты",
 "Ignore words with numbers": "Пропускать слова с цифрами",
 "Ignore words in UPPERCASE": "Пропускать слова из ПРОПИСНЫХ БУКВ",
 "Suggest from main dictionary only": "Предлагать только из основного словаря",
 "Ignore improper case (eg. \"australia\", \"tABle\")": "Пропускать неправильный регистр (например: \"австралия\", \"сТОл\")",
 "Basic Settings": "Основные настройки",
 "Advanced Settings": "Расширенные настройки",
 "Recheck Text": "Проверить текст заново",
 "User Dictionary...": "Пользовательский словарь...",
 "OK": "ОК",
 "User Dictionary Contents": "Содержимое пользовательского словаря",
 "User Dictionary": "Пользовательский словарь",
 "Word:": "Слово:",
 "Dictionary:": "Словарь:",
 "Delete": "Удалить",
 "Options...": "Параметры...",

 "Loading Dictionary...": "Загрузка словаря..."
};




function SpellCheckUITextItems() {
 this.ignore;

}

function rsw_setUIText(language, item, newText) {
 var a = rsw_getLanguageArray(language);
 switch (item) {
 case rsS14[587]: a[0] = newText; break;
 case rsS14[588]: a[1] = newText; break;
 case rsS14[409]: a[2] = newText; break;
 case rsS14[406]: a[3] = newText; break;
 case rsS14[589]: a[4] = newText; break;
 case rsS14[590]: a[5] = newText; break;
 case rsS14[591]: a[6] = newText; break;
 case rsS14[592]: a[7] = newText; break;

 }
}

function rsw_getLanguageArray(lang) {
 for (var i = 0; i < rsw_menuOptionKeys.length; i++) {
 if (rsw_menuOptionKeys[i] == lang)
 return rsw_menuOptionValues[i];
 }
 return null;
}

function rsw_getParameterValue(textBox, param) {
 var searchObj;
 var pos = rsw_getTextBoxIndex(textBox);


 if (pos == -1 && textBox != rsS14[174]) return rsw_getParameterValue(rsS14[174], param); else {
 if (textBox == rsS14[174]) {
 searchObj = rsw_config_defaults;
 } else
 searchObj = rsw_config_textBoxValues[pos];

 var found = -1;
 for (var pp = 0; searchObj.keys && pp < searchObj.keys.length && found == -1; pp++) {
 if (searchObj.keys[pp] == param)
 found = pp;
 }
 if (found == -1) return rsw_getParameterValue(rsS14[174], param); else {
 return searchObj.values[found];
 }
 }
}

function rsw_getConfigurationObject(textBox) {
 var synthObject = {keys:[], values:[]};
 for (var i = 0; i < rsw_config_defaults.keys.length; i++) {
 synthObject.keys[synthObject.keys.length] = rsw_config_defaults.keys[i];
 synthObject.values[synthObject.values.length] = rsw_getParameterValue(textBox, rsw_config_defaults.keys[i]);
 }
 return synthObject;
}

function rsw_getTextBoxIndex(textBox) {
 for (var i = 0; i < rsw_config_textBoxKeys.length; i++) {
 if (rsw_config_textBoxKeys[i] == textBox) return i;
 }
 return -1;
}

function rsw_setParameterValue(textBox, param, value) {
 var pos;
 param = param.replace(/^\s+|\s+$/g, rsS14[3]); if (textBox != rsS14[174]) {

 pos = rsw_getTextBoxIndex(textBox);
 if (pos == -1) {
 rsw_config_textBoxKeys[rsw_config_textBoxKeys.length] = textBox;
 pos = rsw_config_textBoxKeys.length - 1;
 rsw_config_textBoxValues[pos] = {};
 }

 }

 var targ;
 if (textBox != rsS14[174])
 targ = rsw_config_textBoxValues[pos];
 else
 targ = rsw_config_defaults;

 var found = -1;

 for (var pp = 0; targ.keys && pp < targ.keys.length && found == -1; pp++) {
 if (targ.keys[pp] == param)
 found = pp;
 }

 if (!targ.keys) {
 targ.keys = new Array();
 targ.values = new Array();
 }

 if (found == -1) found = targ.keys.length;
 targ.keys[found] = param;
 targ.values[found] = value;

 if(typeof(rsw_scs)!=rsS14[12]){
 for (var i = 0; i < rsw_scs.length; i++) {
 if (textBox==rsS14[174] || rsw_scs[i].textBoxID == textBox.id) {
 rsw_scs[i].config = rsw_getConfigurationObject(rs_s3.getElementById(rsw_scs[i].textBoxID));
 if (param == rsS14[478]) {
 var langArray = rsw_getLanguageArray(value);
 if (langArray != null) {
 rsw_setSpellCheckerText(rsw_scs[i], langArray);
 
 }
 }
 }
 }
 }




}

function rsw_setSpellCheckerText(spellChecker, langArray) {
 spellChecker.ignoreText = langArray[0];
 spellChecker.ignoreAllText = langArray[1];
 spellChecker.addText = langArray[2];
 spellChecker.editText = langArray[3];
 spellChecker.changeAllText = langArray[4];
 spellChecker.removeDuplicateText = langArray[5];
 spellChecker.noSuggestionsText = langArray[6];
}

function rsw_isParentIsNoSpell(tb) {
 if (tb.getAttribute(rsS14[384]) == rsS14[211])
 return true;
 if (tb.parentElement != null)
 return rsw_isParentIsNoSpell(tb.parentElement);
 else if (typeof (tb.parentElement) == rsS14[12] && tb.parentNode != null)
 return rsw_isParentIsNoSpell(tb.parentNode);
 else
 return false;
}

function rsw_isElementVisible(tb) {
 var ifVis = false;
 if (rs_s3.getElementById(tb.id + rsS14[35]) != null) ifVis = rsw_isElementVisible(rs_s3.getElementById(tb.id + rsS14[35]));

 var compVis = rsw_getStyleProperty(tb, rsS14[104]);
 var compDis = rsw_getStyleProperty(tb, rsS14[85]);
 if (compVis == rsS14[30] || compDis == rsS14[48])
 return false || ifVis;
 if (compVis == rsS14[114] && !rsw_parentIsDisplayNone(tb)) return true;
 if (tb.parentElement != null)
 return rsw_isElementVisible(tb.parentElement) || ifVis;
 else if (typeof (tb.parentElement) == rsS14[12] && tb.parentNode != null)
 return rsw_isElementVisible(tb.parentNode) || ifVis;
 else
 return true;
}

function rsw_isElementVisibleOrInitialized(tb) {
 if (rs_s3.getElementById(tb.id + rsS14[35]) != null) return true;
 else{
 return rsw_isElementVisible(tb); 
 }
}

function rsw_parentIsDisplayNone(tb, count) {
 if (typeof (count) == rsS14[12]) count = 0;
 if (count > 30) return false;
 var compDis = rsw_getStyleProperty(tb, rsS14[85]);
 if(compDis==rsS14[48]) return true;
 if (tb.parentElement != null)
 return rsw_parentIsDisplayNone(tb.parentElement, ++count);

 return false;
}


rapidSpell.setServiceType = function (type){
 if (type.toLowerCase() === rsS14[593]) {
 rapidSpellExtension.useASMXService = false;
 rapidSpellExtension.useWCFService = true;
 rapidSpellExtension.useServlet = false;
 } else if (type.toLowerCase() === rsS14[594]) {
 rapidSpellExtension.useASMXService = true;
 rapidSpellExtension.useWCFService = false;
 rapidSpellExtension.useServlet = false;
 } else if (type.toLowerCase() === rsS14[595]) {
 rapidSpellExtension.useASMXService = false;
 rapidSpellExtension.useWCFService = false;
 rapidSpellExtension.useServlet = true;
 } else if(type.toLowerCase() === rsS14[464]) {
 if (typeof rapidSpell.dialog_setUseDivDialog !== rsS14[12]) {
 rapidSpell.dialog_setUseDivDialog(true);
 }
 rapidSpell.useAJAXWebService = true;
 rapidSpellExtension.useWCFService = false;
 rapidSpellExtension.useAPIController = true;
 rapidSpellExtension.serviceProxy.commonFolderUrl = rsS14[596];
 } 
};



var JSON; if (!JSON) { JSON = {} } (function () {
 function f(n) { return n < 10 ? "0" + n : n } if (typeof Date.prototype.toJSON !== "function") { Date.prototype.toJSON = function (key) { return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null };
																																						 String.prototype.toJSON = Number.prototype.toJSON = Boolean.prototype.toJSON = function (key) { return this.valueOf() } } var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = { "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", '"': '\\"', "\\": "\\\\" }, rep; function quote(string) { escapable.lastIndex = 0; return escapable.test(string) ? '"' + string.replace(escapable, function (a) { var c = meta[a]; return typeof c === "string" ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) }) + '"' : '"' + string + '"' } function str(key, holder) {
 var i, k, v, length, mind = gap, partial, value = holder[key]; if (value && typeof value === "object" && typeof value.toJSON === "function") { value = value.toJSON(key) } if (typeof rep === "function") { value = rep.call(holder, key, value) } switch (typeof value) {
 case "string": return quote(value); case "number": return isFinite(value) ? String(value) : "null"; case "boolean": case "null": return String(value); case "object": if (!value) { return "null" } gap += indent; partial = [];
 if (Object.prototype.toString.apply(value) === "[object Array]") { length = value.length; for (i = 0; i < length; i += 1) { partial[i] = str(i, value) || "null" } v = partial.length === 0 ? "[]" : gap ? "[\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "]" : "[" + partial.join(",") + "]"; gap = mind; return v } if (rep && typeof rep === "object") { length = rep.length; for (i = 0; i < length; i += 1) { if (typeof rep[i] === "string") { k = rep[i]; v = str(k, value); if (v) { partial.push(quote(k) + (gap ? ": " : ":") + v) } } } } else { for (k in value) { if (Object.prototype.hasOwnProperty.call(value, k)) { v = str(k, value); if (v) { partial.push(quote(k) + (gap ? ": " : ":") + v) } } } } v = partial.length === 0 ? "{}" : gap ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}" : "{" + partial.join(",") + "}"; gap = mind; return v
 }
 } if (typeof JSON.stringify !== "function") { JSON.stringify = function (value, replacer, space) { var i; gap = ""; indent = ""; if (typeof space === "number") { for (i = 0; i < space; i += 1) { indent += " " } } else { if (typeof space === "string") { indent = space } } rep = replacer; if (replacer && typeof replacer !== "function" && (typeof replacer !== "object" || typeof replacer.length !== "number")) { throw new Error("JSON.stringify") } return str("", { "": value }) } } if (typeof JSON.parse !== "function") { JSON.parse = function (text, reviver) { var j; function walk(holder, key) { var k, v, value = holder[key]; if (value && typeof value === "object") { for (k in value) { if (Object.prototype.hasOwnProperty.call(value, k)) { v = walk(value, k); if (v !== undefined) { value[k] = v } else { delete value[k] } } } } return reviver.call(holder, key, value) } text = String(text); cx.lastIndex = 0; if (cx.test(text)) { text = text.replace(cx, function (a) { return "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4) }) } if (/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, "]").replace(/(?:^|:|,)(?:\s*\[)+/g, ""))) { j = eval("(" + text + ")"); return typeof reviver === "function" ? walk({ "": j }, "") : j } throw new SyntaxError("JSON.parse") } }
}());
var rsw_errorHandler = null;
var rapidSpellExtension = {
 useWCFService: true,
 useASMXService: false,
 useServlet: false,
 useAPIController: false,

 serviceProxy: new function () {
 var _I = this;
 this.isBusy = false;
 this.haveLogged = false;
 this.appendURLString = rsS14[3];
 this.commonFolderUrl = rsw_scriptLocation.substring(0, rsw_scriptLocation.length-1);



 this.invoke = function (method, data, callback, errorHandler, bare, POSTGET) {
 if(typeof errorHandler==rsS14[33])
 rsw_errorHandler = errorHandler;
 if (typeof (POSTGET) == rsS14[12])
 POSTGET = rsS14[161];
 if (rapidSpellExtension.useWCFService)
 this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl + rsS14[597];
 else if (rapidSpellExtension.useASMXService)
 this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl + rsS14[598];
 else if (rapidSpellExtension.useAPIController) this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl + rsS14[599]; else if (rapidSpellExtension.useServlet) {
 var pp = rapidSpellExtension.serviceProxy.commonFolderUrl.indexOf(rsS14[600]);
 this.serviceUrl = rapidSpellExtension.serviceProxy.commonFolderUrl.substring(0, pp) + rsS14[601];
 }

 this.isBusy = true;


 var url = _I.serviceUrl + method + this.appendURLString;

 function htmlEncode(s) {
 return s.replace(/&/g, rsS14[295]).replace(/</g, rsS14[194])
 .replace(/>/g, rsS14[195]);
 }


 if (rapidSpellExtension.useASMXService) {
 var wrapdata = rsS14[602] + encodeURIComponent(htmlEncode(JSON.stringify(data)));
 if (!this.haveLogged)
 console.log(rsS14[603]);
 this.haveLogged = true;
 $.ajax({
 cache: false,
 url: url,
 data: wrapdata, type: POSTGET,
 processData: true,
 contentType: rsS14[604], timeout: 30000,
 dataType: rsS14[98], success:
 function (res) {
 if (!callback) return;

 var firstBrace = res.indexOf(rsS14[605]);
 var lastBrace = res.lastIndexOf(rsS14[606]);
 bare = true;
 var result = null;

 if (firstBrace > -1 && lastBrace > -1)
 result = JSON.parse(res.substring(firstBrace, lastBrace + 1));

 if (bare) {
 if (result.value == null) {
 alert(result.exception);
 } else {
 callback(result.value, rsw_errorHandler);
 }
 return;
 }

 for (var property in result) {
 callback(result[property], rsw_errorHandler);
 break;
 }
 },
 error: function (xhr, textstatus, message) {
 if (typeof rsw_errorHandler == rsS14[33])
 return rsw_errorHandler(xhr, textstatus, message);
 if (xhr.responseText) {
 var err = xhr.responseText; if (err)
 alert(err + rsS14[607] + this.url + rsS14[173] + this.url + rsS14[608]);
 else
 alert(rsS14[609]);
 } else if (textstatus) {
 if (textstatus == rsS14[610]) textstatus = rsS14[611];
 if (textstatus == rsS14[612]) {
 if (xhr.status == 404) {
 textstatus = xhr.status + ' error from server. \r\nTry calling (in Javascript) \r\n\r\nrapidSpell.commonFolderUrl = "/Keyoti_RapidSpell_Web_Common/";\r\n\r\nwith the correct path to the folder that contains RapidSpellService.svc and/or RapidSpellService.asmx\r\n';
 } else
 textstatus = xhr.status + rsS14[613];
 }
 alert(textstatus + rsS14[614] + this.url + rsS14[173] + this.url + rsS14[608]);
 }
 $(rsS14[615]).remove();
 return;
 }
 });
 } else {

 var json = JSON.stringify(data);
 if (!this.haveLogged) {
 if (!rapidSpellExtension.useAPIController) console.log(rsS14[616]);
 else console.log(rsS14[617]); }
 this.haveLogged = true;
 var ajDat = {
 url: url,

 type: POSTGET,


 success:
 function (res) {
 rapidSpellExtension.serviceProxy.isBusy = false;
 if (!callback) return;

 var result = JSON.parse(res);



 if (bare) {
 if (result.value == null) {
 alert(result.exception);
 } else {
 callback(result.value, rsw_errorHandler);
 }
 return;
 }

 if (rapidSpellExtension.useServlet) {
 if (result.error != null && result.error.length > 0) {
 alert(result.error);
 return;
 }
 callback(result, rsw_errorHandler);
 } else {
 if (typeof result[rsS14[618]] == rsS14[12]) { if (result.exception != null && result.exception.length > 0) {
 alert(result.exception);
 return;
 }
 callback(result.value, rsw_errorHandler); } else {
 for (var property in result) {
 if (result[property].exception != null && result[property].exception.length > 0) {
 alert(result[property].exception);
 return;
 }
 if (result[property].Exception != null && result[property].Exception.length > 0) {
 alert(result[property].Exception);
 return;
 }
 callback(result[property].value, rsw_errorHandler);
 break;
 }
 }
 }
 },
 error: function (xhr, textstatus, message) {
 if (typeof rsw_errorHandler == rsS14[33])
 return rsw_errorHandler(xhr, textstatus, message);
 if (xhr.status == 500 && xhr.responseText.length == 0) {
 alert(rsS14[619]);
 }
 rapidSpellExtension.serviceProxy.isBusy = false;
 if (typeof xhr.responseText !== rsS14[12] && xhr.responseText.indexOf(rsS14[620]) > -1) alert(rsS14[621]);
 if (xhr.responseText) {
 var err;
 try {
 err = JSON.parse(xhr.responseText);
 } catch (ee) {
 err = { Message: rsS14[622] + this.url + rsS14[173] + this.url + rsS14[608] + rsS14[623] + xhr.responseText };
 }
 if (err) {
 err.Message += rsS14[607] + this.url + rsS14[173] + this.url + rsS14[608];
 alert(err.Message);
 } else
 alert(rsS14[609] + rsS14[607] + this.url + rsS14[173] + this.url + rsS14[608]);
 } else if (textstatus) {
 if (textstatus == rsS14[610]) textstatus = rsS14[611];
 if (textstatus == rsS14[612]) {
 if (xhr.status == 404) {
 textstatus = xhr.status + ' error from server. \r\nTry calling (in Javascript) \r\n\r\nrapidSpellExtension.commonFolderUrl = "/Keyoti_RapidSpell_Web_Common/";\r\n\r\nwith the correct path to the folder that contains RapidSpellService.svc\r\n';
 } else
 textstatus = xhr.status + rsS14[613];
 }
 alert(textstatus + rsS14[614] + this.url + rsS14[173] + this.url + rsS14[608]);
 }
 $(rsS14[615]).remove();
 return;
 }
 };
 }

 if (rapidSpellExtension.useWCFService || rapidSpellExtension.useAPIController) { ajDat.data = json;
 ajDat.contentType = rsS14[624];
 ajDat.timeout = 30000;
 ajDat.dataType = rsS14[98];
 ajDat.processData = false;
 ajDat.cache = false;

 } else if (rapidSpellExtension.useServlet) {
 ajDat.data = { data: json };
 ajDat.timeout = 30000;
 ajDat.dataType = rsS14[98];
 ajDat.cache = false;
 }
 if (typeof ($) === rsS14[12]) alert(rsS14[625]);
 $.ajax(ajDat);
 };
 }
};













var rsw_originalEvent;
rsw_createLink(document, rsw_resourceLocation + rsS14[471]);
rsw_createLink(document, rsw_resourceLocation + rsS14[472]);

RapidSpell.prototype.ayt_removeUnderlines = rsw_removeUnderlines;
RapidSpell.prototype.ayt_refreshUnderlines = rsw_refreshUnderlines;
RapidSpell.prototype.ayt_setupTextBoxes = rsw_setupTextBoxes;
RapidSpell.prototype.ayt_spellCheck = rsw_spellCheckProxy;



rapidSpell.ayt_helperURL = rsw_scriptLocation + rsS14[626];
rapidSpell.ayt_showAddMenuItem = true;
rapidSpell.ayt_showIgnoreAllMenuItem = true;
rapidSpell.ayt_checkLabels = false;
rapidSpell.ayt_findByClass = false;
rapidSpell.ayt_aytEnabled = true;
rapidSpell.ayt_staticMode = false;
rapidSpell.ayt_recheckDelay = 500;
rapidSpell.ayt_ignoreTextBoxIds = new Array();
rapidSpell.ayt_setUIText = rsw_setUIText;
rapidSpell.ayt_copyStyleSheets = true;
rapidSpell.ayt_forceNoScrollBars = false;



function rsw_spellCheckProxy(optionalID, button) {
 if (typeof (optionalID) == rsS14[56]) {
 rsw_spellCheckTextBox(rs_s3.getElementById(optionalID), button);
 } else{
 rsw_spellCheckAll();
 }
}


if (!rsw_RapidSpell_Core) alert(rsS14[627]);

rsw_isASPX = true;


var rsw_haveadded = false;
var rsw_prm = null;

function rsw_endRequest(sender, args) {
 rsw_setupTextBoxes(false);
}

function rsw_refreshUnderlines() {
 rsw_removeUnderlines(); 
 rsw_startAYT(0);
}

function rsw_removeUnderlines() {
 for (var j = 0; j < rsw_tbs.length; j++) {
 var tb = rsw_tbs[j];
 var errors = tb.getSpanElements();
 for (var i = 0; i < errors.length; i++) {
 tError = errors[i].innerHTML.replace(/<[^>]+>/g, rsS14[3]);
 if (errors[i].className == rsS14[284]) {
 rsw_dehighlight(errors[i--]); }
 }
 }
}

function rsw_isTextBoxIgnored(tbId) {
 if (tbId.indexOf(rsS14[41]) > -1 && rapidSpell.ayt_checkLabels) return true;
 for (var i = 0; i < rapidSpell.ayt_ignoreTextBoxIds.length; i++)
 if (tbId == rapidSpell.ayt_ignoreTextBoxIds[i]) return true;
 return false;
}

var rsw_ignorePropertyChange = false;

function rsw_watchedElementChange_Mutations(mutations) {

 mutations.forEach(function (mutation) {
 var map = { attrName: mutation.attributeName, newValue: mutation.target.getAttribute(mutation.attributeName), target: mutation.target };
 rsw_watchedElementChange(map); 
 });
}

function rsw_getIntFromCssUnits(s) {
 if (s == null) return null;
 if (s.length == 0) return null;
 if (s.indexOf(rsS14[58]) > -1) return parseInt(s.substring(0, s.length - 2), 10);
 if (s.indexOf(rsS14[57]) > -1) return parseInt(s.substring(0, s.length - 1), 10);
}

function rsw_watchedElementChange(e) {
 if (rsw_ignorePropertyChange) return;
 
 if (e) {
 if (e.attrName == rsS14[386] || e.attrName == rsS14[44] || e.attrName == rsS14[45]) { var tbs = rsw_getTBSFromTB(e.target);
 if (e.attrName == rsS14[386]) {
 if (tbs != null && typeof (tbs.updateIframe) == rsS14[33]) {
 tbs.updateIframe();
 if (tbs.spellChecker != null)
 tbs.spellChecker.OnSpellButtonClicked();
 }
 }

 if (e.attrName == rsS14[44]) {
 if (tbs != null) {
 rsw_copyComputedStyle(tbs.iframe, tbs.shadowTB);
 var col;
 if (tbs.shadowTB.currentStyle)
 col = tbs.shadowTB.currentStyle;
 else if (rs_s3.defaultView && rs_s3.defaultView.getComputedStyle)
 col = rs_s3.defaultView.getComputedStyle(tbs.shadowTB, null);
 for (sp in col) {
 if (isNaN(parseInt(sp))) { try {
 if (sp.indexOf(rsS14[91]) > -1) {
 var v = rsw_getStyleProperty(tbs.shadowTB, sp);
 if (typeof (v) != rsS14[12] && v != rsS14[3] && v != null) {
 tbs.iframe.style[sp] = v;
 }
 }
 } catch (ex) { }
 }
 }
 }
 }

 if (e.attrName == rsS14[45]) {
 var p, pe;
 var dimensions = [rsS14[88], rsS14[89]];
 for (var i = 0; i < dimensions.length; i++) {
 if ((p = e.newValue.indexOf(dimensions[i] + rsS14[38])) > -1 && (pe = e.newValue.indexOf(rsS14[452], p)) > -1) {
 var newV = e.newValue.substring(p + (dimensions[i] + rsS14[38]).length, pe);
 if (tbs != null && tbs.iframe != null && !(rsw_supportAutoSize && dimensions[i] === rsS14[88])) {
 var bbw = rsw_getIntFromCssUnits(tbs.iframe.style[rsS14[74]]);
 var btw = rsw_getIntFromCssUnits(tbs.iframe.style[rsS14[73]]);
 var pt = rsw_getIntFromCssUnits(tbs.iframe.style[rsS14[71]]);
 var pb = rsw_getIntFromCssUnits(tbs.iframe.style[rsS14[72]]);
 var sum=0;
 if (bbw != null) sum += bbw;
 if (btw != null) sum += btw;
 if (pt != null) sum += pt;
 if (pb != null) sum += pb;
 if (newV.indexOf(rsS14[58]) > -1) newV = (rsw_getIntFromCssUnits(newV) + sum)+rsS14[58];
 tbs.iframe.style[dimensions[i]] = newV;
 }
 }
 }

 }

 if ((e.attrName == rsS14[45] && e.newValue.indexOf(rsS14[628]) > -1 && e.target.style.visibility == rsS14[30])
 ) {
 if (tbs != null) tbs.iframe.style.display = rsS14[48];
 }
 if (
 (e.attrName == rsS14[45] && e.newValue.indexOf(rsS14[628]) > -1 && e.target.style.visibility == rsS14[114])
 ||
 (e.attrName == rsS14[45] && e.newValue.indexOf(rsS14[628]) > -1 && (e.target.style.display == rsS14[227] || e.target.style.display == rsS14[231]))
 ) {
 if (tbs != null) tbs.iframe.style.display = rsS14[227];
 }
 }
 } else if (event.propertyName == rsS14[386] || event.propertyName == rsS14[44] || event.propertyName == rsS14[629] ||
 event.propertyName == rsS14[630] || event.propertyName == rsS14[631] || event.propertyName == rsS14[632]) {
 var tbs = rsw_getTBSFromTB(event.srcElement);
 if (event.propertyName == rsS14[386]) tbs.setContent(event.srcElement.value);

 if (event.propertyName == rsS14[44]) {
 if (tbs != null) rsw_copyComputedStyle(tbs.iframe, tbs.shadowTB);
 }

 if (event.propertyName == rsS14[629]) {
 tbs.iframe.style.height = event.srcElement.style.height;
 }
 if (event.propertyName == rsS14[630]) {
 tbs.iframe.style.width = event.srcElement.style.width;
 }

 if ((event.propertyName == rsS14[631] && event.srcElement.style.visibility == rsS14[30]) || (event.propertyName == rsS14[632] && event.srcElement.style.display == rsS14[48])) {
 if (tbs != null) tbs.iframe.style.display = rsS14[48];
 }
 if (
 (event.propertyName == rsS14[631] && event.srcElement.style.visibility == rsS14[114])
 ||
 (event.propertyName == rsS14[632] && (event.srcElement.style.display == rsS14[227] || event.srcElement.style.display == rsS14[231]))
 ) {
 if (tbs != null) tbs.iframe.style.display = rsS14[227];
 }

 

 }
 }

function rsw_checkValuesForChange() {
 if (rsw_ignorePropertyChange) return;
 var ov;
 for (var i = 0; i < rsw_tbs.length; i++) {
 if(rsw_tbs[i]!=null && rsw_tbs[i].shadowTB!=null){
 ov = rsw_tbs[i].shadowTB.getAttribute(rsS14[40]);

 rsw_tbs[i].shadowTB.setAttribute(rsS14[40], rsw_tbs[i].shadowTB.value);
 if (ov != null) {
 if (!(ov==rsS14[12] && typeof(rsw_tbs[i].shadowTB.value)==rsS14[12]) && ov != rsw_tbs[i].shadowTB.value){ 
 var e = new Object();
 e.target = rsw_tbs[i].shadowTB;
 e.srcElement = rsw_tbs[i].shadowTB;
 e.attrName = rsS14[386];
 rsw_watchedElementChange(e);
 }
 } 
 }
 }
}

var rsw_MutationObservers = {};

function rsw_attachMutationObserver(tb) {
 if (rsw_MutationObservers[tb.id] != null) rsw_MutationObservers[tb.id].observe(tb, { attributes: true, childList: false, characterData: true });
}

function rsw_detachMutationObserver(tb) {
 if (rsw_MutationObservers[tb.id] != null) rsw_MutationObservers[tb.id].disconnect();
}

function rsw_attachListeners(tb) {
 
 var MutationObserver = rs_s2.MutationObserver || rs_s2.WebKitMutationObserver || rs_s2.MozMutationObserver;
 if (typeof (MutationObserver) != rsS14[12]) {
 if (rsw_MutationObservers[tb.id] != null) rsw_detachMutationObserver(tb);
 rsw_MutationObservers[tb.id] = new MutationObserver(rsw_watchedElementChange_Mutations);
 rsw_attachMutationObserver(tb);
 

 
 } else {
 
 if (typeof (tb.addEventListener) == rsS14[33]) {
 tb.addEventListener(rsS14[633], rsw_watchedElementChange, true);
 
 }
 else if (typeof (tb.onpropertychange) == rsS14[177])
 tb.onpropertychange = rsw_watchedElementChange;
 else
 setInterval(rsS14[634], 50);


 
 }
 if (navigator.userAgent.indexOf(rsS14[14]) > -1 && !rsw_msie11) setInterval(rsS14[634], 50);
}


var rsw_indexOf = [].indexOf || function (prop) {
 for (var i = 0; i < this.length; i++) {
 if (this[i] === prop) return i;
 }
 return -1;
};


rs_s2.rsw_getElementsByClassName = function (className, context) {
 if (typeof(context.getElementsByClassName)==rsS14[33]) return context.getElementsByClassName(className);
 var elems = rs_s3.querySelectorAll ? context.querySelectorAll(rsS14[166] + className) : (function () {
 var all = context.getElementsByTagName(rsS14[460]),
 elements = [],
 i = 0;
 for (; i < all.length; i++) {
 if (all[i].className && (rsS14[39] + all[i].className + rsS14[39]).indexOf(rsS14[39] + className + rsS14[39]) > -1 && rsw_indexOf.call(elements, all[i]) === -1) elements.push(all[i]);
 }
 return elements;
 })();
 return elems;
};

function rsw_isTextBoxSpellChecked(textbox) {
 if (textbox == null) return false;
 return textbox.getAttribute(rsS14[384]) != rsS14[211] && rsw_isElementVisibleOrInitialized(textbox) && !rsw_isParentIsNoSpell(textbox) && !rsw_isTextBoxIgnored(textbox.id);
}

function rsw_setupTextBoxes(activate, textBoxIDArray) {
 rsw_consoleLog(rsS14[635]);
 
 var spellables = [];
 if (rs_s3.getElementsByClassName)
 spellables = rs_s3.getElementsByClassName(rsS14[636]);
 else
 spellables = rsw_getElementsByClassName(rsS14[636], document);
 var textareas = rs_s3.getElementsByTagName(rsS14[54]);
 var inputs = rs_s3.getElementsByTagName(rsS14[292]);
 var labels = rapidSpell.ayt_checkLabels ? rs_s3.getElementsByClassName(rsS14[637]) : [];
 var textboxes = [];
 if (rapidSpell.ayt_findByClass) {
 for (var i = 0; i < spellables.length; i++)
 if ((spellables[i].tagName == rsS14[458] || spellables[i].tagName == rsS14[457] || spellables[i].tagName == rsS14[272]) && spellables[i].id != rsS14[3] && (spellables[i].id.indexOf(rsS14[41]) == -1 || !rapidSpell.ayt_checkLabels))
 textboxes[textboxes.length] = spellables[i];
 } else {
 for (var i = 0; i < textareas.length; i++) if (textareas[i].id != rsS14[3]) textboxes[textboxes.length] = textareas[i];
 for (var i = 0; i < inputs.length; i++) if (inputs[i].type == rsS14[98] && inputs[i].id != rsS14[3] && (inputs[i].id.indexOf(rsS14[41]) == -1 || !rapidSpell.ayt_checkLabels)) textboxes[textboxes.length] = inputs[i];
 if (rapidSpell.ayt_checkLabels) {
 for (var i = 0; i < labels.length; i++)
 if (labels[i].id != rsS14[3])
 textboxes[textboxes.length] = labels[i];
 }
 }
 
 textareas = null;
 inputs = null;
 labels = null;

 if (typeof (textBoxIDArray) != rsS14[12]) {
 textboxes = [];
 for (var i = 0; i < textBoxIDArray.length; i++) {
 var tt = rs_s3.getElementById(textBoxIDArray[i]);
 if(tt!=null)
 textboxes[textboxes.length] = tt;
 }
 }
 
 var startAt = -1;
 var actives = new Array();
 var tbs;
 for (var i = 0; i < textboxes.length; i++) {
 if (textboxes[i] != null) {
 if (rapidSpell.ayt_staticMode &&
 (!rsw_ignoreReadyOnlyTextBoxes || !textboxes[i].readOnly) &&
 (!rsw_ignoreDisabledTextBoxes || !textboxes[i].disabled) &&
 rsw_isTextBoxSpellChecked(textboxes[i])
 ) {
 rsw_AYT_configureSpellChecker(new SpellChecker(textboxes[i].id), textboxes[i].id);
 } else {
 tbs = rsw_getTBSFromTB(textboxes[i]);
 if (rsw_isElementVisibleOrInitialized(textboxes[i]) && tbs != null)
 actives[actives.length] = tbs;
 else if (
 (!rsw_ignoreReadyOnlyTextBoxes || !textboxes[i].readOnly) &&
 (!rsw_ignoreDisabledTextBoxes || !textboxes[i].disabled) &&
 rsw_isTextBoxSpellChecked(textboxes[i])
 ) {
 if (tbs == null) {
 rsw_enableAsYouTypeTextBox(textboxes[i]);

 rsw_attachListeners(textboxes[i]);

 if (activate) {
 rsw__initTB(rsw_tbs.length, textboxes[i].id);
 if (rsw_activeTextbox == null)
 rsw_activeTextbox = rsw_tbs[0];
 rsw_addTbFinish(0, textboxes[i].id);
 if (startAt == -1)
 startAt = rsw_tbs.length - 1;
 actives[actives.length] = rsw_tbs[rsw_tbs.length - 1];
 }

 } else {
 if (tbs.iframe.style.display == rsS14[48]) {
 tbs.iframe.style.display = rsS14[227];
 }
 actives[actives.length] = tbs;
 }
 }
 }
 }
 }


 
 setTimeout(function(){rsw_waitStartAYT()}, 1000);

 var found;
 for (var i = rsw_tbs.length - 1; i >= 0; i--) {
 found = false;
 for (var j = 0; j < actives.length; j++) {
 if (rsw_tbs[i] == actives[j]) {
 found = true;
 break;
 }
 }
 if (!found && !rsw_tbs[i].isLabel) {
 if (rsw_tbs[i].iframe != null) {
 
 rsw_tbs[i].iframe.style.display = rsS14[48];
 if (typeof (rsw_tbs[i].shadowTBDisplay) != rsS14[12] && rsw_tbs[i].shadowTBDisplay != rsS14[12]) {
 rsw_tbs[i].shadowTB.style.display = rsw_tbs[i].shadowTBDisplay;
 rsw_consoleLog(rsS14[638] + rsw_tbs[i].shadowTBID + rsS14[639] + rsw_tbs[i].shadowTBDisplay);
 } else if (!rsw_tbs[i].isLabel) {
 rsw_tbs[i].shadowTB.style.display = rsS14[232];
 rsw_consoleLog(rsS14[638] + rsw_tbs[i].shadowTBID + rsS14[640]);
 }
 }

 
 if (rsw_scs[i] == rsw_tbs[i].spellChecker && i < rsw_scs.length) {
 rsw_scs[i] = null;
 rsw_scs.splice(i, 1);
 }

 if (rsw_activeTextbox == rsw_tbs[i])
 rsw_activeTextbox = null;
 if (rsw_inProcessTB == rsw_tbs[i])
 rsw_inProcessTB = null;
 if (rsw_inProcessSC == rsw_tbs[i].spellChecker)
 rsw_inProcessSC = null;

 rsw_tbs[i] = null;
 rsw_tbs.splice(i, 1);
 
 }
 }

}



function rsw_waitStartAYT() {
 rsw_consoleLog(rsS14[641]);
 if (rsw_ayt_initializing || rsw_id_waitingToInitialize!=null)
 setTimeout(function () { rsw_waitStartAYT(); }, 1000);
 else
 rsw_startAYT(0);
}


function rsw_startAYT(startAt) {
 rsw_consoleLog(rsS14[642]+startAt);
 if (startAt >= 0 && rapidSpell.ayt_aytEnabled && rs_AYT != null) {
 rs_AYT.checkerCurrentlyInitializing = startAt;
 rs_AYT.triggeredLast = false;
 rs_AYT.onTextBoxesInit();
 }
}

var rsw_currentlyChecking = 0;
var rsw_checkCompleted;
var rsw_isOverlayed;
var rsw_currentlyCheckingMultiple;
function rsw_spellCheckAll(buttonClick) {
 rsw_currentlyCheckingMultiple = true;
 
 var curState = null;
 if (rsw_scs.length > rsw_currentlyChecking)
 curState = rsw_scs[rsw_currentlyChecking].state;
 if (rsw_currentlyChecking == 0) {
 rsw_isOverlayed = false;
 for (var ch = 0; ch < rsw_scs.length; ch++) {
 if (rsw_scs[ch].state == rsS14[228]) rsw_isOverlayed = true;
 }
 }
 if (rsw_isOverlayed && curState != rsS14[228]) {
 rswm_auto_NotifyDone(true);
 } else {
 if (rsw_scs[rsw_currentlyChecking]!=null) rsw_scs[rsw_currentlyChecking].OnSpellButtonClicked();
 }
}

function rswm_auto_NotifyDone(rsw_spellCheckFinished) {
 if (!rsw_currentlyCheckingMultiple) return;
 rsw_currentlyChecking++;
 rsw_checkCompleted = rsw_spellCheckFinished;

 
 if (rsw_currentlyChecking < rsw_scs.length && rsw_spellCheckFinished) {
 
 rsw_spellCheckAll(false);

 } else {
 rsw_currentlyChecking = 0;
 rsw_currentlyCheckingMultiple = false;
 }

}


function rsw_getTBSFromTB(tb) {
 for (var i = 0; i < rsw_tbs.length; i++) {

 if (rsw_tbs[i].shadowTB.id == tb.id || rsw_tbs[i].shadowTBID == tb.id + rsS14[41]) {

 return rsw_tbs[i];
 }
 }
 return null;
}


function rsw_inline_button_OnStateChanged(state, buttonID, buttonTextSpellChecking, buttonTextSpellMode, buttonText) {
 if (typeof (rsw_inline_button_OnStateChanged_X) == rsS14[33]) return rsw_inline_button_OnStateChanged_X(state, buttonID, buttonTextSpellChecking, buttonTextSpellMode, buttonText);
 try {
 if (buttonID.length == 0) return;
 var button = rs_s3.getElementById(buttonID);
 if (button != null && state == rsS14[222]) { button.value = buttonTextSpellChecking; button.disabled = true; }
 if (button != null && state == rsS14[229]) { button.value = buttonTextSpellMode; button.disabled = false; }
 if (button != null && state == rsS14[220]) { button.value = buttonText; button.disabled = false; }
 } catch (e) { }
}


function rsw__initTB(ptr, tbid) {
 rsw_consoleLog(rsS14[643]);
 rsw_mozly = navigator.userAgent.indexOf(rsS14[14]) > -1;
 rsw_msie = navigator.userAgent.indexOf(rsS14[16]) > -1;
 rsw_chrome = navigator.userAgent.indexOf(rsS14[18]) > -1;
 rsw_applewebkit = navigator.userAgent.indexOf(rsS14[21]) > -1;
 rsw_compatibleBrowser = rsw_msie || rsw_mozly || rsw_chrome || rsw_applewebkit;
 var label = rs_s3.getElementById(tbid);
 if (label.nodeName.toUpperCase() === rsS14[272]) {
 rsw_tbs[ptr] = new LabelTB(label, true);
 rsw_tbs[ptr].initialize();
 } else {
 var tbConfig = rsw_getTBConfig(tbid);
 if (tbConfig != null) {
 var myIFrame = rs_s3.getElementById(tbConfig.values[0]);

 if (rsw_chrome || rsw_applewebkit)
 rsw_tbs[ptr] = new MozlyTB(myIFrame, true);
 else if (rsw_mozly)
 rsw_tbs[ptr] = new MozlyTB(myIFrame, true);
 else
 rsw_tbs[ptr] = new IETB(myIFrame, true);

 rsw_tbs[ptr].enabled = tbConfig.values[1];
 rsw_tbs[ptr].CssSheetURL = tbConfig.values[2];





 try {
 rsw_tbs[ptr].tbConfig = tbConfig;
 rsw_tbs[ptr].initialize();

 } catch (ex) {
 }
 }
 }
}

function rsw_copyFontStyleSheets(doc, targetIframeDoc) {
 var links = doc.getElementsByTagName(rsS14[644]);
 var head = null;
 if (targetIframeDoc.getElementsByTagName(rsS14[280]).length > 0) head = targetIframeDoc.getElementsByTagName(rsS14[280])[0];
 else head = targetIframeDoc.getElementsByTagName(rsS14[437])[0];
 for (var i = 0; i < links.length; i++) {
 if (links[i].getAttribute(rsS14[282]) != null && links[i].getAttribute(rsS14[282]).toLowerCase() == rsS14[283] && 
 links[i].getAttribute(rsS14[281])!=null && 
 links[i].getAttribute(rsS14[281]).indexOf(rsS14[645])>-1) {
 var ss = targetIframeDoc.createElement(rsS14[644]);
 ss.type = rsS14[279];
 ss.rel = rsS14[283];
 ss.href = links[i].getAttribute(rsS14[281]);
 head.appendChild(ss);
 }
 
 }
}

var rsw_AYT_oldEvt = rs_s2.onload;
rs_s2.onload = function () {
 rsw_consoleLog(rsS14[646]);
 if (rapidSpell.ayt_staticMode) {
 rsw_setupTextBoxes();
 return;
 }
 

 if (typeof (Sys) != rsS14[12] && Sys.WebForms && Sys.WebForms.PageRequestManager)
 rsw_prm = Sys.WebForms.PageRequestManager.getInstance();
 if (!rsw_haveadded && rsw_prm != null) {
 rsw_prm.add_endRequest(rsw_endRequest);
 rsw_haveadded = true;

 rsw_prm.add_initializeRequest(rsw_ASPNETAJAX_OnInitializeRequest);
 rsw_prm.add_endRequest(rsw_ASPNETAJAX_OnEndRequest);
 rsw_ASPNETAJAX_OnHandlersAdded = true;
 }


 rsw_setupTextBoxes();
 if (rsw_AYT_oldEvt) rsw_AYT_oldEvt();
 rsw__init();

 
};

var rsw_AYT_oldEvt2 = rs_s3.onclick;
rs_s3.onclick = function (ev) {
 if (rsw_AYT_oldEvt2) rsw_AYT_oldEvt2();
 var gEvent;
 if (rs_s2.event) {
 gEvent = rs_s2.event;
 } else {
 gEvent = ev;
 }
 var gTar;
 if (gEvent.target) {
 gTar = gEvent.target;
 } else {
 gTar = gEvent.srcElement;
 }
 var gTo=null;
 if (gEvent.toElement) {
 gTo = gEvent.toElement;
 }
 var gParent;
 if (gTar != null && gTar.parentNode) {
 gParent = gTar.parentNode;
 } else if (gTar != null) {
 gParent = gTar.parentElement;
 }
 if (gTar != null && gTar.className != rsS14[284] && (gParent == null || gParent.className != rsS14[284]) && (gTo == null || gTo.className != rsS14[284])) {
 rsw_hideCM();
 }
};
var rsw_AYT_oldEvtRESIZE = rs_s2.onresize;
rs_s2.onresize = function () {
 if (rsw_AYT_oldEvtRESIZE) rsw_AYT_oldEvtRESIZE();
 if (rsw_absolutePositionStaticOverlay) rsw__resize();
};






function rsw_AYT_configureSpellChecker(sc, tbid) {


 sc.config = rsw_getConfigurationObject(rs_s3.getElementById(tbid));

 sc.rapidSpellWebPage = rapidSpell.ayt_helperURL;
 sc.buttonID = rsS14[647];
 var v = rsw_getParameterValue(rs_s3.getElementById(tbid), rsS14[483]);
 sc.showNoSpellingErrorsMesg = v!=rsS14[334] && v!=false;
 sc.noSuggestionsText = rsS14[196];
 sc.ignoreAllText = rsS14[197];
 sc.addText = rsS14[199];
 sc.editText = rsS14[200];
 sc.changeAllText = rsS14[198];
 sc.showChangeAllItem = false;
 sc.removeDuplicateText = rsS14[201];
 sc.buttonTextSpellChecking = rsS14[202];
 sc.buttonTextSpellMode = rsS14[203];
 sc.buttonText = rsS14[204];
 sc.noSpellingErrorsText = rsS14[205];
 sc.responseTimeout = rsS14[648];
 sc.responseTimeoutMessage = rsS14[649];

 sc.changeButtonTextWithState = true;
 sc.showAddMenuItem = rapidSpell.ayt_showAddMenuItem;
 sc.showIgnoreAllMenuItem = rapidSpell.ayt_showIgnoreAllMenuItem;
 sc.showEditMenuItem = true;
 sc.doubleClickSwitchesMode = true;
 sc.useXMLHTTP = true;
 sc.ignoreXML = false;
 sc.copyComputedStyleToOverlay = true;
 sc.enterEditModeWhenNoErrors = true;
 sc.overlayCSSClassName = rsS14[11];
 if (typeof (rapidSpell.textInterfaceNeeded) == rsS14[33]) sc.tbInterface = rapidSpell.textInterfaceNeeded(tbid, rsS14[650]);
 else sc.tbInterface = new RSAutomaticInterface(tbid);
 sc.textBoxID = tbid;
 var langArray = rsw_getLanguageArray(rsw_getParameterValue(rs_s3.getElementById(tbid), rsS14[478]));
 if (langArray != null) 
 rsw_setSpellCheckerText(sc, langArray);

 rsw_scs[rsw_scs.length] = sc;
}


function rsw_enableAsYouTypeTextBox(textBox) {
 rsw_consoleLog(rsS14[651]);
 if (textBox.tagName.toUpperCase() == rsS14[272]) {

 } else {

 var multiline = textBox.tagName.toUpperCase() == rsS14[457];
 var createdIF = false;
 var newIF = rs_s3.getElementById(textBox.id + rsS14[35]);
 if (newIF == null) {
 newIF = rs_s3.createElement(rsS14[652]);
 createdIF = true;
 if(rapidSpell.ayt_forceNoScrollBars)newIF.setAttribute(rsS14[440], rsS14[441]); newIF.setAttribute(rsS14[383], textBox.id + rsS14[35]);
 newIF.setAttribute(rsS14[438], rsw_blankLocation);
 newIF.setAttribute(rsS14[45], rsS14[653] + (rsw_useBattleShipStyle ? rsS14[3] : rsS14[654]) + rsS14[655]);
 newIF.setAttribute(rsS14[442], rsw_useBattleShipStyle ? rsS14[656] : rsS14[443]);
 newIF.setAttribute(rsS14[31], textBox.getAttribute(rsS14[31]));
 newIF.style.display = rsS14[48];
 if (createdIF) {
 if (textBox.parentNode)
 textBox.parentNode.insertBefore(newIF, textBox);
 else
 textBox.parentElement.insertBefore(newIF, textBox);
 }
 }
 
 try {
 } catch (e) { }
 var maxlen = textBox.getAttribute(rsS14[657]);
 if (!(maxlen > 0))
 maxlen = 0;

 }
 rsw_addTextBoxSpellChecker(textBox, multiline, maxlen);
}

function rsw_addTextBoxSpellChecker(textBox, multiline, maxlen) {
 var winDefault = rsS14[658];
 var win7Top = rsS14[659];
 var win7 = rsS14[660];
 var win8 = rsS14[661];

 var bTop = bBot = bLef = bRig = winDefault;
 if (rsw_W7) {
 bBot = bLef = bRig = win7;
 bTop = win7Top;
 }
 if (rsw_W8) {
 bTop = bBot = bLef = bRig = win8;
 }

 rsw_addTBConfig({
 keys: [rsS14[662], rsS14[663], rsS14[664], rsS14[379], rsS14[665], rsS14[666], rsS14[667], rsS14[668], rsS14[669], rsS14[670], rsS14[671], rsS14[657], rsS14[672], rsS14[673], rsS14[674], rsS14[675], rsS14[676], rsS14[677], rsS14[678], rsS14[679], rsS14[680], rsS14[681]],
 values: [ (textBox.tagName==rsS14[272]? textBox.id : textBox.id + rsS14[35]), !textBox.disabled, rsw_rs_styleURL, multiline, (multiline ? rsS14[357] : rsS14[359]) + (textBox.disabled ? rsS14[682] : rsS14[3]), rsS14[3], rsS14[3], bTop, bBot, bLef, bRig, maxlen, rsS14[3], (rsw_useBattleShipStyle ? rsS14[3] : rsS14[683]), (rsw_useBattleShipStyle ? rsS14[3] : rsS14[656]), rsS14[3], rsS14[3], rsS14[3], rsS14[3], rsS14[3], false, rsS14[48]]
 });
 textBox.rsw_extension = new RSWITextBox(textBox.id);

 

 rsw_AYT_configureSpellChecker(new SpellChecker(textBox.id), textBox.id);



}



var rs_AYT;
var rsw_oldOnload = rs_s2.onload;
rs_s2.onload = function () {
 rsw_consoleLog(rsS14[684]);
 rsw_attachInitHandler();
 if (rsw_oldOnload) rsw_oldOnload();
 rsw_MenuOnRightClick = true;
 var newDIV = rs_s3.createElement(rsS14[50]);
 newDIV.setAttribute(rsS14[383], rsS14[410]);
 newDIV.setAttribute(rsS14[45], rsS14[685]);
 newDIV.setAttribute(rsS14[435], rsS14[436]);
 newDIV.oncontextmenu = function () { try { event.cancelBubble = true; event.preventDefault(); } catch (e) { } return false; };
 rs_s3.body.appendChild(newDIV);

 var newIF = rs_s3.createElement(rsS14[652]);
 newIF.setAttribute(rsS14[383], rsS14[411]);
 newIF.setAttribute(rsS14[438], rsS14[439]);
 newIF.setAttribute(rsS14[440], rsS14[441]);
 newIF.setAttribute(rsS14[442], rsS14[443]);
 newIF.setAttribute(rsS14[45], rsS14[686]);
 newIF.style.display = rsS14[48];
 rs_s3.body.appendChild(newIF);


};

var rsw_autoCheckTimeout;
function rsw_attachInitHandler() {
 var found = false;
 for (var i = 0; !found && i < rsw_aux_oninit_handlers.length; i++) {
 found = rsw_aux_oninit_handlers[i] == rsS14[687]; 
 }
 if(!found)rsw_aux_oninit_handlers[rsw_aux_oninit_handlers.length] = rsS14[687];
}

function rsw_fireEventInShadow(eventName, textbox, evt) {
 if (!textbox) textbox = rsw_activeTextbox;
 try {
 var event;
 var element = textbox.shadowTB;
 if (rs_s3.createEvent) {
 event = rs_s3.createEvent(rsS14[688]); event.initEvent(eventName, true, true);
 } else {
 event = rs_s3.createEventObject();
 event.eventType = eventName;
 }

 event.eventName = eventName;
 if (evt != null) {
 if (evt.keyCode) event.keyCode = evt.keyCode;
 if (evt.charCode) event.charCode = evt.charCode;
 if (evt.altKey) event.altKey = evt.altKey;
 if (evt.altLeft) event.altLeft = evt.altLeft;
 if (evt.button) event.button = evt.button;
 if (evt.buttonID) event.buttonID = evt.buttonID;
 if (evt.clientX) event.clientX = evt.clientX;
 if (evt.clientY) event.clientY = evt.clientY;
 if (evt.ctrlKey) event.ctrlKey = evt.ctrlKey;
 if (evt.ctrlLeft) event.ctrlLeft = evt.ctrlLeft;
 if (evt.offsetX) event.offsetX = evt.offsetX;
 if (evt.offsetY) event.offsetY = evt.offsetY;
 if (evt.origin) event.origin = evt.origin;
 if (evt.propertyName) event.propertyName = evt.propertyName;
 if (evt.returnValue) event.returnValue = evt.returnValue;
 if (evt.screenX) event.screenX = evt.screenX;
 if (evt.screenY) event.screenY = evt.screenY;
 if (evt.shiftKey) event.shiftKey = evt.shiftKey;
 if (evt.shiftLeft) event.shiftLeft = evt.shiftLeft;
 if (evt.source) event.source = evt.source;
 if (evt.srcElement) event.srcElement = evt.srcElement;
 if (evt.srcFilter) event.srcFilter = evt.srcFilter;
 if (evt.srcUrn) event.srcUrn = evt.srcUrn;
 if (evt.toElement) event.toElement = evt.toElement;
 if (evt.type) event.type = evt.type;
 if (evt.url) event.url = evt.url;
 if (evt.wheelDelta) event.wheelDelta = evt.wheelDelta;
 if (evt.x) event.x = evt.x;
 if (evt.y) event.y = evt.y;
 if (evt.actionURL) event.actionURL = evt.actionURL;
 if (evt.behaviorCookie) event.behaviorCookie = evt.behaviorCookie;
 if (evt.returnValue) event.returnValue = evt.returnValue;
 if (evt.cancelBubble) event.cancelBubble = evt.cancelBubble;
 if (evt.preventDefault) event.preventDefault = evt.preventDefault;
 if (evt.which) event.which = evt.which;
 if (evt.timeStamp) event.timeStamp = evt.timeStamp;

 }
 if (rs_s3.createEvent) {
 element.dispatchEvent(event);
 } else {
 element.fireEvent(rsS14[370] + event.eventType, event);
 }

 if (typeof (event.returnValue)!=rsS14[12]) evt.returnValue = event.returnValue;
 if (typeof (event.cancelBubble) != rsS14[12]) evt.cancelBubble = event.cancelBubble;
 if (typeof (event.defaultPrevented) != rsS14[12]) evt.defaultPrevented = event.defaultPrevented;

 } catch (e) { }}



function _INT_notifyTextBoxListeners(eventName, evt, tb) { if (rapidSpell.ayt_staticMode) return;
 rsw_fireEventInShadow(eventName, tb, evt);
 
 if (eventName == rsS14[324]) {
 clearTimeout(rsw_autoCheckTimeout);
 rsw_autoCheckTimeout = null;
 if (rsw_autoCheckTimeout == null && rapidSpell.ayt_aytEnabled) rsw_autoCheckTimeout = setTimeout(rsS14[689], rapidSpell.ayt_recheckDelay);
 } else if (eventName == rsS14[296]) {
 clearTimeout(rsw_autoCheckTimeout);
 rsw_autoCheckTimeout = null;
 } else if (eventName == rsS14[217] && rapidSpell.ayt_aytEnabled && rs_AYT != null && typeof(rs_AYT.onFinish)==rsS14[33]) rs_AYT.onFinish();
}


function rsw_onRSTextBoxesInit() {
 rsw_consoleLog(rsS14[690]);
 rs_AYT = new RapidSpell_Web_AsYouType();
 rs_AYT.checkAsYouTypeOnPageLoad = true;


 setTimeout(rsS14[691], 50);
}

function rsw_delayInit() {
 rsw_consoleLog(rsS14[692]);
 for (var i = 0; i < rsw_tbs.length; i++) {
 if(rsw_tbs[i].shadowTBID.indexOf(rsS14[41])==-1)
 rsw_switchTB(rsw_tbs[i].shadowTBID);
 }
 if(rapidSpell.ayt_aytEnabled)
 setTimeout(rsS14[693], 100);
 if (typeof (rsw_onRSTextBoxesReady) == rsS14[33])
 rsw_onRSTextBoxesReady();

 if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[276], null);
}

function rsw_switchTB(id) {
 var ifr = rs_s3.getElementById(id + rsS14[35]);
 var shtb = rs_s3.getElementById(id);
 if (shtb.tagName==rsS14[272] && rapidSpell.ayt_checkLabels) return rsw_getTBSFromID(id, false);
 rsw_updatePosition(ifr, shtb);

 rsw_resetTBSSize(ifr, id, true);
 var tb = rsw_getTBSFromID(id, false);

 try {
 if (shtb.tagName == rsS14[457])
 ifr.contentWindow.document.body.style.overflowY = rsS14[63];
 } catch (e) { } 



 ifr.style.backgroundColor = rsS14[694];
 rsw_ignorePropertyChange = true;
 if (typeof (tb.shadowOriginalDisplay) == rsS14[12]) {
 tb.shadowOriginalDisplay = rsw_getStyleProperty(shtb, rsS14[85]); tb.shadowTBDisplay = tb.shadowOriginalDisplay;

 rsw_consoleLog(rsS14[695] + tb.shadowTBID + rsS14[696] + tb.shadowOriginalDisplay);
 }
 rsw_ignorePropertyChange = false;

 rsw_auto_copyStyle(ifr.id, shtb.id);
 

 if (!rsw_supportAutoSize) {
 setTimeout('rsw_auto_copyStyle("' + ifr.id + '", "' + shtb.id + '")', 200); shtb.style.display = rsS14[48];
 
 } else {

 tb.shadowTBPosition = shtb.style.position;
 tb.shadowTBLeft = shtb.style.left;
 rsw_ignorePropertyChange = true;
 shtb.style.position = rsS14[52]; 
 shtb.style.left = rsw_leftHide;
 rsw_ignorePropertyChange = false;
 tb.shadowTBTabIndex = shtb.getAttribute(rsS14[31]);
 shtb.setAttribute(rsS14[31], -1); shtb.setAttribute(rsS14[32], tb.shadowTBTabIndex);
 }



 if (ifr.style.left == rsS14[150] && ifr.style.top == rsS14[150])
 ifr.style.display = rsS14[48];
 else
 ifr.style.display = rsS14[231];

 
 if (rapidSpell.ayt_copyStyleSheets && !(typeof (tb.ifDoc) == rsS14[12] || tb.ifDoc == null)) rsw_copyFontStyleSheets(document, tb.ifDoc);


 if(rsw_areTextBoxesAllReady())if (typeof (rsw_broadcastEvent) == rsS14[33]) rsw_broadcastEvent(rsS14[276], null);


 return tb;
}

function rsw_areTextBoxesAllReady(){
 for(var i=0; i<rsw_tbs.length;i++){
 if(rsw_tbs[i]!=null && rsw_tbs[i].ifDoc==null) return false;
 }
 return true;
}





function _notifySpellCheckListeners(eventName) {
 if (eventName == rsS14[451]) {
 var sx = 0;
 var sy = 0;
 if (rs_s3.getElementById(rsS14[697]) != null) {
 sx = rs_s3.getElementById(rsS14[697]).value;
 sy = rs_s3.getElementById(rsS14[698]).value;
 rs_s2.scrollTo(sx, sy);
 }

 }
}





function rsw_addTbFinish(attempts, tbid) {
 rsw_consoleLog(rsS14[699]);
 if (rsw_haltProcesses) return;
 if (!attempts) attempts = 0;
 if (rsw_id_waitingToInitialize != null && attempts < 100) {
 attempts++;
 eval(rsS14[700] + attempts + rsS14[701] + tbid + rsS14[702]);
 return;
 }
 var tb = rsw_switchTB(tbid);


 
 if (rs_s3.getElementById(tbid).tagName == rsS14[457]) {
 tb.iframe.contentWindow.document.body.style.overflow = rsS14[703];
 tb.iframe.contentWindow.document.body.style.overflowY = rsS14[703];
 tb.iframe.contentWindow.document.body.style.overflowX = rsS14[30];


 }




 tb.isDirty = true;

 }

function rsw_removeTB(id){
 
 for (var i = rsw_tbs.length - 1; i >= 0; i--) {


 if (rsw_tbs[i].shadowTBID == id) {
 rsw_tbs[i].shadowTB.style.display = (rsw_tbs[i].shadowOriginalDisplay != null && rsw_tbs[i].shadowOriginalDisplay.length > 0) ? rsw_tbs[i].shadowOriginalDisplay : rsS14[227];
 rsw_tbs[i].iframe.style.display = rsS14[48];
 rsw_tbs.splice(i, 1);
 break;
 }
 }
}

var rsw_require_init = true;
function rsw_addTb(tb) {
 rsw_enableAsYouTypeTextBox(tb);

 rsw__initTB(rsw_tbs.length, tb.id);
 if (rsw_activeTextbox == null)
 rsw_activeTextbox = rsw_tbs[0];
 rsw_addTbFinish(0, tb.id);
 
}



if (typeof (Sys) != rsS14[12] && typeof (Sys.Application) != rsS14[12]) Sys.Application.notifyScriptLoaded();

































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































/* ]]> */
rapidSpell.ayt_helperURL ='a.rapidspellweb?t=a';
