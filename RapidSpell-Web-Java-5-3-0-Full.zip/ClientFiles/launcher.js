/*--Keyoti js--*/
/*#<![CDATA[*/
/*#Version 1.7f (RapidSpell Web assembly version 5.0 onwards)
Copyright Keyoti Inc. 2005-2021
This code is not to be modified, copied or used without a license in any form.
*/

var rsS22=new Array("Microsoft Internet Explorer",
"MSIE ([0-9]{1,}[\.0-9]{0,})",
"object",
"function",
"rsTCInt",
"undefined",
"IgnoreXML",
"True",
"popUpCheckSpelling",
"('rsTCInt",
"')",
"g",
"&#34;",
"&",
"&amp;",
"Error: element ",
" does not exist, check TextComponentName.",
"",
"Sorry, a textbox with ID=",
" couldn't be found - please check the TextComponentID or TextComponentName property.",
"_IF",
"&lt;",
"&gt;",
"TEXTAREA",
"INPUT",
" EDITABLE",
"\r\n",
" ",
"contentEditable",
"true",
"designMode",
"on",
"IFRAME",
" --has contentWindow.document",
"*");																																				var rs_s2=window;var rs_s3=document;


if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}

var rsw_launcher_script_loaded = true;
var rsw_suppressWarnings=false;
function rsw_getInternetExplorerVersion()
{
 var rv = -1; if (navigator.appName == rsS22[0]) {
 var ua = navigator.userAgent;
 var re = new RegExp(rsS22[1]);
 if (re.exec(ua) != null)
 rv = parseFloat(RegExp.$1);
 }
 return rv;
}


function rsw_dialogOptionsClosed() {
 
 if (typeof rswm_PopUpWin == rsS22[2] && rswm_PopUpWin != null && typeof rswm_PopUpWin.rsw_finish == rsS22[3]) rswm_PopUpWin.rsw_finish();
 else if (typeof rsw_launcherWin == rsS22[2] && typeof rsw_launcherWin.rsw_finish == rsS22[3]) rsw_launcherWin.close(); if (typeof rswm_RunSpellCheck == rsS22[3]) rswm_RunSpellCheck(true);
 else if (rsw_currentLauncher != null) {

 setTimeout(function () { rsw_currentLauncher.OnSpellButtonClicked(); }, 500);
 }
}

var rsw_currentLauncher = null;
function SpellCheckLauncher(clientID){
 this.clientID = clientID;
 this.OnSpellButtonClicked = OnSpellButtonClicked;
 this.config;
 this.hasRunFieldID;
 this.getParameterValue = getParameterValue;
 this.setParameterValue = setParameterValue;
 this.tbInterface = null;
 
 function getParameterValue(param){
 for(var pp=0; pp<this.config.keys.length; pp++){
 if(this.config.keys[pp]==param)
 return this.config.values[pp];
 }
 }
 
 function setParameterValue(param, value){
 for(var pp=0; pp<this.config.keys.length; pp++){
 if(this.config.keys[pp]==param)
 this.config.values[pp] = value;
 }
 } 
 
 function OnSpellButtonClicked(){
 rsw_currentLauncher = this;
 this.tbInterface = eval(rsS22[4]+this.clientID);
 
 if(this.tbInterface!=null && typeof(this.tbInterface.findContainer)!=rsS22[5]){
 this.textBoxID = this.tbInterface.findContainer().id;
 if (!this.tbInterface.targetIsPlain){
 this.setParameterValue(rsS22[6], rsS22[7]);
 }
 } 
 
 
 eval(rsS22[8]+this.clientID+rsS22[9]+this.clientID+rsS22[10]);
 }
}


function RS_writeDoc(toWindow, isSafari){ 
 toWindow.document.open(); 
 toWindow.document.write(spellBoot); 
 toWindow.document.close(); 
 if(isSafari)
 toWindow.document.forms[0].submit();
} 
 
 
function escQuotes(text){ 
 var rx = new RegExp("\"", rsS22[11]); 
 return text.replace(rx,rsS22[12]);
}
function escEntities(text){
 var rx = new RegExp(rsS22[13], rsS22[11]); 
 return text.replace(rx,rsS22[14]);
}

function RSStandardInterface(tbElementName){
 this.tbName = tbElementName;
 this.getText = getText;
 this.setText = setText;
 function getText(){
 if(!document.getElementById(this.tbName) && !rsw_suppressWarnings) {
 alert(rsS22[15]+this.tbName+rsS22[16]);
 return rsS22[17];
 }
 else return rs_s3.getElementById(this.tbName).value;
 }
 function setText(text) {
 if(rs_s3.getElementById(this.tbName)) rs_s3.getElementById(this.tbName).value = text;
 if(typeof(rsw_tbs)!=rsS22[5]){
 for(var i=0; i<rsw_tbs.length; i++){
 if(rsw_tbs[i].shadowTB.id==this.tbName){
 if(rsw_tbs[i].updateIframe){rsw_tbs[i].updateIframe();rsw_tbs[i].focus();}
 }
 }
 }
 }
}




function RSAutomaticInterface(tbElementName){

 this.tbName = tbElementName;this.getText = getText;this.setText = setText;
 this.identifyTarget = identifyTarget;
 this.target=null;
 this.targetContainer = null;
 this.searchedForTarget = false;
 this.targetIsPlain = true;
 this.showNoFindError = showNoFindError;
 this.finder = null;
 
 this.findContainer = findContainer;
 
 function findContainer(){
 this.identifyTarget();
 return this.targetContainer;
 }
 
 function showNoFindError(){
 alert(rsS22[18]+this.tbName+rsS22[19]);
 }
 
 function identifyTarget(){
 if(!this.searchedForTarget){
 this.searchedForTarget = true;
 
 if(this.finder == null)
 this.finder = new RSW_EditableElementFinder();
 
 var plain = this.finder.findPlainTargetElement(this.tbName);
 var richs = this.finder.findRichTargetElements();
 
 if(plain==null && (richs==null || richs.length==0) && !rsw_suppressWarnings) showNoFindError();
 else{ 
 
 if(richs==null || richs.length==0){ this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 } else {
 
 
 if(plain==null && richs.length==1){ this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[0][0]);
 this.targetContainer = richs[0][1]; 
 
 } else {
 for (var rp = 0; rp < richs.length; rp ++){
 if(typeof(richs[rp][1].id)!=rsS22[5] && richs[rp][1].id.indexOf(this.tbName)>-1){
 if(plain!=null && richs[rp][1].id == plain.id+rsS22[20]){
 this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 break;
 } else {
 this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[rp][0]);
 this.targetContainer = richs[rp][1];
 break;
 }
 }
 }
 
 if(this.target==null){ this.target = plain;
 this.targetIsPlain = true;
 this.targetContainer = plain;
 }
 }
 }
 }
 } 
 }
 function getText(){ 
 this.identifyTarget();

 
 if( this.targetIsPlain )
 return this.target.value;
 else
 return this.target.innerHTML;
 }
 function setText(text){ 
 this.identifyTarget();
 if (this.targetIsPlain) {
 var ver = rsw_getInternetExplorerVersion();
 if (ver > 0 && ver < 9) text = text.replace(/</g, rsS22[21]).replace(/>/g, rsS22[22]);
 this.target.value = text;
 }
 else
 this.target.innerHTML = text;
 
 if(typeof(rsw_tbs)!=rsS22[5]){
 for(var i=0; i<rsw_tbs.length; i++){
 
 if(rsw_tbs[i].shadowTB.id==this.tbName){
 if(rsw_tbs[i].updateIframe){rsw_tbs[i].updateIframe();rsw_tbs[i].focus();}
 }
 }
 } 
 }
 }

function RSW_EditableElementFinder(){
 this.findPlainTargetElement = findPlainTargetElement;
 this.findRichTargetElements = findRichTargetElements;
 this.obtainElementWithInnerHTML = obtainElementWithInnerHTML;
 this.findEditableElements = findEditableElements;
 this.elementIsEditable = elementIsEditable;
 this.getEditableContentDocument = getEditableContentDocument;
 
 function findPlainTargetElement(elementID){
 var rsw_elected = rs_s3.getElementById(elementID);
 
 if(rsw_elected!=null && rsw_elected.tagName && 
 (rsw_elected.tagName.toUpperCase()==rsS22[23] || rsw_elected.tagName.toUpperCase()==rsS22[24])){
 return rsw_elected;
 } else
 return null;
 }
 
 function findRichTargetElements(debugTextBox){
 var editables = new Array();
 this.findEditableElements(document, editables, window,rsS22[17], debugTextBox);
 return editables;
 }
 
 function obtainElementWithInnerHTML(editable){
 if(typeof(editable.innerHTML)!=rsS22[5]) return editable;
 else
 if(typeof(editable.documentElement)!=rsS22[5])
 return editable.documentElement;
 
 return null;
 }
 
 
 function findEditableElements(node, editables, parent, debugInset, debugTextBox){
 var children = node.childNodes;
 var editableElement;
 
 if(debugTextBox)
 debugTextBox.value += debugInset + node.tagName;
 
 if( (editableElement=this.elementIsEditable(node))!=null || 
 (editableElement=this.getEditableContentDocument(node, debugTextBox))!=null
 ){
 if(debugTextBox)
 debugTextBox.value += rsS22[25]; 
 editables[editables.length] = editableElement;
 }
 
 if(debugTextBox)
 debugTextBox.value += rsS22[26];
 
 for (var i = 0; i < children.length; i++) {
 this.findEditableElements(children[i], editables, node, debugInset+rsS22[27], debugTextBox);
 } 
 
 }
 
 function elementIsEditable(element){
 if (
 (
 typeof(element.getAttribute)!=rsS22[5] &&
 (
 element.getAttribute(rsS22[28])==rsS22[29] ||
 element.getAttribute(rsS22[30])==rsS22[31]
 )
 )
 || 
 (
 (element.contentEditable && element.contentEditable==true) ||
 (element.designMode && element.designMode.toLowerCase()==rsS22[31])
 ) 
 
 
 )
 return [element, element]; else return null;
 }
 
 function getEditableContentDocument(element, debugTextBox){
 if(element.tagName && element.tagName==rsS22[32]){
 var kids = new Array();
 if(element.contentWindow && element.contentWindow.document){

 if(debugTextBox)
 debugTextBox.value += rsS22[33]; 
 
 this.findEditableElements(element.contentWindow.document, kids, element, rsS22[34], debugTextBox);
 

 if(kids.length>0){ var editable = kids[0][0];
 if(typeof(editable.body)!=rsS22[5])
 editable = editable.body;
 return [editable, element]; }
 }
 }
 return null;
 } 
 }





if( typeof(Sys)!=rsS22[5] && typeof(Sys.Application)!=rsS22[5]) Sys.Application.notifyScriptLoaded();




















































/* ]]> */
