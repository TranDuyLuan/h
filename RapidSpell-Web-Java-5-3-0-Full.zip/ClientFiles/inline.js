/*--Keyoti js--*/
/*#<![CDATA[*/
/*#(RapidSpell Web assembly version 4.0.0 onwards)
Copyright Keyoti Inc. 2005-2020
This code is not to be modified, copied or used without a license in any form.
*/

var rsS57=new Array("RapidSpell script v6.2.0a",
"RapidSpell:",
"-10000px",
"",
"rswinline",
"INACTIVE",
"RS_ContextMenuTable",
"RS_CMItemSeparator",
"RS_ContextMenuItem",
"RS_ContextMenuItem_AllSubItem",
"RS_ContextMenuItem_Disabled",
"oldBrowserBox",
"undefined",
"Mac",
"Gecko",
"Firefox",
"MSIE",
"Trident",
"Chrome",
"Safari",
"Edge/",
"AppleWebKit",
"NT 6.1",
"NT 6.2",
"\r",
"\n",
"MSIE 9.",
"MSIE 10.",
"CSS1Compat",
"type",
"hidden",
"tabindex",
"tabindexIF",
"function",
" | ",
"_IF",
"Microsoft Internet Explorer",
"MSIE ([0-9]{1,}[\.0-9]{0,})",
":",
" ",
"oldValue",
"_SHD",
"DIV",
"_D",
"class",
"style",
"display:none;width:1px; height:1px;",
"display:none;width:1px; height:1px;position:absolute;",
"none",
"pwHtmlBox",
"div",
"__RSFIX",
"absolute",
"IFRAME",
"textarea",
"border-box",
"string",
"%",
"px",
"BackCompat",
"Setting style.width in iframe ",
"px from ",
"Not Setting style.width in iframe ",
"scroll",
"bottom",
"marginTop",
"marginLeft",
"paddingLeft",
"paddingRight",
"borderLeftWidth",
"borderRightWidth",
"paddingTop",
"paddingBottom",
"borderTopWidth",
"borderBottomWidth",
"Couldn't copy style because source is null (",
") or target is null(",
")",
"BODY",
"webkit",
"zIndex",
"position",
"left",
"right",
"top",
"display",
"ms",
"resize",
"width",
"height",
"scrollbar",
"border",
"css",
"get",
"set",
"Moz",
"whiteSpace",
"word",
"text",
"remove",
"item",
"color",
"margin",
"clip",
"visibility",
"padding",
"line",
"lineHeight",
"table",
"max",
"min",
"blockSize",
"background",
"overflow",
"visible",
"backgroundColor",
"transparent",
"fontStyle",
"Cannot copy style from source textbox with id ",
" because getElementById returns null",
"Cannot copy style from target textbox with id ",
" because getElementById returns null, will try again",
"float",
"marginRight",
"marginBottom",
"borderBottom",
"borderTop",
"borderLeft",
"borderRight",
"borderBottomColor",
"borderTopColor",
"borderLeftColor",
"borderRightColor",
"borderBottomStyle",
"borderTopStyle",
"borderLeftStyle",
"borderRightStyle",
"borderRadius",
"borderLeftRadius",
"borderTopRadius",
"borderRightRadius",
"borderBottomRadius",
"borderTopLeftRadius",
"borderTopRightRadius",
"borderBottomLeftRadius",
"borderBottomRightRadius",
"-moz-border-radius",
"-webkit-border-radius",
"-khtml-border-radius",
"2px inset rgb(0, 0, 0)",
"0px",
"1px solid rgb(169, 169, 169)",
"overflowX",
"overflowY",
"text/xml",
"Msxml2.XMLHTTP",
"Microsoft.XMLHTTP",
"debug",
"\r\nMicrosoft.XMLHTTP not available",
"\r\n",
"Sending request to ",
"POST",
"Content-Type",
"text/xml; charset=UTF-8",
"application/xml",
"a",
".",
"b",
"<",
">",
"</",
"<input type=hidden name=",
" value='",
"'>",
"default",
"'",
"','",
"object",
"\r\nerror in rsw_spellCheckText ",
"Check",
"<form accept-charset='UTF-8' action='",
"' method='post'>",
"<input type='hidden' name='textToCheck' value=''><input type='hidden' name='IAW' value=''>",
"</form>",
"|",
"<r><resp>xml</resp><textToCheck>",
"</textToCheck><IAW>",
"</IAW>",
"</r>",
"?fiddlerParam=",
"[",
"]",
"Sorry, a textbox with ID=",
" couldn't be found - please check the TextComponentID or TextComponentName property.",
"&lt;",
"&gt;",
"No suggestions",
"Ignore All",
"All",
"Add",
"Edit...",
"Remove duplicate word",
"Checking...",
"Resume Editing",
"Check Spelling",
"No Spelling Errors In Text.",
"Sorry the server has failed to respond to the spell check request. Please check the URL set in the RapidSpellWebInlinePage property in the RapidSpellWebInline ctrl.",
"Textbox with ID=",
" could not be found, please check the TextComponentID property in the RapidSpell control.",
"regTB",
"rich",
"true",
"IgnoreXML",
"True",
"ACTIVE",
"starting check",
"queued ",
"spellcheckfinish",
"(true,-1)",
"ayt_spellcheckfinish",
"EDITING",
"()",
"TRANSITION-CHECKING",
"before:",
"\r\nafter:",
" **abort",
"setting caret",
"block",
"overlay",
"CHECKING",
"firefox",
"inline",
"inline-block",
"server responded ",
" errors",
"&nbsp;",
" **abort rsw_key_downed_flag. rsw_key_down_timeout=",
" flag=",
" lim=",
"caret at:",
",",
"reset caret2",
"(true,numberOfErrors)",
"Popping queued spell check tb. length ",
"id='resultContent'>",
"id='numberOfErrors'>",
"</div>",
"\r\nCallback, readyState:",
" status:",
"\r\nresponse text:",
"The page holding the RapidSpellWInlineHelper control couldn't be found, please check the URL in the RapidSpellWInlineHelperPage property, it should be set to the URL of the page holding the RapidSpellWInlineHelper control.",
"The page holding the RapidSpellWInlineHelper control returned a 500 server error - which means the page has an error, please visit the URL specified in the RapidSpellWInlineHelperPage to debug this page. ",
"(HINT: Most likely, you need to add validateRequest='false' to the Page directive if you are spell checking HTML content.)",
"There was a problem with the request, please check the URL set in the RapidSpellWInlineHelperPage property. Http Error Code: ",
"RapidSpell AJAX call was cancelled. Status code 0",
"There was a problem with the request. Http Error Code: ",
"BR",
"P",
"<fo",
"rm accept-charset='UTF-8' action='",
"<input type='hidden' name='action' value='add'>",
"UserDictionaryFile",
"<r><action>add</action><w>",
"</w><UserDictionaryFile>",
"</UserDictionaryFile></r>",
"The page holding the RapidSpellWInlineHelper control couldn't be found, please check the URL in the RapidSpellWInlineHelperPage property, it should be set to the URL of the page holding RapidSpellWInlineHelperPage.",
"The page holding the RapidSpellWInlineHelper control returned a 500 server error - which means the page has an error, please visit the URL specified in the RapidSpellWInlineHelperPage to debug this page. (HINT: Most likely, you need to add validateRequest='false' to the Page directive if you are spell checking HTML content.)",
"No server response (null).",
"id='errorContent'>",
"if (rsw_activeTextbox.recordCaretPos) rsw_activeTextbox.recordCaretPos();",
"ayt_contextmenushowing",
"ayt_contextmenushown",
"LABEL",
"setTimeout( function() { rsw_onFinish(",
", ",
");}, 100 ); ",
"ayt_textboxesinitialized",
"boolean",
"LINK",
"text/css",
"head",
"href",
"rel",
"stylesheet",
"rs_err_hl",
"className",
"onmouseup",
"correction",
"#edit",
"br",
"li",
"HTML",
"input",
"p",
"&",
"&amp;",
"keydown",
"rsw_activeTextbox.rsw_key_downed_within_lim=false;",
" DOWN ",
"placeholder",
"<span class='placeholder -moz-placeholder -ms-input-placeholder -webkit-input-placeholder'>",
"</span>",
"textedit",
"character",
"A",
"Subscript",
"span",
"suggestions",
"inside",
"\r\nRECORD A ",
"StartToEnd",
"\r\nRECORD B ",
"EndToEnd",
"sentence",
"\r\nRECORD CARET",
"\r\nSET CARET,",
" has\\r=",
"\r\nnew text=>",
"<== \r\n\r\nOLD=>",
"<==\r\n",
"MSIE 7",
"ayt_correction",
"keypress",
"unlink",
"keyup",
"mousedown",
"mouseup",
"dblclick",
"click",
" rsw_focused",
"focus",
"MSIE 6",
"contentEditable",
"change",
"false",
"blur",
"\r\nblur",
"\r\nSET CONTENT",
" & fromshadow=",
"<br />",
"<nobr>",
"</nobr>",
"MSIE 8",
"contextmenu",
"rsw_activeTextbox.pasting=true;rsw_activeTextbox.updateShadow();if(rsw_activeTextbox.maxlength>0){",
"rsw_setShadowTB(rsw_activeTextbox.shadowTB, rsw_activeTextbox.shadowTB.value.substring(0,rsw_activeTextbox.maxlength));}rsw_activeTextbox.recordCaretPos();rsw_activeTextbox.updateIframe();rsw_activeTextbox.resetCaretPos();rsw_activeTextbox.pasting=false;",
"paste",
"setTimeout( function() {try{ rsw_getTBSFromID('",
"').initialize(",
");}catch(exc){}}, ",
" ); ",
"spellcheck",
"display:inline-block; padding:0; line-height:1; position:absolute; visibility:hidden; font-size:1em",
"M",
"margin:0;",
"AutoUrlDetect",
"RS_MultiLineTB_Disabled",
"RS_MultiLineTB",
"RS_SingleLineTB_Disabled",
"RS_SingleLineTB",
"g",
"firefox/1.0",
"\r\nInnerHTML: ",
"nobr",
"UIEvents",
"<p>$1</p>",
"<p><BR></p>",
"<p style='margin:0px;'>$1</p>",
"/",
"off",
"on",
"setTimeout( function() { rsw_getTBSFromID('",
");}, 50 ); ",
");}catch(exc){}},50 ); ",
"fontSize",
"setTimeout( function() {try{ document.getElementById('",
"').contentDocument.body.contentEditable = true;} catch (exc){} }, 400 ); ",
"').contentDocument.designMode = 'On';} catch (exc){} }, 400 ); ",
"if(rsw_activeTextbox!=null&&rsw_activeTextbox.maxlength>0&&rsw_activeTextbox.shadowTB.value.length>rsw_activeTextbox.maxlength){rsw_activeTextbox.updateShadow();rsw_setShadowTB(rsw_activeTextbox.shadowTB, rsw_activeTextbox.shadowTB.value.substring(0,rsw_activeTextbox.maxlength));rsw_activeTextbox.updateIframe();}",
"multiline",
"yes",
"iframe.style.height",
"px'",
"id",
"nospell",
"td",
"value",
"inlineTB",
"<P style='margin:0px;'>",
"</P>",
"<br>",
"\t",
"<span class='tab'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>",
"#text",
"=",
"SCRIPT",
"Opera 5",
"Opera/5",
"^apos^",
"^qt^",
"#",
"changeall",
"subitem",
"remove duplicate",
"no_suggestions",
"-",
"edit",
"ignore_all",
"ShowAddItemAlways",
"add",
"RS_CM_DIV",
"RS_CM_IF",
"out",
"_Over",
"msie",
"<tr><td width='100%' ",
"colspan='1'",
"colspan='2'",
"</td>",
"<td>",
"</tr>",
"</table>",
"standard",
"', '",
"ayt_ignoringAll",
"ayt_ignoredAll",
"ayt_editingAll",
"ayt_adding",
"ayt_added",
"ayt_removingDuplicate",
"ayt_removedDuplicate",
"ayt_changingAll",
"ayt_changedAll",
"ayt_changing",
"ayt_changed",
"oncontextmenu",
"try{event.cancelBubble=true;event.preventDefault();}catch(e){}return false;",
"body",
"src",
"javascript: false;",
"scrolling",
"no",
"frameborder",
"0",
"position:absolute; top:0px; left:0px; display:none;",
"onTextBoxesInit(), rsw_ayt_initializing==",
"checkNext(), rsw_haltProcesses==",
" rsw_ayt_enabled==",
" this.stopped==",
"onFinish(), this.triggeredLast==",
"onFinish(), set rsw_ayt_initializing false",
"ayt_finished_initializing",
";",
"&amp",
"&nbsp",
"&lt",
"&gt",
"TEXTAREA",
"INPUT",
"designMode",
"*",
"rsw_ASPNETAJAX_OnInitializeRequest",
"rsw_ASPNETAJAX_OnEndRequest",
"rsw__init(true)");																																				var rs_s2=window;var rs_s3=document;




if (!window.console) {
 rs_s2.console = {};
 rs_s2.console.log = function () { };
}
if (!window.rsw_consoleLog) rs_s2.rsw_consoleLog = function () { };
console.log(rsS57[0]);


var rsw_logToConsole = false;
function rsw_consoleLog(m, force) {
 if(rsw_logToConsole || force)
 console.log(rsS57[1]+m);
}


var rsw_boxSizingEnabled = true;
var rsw_leftHide = rsS57[2];
var rsw_supportAutoSize = false;
var rsw_absolutePositionStaticOverlay = false;
var rsw_copyFontColor = true;
var rsw_updatingShadow = false;
var rsw_spellCheckRunning = false;
var rsw_useBattleShipStyle = false;
var rsw_key_down_timeout = 150;
var rsw_inline_script_loaded = true;
var rsw_rs_styleURL = rsS57[3]; var rsw_rs_menu_styleURL = rsS57[3];
var rsw_config = new Array();
var rsw_tbs = new Array();
var rsw_scs = new Array();
var rsw_isASPX = true;
var rsw_copyLineHeight = true;
var rsw_activeTextbox;
var rsw_previouslyActiveTextbox;
var rsw_ASPNETAJAX_OnHandlersAdded = false;
var rsw_ayt_check = false;
var rsw_ayt_enabled = true;
var rsw_key_down_timer = null;
var rsw_contextMenu = null;
var rsw_lastRightClickedError;
var rsw_comIF = rs_s2.frames[rsS57[4]];
var rsw_inProcessTB;
var rsw_inProcessSC;
var rsw_spellBoot = rsS57[3];
var rsw_channel_state = rsS57[5]; var rsw_channel_timeout;
var RS_ContextMenuTable_Class = rsS57[6];
var RS_CMItemSeparator_Class = rsS57[7];
var RS_ContextMenuItem_Class = rsS57[8];
var RS_ContextMenuItem_AllSubItem_Class = rsS57[9];
var RS_ContextMenuItem_Disabled_Class = rsS57[10];
var rsw_debug = false;
var rsw_inProcessTBResetCaret = true;
var rsw_correctCaret = true;
var rsw_reconcileChanges = true;
var rsw_id_waitingToInitialize = null;
var rsw_overlayCSSClassName = rsS57[11];
var rsw_yScroll = null;
var rsw_isMac = typeof (navigator.userAgent) != rsS57[12] && navigator.userAgent.indexOf(rsS57[13]) > -1;
var rsw_spellCheckOnBlur = true;
var rsw_mozly = navigator.userAgent.indexOf(rsS57[14]) > -1;
var rsw_firefox = navigator.userAgent.indexOf(rsS57[15]) > -1;
var rsw_msie = navigator.userAgent.indexOf(rsS57[16]) > -1;
var rsw_msie11 = navigator.userAgent.indexOf(rsS57[16]) == -1 && navigator.userAgent.indexOf(rsS57[17])>-1;
var rsw_chrome = navigator.userAgent.indexOf(rsS57[18]) > -1;
var rsw_safari = navigator.userAgent.indexOf(rsS57[19]) > -1;
var rsw_msedge = navigator.userAgent.indexOf(rsS57[20]) > -1;
var rsw_applewebkit = navigator.userAgent.indexOf(rsS57[21]) > -1;
var rsw_compatibleBrowser = rsw_msie || rsw_mozly || rsw_chrome || rsw_applewebkit;
var rsw_W7 = navigator.userAgent.indexOf(rsS57[22]) > -1;
var rsw_W8 = navigator.userAgent.indexOf(rsS57[23]) > -1;
var rsw_MenuOnRightClick = true;

var rsw_newlineexp = new RegExp(rsw_msie?rsS57[24]:rsS57[25]);
var rsw_ffMaxLengthChecker;
var rsw_haltProcesses = false;
var rsw_cancelCall = false;
var rsw_suppressWarnings = rsw_suppressWarnings ? rsw_suppressWarnings : false;

var rsw_aux_oninit_handlers = new Array(); var rsw_ObjsToInit = new Array(); var RSWITextBox_DownLevels = new Array(); var rsw_showHorizScrollBarsInFF = false;
var rsw_autoFocusAfterAJAX = true;
var rsw_recalculateOverlayPosition = true;
var rsw_adjustOffsetSizeForStrict = true;
var rsw_ie9Standards = false;
var rsw_ie9;
try {
 rsw_ie9 = navigator.appVersion.indexOf(rsS57[26]) > -1 || navigator.appVersion.indexOf(rsS57[27]) > -1;
 rsw_ie9Standards = rsw_ie9 && rs_s3.compatMode == rsS57[28];
} catch (e) {
 rsw_logException(e);
}



function rsw_IeVersion() {
 var value = {
 IsIE: false,
 TrueVersion: 0,
 ActingVersion: 0,
 CompatibilityMode: false
 };

 var trident = navigator.userAgent.match(/Trident\/(\d+)/);
 if (trident) {
 value.IsIE = true;
 value.TrueVersion = parseInt(trident[1], 10) + 4;
 }

 var msie = navigator.userAgent.match(/MSIE (\d+)/);
 if (msie) {
 value.IsIE = true;
 value.ActingVersion = parseInt(msie[1]);
 } else {
 value.ActingVersion = value.TrueVersion;
 }

 if (value.IsIE && value.TrueVersion > 0 && value.ActingVersion > 0) {
 value.CompatibilityMode = value.TrueVersion != value.ActingVersion;
 }
 return value;
}

function rsw_unregisterTextBox(tbId) {
 if (typeof (rsw_tbs) == rsS57[12] || typeof (tbId) == rsS57[12]) return;
 for (var i = rsw_tbs.length - 1; i >= 0; i--) {
 if (rsw_tbs[i].shadowTBID === tbId) {
 if (rsw_scs[i] == rsw_tbs[i].spellChecker && i < rsw_scs.length) {
 rsw_scs[i] = null;
 rsw_scs.splice(i, 1);
 }
 if (rsw_activeTextbox == rsw_tbs[i])
 rsw_activeTextbox = null;
 if (rsw_inProcessTB == rsw_tbs[i])
 rsw_inProcessTB = null;

 if (rsw_inProcessSC == rsw_tbs[i])
 rsw_inProcessSC = null;

 rsw_tbs[i] = null;
 rsw_tbs.splice(i, 1);
 break;
 }
 }
}



function rsw_nextNonHiddenFormElement(_form, startIndex) {
 var i = startIndex;
 var type;
 while (i < _form.length) {
 type = _form[i].getAttribute(rsS57[29]);
 if (type == null || type.toLowerCase() != rsS57[30])
 return _form[i];
 else
 i++;
 }
 if (startIndex > 0)
 return rsw_nextNonHiddenFormElement(_form, 0);
 else
 return null;
}

function rsw_focusToNextField(tbs) {
 var currentTabIndex;
 if (!rsw_supportAutoSize) {
 currentTabIndex = tbs.shadowTB.getAttribute(rsS57[31]);
 } else {
 currentTabIndex = tbs.iframe.getAttribute(rsS57[31]);
 }
 var currentTabIndexP = null;

 if (currentTabIndex != null) currentTabIndexP = parseInt(currentTabIndex);

 if (currentTabIndex == null) {
 for (var i = 0; i < tbs.shadowTB.form.length; i++) {
 if (tbs.shadowTB.form[i] == tbs.shadowTB) {
 var targ = null;
 if (i + 1 < tbs.shadowTB.form.length)
 targ = rsw_nextNonHiddenFormElement(tbs.shadowTB.form, i + 1);

 if (targ != null) {
 rsw_focusTBSOrFormElement(targ);
 }
 
 return;
 }
 }
 } else {
 var nextUpIndex = Number.POSITIVE_INFINITY;
 var nextUpEl = null;
 var elementWith1TI = null;
 for (var i = 0; i < tbs.shadowTB.form.length; i++) {
 var ti;
 if (!rsw_supportAutoSize) {
 ti = parseInt(tbs.shadowTB.form[i].getAttribute(rsS57[31]));
 } else {
 ti = parseInt(tbs.shadowTB.form[i].getAttribute(rsS57[32]));
 if (ti === null || isNaN(ti))
 ti = parseInt(tbs.shadowTB.form[i].getAttribute(rsS57[31])); }



 if (ti > currentTabIndexP && ti < nextUpIndex) {
 nextUpIndex = ti;
 nextUpEl = tbs.shadowTB.form[i];
 }


 if (ti == 1)
 elementWith1TI = tbs.shadowTB.form[i];
 }

 if (nextUpEl!=null) {
 rsw_focusTBSOrFormElement(nextUpEl);
 return;
 }

 if (elementWith1TI != null) {
 rsw_focusTBSOrFormElement(elementWith1TI);
 } else {
 var targ = null;
 targ = rsw_nextNonHiddenFormElement(tbs.shadowTB.form, 0);

 if (targ != null) {
 rsw_focusTBSOrFormElement(targ);
 }
 }
 }
}

function rsw_focusTBSOrFormElement(targ) {
 var ntbs = rsw_getTBSFromID(targ.id);
 if (ntbs != null && typeof ntbs.focus == rsS57[33]) ntbs.focus();
 else targ.focus();
}


function rsw_logException(excep) {
 var extra = rsS57[3];
 
 rsw_consoleLog(excep.message + rsS57[34] + excep.name + rsS57[34] + extra, true);
}

function rsw_addTBConfig(config) {
 var found = false;
 for (var i = 0; rsw_config != null && i < rsw_config.length; i++) {
 if (rsw_config[i].values[0] == config.values[0]) { found = true;
 rsw_config[i] = config;
 }
 }
 if (!found)
 rsw_config[rsw_config.length] = config;
}

function rsw_refreshActiveTextbox() {
 if (rsw_activeTextbox != null && rsw_activeTextbox.iframe != null && !rsw_activeTextbox.isStatic) {
 rsw_activeTextbox.iframe = rs_s3.getElementById(rsw_activeTextbox.iframe.id);
 }
 return rsw_activeTextbox;
}

function rsw_getTBConfig(tbid) {
 for (var i = 0; i < rsw_config.length; i++) {
 if (rsw_config[i].values[0] == tbid + rsS57[35])
 return rsw_config[i];
 }
}


function rsw_getInternetExplorerVersion()
{
 var rv = -1; if (navigator.appName == rsS57[36]) {
 var ua = navigator.userAgent;
 var re = new RegExp(rsS57[37]);
 if (re.exec(ua) != null)
 rv = parseFloat(RegExp.$1);
 }
 return rv;
}

function rsw_debug_getTime() {
 var now = new Date();
 return now.getHours() + rsS57[38] + now.getMinutes() + rsS57[38] + now.getSeconds() + rsS57[38] + now.getMilliseconds() + rsS57[39];
}


function rsw_setShadowTB(shadow, value) {
 if (typeof (rsw_ignorePropertyChange) != rsS57[12]) rsw_ignorePropertyChange = true;
 if (typeof (rsw_detachMutationObserver) != rsS57[12]) rsw_detachMutationObserver(shadow);
 
 shadow.removeAttribute(rsS57[40]);
 shadow.value = value;
 if (typeof (rsw_ignorePropertyChange) != rsS57[12]) rsw_ignorePropertyChange = false;
 if (typeof (rsw_attachMutationObserver) != rsS57[12]) rsw_attachMutationObserver(shadow);
}







function rsw_getTBSFromID(id, copyStyle) {
 
 for (var i = 0; i < rsw_tbs.length; i++) {

 if (rsw_tbs[i].shadowTBID == id || rsw_tbs[i].shadowTBID == id+rsS57[41]) {

 return rsw_tbs[i];
 }
 }

 if (typeof rsw_isTextBoxSpellChecked == rsS57[33] && !rsw_isTextBoxSpellChecked(rs_s3.getElementById(id))) return null;

 var tbs = _createTBSForPlainTB(id, copyStyle);
 if (tbs != null) {
 rsw_tbs[rsw_tbs.length] = tbs;
 return rsw_tbs[rsw_tbs.length - 1];

 } else return null;


 }

function rsw_createBackUpPlainTBS(id) {
 try{
 var divElement = rs_s3.createElement(rsS57[42]);
 divElement.id = id + rsS57[43];
 divElement.setAttribute(rsS57[44], rsw_overlayCSSClassName); if (!rsw_absolutePositionStaticOverlay) {
 divElement.setAttribute(rsS57[45], rsS57[46]);
 rs_s3.getElementById(id).parentNode.insertBefore(divElement, rs_s3.getElementById(id));

 } else {
 divElement.setAttribute(rsS57[45], rsS57[47]);
 rs_s3.body.appendChild(divElement);
 }
 var myIFrame = rs_s3.getElementById(id + rsS57[43]);
 myIFrame.style.display = rsS57[48]; myIFrame.className = rsw_overlayCSSClassName;
 } catch (excep) { rsw_logException(excep); }

 return myIFrame;
}

function _createTBSForPlainTB(id, copyStyle) {
 if (rsw_haltProcesses) return;

 var myIFrame = rs_s3.getElementById(id + rsS57[43]);
 if (myIFrame == null && rs_s3.getElementById(id) != null) myIFrame = rsw_createBackUpPlainTBS(id);

 if (myIFrame == null) return null;

 var ptb = new OldIETB(myIFrame);
 var theTB = rs_s3.getElementById(id);

 try {
 if (theTB.name == rsS57[49] && theTB.parentNode.tagName.toLowerCase() == rsS57[50]) {
 theTB = theTB.parentNode;
 theTB.id = id + rsS57[51];
 }
 } catch (excep) { } 

 if (rsw_absolutePositionStaticOverlay || (theTB.style.position && theTB.style.position == rsS57[52])) {
 myIFrame.style.position = rsS57[52];
 rsw_updatePosition(myIFrame, theTB);


 
 }
 
 if (theTB.tagName.toUpperCase() == rsS57[53]) {
 rsw_auto_copyStyle(myIFrame.id, theTB.id);
 }



 myIFrame.style.backgroundColor = theTB.style.backgroundColor; 
 if (theTB.style.fontFamily)
 myIFrame.style.fontFamily = theTB.style.fontFamily;
 if (theTB.style.fontSize)
 myIFrame.style.fontSize = theTB.style.fontSize;

 ptb.initialize();


 if (copyStyle)
 rsw_copyComputedStyle(myIFrame, theTB);

 rsw_resetTBSSize(myIFrame, theTB.id);

 if (theTB.tagName.toLowerCase() != rsS57[54])
 ptb.multiline = false;

 return ptb;
}

function rsw_resetTBSSize(myIFrame, theTBid, isAYT) {
 var usingBorderSizing = false;
 if (typeof (myIFrame.style.boxSizing) != rsS57[12] && rsw_boxSizingEnabled) {
 myIFrame.style.boxSizing = rsS57[55];
 usingBorderSizing = true;
 }
 var tbWidth = rsw_getElementWidth(theTBid, myIFrame.id.indexOf(rsS57[43]) > -1); var theTB = rs_s3.getElementById(theTBid);
 if (typeof (tbWidth) == rsS57[56] && tbWidth.indexOf(rsS57[57]) > -1) {
 myIFrame.style.width = tbWidth;
 if (rsw_supportAutoSize) {
 setTimeout(function () { theTB.style.width = myIFrame.getBoundingClientRect().width + rsS57[58]; }, 5); myIFrame.contentWindow.onresize = function () {
 theTB.style.width = myIFrame.getBoundingClientRect().width + rsS57[58];
 rs_s2.width++; rs_s2.width--;
 };
 }
 } else {

 if (!usingBorderSizing && (((rs_s3.compatMode && rs_s3.compatMode != rsS57[59]) || (rsw_mozly && !rsw_msie11 && !rsw_chrome)) && rsw_adjustOffsetSizeForStrict)) {
 
 if(theTB.tagName.toUpperCase()==rsS57[53])
 tbWidth = rsw_adjustOffsetWidthForStrict(myIFrame, tbWidth);
 else
 tbWidth = rsw_adjustOffsetWidthForStrict(theTB, tbWidth);
 }


 if (tbWidth >= 0 && !(rsw_supportAutoSize && myIFrame.style.width.indexOf(rsS57[57]) > -1)) { 
 myIFrame.style.width = tbWidth + rsS57[58];

 if (rsw_chrome) {
 setTimeout(function () {
 myIFrame.style.width = (tbWidth + 1) + rsS57[58]; setTimeout(function () { myIFrame.style.width = tbWidth + rsS57[58] }, 50);
 }, 700);
 }
 
 rsw_consoleLog(rsS57[60] + tbWidth + rsS57[61] + myIFrame.style.width, false);
 } else 
 rsw_consoleLog(rsS57[62] + myIFrame.style.width, false);

 }

 var tbHeight = rsw_getElementHeight(theTBid, myIFrame.id.indexOf(rsS57[43]) > -1);

 if (typeof (tbHeight) == rsS57[56] && tbHeight.indexOf(rsS57[57]) > -1) {
 myIFrame.style.height = tbHeight;
 } else {
 
 if (!usingBorderSizing && (((rs_s3.compatMode && rs_s3.compatMode != rsS57[59]) || (rsw_mozly && !rsw_msie11 && !rsw_chrome)) && rsw_adjustOffsetSizeForStrict)) {
 if (theTB.tagName.toUpperCase() == rsS57[53])
 tbHeight = rsw_adjustOffsetHeightForStrict(myIFrame, tbHeight);
 else
 tbHeight = rsw_adjustOffsetHeightForStrict(theTB, tbHeight);
 
 }

 if (tbHeight < 26 && !isAYT) { tbHeight = 50;
 myIFrame.style.overflowX = rsS57[63];
 }

 
 if (tbHeight >= 0)
 myIFrame.style.height = tbHeight + rsS57[58];
 }
}



function rsw_updatePosition(targetElement, sourceElement) {
 if (!rsw_absolutePositionStaticOverlay && !(sourceElement.style.position && sourceElement.style.position == rsS57[52])) {
 targetElement.style.verticalAlign = rsS57[64]; } else {
 
 var marginDeltaY = 0, marginDeltaX = 0;
 
 if (((rs_s3.compatMode && rs_s3.compatMode != rsS57[59]) || rsw_mozly) && rsw_adjustOffsetSizeForStrict) {

 var tpTop = rsw_getStyleProperty(sourceElement, rsS57[65]);
 marginDeltaY = parseInt(tpTop.substring(0, tpTop.length - 2));
 var tpLeft = rsw_getStyleProperty(sourceElement, rsS57[66]);
 marginDeltaX = parseInt(tpLeft.substring(0, tpLeft.length - 2));

 }
 if (isNaN(marginDeltaX)) marginDeltaX = 0;
 if (isNaN(marginDeltaY)) marginDeltaY = 0;
 targetElement.style.left = (rsw_findPosX(sourceElement) - marginDeltaX) + rsS57[58];
 targetElement.style.top = (rsw_findPosY(sourceElement) - marginDeltaY) + rsS57[58];
 }
}

function rsw_adjustOffsetWidthForStrict(el, width) {

 try {
 var tpLeft = rsw_getStyleProperty(el, rsS57[67]);
 var tpRight = rsw_getStyleProperty(el, rsS57[68]);
 var pX = parseInt(tpLeft.substring(0, tpLeft.length - 2)) + parseInt(tpRight.substring(0, tpRight.length - 2));
 var tbLeft = rsw_getStyleProperty(el, rsS57[69]);
 var tbRight = rsw_getStyleProperty(el, rsS57[70]);
 var bX = parseInt(tbLeft.substring(0, tbLeft.length - 2)) + parseInt(tbRight.substring(0, tbRight.length - 2));
 if (isNaN(pX) || isNaN(bX)) return width;
 else {
 
 return width - pX - bX;
 }
 } catch (e) {
 rsw_logException(e);
 return width;
 }
}

function rsw_adjustOffsetHeightForStrict(el, height) {
 try {
 var tpTop = rsw_getStyleProperty(el, rsS57[71]);
 var tpBottom = rsw_getStyleProperty(el, rsS57[72]);
 var pY = parseInt(tpTop.substring(0, tpTop.length - 2)) + parseInt(tpBottom.substring(0, tpBottom.length - 2));
 var tbTop = rsw_getStyleProperty(el, rsS57[73]);
 var tbBottom = rsw_getStyleProperty(el, rsS57[74]);
 var bY = parseInt(tbTop.substring(0, tbTop.length - 2)) + parseInt(tbBottom.substring(0, tbBottom.length - 2));
 if (isNaN(pY) || isNaN(bY)) return height;
 else
 return height - pY - bY;
 } catch (e) {
 return height;
 }

}
function rsw_getStyleProperty(obj, IEStyleProp) {

 if (obj.currentStyle) { return obj.currentStyle[IEStyleProp];
 } else if (rs_s3.defaultView.getComputedStyle) { return rs_s3.defaultView.getComputedStyle(obj, null)[IEStyleProp]; } else {
 return null;
 }
}




function rsw_copyComputedStyle(tEl, sEl) {
 if (sEl == null || tEl == null) {
 rsw_consoleLog(rsS57[75] + (sEl == null) + rsS57[76] + (tEl == null) + rsS57[77]);
 return;
 }
 var col;

 var srcIsIFrame = sEl.tagName.toUpperCase() == rsS57[53];
 var tarIsIFrame = tEl.tagName.toUpperCase() == rsS57[53] || tEl.tagName.toUpperCase() == rsS57[78];
 var tarIsContentWindowBody = tEl.tagName.toUpperCase() == rsS57[78];
 var staticOverRich = srcIsIFrame && !tarIsIFrame;
 var ayt = tarIsIFrame;

 if (sEl.currentStyle)
 col = sEl.currentStyle;
 else if (rs_s3.defaultView && rs_s3.defaultView.getComputedStyle)
 col = rs_s3.defaultView.getComputedStyle(sEl, null);
 else
 return;
 
 for (sp in col) {
 if (isNaN(parseInt(sp))) { try {
 if (sp.indexOf(rsS57[79]) == -1 && sp != rsS57[80] && sp != rsS57[81] && sp != rsS57[82] && sp != rsS57[83] && sp != rsS57[84] && sp != rsS57[85] && sp.toLowerCase().indexOf(rsS57[86]) == -1 && sp != rsS57[87]
 && sp != rsS57[64] && sp != rsS57[88] && sp != rsS57[89] && sp.indexOf(rsS57[90]) == -1 && sp.indexOf(rsS57[91]) == -1
 && sp.indexOf(rsS57[92]) == -1 && sp.indexOf(rsS57[44]) == -1 && sp.indexOf(rsS57[93]) == -1 && sp.indexOf(rsS57[94]) == -1
 && sp.indexOf(rsS57[95]) == -1 && sp.indexOf(rsS57[96]) == -1 && sp.indexOf(rsS57[97]) == -1
 && sp.indexOf(rsS57[98]) == -1 && sp.indexOf(rsS57[99]) == -1 && sp.indexOf(rsS57[100]) == -1 && (rsw_copyFontColor || sp!=rsS57[101])
 && ((!staticOverRich && !ayt) || sp.indexOf(rsS57[102]) == -1)
 && sp.indexOf(rsS57[103]) == -1 && sp.indexOf(rsS57[104]) == -1 && ((!staticOverRich && !ayt) || sp.indexOf(rsS57[105]) == -1) 
 && (sp.indexOf(rsS57[106]) == -1 || sp==rsS57[107]) && sp.indexOf(rsS57[108]) == -1 && sp.indexOf(rsS57[109]) == -1 && sp.indexOf(rsS57[110]) == -1 && sp.indexOf(rsS57[111]) == -1
 && (!tarIsContentWindowBody || sp.indexOf(rsS57[112])==-1)
 ) {
 var v = rsw_getStyleProperty(sEl, sp);
 if (typeof (v) != rsS57[12] && v != rsS57[3] && v != null
 && (rsw_copyLineHeight || sp!=rsS57[107])
 && (sp.indexOf(rsS57[113]) == -1 || v != rsS57[114] || (rsw_firefox && !ayt))
 && (sp.indexOf(rsS57[115]) == -1 || v != rsS57[116]) && !(rsw_msie11 && (sp == rsS57[101] || sp==rsS57[117]) && sEl.placeholder.length > 0 && sEl.value.length == 0) ) {
 tEl.style[sp] = v;

 
 }
 }

 } catch (ex) { rsw_logException(ex);
 }
 }
 }
 if (rsw_firefox)
 tEl.style.overflowY = rsS57[63];

 if (typeof (tEl.style.boxSizing) != rsS57[12]) {
 tEl.style.boxSizing = rsS57[55];
 }


 }



function rsw_auto_copyStyle(iframeId, tbId) {
 
 var shtb = rs_s3.getElementById(tbId);
 var ifr = rs_s3.getElementById(iframeId);
 if (shtb == null) {
 rsw_consoleLog(rsS57[118] + tbId +rsS57[119]);
 }
 if ( ifr == null || ifr.contentWindow == null || ifr.contentWindow.document == null || ifr.contentWindow.document.body ==null) {
 rsw_consoleLog(rsS57[120] + iframeId + rsS57[121]);
 setTimeout(function () { rsw_auto_copyStyle(iframeId, tbId); }, 100);
 return;
 }
 var ignorePosition = shtb.style.left == rsw_leftHide;
 var isOverlay = ifr.tagName.toUpperCase() == rsS57[42];

 try {
 if (!isOverlay) {
 if (shtb.style.zIndex)
 ifr.style.zIndex = shtb.style.zIndex;
 
 if (!rsw_mozly && !rsw_chrome && !rsw_applewebkit) {

 rsw_copyComputedStyle(ifr.contentWindow.document.body, shtb);
 } else {
 rsw_copyComputedStyle(ifr, shtb);
 if (ifr.contentWindow) rsw_copyComputedStyle(ifr.contentWindow.document.body, shtb);
 }

 if (!ignorePosition) {
 ifr.style.position = shtb.style.position;
 ifr.style.left = shtb.style.left;
 ifr.style.top = shtb.style.top;
 }
 }
 var col = null;
 if (shtb.tagName.toUpperCase() == rsS57[53] && shtb.contentWindow) {
 if (shtb.currentStyle)
 col = shtb.contentWindow.document.body.currentStyle;
 else if (shtb.contentWindow.document.defaultView && shtb.contentWindow.document.defaultView.getComputedStyle)
 col = shtb.contentWindow.document.defaultView.getComputedStyle(shtb.contentWindow.document.body, null);
 } else {
 if (shtb.currentStyle)
 col = shtb.currentStyle;
 else if (rs_s3.defaultView && rs_s3.defaultView.getComputedStyle)
 col = rs_s3.defaultView.getComputedStyle(shtb, null);
 }

 if (col != null && !isOverlay) {
 var borderStyles = [rsS57[122], rsS57[81], rsS57[82],
 rsS57[71], rsS57[67], rsS57[68], rsS57[72], rsS57[66], rsS57[65], rsS57[123], rsS57[124],
 rsS57[84], rsS57[91], rsS57[125], rsS57[126], rsS57[127], rsS57[128], rsS57[74],
 rsS57[73], rsS57[69], rsS57[70], rsS57[129], rsS57[130], rsS57[131], rsS57[132], rsS57[133],
 rsS57[134], rsS57[135], rsS57[136], rsS57[137], rsS57[138], rsS57[139], rsS57[140], rsS57[141],
 rsS57[142], rsS57[143], rsS57[142], rsS57[143],
 rsS57[144], rsS57[145],
 rsS57[146], rsS57[147], rsS57[148]];
 for (var v = 0; v < borderStyles.length; v++) {
 if (col[borderStyles[v]]) {
 if (!(rsw_msie && rsw_getInternetExplorerVersion() <= 9 && borderStyles[v].indexOf(rsS57[91]) > -1
 && col[rsS57[134]] == rsS57[48]
 ) && 
 !( rsw_chrome && borderStyles[v].indexOf(rsS57[91]) > -1
 && col[rsS57[91]] == rsS57[149]
 )
 &&
 (!(ignorePosition && (borderStyles[v] == rsS57[81] || borderStyles[v] == rsS57[82] || borderStyles[v] == rsS57[84])))
 ) {
 if (borderStyles[v] != rsS57[82] || col[borderStyles[v]] != rsS57[150]) ifr.style[borderStyles[v]] = col[borderStyles[v]];
 
 }
 }
 }

 } else if (!isOverlay) {

 if (shtb.style.border) {
 ifr.style.border = shtb.style.border;

 if (shtb.style.border == rsS57[149] && rsw_mozly) ifr.style.border = rsS57[151]; }

 } else {
 ifr.style[rsS57[105]] = rsS57[3];
 ifr.style[rsS57[67]] = col[rsS57[67]].substring(0, col[rsS57[67]].length - 2) + col[rsS57[66]].substring(0, col[rsS57[66]].length - 2) + rsS57[58];
 ifr.style[rsS57[68]] = col[rsS57[68]].substring(0, col[rsS57[68]].length - 2) + col[rsS57[123]].substring(0, col[rsS57[123]].length - 2) + rsS57[58];
 ifr.style[rsS57[71]] = col[rsS57[71]].substring(0, col[rsS57[71]].length - 2) + col[rsS57[65]].substring(0, col[rsS57[65]].length - 2) + rsS57[58];
 ifr.style[rsS57[72]] = col[rsS57[72]].substring(0, col[rsS57[72]].length - 2) + col[rsS57[124]].substring(0, col[rsS57[124]].length - 2) + rsS57[58];
 ifr.style[rsS57[152]] = rsS57[30];
 ifr.style[rsS57[153]] = rsS57[63];
 }

 } catch (excep) {
 rsw_logException(excep);

 }



}




var rsw_http_request = false;

function rsw_createRequest() {
 if (rsw_haltProcesses) return;

 rsw_http_request = false;

 if (rs_s2.XMLHttpRequest) { 
 rsw_http_request = new XMLHttpRequest();
 if (rsw_http_request.overrideMimeType) {
 rsw_http_request.overrideMimeType(rsS57[154]);
 }

 } else if (rs_s2.ActiveXObject) { 
 try {
 rsw_http_request = new ActiveXObject(rsS57[155]);
 } catch (e) {
 try {
 rsw_http_request = new ActiveXObject(rsS57[156]);
 } catch (e) { if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[158]; rsw_logException(e); }
 }
 }

 return rsw_http_request;
}

function rsw_sendRequest(req, url, paramXML, callBack, synchronous) {
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[160]+url+rsS57[39];
 req.onreadystatechange = callBack;

 
 req.open(rsS57[161], url, !synchronous);
 req.setRequestHeader(rsS57[162], rsS57[163]);

 if (!rsw_ie9Standards && typeof (DOMParser) != rsS57[12] && navigator.userAgent.indexOf(rsS57[19]) == -1) { var domParser = new DOMParser();
 var xmlDocument = domParser.parseFromString(paramXML, rsS57[164]);
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[165];
 req.send(xmlDocument);
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[166];
 } else {
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[167];
 req.send(paramXML);
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[166];
 }

 if (synchronous) {

 }
}


function RapidSpellCheckerClient(helperPageURL) {
 this.Check = Check;
 this.AddWord = AddWord;

 this.userCallback = null;
 this.result = null;
 this.generateResult = generateResult;
 this.createErrorHTML = createErrorHTML;
 this.createErrorMouseUp = createErrorMouseUp;
 this.textChecked = null;

 this.OnSpellCheckCallBack = OnSpellCheckCallBack;
 this.rapidSpellWebPage = helperPageURL;
 this.getSpellBootString = getSpellBootString;
 this.config;
 this.useXMLHTTP = true;
 this.getParameterValue = getParameterValue;
 this.setParameterValue = setParameterValue;

 function getParameterValue(param) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 return this.config.values[pp];
 }
 }

 function setParameterValue(param, value) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 this.config.values[pp] = value;
 }
 }


 function getSpellBootString(xml) {
 var res = new String();
 if (xml) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 var val = rsw_escapeHTML(this.config.values[pp]);
 res += rsS57[168] + this.config.keys[pp] + rsS57[169] + val + rsS57[170] + this.config.keys[pp] + rsS57[169];
 }
 } else {

 for (var pp = 0; pp < this.config.keys.length; pp++) {
 res += rsS57[171] + this.config.keys[pp] + rsS57[172] + this.config.values[pp] + rsS57[173];
 }
 }
 return res;
 }
 

 function Check(text, asynchronousCallback, errorCallback) {
 var blocking = true;
 if (typeof (asynchronousCallback) == rsS57[33]) {
 blocking = false;
 this.userCallback = asynchronousCallback;
 } else
 this.userCallback = null;

 rsw_inProcessSC = this;
 this.textChecked = text;
 rsw_spellCheckText(text, true, blocking, rsS57[174], errorCallback);

 if (blocking) { _rsXMLCallBack();
 return this.result;
 }
 }

 function AddWord(word, errorCallback) {
 rsw_inProcessSC = this;
 rsw_serverAdd(word, errorCallback);
 }

 function OnSpellCheckCallBack(response, numberOfErrors) {
 this.result = this.generateResult(response, numberOfErrors);
 if (this.userCallback != null)
 this.userCallback(this.result);

 }

 function unescapeEntities(text) {
 return rsw_unescapeHTML(text);

 }

 function createErrorMouseUp(suggestions) {

 var suggestionList = rsS57[3];
 if (suggestions.length > 0) {
 suggestionList = rsS57[175];
 for (var i = 0; i < suggestions.length; i++) {
 var reg1 = new RegExp("'", "g");
 var reg2 = new RegExp("\"", "g");
 suggestionList += suggestions[i].replace(/\\/g, "\\\\").replace(reg1, "^apos^").replace(reg2, "^qt^");
 if (i < suggestions.length - 1)
 suggestionList += rsS57[176];
 }
 suggestionList += rsS57[175];
 }
 return suggestionList;

 }

 function createErrorHTML(word, suggestions) {
 var mouseup = createErrorMouseUp(suggestions);

 var html = "<span class='rs_err_hl' onmouseup=\"" + mouseup + "\" oncontextmenu=\"try{event.cancelBubble=true;event.preventDefault();}catch(e){}return false;\">" + word + "</span>";
 return html;
 }


 function generateResult(response, numberOfErrors, forceIgnoreXML) {
 
 
 response = unescapeEntities(response);

 var result = new RapidSpellChecker_Result();
 result.originalText = this.textChecked;
 result.numberOfErrors = numberOfErrors;

 var errorReg = /<span class=[^>]* onmouseup="rsw_showMenu\(([^\]]*\]),this,event\)[^>]*>([^<]*)<\/span>/g;
 
 var match;
 var lengthToDiscard = 0;
 var wordStart = 0;
 result.errorPositionArray = new Array();
 while ((match = errorReg.exec(response)) != undefined) {
 var sugs = rsw_getSuggestionsArray(match[1]);
 for (var s = 0; s < sugs.length; s++) {
 sugs[s] = rsw_decodeSuggestionItem(sugs[s]);
 }
 wordStart = match.index - lengthToDiscard;
 result.errorPositionArray[result.errorPositionArray.length] = { start: wordStart,
 end: match[2].length + wordStart,
 word: match[2],
 suggestions: sugs
 };

 lengthToDiscard += errorReg.lastIndex - match.index - match[2].length;
 }

 return result;
 }
}

function RapidSpellChecker_Result() {
 this.originalText;
 this.numberOfErrors;
 this.errorPositionArray;
}



function rsw_spellCheck() {
 rsw_spellCheckText(rsw_inProcessSC.tbInterface.getText(), rsw_inProcessSC.useXMLHTTP, false, rs_s3.getElementById(rsw_inProcessSC.tbInterface.tbName));
}

function rsw_spellCheckText(textToCheck, useXmlHttp, synchronous, textBoxForParams, _optionalErrorCallback) {
 try{
 var rsw_useXMLHttpReq = useXmlHttp;
 var req = false;

 if (rsw_haltProcesses) return;
 else if (rsw_cancelCall) rsw_cancelCall = false;


 if (typeof (rapidSpellExtension) == rsS57[177] && (rapidSpellExtension.useWCFService || rapidSpellExtension.useAPIController) && typeof(rapidSpell) == rsS57[177] && rapidSpell.useAJAXWebService) { 
 var params = rsw_createSpellBootJSON(textToCheck, textBoxForParams);


 params[params.length] = { 'ParameterName': 'IAW', 'ParameterValue': rsw_ignoreAllWords.join("|") };
 try {
 rapidSpellExtension.rsw_sc = rsw_inProcessSC;
 } catch (error) {
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[178] + error;
 rsw_logException(error);
 }

 var data = {'textToCheck':textToCheck, 'parameters':params};
 rapidSpellExtension.serviceProxy.invoke(rsS57[179], data, _rsJSONCallBack, _optionalErrorCallback);

 } else {

 if (rsw_useXMLHttpReq) req = rsw_createRequest();

 if (!req) { rsw_comIF = rs_s2.frames[rsS57[4]];
 rsw_spellBoot = rsS57[180] + rsw_inProcessSC.rapidSpellWebPage + rsS57[181];
 rsw_spellBoot += rsS57[182];
 rsw_spellBoot += rsw_inProcessSC.getSpellBootString(false);
 rsw_spellBoot += rsS57[183];

 if (rsw_comIF.document.body)
 rsw_comIF.document.body.innerHTML = rsw_spellBoot;
 else {
 rsw_comIF.document.open();
 rsw_comIF.document.write(rsw_spellBoot);
 }
 rsw_comIF.document.forms[0].textToCheck.value = textToCheck;
 rsw_comIF.document.forms[0].IAW.value = rsw_ignoreAllWords.join(rsS57[184]);
 rsw_comIF.document.forms[0].submit();

 } else { var paramString = new String();
 var text = rsw_escapeHTML(textToCheck);
 paramString = rsS57[185] + text + rsS57[186] + rsw_ignoreAllWords.join(rsS57[184]) + rsS57[187] + rsw_inProcessSC.getSpellBootString(true) + rsS57[188];
 try {
 req.rsw_sc = rsw_inProcessSC;
 } catch (error) {
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[178] + error;
 rsw_logException(error);
 }
 if (typeof (rsw_fiddler_debug) != rsS57[12] && rsw_fiddler_debug)
 rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage + rsS57[189] + textToCheck, paramString, _rsXMLCallBack, synchronous);
 else
 rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage, paramString, _rsXMLCallBack, synchronous);
 }
 }
 } catch (excep) { rsw_logException(excep); }

}

function rsw_getSuggestionsArray(handlerCode) {
 var suggsClean = handlerCode;
 if(suggsClean.indexOf(rsS57[190])>-1)
 suggsClean = suggsClean.substring(suggsClean.indexOf(rsS57[190]) + 1, suggsClean.indexOf(rsS57[191]));
 if (suggsClean.length > 1) {
 suggsClean = suggsClean.substring(1, suggsClean.length - 1); }
 var resArray = suggsClean.split(rsS57[176]);
 if (resArray.length == 1 && resArray[0] == rsS57[3]) return [];
 else return resArray;
}


function RSStandardInterface(tbElementName) {
 this.tbName = tbElementName;
 this.getText = getText;
 this.setText = setText;
 function getText() {
 var t = rs_s3.getElementById(tbElementName).value;
 if (t.indexOf(rsS57[24]) == -1) {
 var rx = new RegExp("\n", "g");
 t = t.replace(rx, "\r\n");
 }
 return t;
 }
 function setText(text) {
 rs_s3.getElementById(tbElementName).value = (text);
 if (rsw_tbs != null) {
 for (var i = 0; i < rsw_tbs.length; i++) {
 if (rsw_tbs[i].shadowTB.id == this.tbName) {
 if (rsw_tbs[i].updateIframe) { rsw_tbs[i].updateIframe(); rsw_tbs[i].focus(); }
 }
 }
 }
 }
}


function RSAutomaticInterface(tbElementName) {

 this.tbName = tbElementName; this.getText = getText; this.setText = setText;
 this.identifyTarget = identifyTarget;
 this.target = null;
 this.targetContainer = null;
 this.searchedForTarget = false;
 this.targetIsPlain = true;
 this.showNoFindError = showNoFindError;
 this.finder = null;

 this.findContainer = findContainer;

 function findContainer() {
 this.identifyTarget();
 return this.targetContainer;
 }

 function showNoFindError() {
 alert(rsS57[192] + this.tbName + rsS57[193]);
 }

 function identifyTarget() {
 if (!this.searchedForTarget) {
 this.searchedForTarget = true;

 if (this.finder == null)
 this.finder = new RSW_EditableElementFinder();

 var plain = this.finder.findPlainTargetElement(this.tbName);
 var richs = this.finder.findRichTargetElements();

 if (plain == null && (richs == null || richs.length == 0) && !rsw_suppressWarnings) showNoFindError();
 else {

 if (richs == null || richs.length == 0) { this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 } else {


 if (plain == null && richs.length == 1) { this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[0][0]);
 this.targetContainer = richs[0][1];

 } else {
 var findIdentical = false;
 for (var rp = 0; rp < richs.length && !findIdentical; rp++)
 findIdentical = typeof (richs[rp][1].id) != rsS57[12] && richs[rp][1].id == this.tbName + rsS57[35];

 for (var rp = 0; rp < richs.length; rp++) {
 if (typeof (richs[rp][1].id) != rsS57[12] &&
 (
 (!findIdentical && richs[rp][1].id.indexOf(this.tbName) > -1) ||
 (findIdentical && richs[rp][1].id == this.tbName)
 )) {
 if (plain != null && richs[rp][1].id == plain.id + rsS57[35]) {
 this.targetIsPlain = true;
 this.target = plain;
 this.targetContainer = plain;
 break;
 } else {
 this.targetIsPlain = false;
 this.target = this.finder.obtainElementWithInnerHTML(richs[rp][0]);
 this.targetContainer = richs[rp][1];
 break;
 }
 }
 }

 

 if (this.target == null) { this.target = plain;
 this.targetIsPlain = true;
 this.targetContainer = plain;
 }
 }
 }
 }
 }
 }
 function getText() {
 try {
 this.identifyTarget();


 if (this.targetIsPlain)
 return this.target.value;
 else
 return this.target.innerHTML;
 } catch (excep) { rsw_logException(excep); return rsS57[3];}
 }
 function setText(text) {
 try{
 this.identifyTarget();


 if (this.targetIsPlain) {
 var ver = rsw_getInternetExplorerVersion();
 if (ver > 0 && ver < 7) text = text.replace(/</g, rsS57[194]).replace(/>/g, rsS57[195]); 
 this.target.value = text;
 } else
 this.target.innerHTML = text;

 if (typeof (rsw_tbs) != rsS57[12]) {
 for (var i = 0; i < rsw_tbs.length; i++) {

 if (rsw_tbs[i].shadowTB.id == this.tbName) {
 if (rsw_tbs[i].updateIframe) { rsw_tbs[i].updateIframe(); 
 }
 }
 }
 }
 } catch (excep) { rsw_logException(excep); }
 }
}


function SpellChecker(textBoxID) {

 this.state; this.getTBS = getTBS;
 this.textBoxID = textBoxID;
 this.rsw_tbs = null;
 this.OnSpellButtonClicked = OnSpellButtonClicked;
 this.OnSpellCheckCallBack = OnSpellCheckCallBack;
 this.finishedListener;
 this.leaveStaticSpellCheckListener;
 this.enterStaticSpellCheckListener;
 this.tbInterface = new RSStandardInterface(textBoxID);
 this.config; this.getSpellBootString = getSpellBootString;
 this.buttonID;
 this.getParameterValue = getParameterValue;
 this.setParameterValue = setParameterValue;
 this.showNoSpellingErrorsMesg = true;
 this.enterEditModeWhenNoErrors = true;
 this.noSuggestionsText = rsS57[196];
 this.ignoreAllText = rsS57[197];
 this.showChangeAllItem = false;
 this.changeAllText = rsS57[198];
 this.addText = rsS57[199];
 this.editText = rsS57[200];
 this.removeDuplicateText = rsS57[201];
 this.buttonTextSpellChecking = rsS57[202];
 this.buttonTextSpellMode = rsS57[203];
 this.buttonText = rsS57[204];
 this.noSpellingErrorsText = rsS57[205];
 this.changeButtonTextWithState = true;
 this.showAddMenuItem = true;
 this.showIgnoreAllMenuItem = true;
 this.showEditMenuItem = true;
 this.responseTimeout = 20; this.responseTimeoutMessage = rsS57[206];
 this.hasRunFieldID;
 this.OnTextBoxDoubleClicked = OnTextBoxDoubleClicked;
 this.doubleClickSwitchesMode = true;
 this.onLeaveEdit = onLeaveEdit;
 this.onEnterEdit = onEnterEdit;
 this.useXMLHTTP;
 this.ignoreXML = false;
 this.copyComputedStyleToOverlay = true;
 this.overlayCSSClassName = rsS57[11];
 this.hasRun = false;

 function OnTextBoxDoubleClicked() {
 if (this.doubleClickSwitchesMode)
 this.OnSpellButtonClicked(true);
 }

 function getSpellBootString(xml, json) {
 var res = new String();
 if (xml) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 var val;
 if(typeof(this.config.values[pp])==rsS57[56])
 val = rsw_escapeHTML(this.config.values[pp]);
 else 
 val = this.config.values[pp].toString();
 res += rsS57[168] + this.config.keys[pp] + rsS57[169] + val + rsS57[170] + this.config.keys[pp] + rsS57[169];
 }
 } else if (json) {
 res = [];
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 var val;
 if (typeof (this.config.values[pp]) == rsS57[56])
 val = rsw_escapeHTML(this.config.values[pp]);
 else
 val = this.config.values[pp].toString();
 res[res.length] = { 'ParameterName': this.config.keys[pp], 'ParameterValue': val };
 }
 } else {

 for (var pp = 0; pp < this.config.keys.length; pp++) {
 res += rsS57[171] + this.config.keys[pp] + rsS57[172] + this.config.values[pp] + rsS57[173];
 }
 }
 return res;
 }

 function getParameterValue(param) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 return this.config.values[pp];
 }
 }

 function setParameterValue(param, value) {
 for (var pp = 0; pp < this.config.keys.length; pp++) {
 if (this.config.keys[pp] == param)
 this.config.values[pp] = value;
 }
 }

 function getTBS() {
 if (rsw_haltProcesses) return;

 if (this.rsw_tbs == null) {
 var el = rs_s3.getElementById(this.textBoxID);
 if (el == null && !rsw_suppressWarnings) alert(rsS57[207] + this.textBoxID + rsS57[208]);
 else if (el != null) {

 rsw_overlayCSSClassName = this.overlayCSSClassName;
 this.rsw_tbs = rsw_getTBSFromID(this.textBoxID, this.copyComputedStyleToOverlay);

 if (this.rsw_tbs == null) return null;

 this.rsw_tbs.spellChecker = this;

 if (this.rsw_tbs.isStatic) {
 this.state = rsS57[209];
 } else
 this.state = rsS57[210];
 }
 } else {
 if (rsw_inProcessTB !=null && rsw_inProcessTB.iframe != null) {
 rsw_inProcessTB.iframe = rs_s3.getElementById(rsw_inProcessTB.iframe.id);
 if (rsw_inProcessTB.iframe == null) {
 var n = _createTBSForPlainTB(rsw_inProcessTB.shadowTBID, true);
 if(n!=null)
 rsw_inProcessTB.iframe = n.iframe;

 }
 }
 }

 if (this.rsw_tbs != null && this.rsw_tbs.isStatic && rsw_recalculateOverlayPosition) {
 rsw_updatePosition(this.rsw_tbs.iframe, this.rsw_tbs.shadowTB);
 }
 if (this.rsw_tbs != null && this.rsw_tbs.isStatic) this.rsw_tbs.targetIsPlain = !this.ignoreXML;
 return this.rsw_tbs;
 }

 var rsw_spellCheckQueue = [];

 function OnSpellButtonClicked(quietFinish, dontResetCaretPosition) {
 rsw_spellCheckRunning = true;
 if (rsw_haltProcesses) { rsw_spellCheckRunning = false; return; }
 
 this.hasRun = true; if (this.hasRunFieldID && rs_s3.getElementById(this.hasRunFieldID))
 rs_s3.getElementById(this.hasRunFieldID).value = rsS57[211];
 if (typeof (this.tbInterface.findContainer) != rsS57[12]) {
 this.textBoxID = this.tbInterface.findContainer().id;
 if (!this.tbInterface.targetIsPlain) {
 this.setParameterValue(rsS57[212], rsS57[213]);
 if (typeof rapidSpell !== rsS57[12] && typeof rapidSpell.setParameterValue === rsS57[33])
 rapidSpell.setParameterValue(rs_s3.getElementById(this.textBoxID), rsS57[212], rsS57[213]);
 this.ignoreXML = true;
 }
 } else if (!this.tbInterface.targetIsPlain) {
 this.setParameterValue(rsS57[212], rsS57[213]);
 if (typeof rapidSpell !== rsS57[12] && typeof rapidSpell.setParameterValue === rsS57[33])
 rapidSpell.setParameterValue(rs_s3.getElementById(this.textBoxID), rsS57[212], rsS57[213]);
 this.ignoreXML = true;
 }
 rsw_inProcessTB = this.getTBS();

 if (rsw_inProcessTB == null) { rsw_spellCheckRunning = false; return; }

 if (!rsw_inProcessTB.enabled && (typeof (rsw_ignoreDisabledBoxes) != rsS57[12] && rsw_ignoreDisabledBoxes)) { rsw_spellCheckRunning = false; return; }

 

 

 rsw_inProcessTB.spellChecker = this; rsw_inProcessSC = this;
 if (this.state == rsS57[209] || this.state == rsS57[210]) {
 if (rsw_channel_state == rsS57[5]) {
 rsw_channel_state = rsS57[214];
 clearTimeout(rsw_channel_timeout);
 var lc_SD6F5S67DF576SD57F6S76F576S576E5R76WE5675WE76R76W567SD5F76SD56F7576E76W5R76EW5757 = rsS57[3];
 var timeoutFn = 'if(rsw_channel_state == "ACTIVE" && !rsw_suppressWarnings){alert("' + this.responseTimeoutMessage + '");rsw_channel_state = "INACTIVE";}';
 rsw_channel_timeout = setTimeout(timeoutFn, this.responseTimeout * 1000);

 rsw_inProcessTBResetCaret = !dontResetCaretPosition;


 if (typeof (rsw_inProcessTB.recordCaretPos) != rsS57[12]) rsw_inProcessTB.recordCaretPos();


 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[215];
 rsw_spellCheck();
 if (this.state == rsS57[209]) {
 rsw_resetTBSSize(rsw_inProcessTB.iframe, this.textBoxID); this.onLeaveEdit();
 }

 } else {
 rsw_spellCheckQueue[rsw_spellCheckQueue.length] = [rsw_inProcessTB, rsw_inProcessSC];
 rsw_consoleLog(rsS57[216] + rsw_inProcessTB.shadowTBID);
 }

 } else { 
 rsw_inProcessTB.updateShadow();
 rsw_inProcessTB.iframe.style.display = rsS57[48];
 rsw_inProcessTB.shadowTB.style.display = rsw_inProcessTB.shadowTBDisplay;
 
 this.state = rsS57[209];
 try {
 if (typeof (rsw_inProcessTB.shadowTB.focus) != rsS57[12])
 rsw_inProcessTB.shadowTB.focus();
 } catch (ee) {
 rsw_logException(ee);
 }
 this.onEnterEdit();

 rsw_broadcastToListeners(rsS57[217]);
 if (this.finishedListener != null && this.finishedListener != rsS57[3] && !quietFinish) {
 eval(this.finishedListener + rsS57[218]);
 }
 
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[219],rsw_inProcessTB, true, -1);
 if (typeof (rswm_auto_NotifyDone) == rsS57[33] && !quietFinish) rswm_auto_NotifyDone(true, -1);
 }
 if(!rsw_ayt_initializing )rsw_hideCM();
 }


 function onEnterEdit() {
 if (rs_s2.rsw_inline_button_OnStateChanged && this.changeButtonTextWithState) {
 rsw_inline_button_OnStateChanged(rsS57[220], rsw_inProcessSC.buttonID, this.buttonTextSpellChecking, this.buttonTextSpellMode, this.buttonText);
 }
 if (this.leaveStaticSpellCheckListener != null && this.leaveStaticSpellCheckListener != rsS57[3])
 eval(this.leaveStaticSpellCheckListener + rsS57[221]);
 }

 function onLeaveEdit() {
 if (rs_s2.rsw_inline_button_OnStateChanged && this.changeButtonTextWithState) {
 rsw_inline_button_OnStateChanged(rsS57[222], rsw_inProcessSC.buttonID, this.buttonTextSpellChecking, this.buttonTextSpellMode, this.buttonText);
 }
 if (this.enterStaticSpellCheckListener != null && this.enterStaticSpellCheckListener != rsS57[3])
 eval(this.enterStaticSpellCheckListener + rsS57[221]);
 }

 this.reconcileChange = reconcileChange;
 function reconcileChange(beforeS, afterS) { if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[223] + beforeS + rsS57[224] + afterS;
 var dif = RSW_diff(beforeS, afterS);
 if (dif.position == -1)
 return [beforeS, false];
 else if (dif.vector > 0) { return [this.insertAtVisible(beforeS, dif.addedText, dif.position), true];
 } else if (dif.vector < 0) {
 return [afterS, true];
 }
 else return [beforeS, false];
 }

 this.insertAtVisible = insertAtVisible;
 function insertAtVisible(str, addition, pos) {
 var cs = new RSW_VisibleCharSeq(str);
 return cs.insertAtVisible(addition, pos);
 }

 var rsw_OnSpellCheckCallBack_vars_text;
 var rsw_OnSpellCheckCallBack_vars_innerHTMLLength;
 var rsw_OnSpellCheckCallBack_vars_haveResetFocus;


 var rsw_tempClient = new RapidSpellCheckerClient();
 function OnSpellCheckCallBack_Breather(scOptional) {
 
 if (rsw_haltProcesses) return;

 var workingWithTB = rsw_inProcessTB;

 if (typeof scOptional !== rsS57[12]) {
 workingWithTB = scOptional.getTBS();
 }

 if (workingWithTB == null) return;


 if (rsw_OnSpellCheckCallBack_vars_innerHTMLLength != workingWithTB.getContent().length) {
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[225];
 return;
 }



 if (typeof (workingWithTB.insertErrorHighlights) != rsS57[12]) {

 workingWithTB.insertErrorHighlights(rsw_tempClient.generateResult(rsw_OnSpellCheckCallBack_vars_text, rsw_OnSpellCheckCallBack_vars_numErrors, rsw_inProcessSC.ignoreXML), rsw_tempClient);
 } else
 workingWithTB.setContent(rsw_OnSpellCheckCallBack_vars_text);

 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[226];

 if (typeof (workingWithTB.insertErrorHighlights) == rsS57[12] && typeof (workingWithTB.resetCaretPos) != rsS57[12] && rsw_inProcessTBResetCaret) workingWithTB.resetCaretPos();

 rsw_OnSpellCheckCallBack_vars_haveResetFocus = true;

 if (workingWithTB.isStatic) {
 workingWithTB.shadowTBDisplay = rsw_getStyleProperty(workingWithTB.shadowTB, rsS57[85]);
 if (workingWithTB.shadowTB.tagName == rsS57[53]) workingWithTB.iframe.style.display = rsS57[227];
 else {
 workingWithTB.iframe.style.display = workingWithTB.shadowTBDisplay;
 }

 if(!rsw_absolutePositionStaticOverlay)
 workingWithTB.shadowTB.style.display = rsS57[48];
 if (rsw_inProcessSC.state == rsS57[209]) {
 rsw_inProcessSC.state = rsS57[228];
 if (rs_s2.rsw_inline_button_OnStateChanged && rsw_inProcessSC.changeButtonTextWithState) {
 rsw_inline_button_OnStateChanged(rsS57[229], rsw_inProcessSC.buttonID, rsw_inProcessSC.buttonTextSpellChecking, rsw_inProcessSC.buttonTextSpellMode, rsw_inProcessSC.buttonText);
 }
 }

 if (navigator.userAgent.toLowerCase().indexOf(rsS57[230]) > -1 && workingWithTB.iframe.style.display == rsS57[231]) {
 workingWithTB.iframe.style.display = rsS57[232];
 }
 } 

 }

 function OnSpellCheckCallBack(text, numberOfErrors) {
 
 var workingTB = this.getTBS();
 var workingSC = this;
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[233] + numberOfErrors + rsS57[234];

 try {
 


 rsw_channel_state = rsS57[5];
 clearTimeout(rsw_channel_timeout);

 if (rsw_cancelCall) { rsw_cancelCall = false; return; }

 workingTB.isDirty = false;
 rsw_OnSpellCheckCallBack_vars_haveResetFocus = false;
 workingTB.rsw_key_downed_flag = false; var innerHTMLLength = workingTB.getContent().length;

 if (numberOfErrors > 0) {



 if (!workingTB.isStatic && !workingTB.noReconcile) {
 if (rsw_haltProcesses) return;

 if (typeof (workingTB.insertErrorHighlights) == rsS57[12]) { var curText = workingSC.tbInterface.getText(); if (rsw_mozly) {
 curText = curText.replace(/\r\n/g, rsS57[25]);
 curText = curText.replace(/\r/g, rsS57[25]);
 text = text.replace(/\r\n/g, rsS57[25]);
 text = text.replace(/\r/g, rsS57[25]);
 }
 if (!workingSC.ignoreXML) {
 if (curText.indexOf(rsS57[235]) > -1) rsw_reconcileChanges = false; }
 
 
 var rec = this.reconcileChange(text, curText);
 text = rec[0];
 if (rec[1] && !rsw_reconcileChanges) return; }

 if (workingTB.rsw_key_downed_flag || workingTB.rsw_key_downed_within_lim) {
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[236] + rsw_key_down_timeout+rsS57[237]+workingTB.rsw_key_downed_flag +rsS57[238]+ workingTB.rsw_key_downed_within_lim;
 return;
 }

 if (typeof (workingTB.recordCaretPos) != rsS57[12]) workingTB.recordCaretPos();
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[239] + workingTB.caretBL + rsS57[240] + workingTB.caretBT;

 }
 
 rsw_OnSpellCheckCallBack_vars_text = text;
 rsw_OnSpellCheckCallBack_vars_innerHTMLLength = innerHTMLLength;
 rsw_OnSpellCheckCallBack_vars_numErrors = numberOfErrors;

 if (rsw_ayt_check && !rsw_ayt_initializing) setTimeout(function () { OnSpellCheckCallBack_Breather(); }, 10);
 else OnSpellCheckCallBack_Breather(this); 


 } else {

 if (workingSC.showNoSpellingErrorsMesg)
 alert(workingSC.noSpellingErrorsText);

 if (workingSC.state == rsS57[209]) {
 workingSC.onEnterEdit();
 }

 }

 if (!workingTB.isStatic && !rsw_ayt_initializing && rsw_inProcessTBResetCaret) {
 }

 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsS57[241];
 if (numberOfErrors > 0 && !rsw_OnSpellCheckCallBack_vars_haveResetFocus && typeof (workingTB.resetCaretPos) != rsS57[12] && rsw_inProcessTBResetCaret && !rsw_ayt_check) workingTB.resetCaretPos();


 rsw_broadcastToListeners(rsS57[217]);
 if (workingSC.finishedListener != null && workingSC.finishedListener != rsS57[3]) {
 eval(workingSC.finishedListener + rsS57[242]);
 }
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[219], workingTB, true, numberOfErrors);
 if (typeof (rswm_auto_NotifyDone) == rsS57[33]) rswm_auto_NotifyDone(true, numberOfErrors);

 } catch (e) {
 rsw_spellCheckRunning = false;
 rsw_logException(e);
 }
 rsw_spellCheckRunning = false;


 while (rsw_spellCheckQueue.length > 0 && rsw_spellCheckQueue[0] == null)
 rsw_spellCheckQueue.splice(0, 1);
 if (rsw_spellCheckQueue.length > 0) {
 rsw_consoleLog(rsS57[243] + rsw_spellCheckQueue.length);
 rsw_inProcessTB = rsw_spellCheckQueue[0][0];
 rsw_spellCheckQueue.splice(0, 1);
 rsw_spellCheckTextBox(rsw_inProcessTB);
 
 
 }
 }

}

function _rsJSONCallBack(jsonData, errorHandler) {
 _rsProcessResponseText(jsonData, errorHandler);
}

function _rsProcessResponseText(responseText, errorHandler) {
 rsw_showXMLResponseError(responseText, errorHandler);
 var rcs = responseText.indexOf(rsS57[244]) + 19;
 var rns = responseText.indexOf(rsS57[245]) + 20;
 var rce = responseText.lastIndexOf(rsS57[246], rns);
 var rne = responseText.indexOf(rsS57[246], rns);

 var responseContent = responseText.substring(rcs, rce);
 if (responseContent.indexOf(rsS57[24]) == -1) {
 var pos = -2;
 while ((pos = responseContent.indexOf(rsS57[25], pos + 2)) > -1)
 responseContent = responseContent.substring(0, pos) + rsS57[159] + responseContent.substring(pos + 1);
 }


 _rsCallBack(responseContent, responseText.substring(rns, rne), rsw_http_request);
}

function _rsXMLCallBack() {
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[247] + rsw_http_request.readyState + (rsw_http_request.readyState<=3?rsS57[3]:rsS57[248] + rsw_http_request.status);
 if (rsw_http_request.readyState == 4) {
 if (rsw_http_request.status == 200) {
 var responseText = rsw_http_request.responseText;
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[249] + responseText;
 _rsProcessResponseText(responseText);

 } else if (rsw_http_request.status == 404 && !rsw_suppressWarnings) {
 alert(rsS57[250]);
 } else if (rsw_http_request.status == 500 && !rsw_suppressWarnings) {
 alert(rsS57[251] + (rsw_isASPX ? rsS57[252] : rsS57[3]));
 } else if (rsw_http_request.status == 405 && !rsw_suppressWarnings) {
 alert(rsS57[253] + rsw_http_request.status);
 } else if (!rsw_suppressWarnings) {
 if (rsw_http_request.status == 0) {
 rs_s2.rsw_consoleLog(rsS57[254]);
 } else 
 alert(rsS57[255] + rsw_http_request.status);
 }
 }
}

function _rsCallBack(text, numberOfErrors, request) {
 
 if (request.rsw_sc) request.rsw_sc.OnSpellCheckCallBack(text, numberOfErrors);
 else if (rsw_inProcessSC) rsw_inProcessSC.OnSpellCheckCallBack(text, numberOfErrors);
}

function rsw_countCharactersTo(elements, toElement) {
 var count = 0;
 var found = false;
 for (var i = 0; i < elements.length && !found; i++) {
 if (elements[i] == toElement || elements[i].parentNode == toElement) { return [count, true];
 }
 else {
 if (elements[i].childNodes.length == 0) {
 if (elements[i].nodeValue == null) {
 if (elements[i].nodeName == rsS57[256] || elements[i].nodeName == rsS57[42] || elements[i].nodeName == rsS57[257]) count += 1;
 } else
 count += elements[i].nodeValue.length;

 } else {
 
 res = rsw_countCharactersTo(elements[i].childNodes, toElement);
 count += res[0];
 found = res[1];

 if (!found && rsw_tagAddsNewline(elements[i])) count += 1;

 }
 }
 }
 return [count, found];
}

function rsw_getAbsSel(range, len, contentElements, findRangeEnd) {
 var i;
 var r = new Array();
 r[0] = len;
 r[1] = false;
 r[2] = false; var tarContainer = findRangeEnd ? range.endContainer : range.startContainer;
 var tarOffset = findRangeEnd ? range.endOffset : range.startOffset;
 var numberOfElementsToCount = contentElements.length;
 
 var result = rsw_countCharactersTo(contentElements, tarContainer);
 if (tarContainer.nodeType == Node.TEXT_NODE) {
 
 len = result[0] + tarOffset;
 } else {
 len = result[0];
 result = rsw_countCharactersTo(tarContainer.childNodes, tarContainer.childNodes[tarOffset]);
 len += result[0];
 }
 r[1] = true;
 r[2] = true;
 r[0] = len;
 return r;
}


function rsw_findEl(index, elements, r) {
 var count = 0;
 if (index == 0) {
 r[2] = elements[0];
 r[3] = 0;
 r[4] = false; r[1] = true;
 }
 for (var i = 0; i < elements.length && count<index; i++) {
 

 if (i > 0 && (elements[i-1].nodeName==rsS57[42] || elements[i-1].nodeName==rsS57[257]))
 count++;


 var countBeforeThisElement = count;



 if (elements[i].childNodes.length == 0) {
 if (elements[i].nodeValue != null) count += elements[i].nodeValue.length;
 } else {
 if (index != count) count += rsw_findEl(index - count, elements[i].childNodes, r);
 }

 

 if (count >= index && r.length == 0) {
 r[2] = elements[i];
 r[3] = index - countBeforeThisElement;
 r[4] = elements[i].nodeName == rsS57[256]; r[1] = true;
 return count;
 } 
 
 
 }
 
 return count;
}




function rsw_serverAdd(word, errorCallback) {

 
 if (typeof (rapidSpellExtension) == rsS57[177] && (rapidSpellExtension.useWCFService || rapidSpellExtension.useAPIController) && typeof (rapidSpell) == rsS57[177] && rapidSpell.useAJAXWebService) { rapidSpellExtension.serviceProxy.invoke('AddWord', { 'Word': word, 'GuiLanguage': 'ENGLISH', 'UserDictionaryFile': rapidSpell.getParameterValue('default', 'UserDictionaryFile') }, function () { }, errorCallback);
 
 

 } else {


 try {
 var rsw_useXMLHttpReq = rsw_inProcessSC.useXMLHTTP;
 var req = false;

 if (rsw_useXMLHttpReq) req = rsw_createRequest();

 if (!req) { rsw_comIF = rs_s2.frames[rsS57[4]];
 var boot = rsS57[3];
 boot += rsS57[258] + rsS57[259] + rsw_inProcessSC.rapidSpellWebPage + rsS57[181] +
 rsS57[260] +
 "<input type='hidden' name='w' value=''><input type='hidden' name='UserDictionaryFile' value=\"\"></form>";

 if (rsw_comIF.document.body)
 rsw_comIF.document.body.innerHTML = boot;
 else {
 rsw_comIF.document.open();
 rsw_comIF.document.write(boot);
 }
 rsw_comIF.document.forms[0].w.value = word;
 rsw_comIF.document.forms[0].UserDictionaryFile.value = rsw_inProcessSC.getParameterValue(rsS57[261]);
 rsw_comIF.document.forms[0].submit();

 } else { var paramString = new String();
 paramString = rsS57[262] + rsw_escapeHTML(word) + rsS57[263] + rsw_escapeHTML(rsw_inProcessSC.getParameterValue(rsS57[261])) + rsS57[264];
 rsw_sendRequest(req, rsw_inProcessSC.rapidSpellWebPage, paramString, rsw_serverAddCallback, false);
 }
 } catch (excep) { rsw_logException(excep); }
 }

}

function rsw_serverAddCallback() {
 if (rsw_http_request.readyState == 4) {
 if (rsw_http_request.status == 200) {
 rsw_showXMLResponseError(rsw_http_request.responseText);
 } else if (rsw_http_request.status == 404 && !rsw_suppressWarnings) {
 alert(rsS57[265]);
 } else if (rsw_http_request.status == 500 && !rsw_suppressWarnings) {
 alert(rsS57[266]);
 } else if (rsw_http_request.status == 405 && !rsw_suppressWarnings) {
 alert(rsS57[253] + rsw_http_request.status);
 } else if (!rsw_suppressWarnings) {
 alert(rsS57[255] + rsw_http_request.status);
 }
 }
}

function rsw_showXMLResponseError(responseText, errorHandler) {
 if (responseText == null)
 rsw_consoleLog(rsS57[267], true);
 else {
 var rcs = responseText.indexOf(rsS57[268]) + 18;
 if (rcs > 17) {
 var rce = responseText.indexOf(rsS57[246], rcs);
 if (typeof errorHandler == rsS57[33])
 errorHandler(responseText.substring(rcs, rce));
 else
 alert(responseText.substring(rcs, rce));
 }
 }
}


function rsw_showMenu(menuItems, element, e) {
 try {
 rsw_refreshActiveTextbox();
 function isRightClick(e) {
 var rightclick;
 if (!e) var e = rs_s2.event;
 if (e.which) rightclick = (e.which == 3 || e.which == 93);
 else if (e.button) rightclick = (e.button == 2);
 else if (e.keyCode) rightclick = e.keyCode == 93;
 return rightclick;
 }



 rsw_lastRightClickedError = element;
 
 var atbs = rsw_getTBSHoldingElement(element);

 if (atbs.focus && !atbs.isFocused) {
 var yScroll = null;
 if (atbs.iframe && typeof (atbs.iframe.contentWindow) != rsS57[12])
 yScroll = rsw_getScrollY(atbs.iframe.contentWindow);
 atbs.focus();
 if (yScroll != null) rsw_setScrollY(atbs.iframe.contentWindow, yScroll);
 }
 rsw_activeTextbox = atbs;


 
 setTimeout(rsS57[269], 200);

 if (rsw_isMac) rsw_MenuOnRightClick = false;

 try {
 if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) rsw_MenuOnRightClick = false;
 } catch (e) { }

 if (!rsw_MenuOnRightClick && (e.button == 1 || e.button == 0)) { rsw_showCM(element, menuItems, e);
 } else if (rsw_MenuOnRightClick && isRightClick(e)) {
 rsw_showCM(element, menuItems, e);
 }
 } catch (excep) { rsw_logException(excep); }

 return false;
}

function rsw_getTBSHoldingElement(element) {
 for (var i = 0; i < rsw_tbs.length; i++) if (rsw_tbs[i].containsElement(element))
 return rsw_tbs[i];
}

function rsw_getScrollX(windowEl) {
 if (windowEl.pageYOffset) {
 return windowEl.pageXOffset;

 }
 else if (windowEl.document.documentElement && windowEl.document.documentElement.scrollTop)
 {
 return windowEl.document.documentElement.scrollLeft;
 }
 else if (windowEl.document.body) {
 return windowEl.document.body.scrollLeft;
 }
}

function rsw_getClientWidth(windowEl) {
 if (windowEl.innerHeight) return windowEl.innerWidth;
 else if (windowEl.document.documentElement && rs_s3.documentElement.clientHeight) return windowEl.document.documentElement.clientWidth;
 else if (rs_s3.body) return windowEl.document.body.clientWidth;
}

function rsw_getClientHeight(windowEl) {
 if (windowEl.innerHeight) return windowEl.innerHeight;
 else if (windowEl.document.documentElement && rs_s3.documentElement.clientHeight)
 return windowEl.document.documentElement.clientHeight;
 else if (rs_s3.body) return windowEl.document.body.clientHeight;
}


function rsw_getScrollY(windowEl) {
 if (windowEl.pageYOffset) return windowEl.pageYOffset;
 else if (windowEl.document.documentElement && windowEl.document.documentElement.scrollTop)
 return windowEl.document.documentElement.scrollTop;
 else if (windowEl.document.body) { 
 return windowEl.document.body.scrollTop;
 }
}


function rsw_setScrollY(windowEl, scrollY) {
 windowEl.scrollTo(0, scrollY);
 
}

function rsw_showCM(element, menuItems, event) {
 rsw_refreshActiveTextbox();

 rsw_contextMenu = new RS_ContextMenu(element, menuItems, rsw_activeTextbox);
 rsw_contextMenu.x = rsw_activeTextbox.getAbsX(element, event) + 20;
 rsw_contextMenu.y = rsw_activeTextbox.getAbsY(element, event) + 20;
 

 if (typeof (rsw_getContextMenuOffsetX) == rsS57[33])
 rsw_contextMenu.x += rsw_getContextMenuOffsetX(rsw_contextMenu.x, element, rsw_activeTextbox, event);
 if (typeof (rsw_getContextMenuOffsetY) == rsS57[33])
 rsw_contextMenu.y += rsw_getContextMenuOffsetY(rsw_contextMenu.y, element, rsw_activeTextbox, event);

 
 var winWidth = rsw_getClientWidth(this) + rsw_getScrollX(this);
 if (rsw_contextMenu.x + 220 > winWidth)
 rsw_contextMenu.x = winWidth - 240 - 10; 
 if (typeof (rsw_broadcastEvent) == rsS57[33])
 rsw_broadcastEvent(rsS57[270], rsw_contextMenu, rsw_activeTextbox, event, element);

 rsw_contextMenu.show();

 if (typeof (rsw_broadcastEvent) == rsS57[33])
 rsw_broadcastEvent(rsS57[271], rsw_contextMenu, rsw_activeTextbox, event, element);


 var menuHeight = rsw_getElementHeight(rsw_contextMenu.CMelement.id);
 var winHeight = rsw_getClientHeight(this) + rsw_getScrollY(this);
 if (rsw_contextMenu.y + menuHeight > winHeight) {
 rsw_contextMenu.y = winHeight - menuHeight - 10;
 }

 if (rsw_contextMenu.x <= 0)
 rsw_contextMenu.x = 1;

 if (rsw_contextMenu.y <= 0)
 rsw_contextMenu.y = 1;
 
 rsw_contextMenu.moveCMElement();
}





function rsw__resize() {
 for (var i = 0; i < rsw_tbs.length; i++) {
 if (rsw_tbs[i].isStatic) {
 rsw_updatePosition(rs_s3.getElementById(rsw_tbs[i].iframe.id), rsw_tbs[i].shadowTB);
 }
 }
}

function rsw_setSettings(tbs) {

 if (typeof (tbs.tbConfig) != rsS57[12] && tbs.tbConfig != null && tbs.tbConfig.keys != null) {
 for (var pp = 3; pp < tbs.tbConfig.keys.length; pp++) {
 try {
 if (!rsw_useBattleShipStyle || tbs.tbConfig.keys[pp].indexOf(rsS57[91]) == -1) { var c;
 var parts = tbs.tbConfig.keys[pp].split(rsS57[166]);
 if (parts.length == 1) {
 tbs[parts[0]] = tbs.tbConfig.values[pp];
 } else if (parts.length == 2) {
 tbs[parts[0]][parts[1]] = tbs.tbConfig.values[pp];
 } else if (parts.length == 3) {
 tbs[parts[0]][parts[1]][parts[2]] = tbs.tbConfig.values[pp];
 } else if (parts.length == 4) {
 tbs[parts[0]][parts[1]][parts[2]][parts[3]] = tbs.tbConfig.values[pp];
 }

 }
 } catch (e) {
 rsw_logException(e);
 }
 }

 var tbHeight = rsw_getElementHeight(tbs.iframe.id);
 if (tbHeight < 26 && tbs.multiline) { tbHeight = 36;
 tbs.iframe.style.height = tbHeight + rsS57[58];
 }

 tbs.updateIframe();
 try{
 if (tbs.iframe) {
 tbs.iframe.contentWindow.rsw_showMenu = rsw_showMenu;
 }
 } catch (excep) { rsw_logException(excep); }
 }

}

function rsw__unhook() {

 for (var i = 0; rsw_tbs != null && i < rsw_tbs.length; i++) {
 if (rsw_tbs[i] != null)
 rsw_tbs[i].unhook();
 }
}

function rsw__init(fromAJAXEnd) {
 if (rsw_haltProcesses) return;



 for (var ptr = 0; ptr < rsw_config.length; ptr++) {
 if (rsw_haltProcesses) return;

 var tbConfig = rsw_config[ptr];

 var myIFrame = rs_s3.getElementById(tbConfig.values[0]);

 if (myIFrame == null) { rsw_config.splice(ptr, 1); for (var sp = 0; sp < rsw_scs.length; sp++) {
 if (rsw_scs[sp].textBoxID + rsS57[35] == tbConfig.values[0]) rsw_scs.splice(sp, 1);
 }
 ptr--; continue;
 }

 if (myIFrame.nodeName.toUpperCase() === rsS57[272]) {
 rsw_tbs[ptr] = new LabelTB(myIFrame, true);
 } else {

 if (rsw_chrome || rsw_applewebkit)
 rsw_tbs[ptr] = new MozlyTB(myIFrame, true);
 else if (rsw_mozly)
 rsw_tbs[ptr] = new MozlyTB(myIFrame, true);
 else
 rsw_tbs[ptr] = new IETB(myIFrame, true);
 }
 rsw_tbs[ptr].enabled = tbConfig.values[1];
 rsw_tbs[ptr].CssSheetURL = tbConfig.values[2];

 try {
 rsw_tbs[ptr].tbConfig = tbConfig;
 rsw_tbs[ptr].initialize();

 } catch (ex) {
 rsw_logException(ex);
 }

 }


 rsw_activeTextbox = rsw_tbs[0];
 
 rsw_onFinish(fromAJAXEnd, 0);

}

function rsw_onFinish(fromAJAXEnd, attempts) {
 if (rsw_haltProcesses) return;
 if (!attempts) attempts = 0;
 if (rsw_id_waitingToInitialize != null && attempts < 100) {
 attempts++;
 eval(rsS57[273] + fromAJAXEnd + rsS57[274] + attempts + rsS57[275]);
 return;
 }

 
 if (fromAJAXEnd && rsw_autoFocusAfterAJAX) {
 if (rsw_tbs.length > 0) {
 var first = rsw_tbs[0];
 try{
 first.focus();
 } catch (x) {
 rsw_logException(x);
 }
 }
 }

 
 if (rs_s2.RS_OnTextBoxesInitialized)
 RS_OnTextBoxesInitialized();

 for (var h = 0; h < rsw_ObjsToInit.length; h++) {
 rsw_ObjsToInit[h].Init();
 }

 for (var h = 0; h < rsw_aux_oninit_handlers.length; h++) {
 eval(rsw_aux_oninit_handlers[h]);
 }

 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[276], null);
}

function rsw_spellCheckTextBox(textBox, optionalButton) {
 var found = false;
 if (textBox != null) {
 if (typeof (textBox.isStatic) == rsS57[277]) {
 for (var i = 0; i < rsw_scs.length; i++) {
 if (rsw_scs[i]!=null && rsw_scs[i].textBoxID == textBox.shadowTB.id && textBox.isDirty) {
 if (rsw_scs[i].rsw_tbs != null && rsw_scs[i].rsw_tbs.shadowTB != null && rsw_scs[i].rsw_tbs.shadowTB != textBox) {
 if (typeof (textBox.ifDoc != rsS57[12]))
 rsw_scs[i].rsw_tbs.shadowTB = rs_s3.getElementById(rsw_scs[i].rsw_tbs.shadowTBID);
 else
 rsw_scs[i].rsw_tbs.shadowTB = textBox; rsw_scs[i].tbInterface.searchedForTarget = false;
 }
 if (typeof (optionalButton) != rsS57[12]) rsw_scs[i].buttonID = optionalButton.id;
 rsw_scs[i].OnSpellButtonClicked();
 found = true;
 } else if (rsw_scs[i] != null && rsw_scs[i].textBoxID == textBox.shadowTB.id) found = true;
 }
 } else {
 for (var i = 0; i < rsw_scs.length; i++) {
 if (rsw_scs[i] != null && rsw_scs[i].textBoxID == textBox.id) {
 if (rsw_scs[i].rsw_tbs != null && rsw_scs[i].rsw_tbs.shadowTB != null && rsw_scs[i].rsw_tbs.shadowTB != textBox) {
 if (typeof (textBox.ifDoc != rsS57[12]))
 rsw_scs[i].rsw_tbs.shadowTB = rs_s3.getElementById(rsw_scs[i].rsw_tbs.shadowTBID);
 else
 rsw_scs[i].rsw_tbs.shadowTB = textBox; rsw_scs[i].tbInterface.searchedForTarget = false;
 }
 if (typeof (optionalButton) != rsS57[12]) rsw_scs[i].buttonID = optionalButton.id;
 rsw_scs[i].OnSpellButtonClicked();
 found = true;
 }
 }
 }
 }
 if (!found && typeof (rsw_addTextBoxSpellChecker) == rsS57[33]) { rsw_addTextBoxSpellChecker(textBox, true, 0);
 if (rsw_scs[rsw_scs.length - 1] != null) {
 if (typeof (optionalButton) != rsS57[12]) rsw_scs[rsw_scs.length - 1].buttonID = optionalButton.id;
 rsw_scs[rsw_scs.length - 1].OnSpellButtonClicked();
 }
 }
}


function rsw_createLink(contentWindowDoc, CssSheetURL) {
 var linkElement = contentWindowDoc.createElement(rsS57[278]);
 linkElement.type = rsS57[279];

 var url = (typeof (CssSheetURL) == rsS57[12] || CssSheetURL == rsS57[3]) ? rsw_rs_styleURL : CssSheetURL;
 contentWindowDoc.getElementsByTagName(rsS57[280])[0].appendChild(linkElement);
 linkElement.setAttribute(rsS57[281], url); linkElement.setAttribute(rsS57[282], rsS57[283]);
 

 }

function rsw_updateActiveTextbox(activeElement) {
 
 var o = rsw_getTBSFromElement(activeElement);
 if (o != null) {
 rsw_previouslyActiveTextbox = rsw_activeTextbox;
 rsw_activeTextbox = o;
 }

}

function rsw_getTBSFromElement(activeElement) {
 for (var i = 0; i < rsw_tbs.length; i++) {
 if (activeElement == rsw_tbs[i].ifDoc || activeElement == rsw_tbs[i].iframe
 || (rsw_tbs[i].iframe != null && typeof (rsw_tbs[i].iframe.contentWindow) != rsS57[12] && activeElement == rsw_tbs[i].iframe.contentWindow)
 || (rsw_tbs[i].iframe != null && typeof (rsw_tbs[i].iframe.contentWindow) != rsS57[12] && rsw_tbs[i].iframe.contentWindow != null && rsw_tbs[i].iframe.contentWindow.document != null && activeElement == rsw_tbs[i].iframe.contentWindow.document.documentElement)) {
 return rsw_tbs[i];
 }
 }
 return null;
}


function rsw_ignoreAll(error) {
 try{
 var errorText = error.innerHTML.replace(/<[^>]+>/g, rsS57[3]);
 var tError;
 for (var i = 0; i<rsw_tbs.length; i++) {
 rsw_ignoreAllTB(errorText, rsw_tbs[i]);
 }
 } catch (excep) { rsw_logException(excep); }
}

function rsw_ignoreAllTB(errorText, tb) {
 try{
 var errors = tb.getSpanElements();

 var changeIndexes = new Array();
 for (var i = 0; i < errors.length; i++) {
 tError = errors[i].innerHTML.replace(/<[^>]+>/g, rsS57[3]);
 if (errors[i].className == rsS57[284] && tError == errorText) {
 
 rsw_dehighlight(errors[i]);
 rsw_addIgnoreAllWord(errorText);
 i--;
 }
 }
 } catch (excep) { rsw_logException(excep); }

 }

function rsw_dehighlight(errorNode) {
 try {
 errorNode.removeNode(false);
 } catch (e) {
 errorNode.removeAttribute(rsS57[44]); errorNode.removeAttribute(rsS57[285]); errorNode.setAttribute(rsS57[286], rsS57[3]); }
}

function rsw_getTargetElement(e) {
 var relTarg;
 if (!e) var e = rs_s2.event;
 if (e.relatedTarget) relTarg = e.relatedTarget;
 else if (e.fromElement) relTarg = e.fromElement;
 return relTarg;
}


function rsw_edit(error) {
 try{
 rsw_activeTextbox.createEditBox(error);
 rsw_activeTextbox.OnCorrection(new RSW_CorrectionEvent(rsS57[287], error.innerHTML.replace(/<[^>]+>/g, rsS57[3]), rsS57[288]));
 } catch (excep) { rsw_logException(excep); }
}

function rsw_inlineTB_onBlur() {
 rsw_refreshActiveTextbox();
 rsw_activeTextbox.updateShadow();
}

function rsw_inlineTB_onkeypress(e) {
 var ev;
 if (typeof (e) != rsS57[12])
 ev = e;
 else
 ev = event;

 if (ev && ev.keyCode) {
 if (ev.keyCode == 13) {
 if (ev.preventDefault) ev.preventDefault();
 return false;
 }
 }
 return true;
}

function rsw_add(error) {
 try{
 rsw_refreshActiveTextbox();
 var errorText = rsw_innerHTMLToText(error.innerHTML);
 rsw_ignoreAll(error);
 rsw_inProcessSC = rsw_activeTextbox.spellChecker;
 rsw_serverAdd(errorText);
 } catch (excep) { rsw_logException(excep); }
}

function rsw_innerHTMLToText(html) {
 return html.replace(/<[^>]+>/g, rsS57[3]);
}


function rsw_innerText(node, lastElementInCollection, lastElementInCollectionIsBR) {
 var t = rsS57[3];
 var innerT;

 if (node.nodeName.toLowerCase() == rsS57[289])
 t = rsS57[159];

 if (node.nodeName.toLowerCase() == rsS57[290])
 t = String.fromCharCode(8226);

 var nV = null;
 try {
 nV = node.nodeValue; } catch (er) { }

 if (node.childNodes.length == 0) {
 if (nV && node.nodeType == 3) {

 if (rsw_activeTextbox != null && (rsw_activeTextbox.pasting )) {
 innerT = nV.replace(/\n/g, rsS57[39]).replace(/\r/g, rsS57[3]); } else
 innerT = nV.replace(/\n/g, rsS57[3]).replace(/\r/g, rsS57[3]); 

 while (rsw_newlineexp.test(innerT))
 innerT = innerT.replace(rsw_newlineexp, rsS57[3]);


 t += innerT; }
 } else {
 for (var i = 0; i < node.childNodes.length; i++)
 t += rsw_innerText(node.childNodes[i]);

 if (node.nodeName.toLowerCase() == rsS57[290]) t += rsS57[159];
 }
 if(!node.scopeName || (node.scopeName==rsS57[3] || node.scopeName==rsS57[291])){
 if (node.nodeName.toLowerCase() == rsS57[292])
 t += node.value;
 if (node.nodeName.toLowerCase() == rsS57[293] && !rsw_nodeHasTrailingBR(node) && !lastElementInCollection && (rsw_activeTextbox == null || rsw_activeTextbox.isStatic || node.parentElement == null || node.parentElement.nodeName.toLowerCase() != rsS57[50]) )
 t += rsS57[159];
 if (node.nodeName.toLowerCase() == rsS57[50] && !lastElementInCollection )
 t += rsS57[159];
 }
 return t;
}


function rsw_tagAddsNewline(node) {
 if (node && node.nodeName && (node.nodeName.toLowerCase() == rsS57[293] || node.nodeName.toLowerCase() == rsS57[50])) {
 return !rsw_nodeHasTrailingBR(node);
 }
 return false;
}

function rsw_nodeHasTrailingBR(node) {
 var textContent = false;
 for (var i = node.childNodes.length - 1; i >= 0; i--) {
 if (node.childNodes[i].childNodes.length > 0) {
 return rsw_nodeHasTrailingBR(node.childNodes[i]);
 } else {
 textContent |= rsw_nodeContainsText(node.childNodes[i]);
 if (node.childNodes[i].nodeName.toLowerCase() == rsS57[289]) 
 return !textContent;
 } 
 }
 return false;
}

function rsw_nodeContainsBR(node) {
 var contains = false;
 for (var i = 0; i < node.childNodes.length; i++) {
 contains = contains || node.childNodes[i].nodeName.toLowerCase() == rsS57[289];
 if (rsw_nodeContainsText(node.childNodes[i])) return false; }
 return contains;
}

function rsw_nodeContainsText(node) {
 if (node.nodeValue != null && node.nodeValue.length > 0) return true;
 for (var i = 0; i < node.childNodes.length; i++) {
 if (rsw_nodeContainsText(node.childNodes[i])) return true;
 }
 return false;
}

function rsw_stringContainsWhitespaceOnly(t) {
 for(var i=0; i<t.length; i++)
 if( !/\s/.test(t.charAt(i))) return false;
 return true;
}

var rsw_ignoreAllWords = new Array();
function rsw_addIgnoreAllWord(word) {
 var found = false;
 for (var i = 0; i < rsw_ignoreAllWords.length; i++)
 if (rsw_ignoreAllWords[i] == word)
 found = true;

 if (!found)
 rsw_ignoreAllWords[rsw_ignoreAllWords.length] = word;

}

function rsw_changeTo(error, replacement) {
 try{
 rsw_refreshActiveTextbox();
 var orig = rsw_activeTextbox.getShadowText();
 rsw_activeTextbox.changeTo(error, replacement);
 rsw_activeTextbox.updateShadow();

 rsw_activeTextbox.OnCorrection(new RSW_CorrectionEvent(rsS57[287], error.innerHTML.replace(/<[^>]+>/g, rsS57[3]), replacement, orig));
 } catch (excep) { rsw_logException(excep); }
}

function rsw_changeAllTo(error, replacement) {
 try{
 rsw_refreshActiveTextbox();
 var errorText = error.innerHTML.replace(/<[^>]+>/g, rsS57[3]);
 var tError;
 var errors = rsw_activeTextbox.getSpanElements();
 for (var i = 0; i < errors.length; i++) {
 tError = errors[i].innerHTML.replace(/<[^>]+>/g, rsS57[3]);
 if (errors[i].className == rsS57[284] && tError == errorText) {
 rsw_changeTo(errors[i], replacement);
 i--;
 }
 }
 } catch (excep) { rsw_logException(excep); }
}


function rsw_escapeHTML(t) {
 if (typeof (t) != rsS57[56]) return t;
 var pos = -1;
 while ((pos = t.indexOf(rsS57[294], pos + 1)) > -1)
 t = t.substring(0, pos) + rsS57[295] + t.substring(pos + 1);


 var exp1 = new RegExp(rsS57[168]);
 while (exp1.test(t)) t = t.replace(exp1, rsS57[194]);

 var exp2 = new RegExp(rsS57[169]);
 while (exp2.test(t)) t = t.replace(exp2, rsS57[195]);
 return t;
}

function rsw_unescapeHTML(t) {
 var pos = -1;
 while ((pos = t.indexOf(rsS57[295], pos + 1)) > -1)
 t = t.substring(0, pos) + rsS57[294] + t.substring(pos + 5);


 var exp1 = new RegExp(rsS57[194]);
 while (exp1.test(t)) t = t.replace(exp1, rsS57[168]);

 var exp2 = new RegExp(rsS57[195]);
 while (exp2.test(t)) t = t.replace(exp2, rsS57[169]);
 return t;
}








function RSWITextBox(controlClientID) {
 this.shadowTBID = controlClientID;
 this._getTBS = _getTBS;
 this._onKeyDown = _onKeyDown;
 this._onKeyUp = _onKeyUp;
 this._onKeyPress = _onKeyPress;
 this._onCorrection = _onCorrection;
 this._onPaste = _onPaste;
 this._onContextMenu = _onContextMenu;
 this._onBlur = _onBlur;
 this._onFocus = _onFocus;
 this._onMouseDown = _onMouseDown;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onMouseUp = _onMouseUp;
 this.tbs = null;
 rsw_ObjsToInit[rsw_ObjsToInit.length] = this;
 this.Init = Init;


 function Init() {
 this._getTBS();
 }

 function _getTBS() {
 if (this.tbs == null) {
 this.tbs = rsw_getTBSFromID(this.shadowTBID, false);
 this.tbs.repObj = this; }

 return this.tbs;
 }

 function _onKeyDown(e) { if (typeof (this.OnKeyDown) == rsS57[33]) this.OnKeyDown(this, e); }
 function _onKeyUp(e) { if (typeof (this.OnKeyUp) == rsS57[33]) this.OnKeyUp(this, e); }
 function _onKeyPress(e) { if (typeof (this.OnKeyPress) == rsS57[33]) this.OnKeyPress(this, e); }
 function _onCorrection(e) { if (typeof (this.OnCorrection) == rsS57[33]) this.OnCorrection(this, e); }
 function _onPaste(e) { if (typeof (this.OnPaste) == rsS57[33]) this.OnPaste(this, e); }
 function _onContextMenu(e) { if (typeof (this.OnContextMenu) == rsS57[33]) this.OnContextMenu(this, e); }
 function _onBlur(e) { if (typeof (this.OnBlur) == rsS57[33]) this.OnBlur(this, e); }
 function _onFocus(e) { if (typeof (this.OnFocus) == rsS57[33]) this.OnFocus(this, e); }
 function _onMouseDown(e) { if (typeof (this.OnMouseDown) == rsS57[33]) this.OnMouseDown(this, e); }
 function _onMouseUp(e) { if (typeof (this.OnMouseUp) == rsS57[33]) this.OnMouseUp(this, e); }
 function _onClick(e) { if (typeof (this.OnClick) == rsS57[33]) this.OnClick(this, e); }
 function _onDblClick(e) { if (typeof (this.OnDblClick) == rsS57[33]) this.OnDblClick(this, e); }


 this.GetText = GetText;
 this.SetText = SetText;
 this.OnKeyDown;
 this.OnKeyUp;
 this.OnKeyPress;
 this.OnCorrection;
 this.OnPaste;
 this.OnContextMenu;
 this.OnBlur;
 this.OnFocus;
 this.OnMouseDown;
 this.OnMouseUp;
 this.OnClick;
 this.GetNumberOfErrors = GetNumberOfErrors;
 this.Focus = Focus;
 this.SetDisabled = SetDisabled;
 this.Select = Select;

 function SetDisabled(disabled) {
 var tbs = this._getTBS();
 return tbs.setDisabled(disabled);
 }

 function Select() {
 var tbs = this._getTBS();
 tbs.select();
 }

 function GetText() {
 var tbs = this._getTBS();
 return tbs.shadowTB.value;
 }

 function SetText(text) {
 var tbs = this._getTBS();

 rsw_setShadowTB(tbs.shadowTB, text);
 
 tbs.updateIframe();

 }

 function GetNumberOfErrors() {
 var tbs = this._getTBS();
 return tbs.getNumberOfErrors();
 }

 function Focus() {
 var tbs = this._getTBS();
 return tbs.focus();
 }

}



function RSWITextBox_DownLevel(controlClientID) {
 this.shadowTBID = controlClientID;
 this._getTBS = _getTBS;
 this._onKeyDown = _onKeyDown;
 this._onKeyUp = _onKeyUp;
 this._onKeyPress = _onKeyPress;
 this._onCorrection = _onCorrection;
 this._onPaste = _onPaste;
 this._onContextMenu = _onContextMenu;
 this._onBlur = _onBlur;
 this._onFocus = _onFocus;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this.tbs = null;
 rsw_ObjsToInit[rsw_ObjsToInit.length] = this;

 RSWITextBox_DownLevels[RSWITextBox_DownLevels.length] = this;
 this.Init = Init;
 this.shadowTB; this._getShadowTB = _getShadowTB;

 function Init() {
 this._getShadowTB().onkeydown = this._onKeyDown;
 this._getShadowTB().onkeyup = this._onKeyUp;
 this._getShadowTB().onkeypress = this._onKeyPress;
 this._getShadowTB().onpaste = this._onPaste;
 this._getShadowTB().oncontextmenu = this._onContextMenu;
 this._getShadowTB().onblur = this._onBlur;
 this._getShadowTB().onfocus = this._onFocus;
 this._getShadowTB().onmouseup = this._onMouseUp;
 this._getShadowTB().onmousedown = this._onMouseDown;
 this._getShadowTB().onclick = this._onClick;
 this._getShadowTB().ondblclick = this._onDblClick;

 }

 function _getShadowTB() {
 if (this.shadowTB == null) this.shadowTB = rs_s3.getElementById(this.shadowTBID);
 return this.shadowTB;
 }

 function _getTBS() {
 if (this.tbs == null) {
 this.tbs = rsw_getTBSFromID(this.shadowTBID, false);
 this.tbs.repObj = this; }

 return this.tbs;
 }

 function _tb(e) {
 if (e)
 return _findRSWITextBox_DownLevel(e.target.id);
 else
 return _findRSWITextBox_DownLevel(event.srcElement.id);
 }
 function _findRSWITextBox_DownLevel(id) {
 for (var i = 0; i < RSWITextBox_DownLevels.length; i++) {
 if (RSWITextBox_DownLevels[i].shadowTBID == id) return RSWITextBox_DownLevels[i];
 }
 return null;
 }

 function _onKeyDown(e) { var tb = _tb(e); if (typeof (tb.OnKeyDown) == rsS57[33]) tb.OnKeyDown(tb, e != null ? e : event); }
 function _onKeyUp(e) { var tb = _tb(e); if (typeof (tb.OnKeyUp) == rsS57[33]) tb.OnKeyUp(tb, e != null ? e : event); }
 function _onKeyPress(e) { var tb = _tb(e); if (typeof (tb.OnKeyPress) == rsS57[33]) tb.OnKeyPress(tb, e != null ? e : event); }
 function _onCorrection(e) { var tb = _tb(e); if (typeof (tb.OnCorrection) == rsS57[33]) tb.OnCorrection(tb, e != null ? e : event); }
 function _onPaste(e) { var tb = _tb(e); if (typeof (tb.OnPaste) == rsS57[33]) tb.OnPaste(tb, e != null ? e : event); }
 function _onContextMenu(e) { var tb = _tb(e); if (typeof (tb.OnContextMenu) == rsS57[33]) tb.OnContextMenu(tb, e != null ? e : event); }
 function _onBlur(e) { var tb = _tb(e); if (typeof (tb.OnBlur) == rsS57[33]) tb.OnBlur(tb, e != null ? e : event); }
 function _onFocus(e) { var tb = _tb(e); if (typeof (tb.OnFocus) == rsS57[33]) tb.OnFocus(tb, e != null ? e : event); }
 function _onMouseDown(e) { var tb = _tb(e); if (typeof (tb.OnMouseDown) == rsS57[33]) tb.OnMouseDown(tb, e != null ? e : event); }
 function _onMouseUp(e) { var tb = _tb(e); if (typeof (tb.OnMouseUp) == rsS57[33]) tb.OnMouseUp(tb, e != null ? e : event); }
 function _onClick(e) { var tb = _tb(e); if (typeof (tb.OnClick) == rsS57[33]) tb.OnClick(tb, e != null ? e : event); }
 function _onDblClick(e) { var tb = _tb(e); if (typeof (tb.OnClick) == rsS57[33]) tb.OnDblClick(tb, e != null ? e : event); }


 this.GetText = GetText;
 this.SetText = SetText;
 this.OnKeyDown;
 this.OnKeyUp;
 this.OnKeyPress;
 this.OnCorrection;
 this.OnPaste;
 this.OnContextMenu;
 this.OnBlur;
 this.OnFocus;
 this.OnMouseDown;
 this.OnMouseUp;
 this.GetNumberOfErrors = GetNumberOfErrors;
 this.Focus = Focus;
 this.SetDisabled = SetDisabled;
 this.Select = Select;
 this.OnClick;
 function Select() {
 this._getShadowTB().select();
 }


 function SetDisabled(disabled) {
 this._getShadowTB().disabled = disabled;
 }


 function GetText() {
 return this._getShadowTB().value;
 }

 function SetText(text) {
 this._getShadowTB().value = text;
 }

 function GetNumberOfErrors() {
 var tbs = this._getTBS();
 return tbs.getNumberOfErrors();
 }

 function Focus() {
 return this._getShadowTB().focus();
 }

}


function rsw_broadcastToListeners(eventType, evt, tb) { rsw_refreshActiveTextbox();
 if (eventType == rsS57[296]) {
 rsw_activeTextbox.rsw_key_downed_flag = true;
 rsw_activeTextbox.rsw_key_downed_within_lim = true;
 if (rsw_key_down_timer != null) clearTimeout(rsw_key_down_timer);
 rsw_key_down_timer = setTimeout(rsS57[297], rsw_key_down_timeout);
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[159] + rsw_debug_getTime() + rsw_activeTextbox.shadowTBID+rsS57[298] + String.fromCharCode(rsw_activeTextbox.iframe.contentWindow.event.keyCode);
																																						
 }

 if (rs_s2._INT_notifyTextBoxListeners)
 _INT_notifyTextBoxListeners(eventType, evt, tb);

 if (rs_s2._notifyTextBoxListeners)
 _notifyTextBoxListeners(eventType, evt);
}






function RSW_IntEvent(eventType) { this.type = eventType; }
function RSW_CorrectionEvent(eventType, errorWord, replacement, oldText) { this.type = eventType; this.errorWord = errorWord, this.replacement = replacement; this.originalText = oldText; }



function IETB(iframeEl, editable) {
 this.skipAYTUpdates = false;
 this.iframe = iframeEl;
 this.editable = editable;
 this.ifDoc; this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onKeyUp = _onKeyUp;
 this._onKeyDown = _onKeyDown;
 this._onPaste = _onPaste;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onContextMenu = _onContextMenu;
 this._onFocus = _onFocus;
 this._onBlur = _onBlur;
 this.focus = focus;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = false;
 this.getContentText = getContentText;
 this.selectedErrorNode = selectedErrorNode;
 this.containsElement = containsElement;
 this.multiline = true;
 this.enabled = true;
 this.maxlength = 0;
 this.shadowTB;
 this.shadowTBID;
 this.updateIframe = updateIframe;
 this.updateShadow = updateShadow;
 this.getShadowText = getShadowText;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.oldOnBlur;
 this.oldOnFocus;
 this.isDirty = false;
 this.recordCaretPos = recordCaretPos;
 this.resetCaretPos = resetCaretPos;
 this.setCaretPos = setCaretPos;
 this.caretBL;
 this.caretBT;
 this.selectedText;
 this.CssSheetURL;
 this.getNumberOfErrors = getNumberOfErrors;
 this.textIsXHTML;
 this.unhook = unhook; this.repObj = null;
 this.setDisabled = setDisabled;
 this.select = select;
 this.isFocused = false;
 this.insertErrorHighlights = insertErrorHighlights;
 this.attachEvents = attachEvents;
 this.isVisible = isVisible;
 this.container = container;
 this.isShowingPlaceholder = false;
 this.placeHolderText = null;
 this.submitOnEnterForSingleLine = true;
 this.showPlaceholder = function () {
 if (this.placeHolderText == null)
 this.placeHolderText = this.shadowTB.getAttribute(rsS57[299]);

 if (this.placeHolderText != null && this.placeHolderText.length > 0 && this.getShadowText().length == 0) {
 this.isShowingPlaceholder = true;
 this.setContent(rsS57[300] + this.placeHolderText + rsS57[301]);
 
 }
 };
 this.hidePlaceholder = function () {
 if (this.isShowingPlaceholder) {
 this.setContent(rsS57[3]);
 this.isShowingPlaceholder = false;
 }
 };



 this.currentEventDefaultPrevent = false;
 this.preventDefaultCurrentEvent = function () {
 this.currentEventDefaultPrevent = true;
 }
 this.processDefaultPrevented = function (event) {
 if (this.currentEventDefaultPrevent) {
 event.preventDefault();
 event.cancelBubble = true;
 }
 this.currentEventDefaultPrevent = false;
 }

 function container() {
 if (this.iframe != null) {
 if(this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }

 function isVisible() {
 try{
 
 if (this.iframe == null) return false;
 var rect = this.iframe.getBoundingClientRect();
 return rect.left != 0 || rect.top != 0 || rect.bottom != 0 || rect.right != 0;
 } catch (excep) { rsw_logException(excep); return false;}
 }

 function select() {
 this.focus();

 var r = this.ifDoc.selection.createRange();
 r.expand(rsS57[302]);
 r.select();
 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS57[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); return 0;}
 }

 function insertErrorHighlights(result, client) {

 try {




 var selection = this.ifDoc.selection;
 var selRange = selection.createRange().duplicate();
 var bookmark = selRange.getBookmark();
 var range; 
 var numRs;
 var content = this.getContentText();

 var calibration = -1;
 range = this.ifDoc.body.createTextRange().duplicate();
 range.collapse(true);

 var contentChar;
 var rangeCharCode;
 var contentCharCode;
 var lookingForLeadingSpace = false;


 
 var start = 0;
 var k = 0;
 var numberOfChars = 0;
 for (var i = 0; i < result.errorPositionArray.length; i++) {
 
 if (i > 0) start = result.errorPositionArray[i - 1].start;

 lookingForLeadingSpace = result.errorPositionArray[i].word.charAt(0) == rsS57[39];

 if (lookingForLeadingSpace) result.errorPositionArray[i].start++;

 for (var j = start; j <= result.errorPositionArray[i].start; j++) {

 contentCharCode = content.charCodeAt(j);
 if (
 (contentCharCode > 0x20 && contentCharCode < 0x7f) || contentCharCode > 0xA1

 ) numberOfChars++;
 }



 

 
 do {

 range.moveEnd(rsS57[303], 1);
 rangeCharCode = range.text.charCodeAt(0);
 if ((rangeCharCode > 0x20 && rangeCharCode < 0x7f) || rangeCharCode > 0xA1) k++;


 range.move(rsS57[303], 1);

 } while (k < numberOfChars);

 if (lookingForLeadingSpace)
 range.move(rsS57[303], -2); else
 range.move(rsS57[303], -1); 
 var startRangeParent = range.parentElement();

 if (lookingForLeadingSpace)
 delta = -1;
 else
 delta = 0;
 range.moveEnd(rsS57[303], (result.errorPositionArray[i].end - result.errorPositionArray[i].start) - delta);

 var rangeParent = range.parentElement();
 if (rangeParent.nodeName == rsS57[304]) {
 rangeParent.removeNode(false); rangeParent = range.parentElement();
 }

 if (rangeParent != null && (rangeParent.getAttribute(rsS57[44]) == null || rangeParent.getAttribute(rsS57[44]) != rsS57[284]) && range.text == result.errorPositionArray[i].word) {
 if (startRangeParent.getAttribute(rsS57[44]) == rsS57[284]) startRangeParent.removeNode(false); 
 range.execCommand(rsS57[305], false);
 var span = this.ifDoc.createElement(rsS57[306]);
 span.setAttribute(rsS57[285], rsS57[284]); span.setAttribute(rsS57[44], rsS57[284]); 
 var mouseup = client.createErrorMouseUp(result.errorPositionArray[i].suggestions);
 span.setAttribute(rsS57[307], mouseup);

 
 span.onmouseup = function () { rsw_clickedSpan = this; };

 

 span.attachEvent(rsS57[286], function () { if (rsw_clickedSpan != null) { var suggsClean = rsw_clickedSpan.getAttribute(rsS57[307]); rsw_showMenu(rsw_getSuggestionsArray(suggsClean), rsw_clickedSpan, arguments[0]);
																																						 } rsw_clickedSpan = null; }); span.oncontextmenu = function () { try { event.cancelBubble = true; event.preventDefault(); } catch (e) { } return false; };
 var italic = range.parentElement();
 italic.applyElement(span, rsS57[308]);
 italic.removeNode(false);

 
 }
 }

 
 } catch (e) {
 }
 }


 function recordCaretPos() {
 
 try {
 var selection = this.ifDoc.selection;
 var range = selection.createRange().duplicate();
 

 if (rsw_ie9) {

 var start = 0, end = 0, normalizedValue, textInputRange, len, endRange;
 el = this.ifDoc;
 
 this.origTextInRange = this.getContentText();
 len = this.origTextInRange.length;
 normalizedValue = this.origTextInRange.replace(/\r\n/g, rsS57[25]); textInputRange = this.ifDoc.body.createTextRange();

 var ie = IeVersion();
 if(ie.TrueVersion==9) textInputRange.moveToBookmark(range.getBookmark());


 endRange = this.ifDoc.body.createTextRange();
 endRange.collapse(false);

 

 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[309] + textInputRange.text + rsS57[39] + textInputRange.compareEndPoints(rsS57[310], endRange);
 if (textInputRange.compareEndPoints(rsS57[310], endRange) > -1) {
 start = end = len;
 } else {
 start = -textInputRange.moveStart(rsS57[303], -len);
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[311] + textInputRange.compareEndPoints(rsS57[312], endRange);
 if (textInputRange.compareEndPoints(rsS57[312], endRange) > -1) {
 end = len;
 } else {
 end = -textInputRange.moveEnd(rsS57[303], -len);
 end += normalizedValue.slice(0, end).split(rsS57[25]).length - 1;
 }


 }



 this.cursorPosition = start;
 } else {

 range.moveStart(rsS57[313], -9000000);

 this.origTextInRange = range.text.replace(/\n/g, rsS57[3]);
 
 this.cursorPosition = this.origTextInRange.length;

 }



 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[314] + this.cursorPosition;
 } catch (excep) { if (rsw_debug) rsw_logException(excep); }
 }

 function setCaretPos(characterIndex) {
 var selection = this.ifDoc.selection;
 var newRange = selection.createRange();
 newRange.move(rsS57[313], -9000000);
 newRange.moveStart(rsS57[303], characterIndex);
 newRange.collapse(false);
 newRange.select();
 }

 function resetCaretPos() {

 try {
 var selection = this.ifDoc.selection;
 var newRange = selection.createRange();
 newRange.move(rsS57[313], -9000000);
 var o = newRange.moveEnd(rsS57[303], this.cursorPosition);
 var ignNewL = this.origTextInRange.replace(/\r/g, rsS57[3]);
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[315] + o + rsS57[316] + newRange.text.indexOf(rsS57[24]) + rsS57[317] + newRange.text.replace(/\r\n/g, rsS57[25]) + rsS57[318] + ignNewL + rsS57[319];
																																						 ;
 var moveAmount = 1;
 
 
 if (navigator.userAgent.indexOf(rsS57[320]) > -1)
 newRange.moveStart(rsS57[303], this.cursorPosition); else
 newRange.collapse(false);
 newRange.select();

 } catch (excep) { if (rsw_debug) rsw_logException(excep); }

 }

 

 
 



 function OnCorrection(e) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e);



 rsw_broadcastToListeners(rsS57[287], e);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[321], rsw_activeTextbox, e);
 }

 function focus() {
 try{
 this.iframe.contentWindow.focus();
 } catch (excep) { rsw_logException(excep); } try { this.iframe.focus(); } catch (e) { }
 try {
 this.iframe.contentWindow.focus();
 } catch (excep) { rsw_logException(excep); } this.isFocused = true;

 try {
 var caret = this.ifDoc.selection.createRange();
 correctCaret(caret);
 } catch (excep) { rsw_logException(excep); }
 }


 function containsElement(element) {
 return element.ownerDocument == this.ifDoc;
 }


 function selectedErrorNode() {
 rsw_refreshActiveTextbox();
 try {
 var selection = rsw_activeTextbox.ifDoc.selection;
 var parentEl = selection.createRange().parentElement();



 if (parentEl.className == rsS57[284])
 return parentEl;
 else {

 if (parentEl.children.length > 0 && parentEl.children[parentEl.children.length - 1].className==rsS57[284]) {
 var r = this.ifDoc.body.createTextRange();
 r.moveToElementText(parentEl.children[parentEl.children.length - 1]);
 var r2 = selection.createRange();
 if (r.compareEndPoints(rsS57[312], r2) == 0) {
 return parentEl.children[parentEl.children.length - 1];
 } else {
 r2.moveStart(rsS57[303], r.compareEndPoints(rsS57[312], r2));
 if (r2.text == rsS57[175]) return parentEl.children[parentEl.children.length - 1]; }
 }
 return null;
 }
 } catch (excep) { rsw_logException(excep); 
 return null;
 }
 }

 function getAbsX(element, event) {
 
 try {
 return element.getBoundingClientRect().left + rsw_activeTextbox.iframe.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 }

 function getAbsY(element, event) {
 
 try{
 return element.getBoundingClientRect().top + rsw_activeTextbox.iframe.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); }
 }

 function changeTo(error, replacement) {
 try {
 var repl = this.ifDoc.createTextNode(replacement);
 error.parentNode.replaceChild(repl, error);
 } catch (e) {
 return null;
 }
 }

 function getSpanElements() {
 return this.ifDoc.getElementsByTagName(rsS57[306]);
 }


 function _onKeyPress() {
 
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 rsw_hideCM();

 var evt = null;

 try{
 evt = rsw_activeTextbox.iframe.contentWindow.event;
 } catch (excep) { rsw_logException(excep); }



 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);


 if (evt != null && evt.keyCode == 13 && !rsw_activeTextbox.multiline) {
 evt.returnValue = false;
 if (rsw_activeTextbox.submitOnEnterForSingleLine)
 rsw_activeTextbox.shadowTB.form.submit();
 } else if (evt != null && evt.keyCode == 13) {
 
 }

 rsw_activeTextbox.isDirty = true;

 if (rsw_activeTextbox.maxlength > 0) {
 if (rsw_activeTextbox.getContentText().replace(/\r/g, rsS57[3]).replace(/\n/g, rsS57[3]).length >= rsw_activeTextbox.maxlength)
 evt.returnValue = false;
 }

 try{
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyPress(rsw_activeTextbox.iframe.contentWindow.event);
 


 rsw_broadcastToListeners(rsS57[322], rsw_activeTextbox.iframe.contentWindow.event);


 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[322], rsw_activeTextbox, event);



 } catch (excep) { rsw_logException(excep); }

 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[322], rsw_activeTextbox, evt);
 if(rsw_activeTextbox!=null)rsw_activeTextbox.processDefaultPrevented(evt);
 }


 function _onKeyDown() {
 
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 try{
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyDown(rsw_activeTextbox.iframe.contentWindow.event);

 var event = rsw_activeTextbox.iframe.contentWindow.event;
 if (event != null && ((event.keyCode >= 33 && event.keyCode <= 40) || event.keyCode == 13) && rsw_contextMenu != null && rsw_contextMenu.isVisible) {
 event.cancelBubble = true;
 if(rsw_contextMenu!=null)rsw_contextMenu.onkeydown(event);
 return false;
 }
 if (event != null && event.keyCode == 13 && !rsw_activeTextbox.multiline) {
 event.preventDefault();
 event.cancelBubble = true; 
 return;
 }

 rsw_activeTextbox.lastKeyDown = event.keyCode;

 rsw_broadcastToListeners(rsS57[296], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[296], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[296], rsw_activeTextbox, event);

 } catch (x) { rsw_consoleLog(x.message + rsS57[34] + x.name + rsS57[34] + x.toString(), true); }
 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function _onKeyUp() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 var evt = rsw_activeTextbox.iframe.contentWindow.event;
 if (evt.keyCode != 93 && (!(evt.keyCode >= 33 && evt.keyCode <= 40))) rsw_hideCM();

 if (!rsw_ie9) rsw_activeTextbox.ifDoc.body.createTextRange().execCommand(rsS57[323]); 
 if (evt == null || (!(evt.keyCode >= 33 && evt.keyCode <= 40) && evt.keyCode != 93)) { var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);

 }





 if (evt.keyCode == 93) {

 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS57[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, errorNode, evt);
 }
 } catch (ex) {
 rsw_logException(ex);
 }
 }
 return;
 }
 if (evt != null && ((evt.keyCode >= 33 && evt.keyCode <= 40) || evt.keyCode == 13) && rsw_contextMenu != null && rsw_contextMenu.isVisible) { return;
 }




 rsw_activeTextbox.updateShadow();

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyUp(evt);


 rsw_broadcastToListeners(rsS57[324], evt);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[324], rsw_activeTextbox, evt);

 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[324], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[292], rsw_activeTextbox, event);

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(evt);
 }



 function _onMouseDown() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;

 if (rsw_activeTextbox == null) { if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS57[12])
 rsw_updateActiveTextbox(this.document);
 else
 rsw_updateActiveTextbox(this);
 }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(rsw_activeTextbox.iframe.contentWindow.event);

 rsw_hideCM();

 var activeElement;
 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS57[12])
 activeElement = this.document;
 else
 activeElement = this;

 rsw_broadcastToListeners(rsS57[325], rsw_activeTextbox.iframe.contentWindow.event, rsw_getTBSFromElement(activeElement));


 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[325], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 rsw_activeTextbox.updateShadow();
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 function _onMouseUp() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(rsw_activeTextbox.iframe.contentWindow.event);


 rsw_broadcastToListeners(rsS57[326], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[326], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 function _onDblClick() {
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[327], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }


 function _onClick() {
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 
 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[328], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 this.textAtFocus=rsS57[3];
 function _onFocus(event, circle) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;

 

 if ((typeof (rsw_useIFrameMenuBacker) == rsS57[12] || rsw_useIFrameMenuBacker) && !rsw_activeTextbox.isFocused) rsw_hideCM();


 rsw_activeTextbox.updateShadow();
 


 rsw_updateActiveTextbox(this); 
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;

 if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS57[12]) {
 rsw_yScroll = rsw_getScrollY(rsw_activeTextbox.iframe.contentWindow);
 rsw_activeTextbox.ifDoc.body.className += rsS57[329];
 }


 rsw_activeTextbox.hidePlaceholder();

 rsw_activeTextbox.isFocused = true;

 if (rsw_correctCaret) {
 var caret = rsw_activeTextbox.ifDoc.selection.createRange();
 correctCaret(caret);
 }
 
 rsw_broadcastToListeners(rsS57[330], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[330], rsw_activeTextbox, event);

 if (navigator.userAgent.indexOf(rsS57[320]) > -1 || navigator.userAgent.indexOf(rsS57[331]) > -1) {
 rsw_activeTextbox.ifDoc.body.setAttribute(rsS57[332], rsS57[211]);
 if (rsw_yScroll != null) rsw_setScrollY(rsw_activeTextbox.iframe.contentWindow, rsw_yScroll ); }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onFocus(new RSW_IntEvent(rsS57[330]));

 if (rsw_activeTextbox.oldOnFocus && rsw_activeTextbox.oldOnFocus != rsw_activeTextbox._onFocus && !circle) rsw_activeTextbox.oldOnFocus(event, true);

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function _onBlur(event, circle) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rs_s3.activeElement != null && rs_s3.activeElement.id != rsw_activeTextbox.iframe.id) {
 rsw_activeTextbox.isFocused = false;
 rsw_activeTextbox.rsw_key_downed_within_lim = false; rsw_activeTextbox.updateShadow();

 rsw_activeTextbox.ifDoc.body.className = rsw_activeTextbox.ifDoc.body.className.replace(/(?:^|\s)rsw_focused(?!\S)/g, rsS57[3]);
 }
 
 function callOnchange(event, textbox)
 {
 return function () {
 
 try {
 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[333], textbox);
 else if (typeof (textbox.shadowTB.onchange) == rsS57[33]) textbox.shadowTB.onchange(event);
 } catch (x) { }
 }
 }

 
 if (rsw_activeTextbox != null && rsw_activeTextbox.textAtFocus != rsw_activeTextbox.shadowTB.value && (rsw_contextMenu == null || !rsw_contextMenu.isVisible)) {
 setTimeout(callOnchange(event, rsw_activeTextbox), 0);
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;
 }
 

 if (navigator.userAgent.indexOf(rsS57[320]) > -1 || navigator.userAgent.indexOf(rsS57[331]) > -1) rsw_activeTextbox.ifDoc.body.setAttribute(rsS57[332], rsS57[334]);

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onBlur(new RSW_IntEvent(rsS57[335]));

 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[336];
 if (rsw_activeTextbox != null && rsw_activeTextbox.isAYT && rsw_spellCheckOnBlur) rsw_spellCheckTextBox(rsw_activeTextbox);

 rsw_broadcastToListeners(rsS57[335], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[335], rsw_activeTextbox, event);


 if (rsw_activeTextbox != null && rsw_activeTextbox.oldOnBlur && rsw_activeTextbox.oldOnBlur != rsw_activeTextbox._onBlur && !circle) rsw_activeTextbox.oldOnBlur(event, true);

 rsw_activeTextbox.showPlaceholder();
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function setContent(content, contentIsFromShadow) {
 try {
 if (contentIsFromShadow) this.hidePlaceholder();
 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[337] + content + rsS57[338] + contentIsFromShadow;
 var pos = -1;
 var ppos = 0;
 var t = rsS57[3];
 while ((pos = content.indexOf(rsS57[25], pos + 1)) > -1) {
 if (pos > ppos + 2) {
 
 if (content.substring(pos - 1, pos) == rsS57[24])
 t += content.substring(ppos, pos - 1) + rsS57[339];
 else
 t += content.substring(ppos, pos) + rsS57[339];


 } else {
 if (content.charAt(ppos) != rsS57[24])
 t += content.substring(ppos, pos) + rsS57[339]; else
 t += rsS57[339];

 }
 ppos = pos + 1;
 }

 

 
 if ((ppos < content.length || ppos == 0) && !rsw_ie9Standards) {
 } else if (ppos == content.length) { 
 } else {

 }

 t += content.substring(ppos, content.length);


 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);
 ppos = pos;
 }

 t = rsS57[340] + t + rsS57[341];
 } else {

 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {
 if (pos + 1 < t.length && (t.charAt(pos + 1) == rsS57[39] || (pos > 4 && t.charAt(pos - 1) == rsS57[169] && t.substring(pos - 5, pos - 1) != rsS57[306]))) { opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);

 }
 ppos = pos;
 }
 }
 
 }
 if (this.ifDoc!=null && this.ifDoc.body != null) this.ifDoc.body.innerHTML = t;



 

 

 if (!contentIsFromShadow && this.ifDoc != null && this.ifDoc.body != null) this.updateShadow();
 } catch (excep) { rsw_logException(excep); }
 }

 function correctCaret(caret) {

 if (caret.text.length == 0 && caret.moveStart(rsS57[303], -1) < 0) {
 caret.select();
 caret.moveStart(rsS57[303], 1);
 caret.select();
 caret.collapse(true);
 }
 caret.select();

 }

 function getContent() {
 try{
 return this.ifDoc.body.innerHTML;
 } catch (excep) { rsw_logException(excep); return rsS57[3];}
 }


 function getContentText() {
 if (this.ifDocElement == null || this.isShowingPlaceholder) return rsS57[3];
 var contentElements;
 for(var i=0; i<this.ifDocElement.childNodes.length;i++)
 if (this.ifDocElement.childNodes[i].tagName==rsS57[78]) contentElements = this.ifDocElement.childNodes[i].childNodes;
 var contents = rsS57[3];
 if (contentElements == null) return rsS57[3];
 for (var i = 0; i < contentElements.length; i++) {
 var nV = null;
 try {
 nV = contentElements[i].nodeValue; } catch (er) { }
 if (nV)
 contents += nV;
 else if (contentElements[i].nodeName.toLowerCase() == rsS57[289] && i < contentElements.length - 1) contents += rsS57[159];
 else if (contentElements[i].nodeName.toLowerCase() == rsS57[292])
 contents += contentElements[i].value;
 else contents += rsw_innerText(contentElements[i],
 i == contentElements.length - 1, contentElements[contentElements.length - 1].nodeName.toLowerCase() == rsS57[289]); 
 
 
 }
 

 return contents;
 }



 
 function _onContextMenu() {
 var returnV = true;
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(rsw_activeTextbox.iframe.contentWindow.event);

 if (rsw_activeTextbox.lastKeyDown && rsw_activeTextbox.lastKeyDown == 93) {
 var e = rsw_activeTextbox.iframe.contentWindow.event;
 e.cancelBubble = true;
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS57[307]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 e.keyCode = 93;
 rsw_showMenu(suggestions, errorNode, e);
 returnV = false;
 }
 } catch (ex) {

 }
 }
 } else if (navigator.userAgent.indexOf(rsS57[320]) > -1 || navigator.userAgent.indexOf(rsS57[342]) > -1) {
 if(rsw_activeTextbox.selectedErrorNode()!=null){
 returnV = false; }
 }



 rsw_broadcastToListeners(rsS57[343], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[343], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);
 } catch (excep) { rsw_logException(excep); }
 return returnV;
 }

 function _onPaste() {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onPaste(rsw_activeTextbox.iframe.contentWindow.event);
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);
 setTimeout(rsS57[344] +
 rsS57[345], 300);

 rsw_broadcastToListeners(rsS57[346], rsw_activeTextbox.iframe.contentWindow.event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[346], rsw_activeTextbox, rsw_activeTextbox.iframe.contentWindow.event);
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(rsw_activeTextbox.iframe.contentWindow.event);
 }

 function initialize(attempts) {
 try{


 var ifID;
 if (!this.iframe)
 ifID = this.tbConfig.values[0];
 else
 ifID = this.iframe.id;

 this.shadowTBID = ifID.substring(0, ifID.length - 3); this.shadowTB = rs_s3.getElementById(this.shadowTBID);

 


 if (rsw_id_waitingToInitialize == null) rsw_id_waitingToInitialize = ifID;
 if (!attempts) attempts = 0;
 try {
 if ((!this.iframe.contentWindow.loaded && attempts < 100) || attempts == 0 || rsw_id_waitingToInitialize != ifID) { var time = 50;
 attempts++;
 eval(rsS57[347] + this.shadowTBID + rsS57[348] + attempts + rsS57[349] + time + rsS57[350]);
 return;
 }
 } catch (xx) {
 var time = 50;
 attempts++;
 eval(rsS57[347] + this.shadowTBID + rsS57[348] + attempts + rsS57[349] + time + rsS57[350]);
 return;
 }
 rsw_id_waitingToInitialize = null;
 
 this.ifDoc = this.iframe.contentWindow.document;

 this.iframe.contentWindow.document.documentElement.setAttribute(rsS57[351], false);

 this.ifDocElement = this.iframe.contentWindow.document.documentElement;

 function getDefaultFontSize(pa) {
 pa = pa || rs_s3.body;
 var who = rs_s3.createElement(rsS57[50]);

 who.style.cssText = rsS57[352];

 who.appendChild(rs_s3.createTextNode(rsS57[353]));
 pa.appendChild(who);
 var fs = [who.offsetWidth, who.offsetHeight];
 try{
 pa.removeChild(who);
 } catch (x) { } return fs;
 }


 this.iframe.contentWindow.document.documentElement.style.fontSize = getDefaultFontSize(this.shadowTB.parentElement)[1]+rsS57[58];
 
 rsw_createLink(this.ifDoc, this.CssSheetURL);

 this.ifDoc.styleSheets[0].addRule(rsS57[257], rsS57[354]);

 if (this.enabled) {
 
 if (this.editable) { this.ifDoc.body.setAttribute(rsS57[332], rsS57[211]);
 }

 this.attachEvents();

 }

 rsw_setSettings(this);

 if (this.enabled) 
 this.showPlaceholder();

 } catch (excep) { rsw_logException(excep); }

 
 }

 function attachEvents() {
 if (this.ifDocElement.onmousedown != this._onMouseDown) {
 this.ifDocElement.onmousedown = this._onMouseDown;
 this.ifDocElement.onmouseup = this._onMouseUp;
 this.ifDocElement.onclick = this._onClick;
 this.ifDocElement.ondblclick = this._onDblClick;
 this.ifDocElement.onkeypress = this._onKeyPress;
 this.ifDocElement.onkeydown = this._onKeyDown;
 this.ifDocElement.onkeyup = this._onKeyUp;
 this.ifDocElement.onpaste = this._onPaste;
 }

 if (this._onFocus != this.iframe.onfocus) {
 this.oldOnFocus = this.iframe.onfocus;
 this.iframe.onfocus = this._onFocus;

 this.oldOnBlur = this.iframe.onblur;
 this.iframe.onblur = this._onBlur;
 this.ifDoc.oncontextmenu = this._onContextMenu;
 }

 try {
 rs_s3.execCommand(rsS57[355], false, false); } catch (exc) { }
 }

 function setDisabled(disabled) {
 try{
 this.ifDoc.body.setAttribute(rsS57[332], !disabled);

 this.enabled = !disabled;

 if (this.enabled) this.attachEvents();

 if (typeof (rsw_ignoreDisabledBoxes) != rsS57[12] && rsw_ignoreDisabledBoxes && disabled) 
 this.updateIframe();

 if (this.enabled) this.attachEvents();

 if (this.multiline) {
 if (disabled) this.ifDoc.body.className = rsS57[356];
 else this.ifDoc.body.className = rsS57[357];
 } else {
 if (disabled) this.ifDoc.body.className = rsS57[358];
 else this.ifDoc.body.className = rsS57[359];
 }
 } catch (excep) { rsw_logException(excep); }
 }

 function unhook() {
 this.ifDoc.body.setAttribute(rsS57[332], rsS57[334]);


 this.ifDocElement.onmousedown = null;
 this.ifDocElement.onmouseup = null;
 this.ifDocElement.onclick = null;
 this.ifDocElement.onkeypress = null;
 this.ifDocElement.onkeydown = null;
 this.ifDocElement.onkeyup = null;
 this.ifDocElement.onpaste = null;



 this.oldOnFocus = null;
 this.iframe.onfocus = null;

 this.oldOnBlur = null;
 this.iframe.onblur = null;
 this.ifDoc.oncontextmenu = null;

 }


 function updateIframe() {
 if (this.textIsXHTML)
 this.setContent((this.shadowTB.value), true);
 else
 this.setContent(rsw_escapeHTML(this.shadowTB.value), true);

 }

 function updateShadow() {
 
 var reg = new RegExp(String.fromCharCode(160), rsS57[360]);
 rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS57[39]));

 
 }

 function getShadowText() {

 return this.shadowTB.value;
 }

}
























function MozlyTB(iframeEl, editable) {
 this.skipAYTUpdates = false;
 this.iframe = iframeEl;
 this.editable = editable;
 this.ifDoc; this.designMode;
 this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onKeyUp = _onKeyUp;
 this._onKeyDown = _onKeyDown;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 
 this._onFocus = _onFocus;
 this.isFocused = false;
 this._onBlur = _onBlur;
 this._onPaste = _onPaste;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onContextMenu = _onContextMenu;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = false;
 this.getContentText = getContentText;
 this.selectedErrorNode = selectedErrorNode;
 this.containsElement = containsElement;
 this.focus = focus;
 this.multiline = false;
 this.enabled = true;
 this.maxlength = 0;
 this.shadowTB;
 this.updateIframe = updateIframe;
 this.updateShadow = updateShadow;
 this.getShadowText = getShadowText;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.isWrappedInNOBR = false;
 this.oldOnBlur;
 this.oldOnFocus;
 this.isDirty = false;
 this.recordCaretPos = recordCaretPos;
 this.resetCaretPos = resetCaretPos;
 this.setCaretPos = setCaretPos;
 this.selOffset;
 this.selOffsetEnd;
 this.CssSheetURL;
 
 this.getNumberOfErrors = getNumberOfErrors;
 this.textIsXHTML;
 this.unhook = unhook;
 this.repObj = null;
 this.setDisabled = setDisabled;
 this.select = select;
 this.attachEvents = attachEvents;
 this.isVisible = isVisible;
 this.recordCaretPosAppleWebKit = recordCaretPosAppleWebKit;
 this.resetCaretPosAppleWebKit = resetCaretPosAppleWebKit;
 this.container = container;
 this.submitOnEnterForSingleLine = true;
 this.isShowingPlaceholder = false;
 this.placeHolderText = null;


 this.currentEventDefaultPrevent = false;
 this.preventDefaultCurrentEvent = function () {
 this.currentEventDefaultPrevent = true;
 }
 this.processDefaultPrevented = function (event) {
 if (this.currentEventDefaultPrevent) {
 event.preventDefault();
 event.cancelBubble = true;
 }
 this.currentEventDefaultPrevent = false;
 }

 this.showPlaceholder = function () {
 if (this.placeHolderText == null)
 this.placeHolderText = this.shadowTB.getAttribute(rsS57[299]);

 if (this.placeHolderText != null && this.placeHolderText.length > 0 && this.getShadowText().length == 0) {
 this.isShowingPlaceholder = true;
 this.setContent(rsS57[300] + this.placeHolderText + rsS57[301]);
 
 }
 };
 this.hidePlaceholder = function () {
 if (this.isShowingPlaceholder) {
 this.setContent(rsS57[3]);
 this.isShowingPlaceholder = false;
 }
 };


 function container() {
 if (this.iframe != null) {
 if (this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }
 


 this.walk = function (container, range, isStart, index) {
 if (container.nodeType != Node.TEXT_NODE && container.childNodes.length > 0) {
 var gobbledLength = 0;
 for (var c = 0; c < container.childNodes.length; c++) {

 var newGobbledLength = this.walk(container.childNodes[c], range, isStart, index - gobbledLength);
 if (newGobbledLength == index - gobbledLength) return index;
 else gobbledLength = newGobbledLength;
 }
 return gobbledLength;
 } else {
 var rangeText = container.nodeValue;
 if (rangeText != null && (rangeText.length > index || (rangeText.length == index && !isStart))) {
 if (isStart)
 range.setStart(container, index);
 else
 range.setEnd(container, index);

 return index;
 } else {
 if (rangeText == null) return 0;
 else {
 if (container.nextSibling != null && rangeText.length == index) {
 if (isStart) {
 if (container.nextSibling.childNodes.length > 0) {
 for (var z = 0; z < container.nextSibling.childNodes.length; z++) {
 if (container.nextSibling.childNodes[z].nodeType == Node.TEXT_NODE) {
 range.setStart(container.nextSibling.childNodes[z], 0);
 break;
 }
 }

 } else range.setStart(container.nextSibling, 0);
 }

 }

 return rangeText.length;
 }
 }
 }


 };

 
 

 function isVisible() {
 
 try {
 if (this.iframe == null) return false;
 var rect = this.iframe.getBoundingClientRect();
 return rect.left != 0 || rect.top != 0 || rect.width != 0 || rect.height != 0;
 } catch (excep) { rsw_logException(excep); return false;}
 }


 function select() {
 try{
 this.focus();
 if (this.getContentText().length > 0) {
 var sel = this.iframe.contentWindow.getSelection();
 var range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;
 range.setStartBefore(contentElements[0]);
 range.setEndAfter(contentElements[contentElements.length - 1]);
 }
 } catch (excep) { rsw_logException(excep); }
 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS57[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); }
 }

 
 
 
 

 function recordCaretPos() {
 

 try {
 var sel = this.iframe.contentWindow.getSelection();
 var range = sel.getRangeAt(0);
 var len = 0;
 var contentElements = this.ifDoc.body.childNodes;
 this.selOffset = rsw_getAbsSel(range, len, contentElements)[0];
 this.selOffsetEnd = rsw_getAbsSel(range, len, contentElements, true)[0];
 } catch (excep) { if (rsw_debug) rsw_logException(excep); }
 
 }

 function recordCaretPosAppleWebKit() {
 try{
 var oWin = this.iframe.contentWindow;
 var sel = oWin.getSelection();

 this._previous_range = new Object();
 this._previous_range.baseNode = sel.baseNode;
 this._previous_range.baseOffset = sel.baseOffset;
 this._previous_range.extentNode = sel.extentNode;
 this._previous_range.extentOffset = sel.extentOffset;
 } catch (excep) { if (rsw_debug) rsw_logException(excep); }
 
 
 }

 function resetCaretPosAppleWebKit() {
 try{
 var oWin = this.iframe.contentWindow;
 var sel = oWin.getSelection();
 sel.setBaseAndExtent(this._previous_range.baseNode,
 this._previous_range.baseOffset,
 this._previous_range.extentNode,
 this._previous_range.extentOffset);

 } catch (excep) { rsw_logException(excep); }
 }

 function setCaretPos(characterIndex) {
 this.selOffset = characterIndex;
 this.selOffsetEnd = characterIndex;
 this.resetCaretPos();
 }

 function resetCaretPos() {
 
 

 
 try {
 var sel = this.iframe.contentWindow.getSelection();
 var range;
 if(sel.rangeCount==0) range = this.iframe.contentWindow.document.createRange();
 else range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;



 
 var absRange = new Array();
 var absRangeEnd = new Array();
 rsw_findEl(this.selOffset, contentElements, absRange);
 rsw_findEl(this.selOffsetEnd, contentElements, absRangeEnd);


 if (absRange.length == 0)
 range.setStartAfter(contentElements[contentElements.length - 1]);

 if (absRangeEnd.length == 0)
 range.setEndAfter(contentElements[contentElements.length - 1]);
 

 if (absRange.length > 0) {
 if (absRange[4])
 range.setStartAfter(absRange[2]);
 else
 range.setStart(absRange[2], absRange[3]);
 }

 if (absRangeEnd.length > 0) {
 if (absRangeEnd[4])
 range.setEndAfter(absRangeEnd[2]);
 else
 range.setEnd(absRangeEnd[2], absRangeEnd[3]);
 }



 if (this.isFocused && (rsw_chrome || rsw_applewebkit || rsw_msie11)) {
 sel.removeAllRanges();
 sel.addRange(range);
 }
 } catch (e) {
 try {
 var range; if (sel.rangeCount == 0) range = this.iframe.contentWindow.document.createRange();
 else range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;
 var lastElPtr = contentElements.length - 1;
 while (!contentElements[lastElPtr].nodeValue && lastElPtr > 0) {
 lastElPtr--;
 }
 range.setEnd(contentElements[lastElPtr], contentElements[lastElPtr].nodeValue.length);
 range.setStart(contentElements[lastElPtr], contentElements[lastElPtr].nodeValue.length);
 if (rsw_chrome || rsw_applewebkit) {
 sel.removeAllRanges();
 sel.addRange(range);
 }
 } catch (ex) {
 }
 }
 
 }





 function OnCorrection(e) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e);

 rsw_broadcastToListeners(rsS57[287], e);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[321], rsw_activeTextbox, e);

 
 }


 function focus() {
 try{
 this.iframe.contentWindow.focus();
 this.isFocused = true;
 } catch (excep) { rsw_logException(excep); }
 }




 function containsElement(element) {
 return element.ownerDocument == this.ifDoc;
 }

 function selectedErrorNode() {
 rsw_refreshActiveTextbox();
 try {
 var selection = rsw_activeTextbox.iframe.contentWindow.getSelection();
 if (selection.anchorNode!= null && selection.anchorNode.parentNode.className == rsS57[284])
 return selection.anchorNode.parentNode;
 else if (selection.anchorNode != null && selection.anchorNode.parentNode != null) {
 
 var parentEl = selection.anchorNode.parentNode;
 for (var i = 0; parentEl.children.length > i; i++) {
 if (parentEl.children[i].className == rsS57[284]) {
 var r = this.ifDoc.createRange();
 r.selectNode(parentEl.children[i]);
 r.setEndAfter(selection.anchorNode);
 if (r.toString().charAt(r.toString().length - 2) == rsS57[175]) return parentEl.children[i];
 }
 }
 
 }
 
 
 return null;
 } catch (e) {
 return null;
 }
 }


 function getAbsX(element, event) {
 
 try{
 return element.getBoundingClientRect().left + rsw_activeTextbox.iframe.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 }

 function getAbsY(element, event) {
 try{
 return element.getBoundingClientRect().top + rsw_activeTextbox.iframe.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }


 function changeTo(error, replacement) {
 var repl = this.ifDoc.createTextNode(replacement);
 if(error.parentNode!=null)
 error.parentNode.replaceChild(repl, error);
 }


 function getSpanElements() {
 return this.ifDoc.getElementsByTagName(rsS57[306]);
 }
 
 function getContentText() {
 
 if (this.isShowingPlaceholder) return rsS57[3];
 var text;
 if (!rsw_msie11 && !rsw_msedge && this.ifDoc.body.innerText && !rsw_mozly) { text = this.ifDoc.body.innerText;
 if (text.charAt(text.length - 1) == rsS57[25]) text = text.substring(0, text.length - 1);
 return text;
 }
 
 var contentElements = this.ifDoc.body.childNodes;

 

 var contents = rsS57[3];
 var innerT = rsS57[3];
 for (var i = 0; i < contentElements.length; i++) {

 innerT = rsw_innerText(contentElements[i]);

 if (contentElements[i].nodeName.toLowerCase() == rsS57[292])
 contents += contentElements[i].value;
 else if ((contentElements[i].nodeName.toLowerCase() != rsS57[289] || i < contentElements.length - 1)
 ) {


 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS57[25]) innerT = innerT.substring(0, innerT.length - 1);
 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS57[24]) innerT = innerT.substring(0, innerT.length - 1);
 
 contents += innerT;
 }

 }

 

 
 


 
 
 contents = contents.replace(/\r\n/g, "\n");
 


 return contents;
 }

 function _onDblClick(event) {
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[327], rsw_activeTextbox, event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }



 function _onClick(event) {
 
 
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;

 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[328], rsw_activeTextbox, event);

 if (navigator.userAgent.toLowerCase().indexOf(rsS57[361]) == -1 && navigator.userAgent.toLowerCase().indexOf(rsS57[230]) > -1) {
 if (typeof event != rsS57[12]) {
 try {
 var omu = event.target.attributes[rsS57[286]];
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;

 

 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 } catch (ex) {

 }
 }
 }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);

 }



 function _onKeyPress(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 rsw_hideCM();



 var evt = event;

 if (evt != null && evt.keyCode == 13 && !rsw_activeTextbox.multiline) {
 event.preventDefault();
 event.cancelBubble = true;
 if (rsw_activeTextbox.submitOnEnterForSingleLine)
 rsw_activeTextbox.shadowTB.form.submit();
 }

 if (evt != null && evt.keyCode == 9) {
 
 }

 rsw_activeTextbox.isDirty = true;

 if (rsw_activeTextbox.maxlength > 0) {
 if (
 evt.keyCode != 8 && evt.keyCode != 46 && (evt.keyCode < 33 || evt.keyCode > 40) && rsw_activeTextbox.getContentText().replace(/\r/g, rsS57[3]).replace(/\n/g, rsS57[3]).length >= rsw_activeTextbox.maxlength) {
 event.preventDefault();
 event.cancelBubble = true;
 return;
 }
 }

 if (rsw_debug) rs_s3.getElementById(rsS57[157]).value += rsS57[362]+rsw_activeTextbox.ifDoc.body.innerHTML+rsS57[38];
 if (!rsw_activeTextbox.multiline && rsw_activeTextbox.getContentText() == rsS57[159]) {
 var els = rsw_activeTextbox.ifDoc.getElementsByTagName(rsS57[363]);
 for (var xi = 0; xi < els.length; xi++) {
 els[xi].parentNode.removeChild(els[xi]);
 }
 }

 

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyPress(event);

 rsw_broadcastToListeners(rsS57[322], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[322], rsw_activeTextbox, event);


 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[322], rsw_activeTextbox, event);



 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function _onKeyDown(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyDown(event);

 if ((rsw_chrome || rsw_safari) && event != null && event.keyCode == 9) {
 event.preventDefault();
 event.cancelBubble = true;
 rsw_focusToNextField(rsw_activeTextbox);
 }
 
 if (event != null && ((event.keyCode >= 33 && event.keyCode <= 40) || event.keyCode == 13) && rsw_contextMenu!=null && rsw_contextMenu.isVisible) { event.preventDefault();
 event.cancelBubble = true;
 if (rsw_contextMenu != null) rsw_contextMenu.onkeydown(event);
 return;
 }
 if (event != null && event.keyCode == 13 && !rsw_activeTextbox.multiline) {
 event.preventDefault();
 event.cancelBubble = true;
 if (rsw_contextMenu != null) rsw_contextMenu.onkeydown(event);
 return;
 }


 rsw_activeTextbox.lastKeyDown = event.keyCode;

 rsw_broadcastToListeners(rsS57[296],event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[296], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[296], rsw_activeTextbox, event);



 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 this.textAtFocus;
 function _onFocus(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (!rsw_activeTextbox.isFocused) rsw_hideCM();
 rsw_activeTextbox.updateShadow();


 

 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS57[12])
 rsw_updateActiveTextbox(this.document); else
 rsw_updateActiveTextbox(this); 
 
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;


 if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS57[12]) {
 rsw_activeTextbox.ifDoc.body.className += rsS57[329];
 }


 rsw_activeTextbox.hidePlaceholder();
 rsw_activeTextbox.isFocused = true;

 if (typeof (rsw_activeTextbox.iframe.contentWindow) != rsS57[12]) {
 rsw_activeTextbox.ifDoc.body.focus();
 }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onFocus(event);

 rsw_broadcastToListeners(rsS57[330], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[330], rsw_activeTextbox, event);
 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);

 }

 function _onBlur(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 rsw_activeTextbox.isFocused = false;
 rsw_activeTextbox.rsw_key_downed_within_lim = false; rsw_activeTextbox.updateShadow();

 rsw_activeTextbox.ifDoc.body.className = rsw_activeTextbox.ifDoc.body.className.replace(/(?:^|\s)rsw_focused(?!\S)/g, rsS57[3]);

 
 if (rsw_activeTextbox.textAtFocus != rsw_activeTextbox.shadowTB.value && (rsw_contextMenu == null || !rsw_contextMenu.isVisible)) {

 var evt = rs_s3.createEvent(rsS57[364]);
 evt.initUIEvent(rsS57[333], event.canBubble, event.cancelable, event.view,
 event.detail);
 rsw_activeTextbox.shadowTB.dispatchEvent(evt);
 rsw_activeTextbox.textAtFocus = rsw_activeTextbox.shadowTB.value;
 }

 if (rsw_activeTextbox.isAYT && rsw_spellCheckOnBlur)
 rsw_spellCheckTextBox(rsw_activeTextbox);
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onBlur(event);

 rsw_broadcastToListeners(rsS57[335], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[335], rsw_activeTextbox, event);

 rsw_activeTextbox.showPlaceholder();

 } catch (excep) { rsw_logException(excep); }

 
 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function _onKeyUp(event) {
 try{
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (event == null || (!(event.keyCode >= 33 && event.keyCode <= 40) && event.keyCode!=93 )) { var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);
 }

 if (event.keyCode == 93) {
 if (!rsw_msie11) {
 
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS57[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, errorNode, event);
 }
 } catch (ex) {

 }
 }
 }
 return;
 }
 if (event != null && ((event.keyCode >= 33 && event.keyCode <= 40) || event.keyCode == 13) && rsw_contextMenu!=null && rsw_contextMenu.isVisible) { return;
 }

 rsw_activeTextbox.updateShadow();

 if (!rsw_activeTextbox.multiline && rsw_activeTextbox.ifDoc.body.innerHTML == rsS57[25]) rsw_activeTextbox.ifDoc.body.innerHTML = rsS57[3];

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onKeyUp(event);

 rsw_broadcastToListeners(rsS57[324], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[324], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[324], rsw_activeTextbox, event);

 if (typeof (rsw_fireEventInShadow) == rsS57[33])
 rsw_fireEventInShadow(rsS57[292], rsw_activeTextbox, event);

 } catch (excep) { rsw_logException(excep); }

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function _onPaste(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox!=null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onPaste(event);
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode)
 rsw_dehighlight(errorNode);
 setTimeout(rsS57[344] +
 rsS57[345], 300);

 rsw_broadcastToListeners(rsS57[346], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[346], rsw_activeTextbox, event);

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);

 }

 function _onMouseDown(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if( !(event.which==3 || (event.which==1 && !rsw_MenuOnRightClick))) rsw_hideCM();

 if (rsw_activeTextbox == null) { if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS57[12])
 rsw_updateActiveTextbox(this.document);
 else
 rsw_updateActiveTextbox(this);
 }

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(event);


 var activeElement;
 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS57[12])
 activeElement = this.document;
 else
 activeElement = this;

 rsw_broadcastToListeners(rsS57[325], event, rsw_getTBSFromElement(activeElement));
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[325], rsw_activeTextbox, event);
 rsw_activeTextbox.updateShadow();

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }

 function _onMouseUp(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null) rsw_activeTextbox.currentEventDefaultPrevent = false;
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(event);

 if (rsw_msie11) { if (typeof event != rsS57[12]) {
 try {
 var omu = event.target.attributes[rsS57[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 }
 } catch (ex) {

 }
 }
 }

 rsw_broadcastToListeners(rsS57[326], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[326], rsw_activeTextbox, event);

 

 if (rsw_activeTextbox != null) rsw_activeTextbox.processDefaultPrevented(event);
 }


 function setContent(content, contentIsFromShadow) {
 try {
 if (contentIsFromShadow) this.hidePlaceholder();
 var t = content + rsS57[25];

 

 if (this.multiline) {
 
 
 t = t.replace(/(.*?)\n/g, rsS57[365]);
 t = t.replace(/<p><\/p>/g, rsS57[366]);

 } else {
 if (rsw_msie11) {
 t = t.replace(/(.*?)\n/g, rsS57[367]);
 t = t.replace(/<p><\/p>/g, rsS57[366]);
 }
 }

 var newlineexp = new RegExp(rsS57[24]);
 while (newlineexp.test(t))
 t = t.replace(newlineexp, rsS57[3]);


 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;

 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS57[235] + t.substring(pos + 1);
 ppos = pos;
 }
 if (t.length == 0 || t==rsS57[25])
 t = rsS57[3];
 else {
 this.isWrappedInNOBR = true;
 }

 
 } else {
 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {

 if (pos + 1 < t.length &&
 (
 t.charAt(pos + 1) == rsS57[39] ||
 (pos > 4 && t.charAt(pos - 1) == rsS57[169] && t.substring(pos - 5, pos - 1) != rsS57[306])
 ||
 (pos + 3 < t.length && t.charAt(pos + 1) == rsS57[168] && t.charAt(pos + 2) == rsS57[368] && t.charAt(pos + 3) == rsS57[293])
 ||
 (pos >= 3 && t.charAt(pos - 1) == rsS57[169] && t.charAt(pos - 2) == rsS57[293])
 )
 ) { opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);

 
 }
 ppos = pos;
 }
 }
 
 
 }

 if(this.ifDoc!=null && this.ifDoc.body!=null) this.ifDoc.body.innerHTML = t;


 


 if(!contentIsFromShadow && this.ifDoc != null && this.ifDoc.body != null)this.updateShadow();
 } catch (excep) { rsw_logException(excep); }
 }

 function getContent() {
 try{
 return this.ifDoc.body.innerHTML;
 } catch (excep) { rsw_logException(excep); }
 }

 function setDisabled(disabled) {
 try{


 if (disabled) {
 this.unhook(true);
 if (rsw_msie11)
 this.iframe.contentDocument.body.contentEditable = false;
 else
 this.iframe.contentDocument.designMode = rsS57[369];
 } else {
 this.attachEvents(true);
 if (rsw_msie11)
 this.iframe.contentDocument.body.contentEditable = true;
 else this.iframe.contentDocument.designMode = rsS57[370];
 }


 this.enabled = !disabled;

 if (typeof (rsw_ignoreDisabledBoxes) != rsS57[12] && rsw_ignoreDisabledBoxes && disabled)
 this.updateIframe();

 if (this.multiline) {
 if (disabled) this.ifDoc.body.className = rsS57[356];
 else this.ifDoc.body.className = rsS57[357];
 } else {
 if (disabled) this.ifDoc.body.className = rsS57[358];
 else this.ifDoc.body.className = rsS57[359];
 }
 } catch (excep) { rsw_logException(excep); }
 }

 
 function _onContextMenu(e) {
 rsw_refreshActiveTextbox();
 
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(e);

 if (rsw_MenuOnRightClick && rsw_contextMenu!=null && rsw_contextMenu.isVisible) {
 e.cancelBubble = true;
 e.preventDefault();
 }

 if (rsw_activeTextbox.lastKeyDown && rsw_activeTextbox.lastKeyDown == 93) {
 e.cancelBubble = true;
 e.preventDefault();
 var errorNode = rsw_activeTextbox.selectedErrorNode();
 if (errorNode) {
 try {
 var omu = errorNode.attributes[rsS57[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, errorNode, e);
 }
 } catch (ex) {

 }
 }
 }

 rsw_broadcastToListeners(rsS57[343], e);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[343], rsw_activeTextbox, e);
 }


 function initialize(attempts) {
 try{
 rsw_refreshActiveTextbox();
 var ifID = this.iframe.id;
 this.shadowTBID = ifID.substring(0, ifID.length - 3); this.shadowTB = rs_s3.getElementById(this.shadowTBID);



 if (rsw_id_waitingToInitialize == null) rsw_id_waitingToInitialize = ifID;
 if (!attempts) attempts = 0;
 try {
 if (!this.iframe.contentWindow.loaded && attempts < 100) { attempts++;
 eval(rsS57[371] + this.shadowTBID + rsS57[348] + attempts + rsS57[372]);
 return;
 }
 } catch (xx) {
 attempts++;
 eval(rsS57[347] + this.shadowTBID + rsS57[348] + attempts + rsS57[373]);
 return;
 }

 rsw_id_waitingToInitialize = null;
 
 this.ifDoc = this.iframe.contentWindow.document;

 this.iframe.contentWindow.document.documentElement.setAttribute(rsS57[351], false);

 this.ifDocElement = this.iframe.contentWindow.document.documentElement;

 
 function getDefaultFontSize(pa) {
 pa = pa || rs_s3.body;
 var who = rs_s3.createElement(rsS57[50]);

 who.style.cssText = rsS57[352];

 who.appendChild(rs_s3.createTextNode(rsS57[353]));
 pa.appendChild(who);
 var fs = [who.offsetWidth, who.offsetHeight];
 pa.removeChild(who);
 return fs;
 }
 
 this.iframe.contentWindow.document.documentElement.style.fontSize = rsw_getStyleProperty(this.iframe.parentElement, rsS57[374]);
 
 rsw_createLink(this.ifDoc, this.CssSheetURL);

 
 


 if (this.enabled) {
 

 if (this.editable) {
 
 if (rsw_msie11){ eval(rsS57[375] + this.iframe.id + rsS57[376]);
 } else {

 eval(rsS57[375] + this.iframe.id + rsS57[377]);
 }
 this.attachEvents();
 }
 }



 rsw_setSettings(this);

 if (this.enabled)
 this.showPlaceholder();

 if (rsw_ffMaxLengthChecker == null && this.maxlength > 0)
 rsw_ffMaxLengthChecker = setInterval(rsS57[378], 300);

 } catch (excep) { rsw_logException(excep); }


 }

 this._onFrameFocus = function (e) {
 if (rsw_msie11) {
 
 setTimeout(function () {
 var tbs = rsw_getTBSFromID(e.target.id.substring(0, e.target.id.length - 3));
 if (!tbs.isFocused) {
 rs_s2.focus();
 tbs.focus();
 }
 }, 0);
 }
 };


 function attachEvents(allButClick) {
 try{

 this.ifDoc.addEventListener(rsS57[325], this._onMouseDown, false);
 this.ifDoc.addEventListener(rsS57[326], this._onMouseUp, false);


 if (rsw_chrome) this.ifDocElement.addEventListener(rsS57[322], this._onKeyPress, false);
 else
 this.ifDoc.addEventListener(rsS57[322], this._onKeyPress, false);


 if (rsw_chrome) this.ifDocElement.addEventListener(rsS57[296], this._onKeyDown, false);
 else
 this.ifDoc.addEventListener(rsS57[296], this._onKeyDown, false);


 this.ifDoc.addEventListener(rsS57[324], this._onKeyUp, false);
 this.ifDoc.addEventListener(rsS57[343], this._onContextMenu, false);
 if (!rsw_chrome && !rsw_applewebkit && !rsw_msie11) {
 this.iframe.addEventListener(rsS57[330], this._onFrameFocus, false);
 this.ifDoc.addEventListener(rsS57[330], this._onFocus, false);
 this.ifDoc.addEventListener(rsS57[335], this._onBlur, false);
 } else {
 this.iframe.addEventListener(rsS57[330], this._onFrameFocus, false);
 this.iframe.contentWindow.addEventListener(rsS57[330], this._onFocus, false);
 this.iframe.contentWindow.addEventListener(rsS57[335], this._onBlur, false);
 }
 this.iframe.contentWindow.document.addEventListener(rsS57[346], this._onPaste, false);
 
 

 if (!allButClick) {
 this.ifDoc.addEventListener(rsS57[328], this._onClick, false);
 this.ifDoc.addEventListener(rsS57[327], this._onDblClick, false);
 }


 if (typeof (this.tbConfig) != rsS57[12] && this.tbConfig != null && this.tbConfig.keys != null) {
 for (var v = 0; v < this.tbConfig.keys.length; v++)
 if (this.tbConfig.keys[v] == rsS57[379])
 this.multiline = this.tbConfig.values[v];

 if (!this.multiline && rsw_showHorizScrollBarsInFF) {
 this.iframe.scrolling = rsS57[380];
 for (var v = 0; v < this.tbConfig.keys.length; v++) {
 if (this.tbConfig.keys[v] == rsS57[381]) {
 var hstr = parseInt(this.tbConfig.values[v].substring(1, this.tbConfig.values[v].length - 3), 10) + 22;
 if (hstr < 50)
 this.tbConfig.values[v] = rsS57[175] + hstr + rsS57[382];

 }
 }

 }
 }
 } catch (excep) { rsw_logException(excep); }

 }

 function unhook(allButClick) {
 this.ifDoc.removeEventListener(rsS57[325], this._onMouseDown, false);
 this.ifDoc.removeEventListener(rsS57[326], this._onMouseUp, false);
 this.ifDoc.removeEventListener(rsS57[322], this._onKeyPress, false);
 this.ifDoc.removeEventListener(rsS57[296], this._onKeyDown, false);
 this.ifDoc.removeEventListener(rsS57[324], this._onKeyUp, false);
 this.ifDoc.removeEventListener(rsS57[343], this._onContextMenu, false);
 this.ifDoc.removeEventListener(rsS57[330], this._onFocus, false);
 this.ifDoc.removeEventListener(rsS57[335], this._onBlur, false);

 if (!allButClick) {
 this.ifDoc.removeEventListener(rsS57[328], this._onClick, false);
 this.ifDoc.removeEventListener(rsS57[327], this._onDblClick, false);
 }
 }


 function updateIframe() {
 if (this.textIsXHTML)
 this.setContent((this.shadowTB.value), true);
 else
 this.setContent(rsw_escapeHTML(this.shadowTB.value), true);

 
 }
 function updateShadow() {
 
 var reg = new RegExp(String.fromCharCode(160), rsS57[360]);
 rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS57[39]));


 
 
 }

 function getShadowText() {
 return this.shadowTB.value;
 }

}







function LabelTB(iframeEl, editable) {
 this.isLabel = true;
 this.skipAYTUpdates = true;
 this.iframe = iframeEl;
 this.editable = editable;
 this.ifDoc; this.designMode;
 this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onKeyUp = _onKeyUp;
 this._onKeyDown = _onKeyDown;
 this._onMouseDown = _onMouseDown;
 this._onMouseUp = _onMouseUp;
 this.noReconcile = true;
 this._onFocus = _onFocus;
 this.isFocused = false;
 this._onBlur = _onBlur;
 this._onPaste = _onPaste;
 this._onClick = _onClick;
 this._onDblClick = _onDblClick;
 this._onContextMenu = _onContextMenu;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = false;
 this.getContentText = getContentText;
 this.selectedErrorNode = selectedErrorNode;
 this.containsElement = containsElement;
 this.focus = focus;
 this.multiline = false;
 this.enabled = true;
 this.maxlength = 0;
 this.shadowTB;
 this.updateIframe = updateIframe;
 this.updateShadow = updateShadow;
 this.getShadowText = getShadowText;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.isWrappedInNOBR = false;
 this.oldOnBlur;
 this.oldOnFocus;
 this.isDirty = false;
 this.recordCaretPos = recordCaretPos;
 this.resetCaretPos = resetCaretPos;
 this.setCaretPos = setCaretPos;
 this.selOffset;
 this.selOffsetEnd;
 this.CssSheetURL;
 this.targetIsPlain = false;
 this.getNumberOfErrors = getNumberOfErrors;
 this.textIsXHTML;
 this.unhook = unhook;
 this.repObj = null;
 this.setDisabled = setDisabled;
 this.select = select;
 this.attachEvents = attachEvents;
 this.isVisible = isVisible;
 this.recordCaretPosAppleWebKit = recordCaretPosAppleWebKit;
 this.resetCaretPosAppleWebKit = resetCaretPosAppleWebKit;
 this.container = container;

 function container() {
 if (this.iframe != null) {
 if (this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }

 this.walk = function (container, range, isStart, index) {
 if (container.nodeType != Node.TEXT_NODE && container.childNodes.length > 0) {
 var gobbledLength = 0;
 for (var c = 0; c < container.childNodes.length; c++) {

 var newGobbledLength = this.walk(container.childNodes[c], range, isStart, index - gobbledLength);
 if (newGobbledLength == index - gobbledLength) return index;
 else gobbledLength = newGobbledLength;
 }
 return gobbledLength;
 } else {
 var rangeText = container.nodeValue;
 if (rangeText != null && (rangeText.length > index || (rangeText.length == index && !isStart))) {
 if (isStart)
 range.setStart(container, index);
 else
 range.setEnd(container, index);

 return index;
 } else {
 if (rangeText == null) return 0;
 else {
 if (container.nextSibling != null && rangeText.length == index) {
 if (isStart) {
 if (container.nextSibling.childNodes.length > 0) {
 for (var z = 0; z < container.nextSibling.childNodes.length; z++) {
 if (container.nextSibling.childNodes[z].nodeType == Node.TEXT_NODE) {
 range.setStart(container.nextSibling.childNodes[z], 0);
 break;
 }
 }

 } else range.setStart(container.nextSibling, 0);
 }

 }

 return rangeText.length;
 }
 }
 }


 };

 

 function isVisible() {
 
 try {
 if (this.iframe == null) return false;
 var rect = this.iframe.getBoundingClientRect();
 return rect.left != 0 || rect.top != 0 || rect.width != 0 || rect.height != 0;
 } catch (excep) { rsw_logException(excep); return false;}
 }


 function select() {
 try{
 this.focus();
 if (this.getContentText().length > 0) {
 var sel = this.iframe.contentWindow.getSelection();
 var range = sel.getRangeAt(0);
 var contentElements = this.ifDoc.body.childNodes;
 range.setStartBefore(contentElements[0]);
 range.setEndAfter(contentElements[contentElements.length - 1]);
 }
 } catch (excep) { rsw_logException(excep); }

 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS57[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); }
 }

 
 
 
 

 function recordCaretPos() {

 
 }

 function recordCaretPosAppleWebKit() {
 
 }

 function resetCaretPosAppleWebKit() {
 
 }

 function setCaretPos(characterIndex) {
 
 }

 function resetCaretPos() {
 
 
 
 }





 function OnCorrection(e) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onCorrection(e);

 rsw_broadcastToListeners(rsS57[287], e);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[321], rsw_activeTextbox, e);
 }


 function focus() {


 }




 function containsElement(element) {
 var p = element;
 while ((p = p.parentNode) != null) {
 if (p.id == this.ifDoc.id) return true;
 }
 return false;
 }

 function selectedErrorNode() {
 rsw_refreshActiveTextbox();
 try {
 var selection = rsw_activeTextbox.iframe.contentWindow.getSelection();
 if (selection.anchorNode!= null && selection.anchorNode.parentNode.className == rsS57[284])
 return selection.anchorNode.parentNode;
 else if (selection.anchorNode != null && selection.anchorNode.parentNode != null) {
 
 var parentEl = selection.anchorNode.parentNode;
 for (var i = 0; parentEl.children.length > i; i++) {
 if (parentEl.children[i].className == rsS57[284]) {
 var r = this.ifDoc.createRange();
 r.selectNode(parentEl.children[i]);
 r.setEndAfter(selection.anchorNode);
 if (r.toString().charAt(r.toString().length - 2) == rsS57[175]) return parentEl.children[i];
 }
 }
 
 }
 
 
 return null;
 } catch (e) {
 return null;
 }
 }


 function getAbsX(element, event) {
 try{
 return element.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }

 function getAbsY(element, event) {
 try{
 return element.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }


 function changeTo(error, replacement) {
 var repl = rs_s3.createTextNode(replacement);
 error.parentNode.replaceChild(repl, error);
 }


 function getSpanElements() {
 return rs_s3.getElementById(this.ifDoc.id).getElementsByTagName(rsS57[306]);
 }
 
 function getContentText() {
 

 var text;
 if (!rsw_msie11 && this.ifDoc.innerText) { text = this.ifDoc.innerText;
 if (text.charAt(text.length - 1) == rsS57[25]) text = text.substring(0, text.length - 1);
 return text;
 }
 
 var contentElements = this.ifDoc.childNodes;

 

 var contents = rsS57[3];
 var innerT = rsS57[3];
 for (var i = 0; i < contentElements.length; i++) {

 innerT = rsw_innerText(contentElements[i]);

 if (contentElements[i].nodeName.toLowerCase() == rsS57[292])
 contents += contentElements[i].value;
 else if ((contentElements[i].nodeName.toLowerCase() != rsS57[289] || i < contentElements.length - 1)
 ) {


 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS57[25]) innerT = innerT.substring(0, innerT.length - 1);
 if (i == contentElements.length - 1 && innerT.charAt(innerT.length - 1) == rsS57[24]) innerT = innerT.substring(0, innerT.length - 1);
 
 contents += innerT;
 }

 }

 

 
 


 
 
 contents = contents.replace(/\r\n/g, "\n");
 


 return contents;
 }


 function _onDblClick(event) {
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onDblClick(event);
 }

 function _onClick(event) {
 
 
 if (navigator.userAgent.toLowerCase().indexOf(rsS57[361]) == -1 && navigator.userAgent.toLowerCase().indexOf(rsS57[230]) > -1) {
 if (typeof event != rsS57[12]) {
 try {
 var omu = errorNode.attributes[rsS57[286]];
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;


 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 } catch (ex) {

 }
 }
 }

 

 }



 function _onKeyPress(event) {
 
 }


 function _onKeyDown(event) {
 
 }

 function _onFocus(event) {
 
 }

 function _onBlur(event) {
 
 }


 function _onKeyUp(event) {
 
 }

 function _onPaste(event) {
 
 }

 function _onMouseDown(event) {
 rsw_refreshActiveTextbox();
 rsw_hideCM();

 if ((rsw_chrome || rsw_applewebkit) && typeof (this.document) != rsS57[12])
 rsw_updateActiveTextbox(this.document);
 else
 rsw_updateActiveTextbox(this);

 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseDown(event);

 rsw_broadcastToListeners(rsS57[325], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[325], rsw_activeTextbox, event);
 rsw_activeTextbox.updateShadow();
 }

 function _onMouseUp(event) {
 rsw_refreshActiveTextbox();
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onMouseUp(event);

 if (rsw_msie11) { if (typeof event != rsS57[12]) {
 try {
 var omu = event.target.attributes[rsS57[286]];
 if (omu != null) {
 var embedhandler = typeof (omu.value) != rsS57[12] ? embedhandler = omu.value : embedhandler = omu.nodeValue;
 var suggestions = rsw_getSuggestionsArray(embedhandler);
 rsw_showMenu(suggestions, event.target, event);
 }
 } catch (ex) {

 }
 }
 }

 rsw_broadcastToListeners(rsS57[326], event);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[326], rsw_activeTextbox, event);

 
 }


 function setContent(content, contentIsFromShadow) {
 try {
 var ignoredRegex = /<!--rs_ignored-->/;
 var arr;

 var ptr = 0;
 if (this.spellChecker.tbInterface.ignoredRegions.length > 0) {
 while (ignoredRegex.test(content))
 content = content.replace(ignoredRegex, this.spellChecker.tbInterface.ignoredRegions[ptr++]);
 }
 var t = content;
 

 if (this.multiline) {
 
 t = t.replace(/(.*?)\n/g, rsS57[365]);
 t = t.replace(/<p><\/p>/g, rsS57[366]);

 }

 var newlineexp = new RegExp(rsS57[24]);
 while (newlineexp.test(t))
 t = t.replace(newlineexp, rsS57[3]);


 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;

 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS57[235] + t.substring(pos + 1);
 ppos = pos;
 }
 if (t.length == 0 || t==rsS57[25])
 t = rsS57[3];
 else {
 this.isWrappedInNOBR = true;
 }

 
 } else {
 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {

 if (pos + 1 < t.length &&
 (
 t.charAt(pos + 1) == rsS57[39] ||
 (pos > 4 && t.charAt(pos - 1) == rsS57[169] && t.substring(pos - 5, pos - 1) != rsS57[306])
 ||
 (pos + 3 < t.length && t.charAt(pos + 1) == rsS57[168] && t.charAt(pos + 2) == rsS57[368] && t.charAt(pos + 3) == rsS57[293])
 ||
 (pos >= 3 && t.charAt(pos - 1) == rsS57[169] && t.charAt(pos - 2) == rsS57[293])
 )
 ) { opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { t = t.substring(0, pos) + String.fromCharCode(160) + t.substring(pos + 1);

 
 }
 ppos = pos;
 }
 }
 
 
 }

 if(this.ifDoc!=null && this.ifDoc!=null) this.ifDoc.innerHTML = t;




 if(!contentIsFromShadow && this.ifDoc != null)this.updateShadow();
 } catch (excep) { rsw_logException(excep); }
 }

 function getContent() {
 try{
 return this.ifDoc.innerHTML;
 } catch (excep) { rsw_logException(excep); }
 }

 function setDisabled(disabled) {
 
 }

 
 function _onContextMenu(e) {
 rsw_refreshActiveTextbox();
 
 if (rsw_activeTextbox != null && rsw_activeTextbox.repObj != null) rsw_activeTextbox.repObj._onContextMenu(e);

 if (rsw_MenuOnRightClick && rsw_contextMenu.isVisible) {
 e.cancelBubble = true;
 e.preventDefault();
 }



 rsw_broadcastToListeners(rsS57[343], e);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[343], rsw_activeTextbox, e);
 }


 function initialize(attempts) {
 rsw_refreshActiveTextbox();
 this.id = this.iframe.id;
 this.shadowTBID = this.iframe.id+rsS57[41]; if ( (this.shadowTB=document.getElementById(this.shadowTBID)) == null) {
 var input = rs_s3.createElement(rsS57[292]);
 input.type = rsS57[98];
 input.style.display = rsS57[48];
 input.setAttribute(rsS57[383], this.shadowTBID);
 input.setAttribute(rsS57[384], rsS57[211]);
 input.id = this.shadowTBID;
 rs_s3.documentElement.appendChild(input);
 this.shadowTB = input; }
 
 this.ifDoc = this.iframe;


 this.ifDocElement = this.ifDoc;

 this.attachEvents();
 
 }

 this.addEvent = function (evnt, elem, func) {
 if (elem.addEventListener) elem.addEventListener(evnt, func, false);
 else if (elem.attachEvent) { elem.attachEvent(rsS57[370] + evnt, func);
 }
 else { elem[evnt] = func;
 }
 };

 this.removeEvent = function (evnt, elem, func) {
 if (elem.removeEventListener) elem.removeEventListener(evnt, func, false);
 else if (elem.detachEvent) { elem.detachEvent(rsS57[370] + evnt, func);
 }
 else { elem[evnt] = null;
 }
 };

 function attachEvents() {


 this.addEvent(rsS57[325], this.ifDoc, this._onMouseDown);
 this.addEvent(rsS57[326], this.ifDoc, this._onMouseUp);
 this.addEvent(rsS57[343], this.ifDoc, this._onContextMenu);

 }

 

 function unhook() {
 this.removeEvent(rsS57[325], this.ifDoc, this._onMouseDown);
 this.removeEvent(rsS57[326], this.ifDoc, this._onMouseUp);
 this.removeEvent(rsS57[343], this.ifDoc, this._onContextMenu);
 
 }


 function updateIframe() {
 if (this.textIsXHTML)
 this.setContent((this.shadowTB.value), true);
 else
 this.setContent(rsw_escapeHTML(this.shadowTB.value), true);

 
 }
 function updateShadow() {
 
 var reg = new RegExp(String.fromCharCode(160), rsS57[360]);
 rsw_setShadowTB(this.shadowTB, this.getContentText().replace(reg, rsS57[39]));


 
 
 }

 function getShadowText() {
 return this.shadowTB.value;
 }

}











































































































































































































































function OldIETB(iframe) {
 this.iframe = iframe; this.ifDoc; this.initialize = initialize;
 this.ifDocElement;
 this.setContent = setContent;
 this.getContent = getContent;
 this._onKeyPress = _onKeyPress;
 this._onPaste = _onPaste;
 this._onMouseDown = _onMouseDown;
 this._onContextMenu = _onContextMenu;
 this._onDblClick = _onDblClick;
 this.getSpanElements = getSpanElements;
 this.changeTo = changeTo;
 this.getAbsY = getAbsY;
 this.getAbsX = getAbsX;
 this.isStatic = true;
 this.createEditBox = createEditBox;
 this.getContentText = getContentText;
 this.containsElement = containsElement;
 this.getShadowText = getShadowText;
 this.updateShadow = updateShadow;
 this.multiline = true;
 this.spellChecker;
 this.OnCorrection = OnCorrection;
 this.getNumberOfErrors = getNumberOfErrors;
 this.getContentCleanHTML = getContentCleanHTML;
 this.targetIsPlain = true; this.unhook = unhook;
 this.resetCaretPos = unimplementedFunction;
 this.recordCaretPos = unimplementedFunction;
 this.container = container;

 function container() {
 if (this.iframe != null) {
 if (this.iframe.parentNode)
 return this.iframe.parentNode;
 if (this.iframe.parentElement)
 return this.iframe.parentElement;
 if (this.iframe.parent)
 return this.iframe.parent;
 }
 return null;
 }

 function unimplementedFunction() { }

 function containsElement(element) {
 var p;
 if (element == this.iframe) return true;

 while ((p = element.parentNode)) {
 if (p == this.iframe)
 return true;
 element = p;
 }

 return false;
 }

 function getAbsX(element, ev) {
 try{
 return element.getBoundingClientRect().left + rsw_getScrollX(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }

 function getAbsY(element, ev) {
 try{
 return element.getBoundingClientRect().top + rsw_getScrollY(window);
 } catch (excep) { rsw_logException(excep); return 0;}
 
 }

 function changeTo(error, replacement) {
 var repl = rs_s3.createTextNode(replacement);
 error.parentNode.replaceChild(repl, error);
 }

 function findElementsCell(element) {
 var p = element;
 while ((p = p.parentNode) != null && p.tagName.toLowerCase() != rsS57[385]) { }
 return p;
 }

 function createEditBox(error) {
 try{
 var width = error.offsetWidth;
 var repl = rs_s3.createElement(rsS57[292]);
 repl.setAttribute(rsS57[386], rsw_innerHTMLToText(error.innerHTML));
 repl.setAttribute(rsS57[44], rsS57[387]);
 repl.onkeypress = rsw_inlineTB_onkeypress;


 repl.onblur = rsw_inlineTB_onBlur;
 repl.style.width = width * 1.8;
 error.parentNode.replaceChild(repl, error);




 var scrollTop = this.iframe.scrollTop;
 repl.focus();
 this.iframe.scrollTop = scrollTop;
 } catch (excep) { rsw_logException(excep); }
 }


 function getSpanElements() {
 return this.iframe.getElementsByTagName(rsS57[306]);
 }


 function _onKeyPress() {

 rsw_hideCM();
 rsw_broadcastToListeners(rsS57[322]);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[322], null, null);
 }

 function _onMouseDown() {

 rsw_hideCM();
 rsw_broadcastToListeners(rsS57[325]);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[325], null, null);
 }

 function _onDblClick() {
 rsw_getTBSHoldingElement(this).spellChecker.OnTextBoxDoubleClicked();

 rsw_broadcastToListeners(rsS57[327]);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[327], null, null);
 }

 function setContent(content) {
 try {

 
 if (this.targetIsPlain) {
 var pos = -1;
 var ppos = 0;
 var t = rsS57[3];
 while ((pos = content.indexOf(rsS57[25], pos + 1)) > -1) {
 if (pos > ppos + 2) {
 if (content.substring(pos - 1, pos) == rsS57[24])
 t += rsS57[388] + content.substring(ppos, pos - 1) + rsS57[389];
 else
 t += rsS57[388] + content.substring(ppos, pos) + rsS57[389];
 } 
 else
 t += content.substring(ppos, pos) + rsS57[390]; 
 ppos = pos;
 }

 if (ppos < content.length - 1)
 t += rsS57[388] + content.substring(ppos, content.length) + rsS57[389];


 var flag = false;
 if (!this.multiline) { var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {
 opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) t = t.substring(0, pos) + rsS57[235] + t.substring(pos + 1);
 ppos = pos;
 }

 t = rsS57[340] + t + rsS57[341];
 

 } else {
 var pos = -1;
 var ppos = 0;
 var opener = -1;
 var closer = -1;
 var flag = true;
 while ((pos = t.indexOf(rsS57[39], pos + 1)) > -1) {
 if (pos + 1 < t.length && t.charAt(pos + 1) == rsS57[39]) {
 opener = t.lastIndexOf(rsS57[168], pos);
 closer = t.lastIndexOf(rsS57[169], pos);
 if ((opener == -1 && closer == -1) || opener == -1 || opener < closer) { 
 if (flag)
 t = t.substring(0, pos) + rsS57[235] + t.substring(pos + 1);
 else
 t = t.substring(0, pos) + rsS57[39] + t.substring(pos + 1);
 flag = !flag;
 }
 ppos = pos;
 }
 }
 }


 var tabexp = new RegExp(rsS57[391]);
 while (tabexp.test(t))
 t = t.replace(tabexp, rsS57[392]);



 this.iframe.innerHTML = t;
 } else
 this.iframe.innerHTML = content;

 } catch (excep) { rsw_logException(excep); }

 }

 function getContent() {
 try{
 return this.iframe.innerHTML;
 } catch (excep) { rsw_logException(excep); }
 }

 function getContentCleanHTML() {
 

 
 rsw_processedNodes = new Array();

 var nodes = this.iframe.childNodes;
 var out = rsS57[3];
 for (var i = 0; i < nodes.length; i++) {

 out += rsw_cleanHTML(nodes[i]);
 }
 return out;


 }

 function isNodeKnownToBeProcessed(node) {
 if (rsw_processedNodes == null || typeof (node.sourceIndex) == rsS57[12]) return false;

 for (var i = 0; i < rsw_processedNodes.length; i++) {
 if (node.sourceIndex == rsw_processedNodes[i]) return true;
 }
 return false;
 }

 var rsw_processedNodes = null;

 function rsw_cleanHTML(node) {
 try{
 var t = rsS57[3];
 var styleInAttr = false;
 var quote = '"';

 if (isNodeKnownToBeProcessed(node)) return t;
 if (rsw_processedNodes != null && typeof (node.sourceIndex) != rsS57[12])
 rsw_processedNodes.push(node.sourceIndex);

 if (node.nodeName.toLowerCase() != rsS57[393] && node.nodeName.toLowerCase() != rsS57[292]
 && !(node.nodeName.toLowerCase() == rsS57[306] && node.className == rsS57[284])
 ) {


 t += rsS57[168] + node.nodeName + rsS57[39]; 
 for (var att = 0; node.attributes!=null && att < node.attributes.length; att++) {
 if (node.attributes[att].nodeValue) {
 styleInAttr = styleInAttr || node.attributes[att].nodeName.toLowerCase() == rsS57[45];
 if (node.attributes[att].nodeValue!=null && typeof(node.attributes[att].nodeValue.indexOf)==rsS57[33] && node.attributes[att].nodeValue.indexOf(rsS57[175]) > -1) quote = '"';
 else quote = rsS57[175];
 t += node.attributes[att].nodeName + rsS57[394] + quote + node.attributes[att].nodeValue + quote + rsS57[39];
 }
 }
 if (typeof (node.style) != rsS57[12] && !styleInAttr) {
 t += "style=\"";
 t += node.style.cssText;
 t += "\" ";
 }



 if (node.childNodes.length == 0 && !node.nodeValue && node.nodeName!=rsS57[53] && node.nodeName!=rsS57[395])
 t += rsS57[368];
 t += rsS57[169];
 }


 if (node.childNodes.length == 0) {

 if (node.nodeValue) {

 t += node.nodeValue.replace(rsS57[168], rsS57[194]).replace(rsS57[169], rsS57[195]);
 }

 if (node.value) {

 t += node.value.replace(rsS57[168], rsS57[194]).replace(rsS57[169], rsS57[195]);
 }

 } else {
 for (var i = 0; i < node.childNodes.length; i++)
 t += rsw_cleanHTML(node.childNodes[i]);

 }

 if (node.nodeName.toLowerCase() != rsS57[393] && node.nodeName.toLowerCase() != rsS57[292]
 && !(node.nodeName.toLowerCase() == rsS57[306] && node.className == rsS57[284])
 && !(node.childNodes.length == 0 && !node.nodeValue && node.nodeName != rsS57[53] && node.nodeName != rsS57[395])
 )
 t += rsS57[170] + node.nodeName + rsS57[169];

 return t;
 } catch (excep) { rsw_logException(excep); return rsS57[3];}
 }



 
 function getContentText() {

 var contentElements = this.iframe.childNodes;
 var contents = rsS57[3];


 for (var i = 0; i < contentElements.length; i++) {
 var nV = null;
 try {
 nV = contentElements[i].nodeValue; } catch (er) { }
 if (nV) contents += nV.replace(/\n/g, rsS57[3]).replace(/\r/g, rsS57[3]); 
 else if (contentElements[i].nodeName.toLowerCase() == rsS57[289] && i < contentElements.length - 1) contents += rsS57[159];
 else if (contentElements[i].nodeName.toLowerCase() == rsS57[292])
 contents += contentElements[i].value;
 else contents += rsw_innerText(contentElements[i],
 i == contentElements.length - 1, contentElements[contentElements.length - 1].nodeName.toLowerCase() == rsS57[289]); }
 

 var t = contents;
 while (rsw_newlineexp.test(t))
 t = t.replace(rsw_newlineexp, rsS57[3]);
 contents = t;




 return contents;

 }


 
 function _onContextMenu() {

 rsw_broadcastToListeners(rsS57[343]);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[343], null, null);
 return false;
 }

 function _onPaste() {
 rsw_broadcastToListeners(rsS57[346]);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[346], null, null);
 }

 function getShadowText() {
 return this.shadowTB.value;
 }


 function updateShadow() {
 if (this.targetIsPlain)
 this.spellChecker.tbInterface.setText(this.getContentText());
 else
 this.spellChecker.tbInterface.setText(this.getContentCleanHTML());

 }

 function initialize() {

 this.iframe.onmousedown = this._onMouseDown;
 this.iframe.ondblclick = this._onDblClick;



 var ifID = this.iframe.id;
 this.shadowTBID = ifID.substring(0, ifID.length - 2); this.shadowTB = rs_s3.getElementById(this.shadowTBID);

 }

 function unhook() {
 this.iframe.onmousedown = null;
 this.iframe.ondblclick = null;
 }

 function OnCorrection(e) {
 if (this.getNumberOfErrors() == 0) {
 if (this.spellChecker.enterEditModeWhenNoErrors) {
 this.spellChecker.OnSpellButtonClicked(true);
 }
 }
 rsw_broadcastToListeners(rsS57[287]);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[321], null, e);
 }

 function getNumberOfErrors() {
 try{
 var errors = this.getSpanElements();
 var numErrors = 0;
 for (var i = 0; i < errors.length; i++) {
 if (errors[i].className == rsS57[284]) {
 numErrors++;
 }
 }
 return numErrors;
 } catch (excep) { rsw_logException(excep); }
 }

}




function rsw_getElementHeight(Elem, isoverlay) {
 var op5 = (navigator.userAgent.indexOf(rsS57[396]) != -1)
 || (navigator.userAgent.indexOf(rsS57[397]) != -1);


 if (rs_s3.layers) {
 var elem = rsw_getObjNN4(document, Elem);
 return elem.clip.height;
 } else {
 if (rs_s3.getElementById) {
 var elem = rs_s3.getElementById(Elem);
 } else if (rs_s3.all) {
 var elem = rs_s3.all[Elem];
 }
 if (op5) {
 xPos = elem.style.pixelHeight;
 } else {
 
 xPos = elem.offsetHeight;

 }

 if (!isoverlay && elem.style != null && elem.style.height != null && elem.style.height.indexOf(rsS57[57]) > -1)
 return elem.style.height; 
 return xPos;
 }
}
function rsw_getObjNN4(obj, name) {
 var x = obj.layers;
 var foundLayer;
 for (var i = 0; i < x.length; i++) {
 if (x[i].id == name)
 foundLayer = x[i];
 else if (x[i].layers.length)
 var tmp = rsw_getObjNN4(x[i], name);
 if (tmp) foundLayer = tmp;
 }
 return foundLayer;
}

function rsw_getElementWidth(Elem, isoverlay) {
 var op5 = (navigator.userAgent.indexOf(rsS57[396]) != -1)
 || (navigator.userAgent.indexOf(rsS57[397]) != -1);

 if (rs_s3.layers) {
 var elem = rsw_getObjNN4(document, Elem);
 return elem.clip.width;
 } else {
 if (rs_s3.getElementById) {
 var elem = rs_s3.getElementById(Elem);
 } else if (rs_s3.all) {
 var elem = rs_s3.all[Elem];
 }
 if (op5) {
 xPos = elem.style.pixelWidth;
 } else {
 
 xPos = elem.offsetWidth;

 }

 var compWidth = rsw_getStyleProperty(elem, rsS57[88]);
 if (((compWidth == null || compWidth == rsS57[3]) && elem.style != null) || (!rsw_msie && elem.style != null))
 compWidth = elem.style.width;

 if (!isoverlay && compWidth != null && compWidth.indexOf(rsS57[57]) > -1)
 return compWidth;
 return xPos;
 }
}

function rsw_findPosX(obj) {
 var curleft = 0;
 var isFirefox = navigator.userAgent.toLowerCase().indexOf(rsS57[230]) > -1;
 
 if (typeof (obj.offsetParent) != rsS57[12] && obj.offsetParent) {
 while (obj.offsetParent) {
 var tBW = rsw_getStyleProperty(obj, rsS57[69]);
 curleft += obj.offsetLeft + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0); ;
 if (obj.parentNode.scrollLeft)
 curleft -= obj.parentNode.scrollLeft;
 obj = obj.offsetParent;
 }
 var tBW = rsw_getStyleProperty(obj, rsS57[69]);
 curleft += obj.offsetLeft + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0); ;
 }
 else if (obj.x)
 curleft += obj.x;




 return curleft;

 
}

function rsw_findPosY(obj) {
 var curtop = 0;
 var isFirefox = navigator.userAgent.toLowerCase().indexOf(rsS57[230]) > -1;
 
 if (typeof (obj.offsetParent) != rsS57[12] && obj.offsetParent) {
 while (obj.offsetParent) {
 var tBW = rsw_getStyleProperty(obj, rsS57[73]);

 curtop += obj.offsetTop + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0);
 if (obj.parentNode.scrollTop)
 curtop -= obj.parentNode.scrollTop;
 obj = obj.offsetParent;

 }
 var tBW = rsw_getStyleProperty(obj, rsS57[73]);
 curtop += obj.offsetTop + (isFirefox ? parseInt(tBW.substring(0, tBW.length - 2)) : 0);
 }
 else if (obj.y)
 curtop += obj.y;


 return curtop;

 
 
}








function rsw_decodeSuggestionItem(item) {
 return unescape(item).replace(rsS57[398], rsS57[175]).replace(rsS57[399], "\"");
}


function RS_ContextMenu(errorElement, suggestions, textBox) {
 this.suggestions = suggestions;
 this.CMItems = new Array();
 this.x = 0;
 this.y = 0;
 this.CMelement = null;
 this.textBox = textBox;
 this.show = show;
 this.setCMContent = setCMContent;
 this.hide = hide;
 this.setVisible = setVisible;
 this.isVisible = false;
 this.moveCMElement = moveCMElement;
 this.getContentHtml = getContentHtml;
 this.addItems = addItems;
 this.addItems();

 function addItems() {
 var newSuggs = new Array();
 var errorText = errorElement.textContent ? errorElement.textContent : errorElement.innerText;
 var errorLength = errorText.length;
 for (var i = 0; i < this.suggestions.length; i++) {
 if (this.suggestions[i].indexOf(rsS57[400]) == 0 || this.textBox.maxlength == 0 || typeof(this.textBox.maxlength)==rsS57[12] || rsw_decodeSuggestionItem(this.suggestions[i]).length - errorLength + this.textBox.getContentText().length <= this.textBox.maxlength)
 newSuggs[newSuggs.length] = this.suggestions[i];
 }
 this.suggestions = newSuggs;

 var isCapitalCorrection = false;
 if (this.suggestions.length == 1) {
 isCapitalCorrection = this.suggestions[0].toLowerCase() == errorText && this.suggestions[0].charAt(0).toUpperCase() == this.suggestions[0].charAt(0);
 }

 var isDuplicateWordErr = false;
 for (i = 0; i < this.suggestions.length; i++) {
 if (this.suggestions[i].indexOf(rsS57[400]) < 0) {
 this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement,
 rsw_decodeSuggestionItem(this.suggestions[i]),
 escape(this.suggestions[i]),
 rsS57[333]
 );
 if (this.textBox.spellChecker.showChangeAllItem) {
 this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement,
 unescape(this.textBox.spellChecker.changeAllText),
 escape(this.suggestions[i]),
 rsS57[401], rsS57[402]
 );
 }
 } else {
 this.CMItems[this.CMItems.length] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.removeDuplicateText,
 escape(this.suggestions[i].substring(1)),
 rsS57[403]
 );
 isDuplicateWordErr = true;
 }

 }

 if (this.suggestions.length == 0) {
 this.CMItems[0] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.noSuggestionsText,
 rsS57[196],
 rsS57[404]
 );

 i = 1;
 } else {
 i = this.CMItems.length;
 }


 if (!isDuplicateWordErr || this.textBox.isStatic) {
 this.CMItems[i] = new RS_ContextMenuItem(errorElement,
 rsS57[405],
 rsS57[405],
 rsS57[405]
 );
 }


 if (this.textBox.isStatic) {
 if (this.textBox.spellChecker.showEditMenuItem) {
 this.CMItems[i + 1] = new RS_ContextMenuItem(errorElement, this.textBox.spellChecker.editText,
 rsS57[200],
 rsS57[406]
 );

 i++;
 }
 }

 if (!isDuplicateWordErr) {
 if (this.textBox.spellChecker.showIgnoreAllMenuItem) {
 this.CMItems[i + 1] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.ignoreAllText,
 rsS57[197],
 rsS57[407]
 );
 } else i--;
 var thisUD = null;
 var overrideUD = false;
 if(typeof (rsw_getParameterValue) == rsS57[33]){
 thisUD = rsw_getParameterValue(this.textBox.shadowTB, rsS57[261]);
 overrideUD = thisUD == null || thisUD == rsS57[3];
 }
 var ShowAddItemAlways = false;
 if (typeof (rsw_getParameterValue) == rsS57[33]) 
 ShowAddItemAlways = rsw_getParameterValue(this.textBox.shadowTB, rsS57[408]);
 
 if (((this.textBox.spellChecker.showAddMenuItem && !overrideUD) || ShowAddItemAlways) && !isCapitalCorrection) {
 this.CMItems[i + 2] = new RS_ContextMenuItem(errorElement,
 this.textBox.spellChecker.addText,
 rsS57[199],
 rsS57[409]
 );
 }
 }

 
 if (rs_s3.getElementById(rsS57[410]) == null)
 rsw_create_menu_div();

 this.CMelement = rs_s3.getElementById(rsS57[410]);
 this.CMIFelement = rs_s3.getElementById(rsS57[411]);
 


 this.setVisible(false);
 }

 this.onkeydown = function (e) {
 if (rsw_contextMenu.isVisible) {
 if (typeof(event)!=rsS57[12] && event !=null) e = event;
 var menuItems = rsw_contextMenu.getMenuItems();
 var i = rsw_contextMenu.getCurrentHighlightedItemIndex(menuItems);
 if (i >= 0)
 RS_CMItemHighlight(menuItems[i], rsS57[412]);

 if (e.keyCode == 40) {
 if (i + 1 == menuItems.length) i = -1;
 while (menuItems[++i].className == RS_ContextMenuItem_Disabled_Class) {
 if (i == menuItems.length) i = 0;
 }

 

 RS_CMItemHighlight(menuItems[i], rsS57[3]);
 } else if (e.keyCode == 38) {
 if (i <= 0) i = menuItems.length;
 while (menuItems[--i].className == RS_ContextMenuItem_Disabled_Class) {
 if (i == -1) i = menuItems.length - 1;
 }
 
 RS_CMItemHighlight(menuItems[i], rsS57[3]);
 }
 if (e.keyCode == 13 && i > -1 && i < menuItems.length) {
 menuItems[i].click();
 }
 }
 };

 this.getMenuItems = function () {
 return this.CMelement.getElementsByTagName(rsS57[306]);
 };

 this.getCurrentHighlightedItemIndex = function (menuItems) {
 for (var i = 0; i < menuItems.length; i++) {
 if (menuItems[i].className == RS_ContextMenuItem_Class + rsS57[413])
 return i;
 }
 return -1;

 };


 function show() {
 if (typeof(this.textBox.enabled)!=rsS57[12] && !this.textBox.enabled) return;
 
 this.setVisible(true);
 this.moveCMElement();
 this.setCMContent(this.getContentHtml());
 if (typeof (rsw_useIFrameMenuBacker) == rsS57[12] || rsw_useIFrameMenuBacker) {
 if (navigator.userAgent.toLowerCase().indexOf(rsS57[414]) > -1 && !rsw_isMac) { this.CMIFelement.style.left = this.x + rsS57[58];
 this.CMIFelement.style.top = this.y + rsS57[58];
 this.CMIFelement.style.height = (rsw_getElementHeight(rsS57[410]) - 4) + rsS57[58]; this.CMIFelement.style.width = (rsw_getElementWidth(rsS57[410]) - 4) + rsS57[58];
 }
 }

 }

 function hide() {
 try{
 this.setVisible(false);

 this.CMelement.innerHTML = rsS57[3];
 } catch (excep) { rsw_logException(excep); }
 }

 function setCMContent(s) {
 try{
 this.CMelement.innerHTML = s;
 } catch (excep) { rsw_logException(excep); }

 }




 function setVisible(visible) {
 this.CMelement.style.visibility = visible ? rsS57[114] : rsS57[30];

 
 if (typeof (rsw_useIFrameMenuBacker) == rsS57[12] || rsw_useIFrameMenuBacker) {
 if (navigator.userAgent.toLowerCase().indexOf(rsS57[414]) > -1 && !rsw_isMac) {
 this.CMIFelement.style.visibility = visible ? rsS57[114] : rsS57[30];
 this.CMIFelement.style.display = visible ? rsS57[227] : rsS57[48];
 }
 }
 this.isVisible = visible;
 }

 function moveCMElement() {

 this.CMelement.style.left = this.x + rsS57[58];
 this.CMelement.style.top = this.y + rsS57[58];
 if (typeof (rsw_useIFrameMenuBacker) == rsS57[12] || rsw_useIFrameMenuBacker) {
 
 if (navigator.userAgent.toLowerCase().indexOf(rsS57[414]) > -1 && !rsw_isMac) {
 this.CMIFelement.style.left = this.x + rsS57[58];
 this.CMIFelement.style.top = this.y + rsS57[58];
 }
 }
 }

 function getContentHtml() {
 var s = "<table class=\"" + RS_ContextMenuTable_Class + "\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
 var hasSubMenu = false;
 for (var i = 0; i < this.CMItems.length; i++) {
 hasSubMenu = i < this.CMItems.length - 1 && this.CMItems[i + 1].type == rsS57[402];
 s += rsS57[415] + (hasSubMenu ? rsS57[416] : rsS57[417]) + rsS57[169];
 s += this.CMItems[i].getContentHtml();
 s += rsS57[418];

 if (hasSubMenu) {
 i++;
 s += rsS57[419] +
 this.CMItems[i].getContentHtml()
 + rsS57[418];
 }
 s += rsS57[420];
 }
 s += rsS57[421];
 return s;
 }
}




function RS_ContextMenuItem(e, unescapedValue, escapedValue, action, type) {
 this.unescapedValue = unescapedValue;
 this.escapedValue = escapedValue;
 this.action = action;
 this.getContentHtml = getContentHtml;
 this.type = type ? type : rsS57[422];

 function getContentHtml() {


 var s;
 if (this.unescapedValue != rsS57[405] && this.action != rsS57[404]) {
 s = "<span class=\"" +
 (this.type == rsS57[422] ?
 RS_ContextMenuItem_Class :
 RS_ContextMenuItem_AllSubItem_Class
 )
 + "\" "
 + " onclick=\"RS_CMItemClicked( '" + this.escapedValue + rsS57[423] + this.action + "') ;\""
 + " onMouseOut=\" RS_CMItemHighlight(this, 'out');\" "
 + " onMouseOver=\"RS_CMItemHighlight(this, 'over'); \" "
 + rsS57[169] + this.unescapedValue + rsS57[301];




 } else if (this.action == rsS57[404]) {
 s = "<span class=\"" + RS_ContextMenuItem_Disabled_Class + "\" "
 + rsS57[169] + this.unescapedValue + rsS57[301];

 } else {
 s = "<hr class=\"" + RS_CMItemSeparator_Class + "\"/>";
 }
 return s;
 }

 
}





function RS_CMItemHighlight(e, type) {
 try{
 var p = e.className.indexOf(rsS57[413]);
 if (type == rsS57[412]) {
 if (p > 0) e.className = e.className.substring(0, p);
 } else {
 if (p == -1) e.className = e.className + rsS57[413];
 }
 } catch (excep) { rsw_logException(excep); }
}



function RS_CMItemClicked(replacement, action) {
 
 try{
 rsw_refreshActiveTextbox();
 var yScroll = null;
 if (typeof(rsw_activeTextbox.iframe.contentWindow) != rsS57[12])
 yScroll = rsw_getScrollY(rsw_activeTextbox.iframe.contentWindow);

 replacement = unescape(replacement).replace(rsS57[398], rsS57[175]).replace(rsS57[399], "\"");
 if (action == rsS57[407]) {
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[424], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_ignoreAll(rsw_lastRightClickedError);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[425], rsw_activeTextbox, rsw_lastRightClickedError);
 } else if (action == rsS57[406]) {
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[426], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_edit(rsw_lastRightClickedError);

 } else if (action == rsS57[409]) {
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[427], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_add(rsw_lastRightClickedError);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[428], rsw_activeTextbox, rsw_lastRightClickedError);
 } else if (action == rsS57[403]) {
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[429], rsw_activeTextbox, rsw_lastRightClickedError);
 rsw_changeTo(rsw_lastRightClickedError, rsS57[3]);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[430], rsw_activeTextbox, rsw_lastRightClickedError);
 } else if (action == rsS57[401]) {
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[431], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 rsw_changeAllTo(rsw_lastRightClickedError, replacement);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[432], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 } else {
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[433], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 rsw_changeTo(rsw_lastRightClickedError, replacement);
 if (typeof (rsw_broadcastEvent) == rsS57[33]) rsw_broadcastEvent(rsS57[434], rsw_activeTextbox, rsw_lastRightClickedError, replacement);
 }

 rsw_hideCM();
 if (rsw_activeTextbox.focus && !rsw_activeTextbox.isFocused) {
 



 rsw_activeTextbox.focus();

 if (rsw_activeTextbox.resetCaretPos)
 rsw_activeTextbox.resetCaretPos();

 if(yScroll!=null)
 rsw_setScrollY(rsw_activeTextbox.iframe.contentWindow, yScroll);


 }
 } catch (excep) { rsw_logException(excep); }


}

function rsw_hideCM() {


 if (rsw_contextMenu) {

 rsw_contextMenu.hide();

 }
}


function rsw_create_menu_div() {

 
 var divElement = rs_s3.createElement(rsS57[42]);
 divElement.id = rsS57[410];
 divElement.setAttribute(rsS57[435], rsS57[436]);
 try {
 divElement.oncontextmenu = function () { try { event.cancelBubble = true; event.preventDefault(); } catch (e) { } return false; };
 } catch (e) { }
 
 rs_s3.getElementsByTagName(rsS57[437])[0].appendChild(divElement);


 if (navigator.userAgent.toLowerCase().indexOf(rsS57[414]) > -1) {
 var ifElement = rs_s3.createElement(rsS57[53]);
 ifElement.id = rsS57[411];
 ifElement.setAttribute(rsS57[438], rsS57[439]);
 ifElement.setAttribute(rsS57[440], rsS57[441]);
 ifElement.setAttribute(rsS57[442], rsS57[443]);
 ifElement.setAttribute(rsS57[45], rsS57[444]);
 rs_s3.getElementsByTagName(rsS57[437])[0].appendChild(ifElement);
 }
 }


var rsw_ayt_initializing = false;
function RapidSpell_Web_AsYouType() {


 this.triggeredLast = false;
 this.checkerCurrentlyInitializing = 0;
 this.onTextBoxesInit = onTextBoxesInit;
 this.checkNext = checkNext;
 this.onFinish = onFinish;
 this.onPause = onPause;
 this.checkAsYouTypeOnPageLoad = true;
 this.stop = stop;
 this.start = start;
 this.stopped = false;

 function start() {
 this.stopped = false;
 }
 function stop() {
 this.stopped = true;
 }

 function onPause() {
 rsw_refreshActiveTextbox();
 if (!this.stopped && typeof (rsw_activeTextbox) != rsS57[12] && rsw_activeTextbox != null && rsw_activeTextbox.spellChecker != null) {
 rsw_activeTextbox.updateShadow();
 rsw_activeTextbox.spellChecker.OnSpellButtonClicked();
 }
 }


 function onTextBoxesInit() {
 
 rsw_consoleLog(rsS57[445] + rsw_ayt_initializing);

 if (!rsw_ayt_initializing) {
 rsw_ayt_initializing = true;
 rsw_ayt_check = true;
 if (!this.checkNext())
 rsw_ayt_initializing = false;
 }
 }

 function checkNext() {
 if (rsw_haltProcesses || !rsw_ayt_enabled || this.stopped) {
 rsw_consoleLog(rsS57[446] + rsw_haltProcesses + rsS57[447] + rsw_ayt_enabled + rsS57[448] + this.stopped);
 rsw_ayt_initializing = false; this.checkerCurrentlyInitializing++; this.onFinish();
 }
 if (rsw_scs.length > this.checkerCurrentlyInitializing) {
 var tbs = rsw_scs[this.checkerCurrentlyInitializing].getTBS();
 if (tbs != null && (tbs.isStatic || !tbs.isVisible() || tbs.skipAYTUpdates)) { this.checkerCurrentlyInitializing++;
 this.onFinish();
 } else if (tbs!=null){
 if (this.checkAsYouTypeOnPageLoad)
 rsw_scs[this.checkerCurrentlyInitializing].OnSpellButtonClicked();

 this.checkerCurrentlyInitializing++;

 if (!this.checkAsYouTypeOnPageLoad)
 this.onFinish();

 tbs.isAYT = true;
 }
 }
 return this.checkerCurrentlyInitializing < rsw_scs.length;
 }

 function onFinish() {

 rsw_consoleLog(rsS57[449] + this.triggeredLast);
 if (rsw_ayt_initializing && this.triggeredLast) { rsw_consoleLog(rsS57[450]);
 rsw_ayt_initializing = false;
 
 

 if (typeof (_notifySpellCheckListeners) != rsS57[12])
 _notifySpellCheckListeners(rsS57[451]);
 }

 if (rsw_ayt_initializing) {
 this.triggeredLast = !this.checkNext();
 if (this.triggeredLast) rsw_ayt_initializing = false;
 }

 }
}


String.prototype.rsw_reverse = function () { return this.split(rsS57[3]).reverse().join(rsS57[3]); };

function RSW_Diff(p, v, a) {
 this.position = p;
 this.vector = v;
 this.addedText = a;
}



function RSW_VisibleCharSeq(str) {
 this.str = str;
 this.length = str.length;
 this.allVisible = false;
 this.reverse = reverse;
 this.isReversed = false;
 function reverse() {
 this.str = this.str.rsw_reverse();
 this.isReversed = !this.isReversed;
 }

 this.insertAtVisible = insertAtVisible;
 function insertAtVisible(addition, pos) {
 return this.visibleSubstring(0, pos) + addition + this.visibleSubstring(pos, this.visibleLength());
 }

 this.toString = toString;
 function toString() {
 return this.str;
 }

 this.visibleSubstring = visibleSubstring;
 function visibleSubstring(start, end) {

 var visiChars = 0;
 var inTag = false;
 var inEnt = false;
 var sub = rsS57[3];
 var includeTags = true;
 var tagOpen = this.isReversed ? rsS57[169] : rsS57[168];
 var tagClose = this.isReversed ? rsS57[168] : rsS57[169];
 var entOpen = this.isReversed ? rsS57[452] : rsS57[294];
 var entClose = this.isReversed ? rsS57[294] : rsS57[452];

 for (var i = 0; i < this.str.length; i++) {

 

 if (this.str.charAt(i) == tagOpen && !inTag && !this.allVisible) inTag = true;
 if (this.str.charAt(i) == entOpen && !inTag && !inEnt && !this.allVisible) {
 var closer = this.str.indexOf(entClose, i);
 if (closer > -1 && closer - i < 9) {
 inEnt = true;
 if (visiChars >= start && visiChars < end) {
 var entity = this.str.substring(i, closer);
 if (entity == rsS57[453]) sub += rsS57[294];
 if (entity == rsS57[454]) sub += rsS57[39];
 if (entity == rsS57[455]) sub += rsS57[168];
 if (entity == rsS57[456]) sub += rsS57[169];
 }
 visiChars++;
 }
 }

 if (includeTags && inTag && visiChars >= start && visiChars <= end) sub += this.str.charAt(i);

 if (!inTag && !inEnt) {
 if ( 
 visiChars >= start && visiChars < end) sub += this.str.charAt(i);
 visiChars++;
 }

 if (this.str.charAt(i) == tagClose && inTag) inTag = false;
 if (this.str.charAt(i) == entClose && inEnt) inEnt = false;
 }
 return sub;
 }

 this.lastDiffI = 0;
 this.lastDiffPos = 0;

 this.visibleCharAt = visibleCharAt;
 function visibleCharAt(pos) {
 var startI = 0;
 var visiChars = 0;
 var tagOpen = this.isReversed ? rsS57[169] : rsS57[168];
 var tagClose = this.isReversed ? rsS57[168] : rsS57[169];
 var entOpen = this.isReversed ? rsS57[452] : rsS57[294];
 var entClose = this.isReversed ? rsS57[294] : rsS57[452];
 var entityChar;
 if (pos > this.lastDiffPos) {
 startI = this.lastDiffI;
 visiChars = this.lastDiffPos;
 }



 var inTag = false;
 var inEnt = false;
 for (var i = startI; i < this.str.length; i++) {
 if (this.str.charAt(i) == tagOpen && !inTag && !this.allVisible) inTag = true;
 if (this.str.charAt(i) == entOpen && !inTag && !inEnt && !this.allVisible) {
 var closer = this.str.indexOf(entClose, i);
 if (closer > -1 && closer - i < 9) {
 inEnt = true;

 var entity = this.str.substring(i, closer);
 if (entity == rsS57[453]) entityChar = rsS57[294];
 if (entity == rsS57[454]) entityChar = rsS57[39];
 if (entity == rsS57[455]) entityChar = rsS57[168];
 if (entity == rsS57[456]) entityChar = rsS57[169];

 if (visiChars == pos) return entityChar;
 visiChars++;
 }
 }


 if (!inTag && !inEnt) {
 if (visiChars == pos) {
 this.lastDiffI = i;
 this.lastDiffPos = visiChars;

 if (this.str.charAt(i) == String.fromCharCode(160)) return rsS57[39];

 if (this.str.charAt(i) == rsS57[24]) return rsS57[25];




 return this.str.charAt(i);
 }

 visiChars++;
 }



 if (this.str.charAt(i) == tagClose && inTag) inTag = false;
 if (this.str.charAt(i) == entClose && inEnt) inEnt = false;
 }
 }

 this.visibleLength = visibleLength;
 function visibleLength() {
 
 var visiChars = 0;
 var inTag = false;
 var inEnt = false;

 for (var i = 0; i < this.str.length; i++) {
 if (this.str.charAt(i) == rsS57[168] && !inTag && !this.allVisible) inTag = true;
 if (this.str.charAt(i) == rsS57[294] && !inTag && !inEnt && !this.allVisible) {
 var closer = this.str.indexOf(rsS57[452], i);
 if (closer > -1 && closer - i < 9) {
 inEnt = true;
 visiChars++; }
 }

 if (!inTag && !inEnt) {
 visiChars++;
 }

 if (this.str.charAt(i) == rsS57[169] && inTag) inTag = false;
 if (this.str.charAt(i) == rsS57[452] && inEnt) inEnt = false;
 }
 return visiChars;
 }


}

function RSW_diff(beforeS, afterS) {
 var cs = -1;
 var ce = -1;
 var scanLength = 0;
 var before = new RSW_VisibleCharSeq(beforeS);

 var after = new RSW_VisibleCharSeq(afterS);
 after.allVisible = true;

 var beforeVisiLen = before.visibleLength();
 var afterVisiLen = after.visibleLength();

 for (var i = 0; i < beforeVisiLen && cs < 0; i++)
 if (!(i >= afterVisiLen || after.visibleCharAt(i) == before.visibleCharAt(i))) cs = i;
 

 if (cs == -1 && afterVisiLen != beforeVisiLen) cs = beforeVisiLen;

 
 after.reverse();
 before.reverse();

 
 for (var i = 0; i < afterVisiLen && ce < 0; i++)
 if (i >= (beforeVisiLen - cs) || !(i >= beforeVisiLen || after.visibleCharAt(i) == before.visibleCharAt(i))) ce = (afterVisiLen - i);

 if (ce == -1) ce = afterVisiLen;

 var vector = ce - cs;

 if (vector == 0) vector = afterVisiLen - beforeVisiLen;


 after.reverse(); 
 return new RSW_Diff(cs, vector, after.visibleSubstring(cs, ce));
}




function RSW_EditableElementFinder() {
 this.findPlainTargetElement = findPlainTargetElement;
 this.findRichTargetElements = findRichTargetElements;
 this.obtainElementWithInnerHTML = obtainElementWithInnerHTML;
 this.findEditableElements = findEditableElements;
 this.elementIsEditable = elementIsEditable;
 this.getEditableContentDocument = getEditableContentDocument;

 function findPlainTargetElement(elementID) {
 var rsw_elected = rs_s3.getElementById(elementID);

 if (rsw_elected != null && rsw_elected.tagName &&
 (rsw_elected.tagName.toUpperCase() == rsS57[457] || rsw_elected.tagName.toUpperCase() == rsS57[458])) {
 return rsw_elected;
 } else
 return null;
 }

 function findRichTargetElements(debugTextBox) {
 var editables = new Array();
 this.findEditableElements(document, editables, window, rsS57[3], debugTextBox);
 return editables;
 }

 function obtainElementWithInnerHTML(editable) {
 try{
 if (typeof (editable.innerHTML) != rsS57[12]) return editable;
 else
 if (typeof (editable.documentElement) != rsS57[12])
 return editable.documentElement;

 return null;
 } catch (excep) { rsw_logException(excep); }
 }


 function findEditableElements(node, editables, parent, debugInset, debugTextBox) {
 var children = node.childNodes;
 var editableElement;

 
 if ((editableElement = this.elementIsEditable(node)) != null ||
 (editableElement = this.getEditableContentDocument(node, debugTextBox)) != null
 ) {
 editables[editables.length] = editableElement;
 }

 
 for (var i = 0; i < children.length; i++) {
 this.findEditableElements(children[i], editables, node, debugInset + rsS57[39], debugTextBox);
 }

 }

 function elementIsEditable(element) {
 if (
 (
 typeof (element.getAttribute) != rsS57[12] &&
 (
 element.getAttribute(rsS57[332]) == rsS57[211] ||
 element.getAttribute(rsS57[459]) == rsS57[370]
 )
 )
 ||
 (
 (element.contentEditable && element.contentEditable == true) ||
 (element.designMode && element.designMode.toLowerCase() == rsS57[370])
 )
 

 )
 return [element, element]; else return null;
 }

 function getEditableContentDocument(element, debugTextBox) {
 if (element.tagName && element.tagName == rsS57[53]) {
 var kids = new Array();
 try{
 if (element.contentWindow && element.contentWindow.document) {

 
 this.findEditableElements(element.contentWindow.document, kids, element, rsS57[460], debugTextBox);


 if (kids.length > 0) { var editable = kids[0][0];
 if (typeof (editable.body) != rsS57[12])
 editable = editable.body;
 return [editable, element]; }
 }
 } catch (ex) {
 }
 }
 return null;
 }
}





var rsw_require_init = true;
function rsw_ASPNETAJAX_OnInitializeRequest(sender, eventArgs) {
 rsw_consoleLog(rsS57[461]);
 rsw_cancelCall = true;
 rsw_haltProcesses = true;
 rsw_require_init = true;

 for (var i = 0; i < rsw_scs.length; i++) {
 if (rsw_scs[i] != null) {
 if (rsw_scs[i].state == rsS57[228] || (rsw_scs[i].state == rsS57[210] && typeof (rapidSpell) == rsS57[177])) {
 if (rsw_scs[i].rsw_tbs != null) {
 rsw_scs[i].rsw_tbs.updateShadow();
 rsw_scs[i].rsw_tbs.iframe.style.display = rsS57[48];

 if (rsw_scs[i].rsw_tbs.iframe.parentNode != null)
 rsw_scs[i].rsw_tbs.iframe.parentNode.removeChild(rsw_scs[i].rsw_tbs.iframe); 
 if (rsw_supportAutoSize) {
 rsw_scs[i].rsw_tbs.shadowTB.style.position = rsw_scs[i].rsw_tbs.shadowTBPosition;
 rsw_scs[i].rsw_tbs.shadowTB.style.left = rsw_scs[i].rsw_tbs.shadowTBLeft;
 if (typeof (rsw_scs[i].rsw_tbs.shadowTBTabIndex) != rsS57[12] && rsw_scs[i].rsw_tbs.shadowTBTabIndex != null)
 rsw_scs[i].rsw_tbs.shadowTB.setAttribute(rsS57[31], rsw_scs[i].rsw_tbs.shadowTBTabIndex);
 }
 if (typeof rsw_scs[i].rsw_tbs.shadowTBDisplay === rsS57[12]) {
 rsw_scs[i].rsw_tbs.shadowTBDisplay = rsS57[231];
 }
 rsw_scs[i].rsw_tbs.shadowTB.style.display = rsw_scs[i].rsw_tbs.shadowTBDisplay;
 }
 }
 rsw_scs[i].rsw_tbs = null;

 }
 
 }
 rsw_tbs = new Array();
 rsw_scs = new Array(); 
 rsw_config = new Array(); rsw_ObjsToInit = new Array();
}

function rsw_ASPNETAJAX_OnEndRequest(sender, eventArgs) {
 rsw_consoleLog(rsS57[462]);
 rsw_haltProcesses = false;
 try {
 rsw_createLink(document, rsw_rs_menu_styleURL);
 rsw_createLink(document, rsw_rs_styleURL);
 } catch (ex) { }

 if (typeof (attachInitHandler) != rsS57[12])
 attachInitHandler();

 if (rsw_require_init) {
 if (typeof (rsw_autoCallRSWInit) == rsS57[12] || rsw_autoCallRSWInit)
 setTimeout(rsS57[463], 200);
 }

 rsw_require_init = false;


}






if (typeof (Sys) != rsS57[12] && typeof (Sys.Application) != rsS57[12]) Sys.Application.notifyScriptLoaded();










//-]]>


















































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































































/* ]]> */
